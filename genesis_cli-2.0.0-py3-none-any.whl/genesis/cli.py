#!/usr/bin/env python3
"""Genesis CLI - Main command-line interface for Genesis toolkit."""

import importlib
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import click

# Import version from package
from genesis import __version__
from genesis.commands.branch import branch
from genesis.commands.checkout import checkout
from genesis.commands.container import container
from genesis.commands.dev import (
    format,
    lint,
    precommit,
    quality,
    setup,
    test,
    typecheck,
)
from genesis.commands.environment import environment
from genesis.commands.init import init_command
from genesis.commands.migrate import migrate_command
from genesis.commands.migrate_sync import migrate_sync_command
from genesis.commands.pull import pull
from genesis.commands.reset import reset
from genesis.commands.sync import sync
from genesis.commands.update_templates import update_templates
from genesis.commands.version import version
from genesis.commands.worktree import worktree

# Import from genesis.core for consolidated package
from genesis.core import get_logger
from genesis.core.constants import EnvironmentDefaults
from genesis.core.errors import handle_error as core_handle_error


# Custom Click Group for categorized help
class CategoryGroup(click.Group):
    """Custom Click Group that displays commands grouped by category."""

    def format_commands(
        self, ctx: click.Context, formatter: click.HelpFormatter
    ) -> None:
        """Format commands into categories."""
        # Collect commands by category
        categories: dict[str, list[tuple[str, str]]] = {
            "Core Development": [],
            "Project Management": [],
            "Version Control": [],
            "Advanced": [],
        }

        # Single-letter aliases to hide from main help (but still work)
        aliases = {"a", "b", "c", "f", "l", "q", "s", "t", "tc", "x", "y", "st"}

        # Map commands to categories
        for name in self.list_commands(ctx):
            # Skip single-letter aliases from main help
            if name in aliases:
                continue

            cmd = self.get_command(ctx, name)
            if cmd is None:
                continue

            category = getattr(cmd, "category", "Advanced")
            help_text = cmd.get_short_help_str(limit=80)
            categories[category].append((name, help_text))

        # Display each category
        for category, commands in categories.items():
            if not commands:
                continue

            with formatter.section(category):
                formatter.write_dl(sorted(commands))

        # Add note about aliases
        with formatter.section("Quick Aliases"):
            formatter.write_text(
                "Single-letter shortcuts: a (autofix), b (bootstrap), c (commit), "
                "f (format), l (lint), q (quality), s (setup), t (test), tc (typecheck), "
                "x (clean), y (sync), st (status)"
            )


def category(cat: str) -> Any:
    """Decorator to add category metadata to commands."""

    def decorator(f: Any) -> Any:
        if not hasattr(f, "callback"):
            # Direct function decoration
            f.category = cat
        else:
            # Click command decoration
            f.callback.category = cat
            f.category = cat
        return f

    return decorator


# Ensure dependencies and environment bootstrap
def _bootstrap_environment() -> None:
    """Bootstrap environment for environment-free initialization."""
    # Auto-install dependencies if needed (for container/production installs)
    try:
        from genesis.install import ensure_dependencies

        ensure_dependencies()
    except ImportError:
        # If genesis.install not available, try basic shared_core check
        try:
            # Import to check if shared_core is available - don't use the import
            __import__("shared_core")
        except ImportError:
            print("❌ Genesis shared-core dependency missing. Install with:")
            print(
                "pip install https://github.com/jhousteau/genesis/releases/latest/download/genesis_shared_core-0.1.0-py3-none-any.whl"
            )
            sys.exit(1)


# Bootstrap environment
_bootstrap_environment()

# Default to human-readable logs for CLI usage
if not os.getenv("GENESIS_LOG_FORMAT"):
    os.environ["GENESIS_LOG_FORMAT"] = "human"

# Configuration constants
CLEANUP_TIMEOUT = int(
    os.environ.get(
        "GENESIS_CLEANUP_TIMEOUT", EnvironmentDefaults.DEFAULT_CLEANUP_TIMEOUT
    )
)


def handle_error(e: Exception) -> Any:
    """Handle errors using shared_core error context."""
    return core_handle_error(e)


# Initialize logger
logger = get_logger(__name__)


# Genesis root detection
def get_git_root() -> Path | None:
    """Find Git repository root."""
    current = Path.cwd()
    for parent in [current] + list(current.parents):
        if (parent / ".git").exists():
            return parent
    return None


def get_component_path(component_name: str) -> Path | None:
    """Find Genesis component path."""
    # Try relative to CLI file first (for development)
    cli_path = Path(__file__)
    component_path = cli_path.parent.parent / component_name
    get_logger(__name__).debug(
        f"🔍 Looking for {component_name}: {component_path} (exists: {component_path.exists()})"
    )
    if component_path.exists():
        return component_path

    # Try current directory (if we're in Genesis project)
    current_path = Path.cwd() / component_name
    get_logger(__name__).debug(
        f"🔍 Trying current dir: {current_path} (exists: {current_path.exists()})"
    )
    if current_path.exists():
        return current_path

    get_logger(__name__).debug(f"❌ Component {component_name} not found")
    return None


def load_component_command(
    component_name: str, module_path: str, command_name: str
) -> Any:
    """Dynamically load a command from a component."""
    try:
        component_path = get_component_path(component_name)
        if not component_path:
            logger.debug(f"🔍 Component {component_name} not found, skipping")
            return None

        # Add component to Python path temporarily
        sys.path.insert(0, str(component_path))

        try:
            # Import the module containing the command
            module = importlib.import_module(module_path)
            command = getattr(module, command_name, None)

            if command and callable(command):
                logger.debug(f"✅ Loaded {command_name} from {component_name}")
                return command
            else:
                logger.warning(f"⚠️ Command {command_name} not found in {module_path}")
                return None

        except ImportError as e:
            logger.debug(
                f"🔍 Could not import {module_path} from {component_name}: {e}"
            )
            return None
        finally:
            # Remove component path to avoid pollution
            if str(component_path) in sys.path:
                sys.path.remove(str(component_path))

    except Exception as e:
        logger.debug(f"⚠️ Error loading {component_name} command: {e}")
        return None


@click.group(
    cls=CategoryGroup, context_settings={"help_option_names": ["-h", "--help"]}
)
@click.version_option(version=__version__)
@click.pass_context
def cli(ctx: click.Context) -> None:
    """Genesis - Development toolkit for lean, AI-safe projects."""
    # Ensure click context object exists
    ctx.ensure_object(dict)

    # Try to find genesis root - support both toolkit development and client projects
    git_root = get_git_root()
    logger.debug(f"🔍 CLI: git_root = {git_root}")

    if git_root:
        # Check for Genesis toolkit development (genesis/ directory)
        has_genesis_dir = (git_root / "genesis").exists()
        logger.debug(f"🔍 CLI: {git_root}/genesis exists = {has_genesis_dir}")

        # Check for Genesis client project (.genesis/sync.yml)
        has_client_config = (git_root / ".genesis" / "sync.yml").exists()
        logger.debug(
            f"🔍 CLI: {git_root}/.genesis/sync.yml exists = {has_client_config}"
        )

        if has_genesis_dir:
            # Genesis toolkit development
            ctx.obj["genesis_root"] = git_root
            ctx.obj["project_type"] = "toolkit"
            logger.debug("🔍 CLI: Set genesis_root (toolkit development)")
        elif has_client_config:
            # Genesis client project
            ctx.obj["genesis_root"] = git_root
            ctx.obj["project_type"] = "client"
            logger.debug("🔍 CLI: Set genesis_root (client project)")
        else:
            logger.debug("🔍 CLI: No Genesis indicators found")
    else:
        logger.debug("🔍 CLI: No git root found")

    # For commands that don't need Genesis root (like sync), don't require it
    # Individual commands will handle their own validation if needed


@cli.command(context_settings={"help_option_names": ["-h", "--help"]})
@category("Project Management")
@click.argument("name")
@click.option(
    "--type",
    "project_type",
    required=True,
    type=click.Choice(["python-api", "typescript-service", "cli-tool"]),
    help="Project template type (required)",
)
@click.option(
    "--path", "target_path", default=None, help="Directory to create project in"
)
@click.option("--skip-git", is_flag=True, help="Skip Git initialization")
def bootstrap(
    name: str, project_type: str, target_path: str | None, skip_git: bool
) -> None:
    """Create new project with Genesis patterns and tooling."""
    from genesis.commands.bootstrap import bootstrap_command

    bootstrap_command(name, project_type, target_path, skip_git)


@cli.command(context_settings={"help_option_names": ["-h", "--help"]})
@category("Project Management")
@click.option("--worktrees", is_flag=True, help="Clean old worktrees only")
@click.option("--artifacts", is_flag=True, help="Clean build artifacts only")
@click.option("--tmpfs", is_flag=True, help="Clean container tmpfs only")
@click.option("--all", "clean_all", is_flag=True, help="Clean everything")
def clean(worktrees: bool, artifacts: bool, tmpfs: bool, clean_all: bool) -> None:
    """Clean workspace: remove old worktrees and build artifacts."""
    # Get the current repo root instead of genesis_root
    repo_root = get_git_root()
    if not repo_root:
        raise click.ClickException("Not in a Git repository")

    # Default to cleaning everything if no specific flags
    if not any([worktrees, artifacts, tmpfs, clean_all]):
        clean_all = True

    cleaned_items = []

    # Clean old worktrees
    if worktrees or clean_all:
        worktrees_dir = repo_root.parent / "worktrees"
        if worktrees_dir.exists():
            try:
                shutil.rmtree(worktrees_dir)
                cleaned_items.append("worktrees directory")
                logger.info("✅ Cleaned old worktrees")
            except Exception as e:
                handled_error = handle_error(e)
                logger.error(f"⚠️  Could not clean worktrees: {handled_error.message}")

    # Clean build artifacts and Python cache files
    if artifacts or clean_all:
        # Always clean Python cache files first
        basic_patterns = [
            "dist/",
            "build/",
            "*.egg-info/",
            "__pycache__/",
            ".pytest_cache/",
            ".mypy_cache/",
        ]
        file_patterns = [
            "*.pyc",
            "*.pyo",
            "*.pyd",
        ]

        # Track counts by type
        artifact_counts = {
            "dist": 0,
            "build": 0,
            "egg-info": 0,
            "__pycache__": 0,
            ".pytest_cache": 0,
            ".mypy_cache": 0,
            "pyc files": 0,
        }

        # Clean directories
        for pattern in basic_patterns:
            try:
                if pattern.endswith("/"):
                    pattern_name = pattern.rstrip("/")
                    for dir_path in repo_root.glob(f"**/{pattern_name}"):
                        if dir_path.exists():
                            shutil.rmtree(dir_path)
                            # Map pattern to friendly name
                            if pattern_name in artifact_counts:
                                artifact_counts[pattern_name] += 1
                            elif pattern_name.endswith(".egg-info"):
                                artifact_counts["egg-info"] += 1
            except OSError as e:
                logger.debug(f"Could not remove {pattern}: {e}")

        # Clean individual files
        for pattern in file_patterns:
            try:
                for file_path in repo_root.glob(f"**/{pattern}"):
                    if file_path.exists() and file_path.is_file():
                        file_path.unlink()
                        artifact_counts["pyc files"] += 1
            except OSError as e:
                logger.debug(f"Could not remove {pattern}: {e}")

        # Build summary message
        for artifact_type, count in artifact_counts.items():
            if count > 0:
                if count == 1:
                    cleaned_items.append(f"{artifact_type}")
                else:
                    cleaned_items.append(f"{count} {artifact_type} directories")

        # Try to run make clean for additional cleanup if Makefile exists
        makefile_path = repo_root / "Makefile"
        if makefile_path.exists():
            try:
                subprocess.run(
                    ["make", "clean"],
                    cwd=str(repo_root),
                    capture_output=True,
                    text=True,
                    check=True,
                )
                logger.info("✅ Cleaned build artifacts via Makefile")
            except subprocess.CalledProcessError as e:
                logger.warning(f"⚠️  make clean failed: {e}")

    # Clean container tmpfs (issue #268)
    if tmpfs or clean_all:
        try:
            from genesis.commands.container import (
                detect_service_name,
                get_compose_file,
                get_project_name,
                run_docker_compose,
            )

            # Check if container is running
            try:
                compose_file = get_compose_file()
                service_name = detect_service_name(compose_file)
                # Don't treat non-running container as error (check=False)
                output = run_docker_compose(
                    ["ps", "-q", service_name], capture_output=True, check=False
                )
                if output and isinstance(output, str) and output.strip():
                    # Container is running, run cleanup
                    project_name = get_project_name()

                    cleanup_cmd = None
                    try:
                        # Try docker-compose first
                        cleanup_cmd = [
                            "docker-compose",
                            "-f",
                            compose_file,
                            "-p",
                            project_name,
                            "exec",
                            "-T",
                            service_name,
                            "/workspace/scripts/cleanup-temp.sh",
                            "-f",
                            "-a",
                            "6",
                        ]
                        result = subprocess.run(
                            cleanup_cmd,
                            capture_output=True,
                            text=True,
                            timeout=CLEANUP_TIMEOUT,
                        )

                        if result.returncode == 0:
                            cleaned_items.append("container tmpfs")
                            logger.info("✅ Cleaned container tmpfs")
                        else:
                            logger.warning(
                                "⚠️  Container tmpfs cleanup completed with warnings"
                            )
                            cleaned_items.append("container tmpfs (with warnings)")

                    except (FileNotFoundError, subprocess.TimeoutExpired):
                        try:
                            # Fall back to docker compose (v2)
                            cleanup_cmd = [
                                "docker",
                                "compose",
                                "-f",
                                compose_file,
                                "-p",
                                project_name,
                                "exec",
                                "-T",
                                service_name,
                                "/workspace/scripts/cleanup-temp.sh",
                                "-f",
                                "-a",
                                "6",
                            ]
                            result = subprocess.run(
                                cleanup_cmd,
                                capture_output=True,
                                text=True,
                                timeout=CLEANUP_TIMEOUT,
                            )

                            if result.returncode == 0:
                                cleaned_items.append("container tmpfs")
                                logger.info("✅ Cleaned container tmpfs")
                            else:
                                logger.warning(
                                    "⚠️  Container tmpfs cleanup completed with warnings"
                                )
                                cleaned_items.append("container tmpfs (with warnings)")

                        except Exception as e:
                            logger.warning(f"⚠️  Could not clean container tmpfs: {e}")
                else:
                    if tmpfs:  # Only show message if explicitly requested
                        logger.info("ℹ️  Container not running - tmpfs cleanup skipped")
            except (Exception, SystemExit) as e:
                if tmpfs:  # Only show message if explicitly requested
                    logger.warning(f"⚠️  Could not check container status: {e}")

        except ImportError:
            if tmpfs:  # Only show message if explicitly requested
                logger.warning(
                    "⚠️  Container commands not available - tmpfs cleanup skipped"
                )

    if cleaned_items:
        logger.info(f"🧹 Cleaned: {', '.join(cleaned_items)}")
        logger.info("✅ Workspace cleanup complete!")
    else:
        logger.info("✨ Workspace is already clean!")


# Add all commands to CLI with categories

# Version Control
branch.category = "Version Control"
checkout.category = "Version Control"
pull.category = "Version Control"
reset.category = "Version Control"

# Core Development
format.category = "Core Development"
lint.category = "Core Development"
quality.category = "Core Development"
setup.category = "Core Development"
test.category = "Core Development"
typecheck.category = "Core Development"

# Project Management
init_command.category = "Project Management"
sync.category = "Project Management"
update_templates.category = "Project Management"

# Advanced
container.category = "Advanced"
environment.category = "Advanced"
migrate_command.category = "Advanced"
migrate_sync_command.category = "Advanced"
version.category = "Advanced"
worktree.category = "Advanced"

cli.add_command(branch)
cli.add_command(checkout)
cli.add_command(container)
cli.add_command(environment)
cli.add_command(format)
cli.add_command(init_command, name="init")
cli.add_command(lint)
cli.add_command(migrate_command, name="migrate")
cli.add_command(migrate_sync_command, name="migrate-sync")
cli.add_command(precommit)
cli.add_command(pull)
cli.add_command(quality)
cli.add_command(reset)
cli.add_command(setup)
cli.add_command(sync)
cli.add_command(test)
cli.add_command(typecheck)
cli.add_command(update_templates)
cli.add_command(version)
cli.add_command(worktree)

# Single-letter aliases for imported commands
cli.add_command(format, name="f")
cli.add_command(lint, name="l")
cli.add_command(test, name="t")
cli.add_command(quality, name="q")
cli.add_command(setup, name="s")
cli.add_command(typecheck, name="tc")
cli.add_command(sync, name="y")

# Dynamically load optional components


def _check_container_tmpfs_usage(verbose: bool = False) -> None:
    """Check container tmpfs usage for issue #268 monitoring."""
    try:
        # Try to detect if we have a running container
        from genesis.commands.container import (
            detect_service_name,
            get_compose_file,
            get_project_name,
            run_docker_compose,
        )
    except ImportError:
        if verbose:
            logger.info(
                "ℹ️  Container commands not available - tmpfs monitoring unavailable"
            )
        return

    try:
        # Check if container is running
        try:
            # Get compose file silently (raises FileNotFoundError instead of exiting)
            compose_file = get_compose_file(silent=True)
            service_name = detect_service_name(compose_file)
            # Don't treat non-running container as error (check=False)
            output = run_docker_compose(
                ["ps", "-q", service_name], capture_output=True, check=False
            )
            if not (output and isinstance(output, str) and output.strip()):
                if verbose:
                    logger.info(
                        "ℹ️  Container not running - tmpfs monitoring unavailable"
                    )
                return
        except FileNotFoundError:
            # No compose file found - this is fine for status checks
            if verbose:
                logger.info(
                    "ℹ️  No docker-compose.yml found - tmpfs monitoring unavailable"
                )
            return
        except Exception:
            if verbose:
                logger.info(
                    "ℹ️  Could not check container status - tmpfs monitoring unavailable"
                )
            return

        # Get tmpfs usage from container (compose_file already retrieved above)
        project_name = get_project_name()

        try:
            # Get configurable temp paths for df command
            from genesis.core.constants import get_temp_paths

            temp_paths = get_temp_paths()

            # Try docker-compose first
            cmd = [
                "docker-compose",
                "-f",
                compose_file,
                "-p",
                project_name,
                "exec",
                "-T",
                service_name,
                "df",
                "-h",
            ] + temp_paths
            # CLI timeout for container status operations
            cli_timeout = int(
                os.environ.get(
                    "GENESIS_CLI_TIMEOUT", EnvironmentDefaults.DEFAULT_CLI_TIMEOUT
                )
            )
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=cli_timeout
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            try:
                # Fall back to docker compose (v2)
                cmd = [
                    "docker",
                    "compose",
                    "-f",
                    compose_file,
                    "-p",
                    project_name,
                    "exec",
                    "-T",
                    service_name,
                    "df",
                    "-h",
                ] + temp_paths
                # CLI timeout for container status operations (fallback command)
                cli_timeout = int(
                    os.environ.get(
                        "GENESIS_CLI_TIMEOUT", EnvironmentDefaults.DEFAULT_CLI_TIMEOUT
                    )
                )
                result = subprocess.run(
                    cmd, capture_output=True, text=True, timeout=cli_timeout
                )
            except Exception:
                if verbose:
                    message = "⚠️  Could not check container tmpfs usage"
                    logger.warning(message)
                    click.echo(message)
                return

        if result.returncode == 0:
            stdout_text = (
                result.stdout if isinstance(result.stdout, str) else str(result.stdout)
            )
            lines = stdout_text.strip().split("\n")
            tmpfs_info = []

            # Get configurable temp paths
            from genesis.core.constants import get_temp_paths

            temp_paths = get_temp_paths()

            for line in lines[1:]:  # Skip header
                if any(
                    temp_path.strip() in line
                    for temp_path in temp_paths
                    if isinstance(temp_path, str)
                ):
                    parts = line.split()
                    if len(parts) >= 5:
                        # filesystem = parts[0]  # unused
                        size = parts[1]
                        used = parts[2]
                        # available = parts[3]  # unused
                        use_percent = parts[4]
                        mount = parts[5]

                        # Parse percentage to check if it's concerning
                        try:
                            percent_val = int(use_percent.rstrip("%"))
                            if percent_val >= 80:
                                icon = "🔴"
                                level = "error"
                            elif percent_val >= 60:
                                icon = "🟡"
                                level = "warning"
                            else:
                                icon = "✅"
                                level = "info"

                            tmpfs_line = (
                                f"{icon} {mount}: {used}/{size} ({use_percent} used)"
                            )
                            tmpfs_info.append((tmpfs_line, level))

                        except ValueError:
                            # If we can't parse percentage, just show info
                            tmpfs_line = f"ℹ️  {mount}: {used}/{size} used"
                            tmpfs_info.append((tmpfs_line, "info"))

            if tmpfs_info:
                if verbose or any(
                    level in ["warning", "error"] for _, level in tmpfs_info
                ):
                    message = "💾 Container tmpfs usage:"
                    logger.info(message)
                    click.echo(message)

                    for tmpfs_line, level in tmpfs_info:
                        if level == "error":
                            logger.error(tmpfs_line)
                        elif level == "warning":
                            logger.warning(tmpfs_line)
                        else:
                            logger.info(tmpfs_line)
                        click.echo(tmpfs_line)

                    # Show cleanup suggestion if usage is high
                    if any(level in ["warning", "error"] for _, level in tmpfs_info):
                        cleanup_msg = (
                            "💡 Run 'genesis container tmpfs-cleanup' to free space"
                        )
                        logger.info(cleanup_msg)
                        click.echo(cleanup_msg)

    except Exception as e:
        if verbose:
            message = f"⚠️  Could not check tmpfs usage: {str(e)}"
            logger.warning(message)
            click.echo(message)


@cli.command(context_settings={"help_option_names": ["-h", "--help"]})
@category("Project Management")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed status")
@click.pass_context
def status(ctx: click.Context, verbose: bool) -> None:
    """Check Genesis project health and component status."""
    genesis_root = ctx.obj.get("genesis_root")
    if not genesis_root:
        message = "❌ Not in a Genesis project"
        logger.error(message)
        click.echo(message, err=True)
        sys.exit(1)

    project_type = ctx.obj.get("project_type", "unknown")
    logger.info(f"📍 Genesis root: {genesis_root}")

    if project_type == "client":
        # Client project status checks
        checks = {
            ".genesis/sync.yml": "Genesis sync configuration",
            "pyproject.toml": "Python project configuration (if applicable)",
            ".envrc": "Environment configuration (if using direnv)",
        }

        all_healthy = True
        for check_path, description in checks.items():
            file_path = genesis_root / check_path
            if file_path.exists():
                if verbose:
                    logger.info(f"✅ {check_path}: {description}")
                else:
                    logger.info(f"✅ {check_path.split('/')[-1]}")
            else:
                if check_path == ".genesis/sync.yml":
                    # sync.yml is required for client projects
                    logger.error(f"❌ {check_path}: Missing")
                    all_healthy = False
                elif verbose:
                    # Optional files - only show when verbose
                    logger.warning(f"⚠️  {check_path}: Optional (not found)")

    else:
        # Genesis toolkit development status checks
        components = {
            "bootstrap": "Project initialization system",
            "smart-commit": "Quality gates before commits",
            "worktree-tools": "AI-safe sparse worktree creation",
            "genesis": "Core CLI and shared utilities",
            "testing": "Testing infrastructure and fixtures",
        }

        all_healthy = True
        for component, description in components.items():
            component_path = genesis_root / component
            if component_path.exists():
                if verbose:
                    message = f"✅ {component}: {description}"
                    logger.info(message)
                    click.echo(message)
                else:
                    message = f"✅ {component}"
                    logger.info(message)
                    click.echo(message)
            else:
                # worktree-tools is optional
                if component == "worktree-tools":
                    if verbose:
                        message = f"ℹ️  {component}: Optional (not installed)"
                        logger.info(message)
                        click.echo(message)
                else:
                    message = f"❌ {component}: Missing"
                    logger.error(message)
                    click.echo(message, err=True)
                    all_healthy = False

    # Check file count for AI safety
    try:
        # Use git ls-files to respect .gitignore
        result = subprocess.run(
            ["git", "ls-files"],
            cwd=genesis_root,
            capture_output=True,
            text=True,
            check=True,
        )
        stdout_text = (
            result.stdout if isinstance(result.stdout, str) else str(result.stdout)
        )
        file_count = len(stdout_text.strip().split("\n")) if stdout_text.strip() else 0

        try:
            from genesis.core.constants import AILimits

            max_files = AILimits.get_max_project_files()

            if file_count <= max_files:
                logger.info(f"✅ File count: {file_count} (AI-safe: ≤{max_files})")
            else:
                logger.warning(
                    f"⚠️  File count: {file_count} (Target: ≤{max_files} for AI safety)"
                )
                all_healthy = False
        except ValueError as e:
            logger.warning(f"⚠️  Could not check file limits: {e}")
            all_healthy = False
    except Exception as e:
        handled_error = handle_error(e)
        logger.warning(f"⚠️  Could not check file count: {handled_error.message}")
        all_healthy = False

    # Check container tmpfs usage if container is running (issue #268)
    _check_container_tmpfs_usage(verbose)

    # Overall health
    if all_healthy:
        message = "🎉 Genesis project is healthy!"
        logger.info(message)
        click.echo(message)
    else:
        message = "⚠️  Genesis project has issues"
        logger.warning(message)
        click.echo(message, err=True)
        sys.exit(1)


@cli.command(context_settings={"help_option_names": ["-h", "--help"]})
@category("Version Control")
@click.option(
    "--message",
    "-m",
    help="Commit message (use \\n for multi-line, e.g., 'feat: summary\\n\\nDetailed description')",
)
@click.option(
    "--no-approve",
    is_flag=True,
    help="Skip interactive approval (non-interactive mode for agents/CI)",
)
@click.option(
    "--details",
    "-d",
    is_flag=True,
    help="Show detailed information about quality check findings",
)
@click.pass_context
def commit(
    ctx: click.Context, message: str | None, no_approve: bool, details: bool
) -> None:
    """Smart commit with quality gates and pre-commit hooks."""
    # Check if we're in a git repository
    if not Path.cwd().joinpath(".git").exists():
        error_msg = "❌ Not in a git repository. Initialize git first with: git init"
        logger.error(error_msg)
        click.echo(error_msg, err=True)
        sys.exit(1)

    # Find smart-commit script from component path
    smart_commit_path = get_component_path("smart-commit")
    if not smart_commit_path:
        # Fallback to regular git commit if smart-commit not available
        logger.info(
            "ℹ️  Smart-commit component not found, falling back to git commit with pre-commit hooks"
        )
        try:
            # Use git add -A to stage all changes
            subprocess.run(["git", "add", "-A"], check=True)

            # Build git commit command
            cmd = ["git", "commit"]
            if message:
                cmd.extend(["-m", message])

            # Run git commit (this will trigger pre-commit hooks automatically)
            subprocess.run(cmd, check=True)
            logger.info("✅ Commit completed with pre-commit hooks!")
            return
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ Git commit failed: {e.stderr if e.stderr else str(e)}")
            sys.exit(1)

    smart_commit_script = smart_commit_path / "scripts" / "smart-commit.sh"
    if not smart_commit_script.exists():
        logger.error(f"❌ Smart-commit script not found at {smart_commit_script}")
        sys.exit(1)

    # Set required environment variables for AutoFixer if not already set
    env_vars = {
        "AUTOFIX_MAX_ITERATIONS": "3",
        "AUTOFIX_MAX_RUNS": "5",
        "AI_MAX_FILES": "30",
        "AI_SAFETY_MODE": "enforced",
        "LOG_LEVEL": "info",
    }

    for var, default_value in env_vars.items():
        if var not in os.environ:
            os.environ[var] = default_value

    cmd = [str(smart_commit_script)]

    # Pass the --no-approve flag if specified
    if no_approve:
        cmd.append("--no-approve")

    # Pass the --details flag if specified
    if details:
        cmd.append("--details")

    if message:
        # Support \n in message for multi-line commits
        message = message.replace("\\n", "\n")
        os.environ["COMMIT_MESSAGE"] = message

    try:
        # FIXED: Run smart-commit in the current working directory (project directory)
        # Remove capture_output=True to show real-time output and prevent hanging appearance
        subprocess.run(cmd, check=True, cwd=os.getcwd())
        message = "✅ Smart commit completed!"
        logger.info(message)
        click.echo(message)
    except subprocess.CalledProcessError as e:
        # Display the actual error output from smart-commit script
        error_msg = f"❌ Smart commit failed with exit code {e.returncode}"

        if e.stderr and isinstance(e.stderr, str) and e.stderr.strip():
            # If stderr has content, show it
            logger.error(f"{error_msg}:\n{e.stderr.strip()}")
            click.echo(f"{error_msg}:\n{e.stderr.strip()}", err=True)
        elif e.stdout and isinstance(e.stdout, str) and e.stdout.strip():
            # If no stderr but stdout has content, show stdout
            logger.error(f"{error_msg}:\n{e.stdout.strip()}")
            click.echo(f"{error_msg}:\n{e.stdout.strip()}", err=True)
        else:
            # Fallback to generic message
            logger.error(f"{error_msg}. No additional error details available.")
            click.echo(f"{error_msg}. No additional error details available.", err=True)

        handle_error(e)
        sys.exit(e.returncode)
    except Exception as e:
        handle_error(e)
        logger.error(f"❌ Smart commit failed: {str(e)}")
        sys.exit(1)


@cli.command(name="autofix", context_settings={"help_option_names": ["-h", "--help"]})
@category("Core Development")
@click.option(
    "--dry-run", is_flag=True, help="Show what would be fixed without making changes"
)
@click.option(
    "--stages",
    help="Comma-separated list of stages to run (basic,formatter,linter,validation)",
)
@click.option(
    "--max-iterations",
    type=int,
    help="Maximum convergent fixing iterations (default: 3)",
)
@click.pass_context
def autofix(
    ctx: click.Context, dry_run: bool, stages: str | None, max_iterations: int | None
) -> None:
    """Run autofix (formatting, linting) without committing changes."""

    from genesis.core.autofix import AutoFixer

    try:
        fixer = AutoFixer(max_iterations=max_iterations)

        # Parse stages if provided
        stage_list = None
        if stages:
            stage_list = [s.strip() for s in stages.split(",")]

        if stages and stage_list:
            # Run specific stages only
            result = fixer.run_stage_only(stage_types=stage_list, dry_run=dry_run)
        else:
            # Run full autofix process
            result = fixer.run(dry_run=dry_run)

        if dry_run:
            logger.info("🔍 Dry run completed - no changes made")
        else:
            logger.info("✅ AutoFix completed")

        if hasattr(result, "success") and not result.success:
            logger.warning("⚠️  Some issues were found during autofix")

    except Exception as e:
        handled_error = handle_error(e)
        logger.error(f"❌ AutoFix failed: {handled_error.message}")
        sys.exit(1)


# Single-letter aliases for commands defined in this file
# Set categories (decorator doesn't work with @cli.command)
bootstrap.category = "Project Management"
clean.category = "Project Management"
status.category = "Project Management"
commit.category = "Version Control"
autofix.category = "Core Development"

cli.add_command(bootstrap, name="b")
cli.add_command(clean, name="x")
cli.add_command(status, name="st")
cli.add_command(commit, name="c")
cli.add_command(autofix, name="a")

if __name__ == "__main__":
    cli()
