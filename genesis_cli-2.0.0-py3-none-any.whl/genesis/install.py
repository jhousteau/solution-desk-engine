"""Auto-installation utilities for Genesis dependencies."""

import subprocess
import sys
from pathlib import Path

try:
    from genesis.core.logger import get_logger

    logger = get_logger(__name__)
except ImportError:
    import logging

    logger = logging.getLogger(__name__)


def is_shared_core_available() -> bool:
    """Check if genesis-shared-core is available."""
    try:
        import shared_core

        # Import succeeded, module is available
        _ = shared_core
        return True
    except ImportError:
        return False


def install_shared_core() -> None:
    """Install genesis-shared-core dynamically if not available."""
    if is_shared_core_available():
        logger.debug("genesis-shared-core already available")
        return

    logger.info("genesis-shared-core not found, installing dynamically...")

    try:
        from genesis.core.dependencies import DependencyResolver

        resolver = DependencyResolver()
        url = resolver.get_shared_core_url()

        logger.info(f"Installing genesis-shared-core from {url}")
        subprocess.run(
            [sys.executable, "-m", "pip", "install", url],
            check=True,
            capture_output=True,
        )

        logger.info("✅ genesis-shared-core installed successfully")

    except Exception as e:
        logger.error(f"Failed to install genesis-shared-core: {e}")
        logger.warning(
            "Falling back to development mode - ensure shared-python is available"
        )

        # Try to add local shared-python to path as fallback
        shared_python_path = Path(__file__).parent.parent / "shared-python" / "src"
        if shared_python_path.exists():
            sys.path.insert(0, str(shared_python_path))
            logger.info(f"Added {shared_python_path} to Python path")


def ensure_dependencies() -> None:
    """Ensure all Genesis dependencies are available."""
    install_shared_core()
