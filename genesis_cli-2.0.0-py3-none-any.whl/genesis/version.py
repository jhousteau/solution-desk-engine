"""Version management for Genesis."""

import tomllib
from importlib.metadata import version as get_package_version
from pathlib import Path

# Hardcoded version as final fallback
__version__ = "1.8.1"


def get_version() -> str:
    """Get Genesis version.

    Priority order:
    1. Try pyproject.toml (for development/editable installs)
    2. Try package metadata (for installed wheels)
    3. Fall back to hardcoded version
    """
    # Try reading from pyproject.toml (development mode)
    pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
    try:
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
            version: str = data["tool"]["poetry"]["version"]
            return version
    except (FileNotFoundError, KeyError, tomllib.TOMLDecodeError):
        pass

    # Try reading from package metadata (installed wheels)
    try:
        return get_package_version("genesis-cli")
    except Exception:
        pass

    # Final fallback
    return __version__
