"""AI safety validation utilities for testing."""

from pathlib import Path
from typing import Any

from genesis.core.logger import get_logger

# Initialize logger
logger = get_logger(__name__)


def count_files_in_directory(
    directory: Path, include_hidden: bool = False, use_gitignore: bool = True
) -> int:
    """Count files in directory, respecting gitignore patterns by default."""
    import subprocess

    if use_gitignore:
        # Use git ls-files to get only tracked and untracked files that git would track
        try:
            # Get all files that git would track (respects .gitignore)
            result = subprocess.run(
                ["git", "ls-files", "--cached", "--others", "--exclude-standard"],
                cwd=directory,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                files = [
                    line.strip()
                    for line in result.stdout.strip().split("\n")
                    if line.strip()
                ]
                return len(files)
        except (subprocess.SubprocessError, FileNotFoundError):
            # Fall back to manual counting if git is not available
            pass

    # Fallback: manual file counting with basic exclusions
    exclude_patterns = [
        ".git",
        "__pycache__",
        ".pytest_cache",
        "node_modules",
        "old-bloated-code-read-only",
    ]

    files = []
    for item in directory.rglob("*"):
        if not item.is_file():
            continue

        # Skip hidden files unless requested
        if not include_hidden and any(part.startswith(".") for part in item.parts):
            if not any(
                part in str(item) for part in [".py", ".js", ".ts", ".sh", ".md"]
            ):
                continue

        # Skip excluded patterns
        if any(pattern in str(item) for pattern in exclude_patterns):
            continue

        files.append(str(item))

    return len(files)


def validate_ai_safety_limits(
    directory: Path,
    max_files: int | None = None,
    max_component_files: int | None = None,
) -> dict[str, Any]:
    """Validate directory meets AI safety file count limits."""
    from genesis.core.constants import AILimits

    # Use configured limits if not provided
    if max_files is None:
        max_files = AILimits.get_max_project_files()
    if max_component_files is None:
        max_component_files = AILimits.get_max_component_files()

    total_files = count_files_in_directory(directory)

    # Check component directories
    component_results = {}
    for component_dir in directory.iterdir():
        if component_dir.is_dir() and not component_dir.name.startswith("."):
            if component_dir.name in [
                "bootstrap",
                "genesis",
                "smart-commit",
                "worktree-tools",
                "testing",
            ]:
                component_files = count_files_in_directory(component_dir)
                component_results[component_dir.name] = {
                    "file_count": component_files,
                    "is_safe": component_files <= max_component_files,
                    "limit": max_component_files,
                }

    return {
        "total_files": total_files,
        "max_files": max_files,
        "is_safe": total_files <= max_files,
        "components": component_results,
        "all_components_safe": all(
            result["is_safe"] for result in component_results.values()
        ),
    }


def assert_file_count_safe(
    directory: Path, max_files: int | None = None, message: str | None = None
) -> None:
    """Assert that directory has safe file count for AI."""
    from genesis.core.constants import AILimits

    if max_files is None:
        max_files = AILimits.get_max_project_files()

    file_count = count_files_in_directory(directory)
    if message is None:
        message = (
            f"Directory has {file_count} files, exceeds AI safety limit of {max_files}"
        )

    assert file_count <= max_files, message


def assert_component_isolation(
    component_path: Path, max_files: int | None = None
) -> None:
    """Assert that component meets isolation requirements."""
    from genesis.core.constants import AILimits

    if max_files is None:
        max_files = AILimits.get_max_component_files()

    assert (
        component_path.exists()
    ), f"Component directory {component_path} does not exist"

    # Check required structure
    assert (
        component_path / "README.md"
    ).exists(), f"Component {component_path.name} missing README.md"

    # Check file count
    file_count = count_files_in_directory(component_path)
    assert (
        file_count <= max_files
    ), f"Component {component_path.name} has {file_count} files, exceeds limit of {max_files}"


def get_file_count_report(directory: Path) -> dict[str, Any]:
    """Generate detailed file count report for directory."""
    report: dict[str, Any] = {
        "directory": str(directory),
        "total_files": 0,
        "file_types": {},
        "components": {},
        "largest_files": [],
        "ai_safety_status": {},
    }

    # Count total files and analyze types
    all_files = []
    for item in directory.rglob("*"):
        if item.is_file():
            all_files.append(item)

            # Count by extension
            ext = item.suffix or "no_extension"
            if "file_types" not in report:
                report["file_types"] = {}
            file_types = report["file_types"]
            assert isinstance(file_types, dict)
            file_types[ext] = file_types.get(ext, 0) + 1

    report["total_files"] = len(all_files)

    # Analyze components
    for component_dir in directory.iterdir():
        if component_dir.is_dir() and not component_dir.name.startswith("."):
            if component_dir.name in [
                "bootstrap",
                "genesis",
                "smart-commit",
                "worktree-tools",
                "testing",
            ]:
                component_files = count_files_in_directory(component_dir)
                if "components" not in report:
                    report["components"] = {}
                components = report["components"]
                assert isinstance(components, dict)
                components[component_dir.name] = component_files

    # Find largest files (by line count if possible)
    sorted_files = sorted(all_files, key=lambda f: f.stat().st_size, reverse=True)
    report["largest_files"] = [
        {"path": str(f.relative_to(directory)), "size": f.stat().st_size}
        for f in sorted_files[:10]
    ]

    # AI safety assessment
    report["ai_safety_status"] = validate_ai_safety_limits(directory)

    return report


def print_ai_safety_report(directory: Path) -> None:
    """Print human-readable AI safety report."""
    report = get_file_count_report(directory)

    logger.info(f"\n🤖 AI Safety Report for {report['directory']}")
    logger.info("=" * 50)

    logger.info(f"Total files: {report['total_files']}")

    status = report["ai_safety_status"]
    if status["is_safe"]:
        logger.info(f"✅ SAFE: Within limit of {status['max_files']} files")
    else:
        logger.warning(f"❌ UNSAFE: Exceeds limit of {status['max_files']} files")

    logger.info("\nComponent breakdown:")
    for component, count in report["components"].items():
        status_icon = "✅" if count <= 30 else "❌"
        logger.info(f"  {status_icon} {component}: {count} files")

    logger.info("\nFile types:")
    for ext, count in sorted(report["file_types"].items()):
        logger.info(f"  {ext}: {count}")

    if not status["is_safe"] or not status["all_components_safe"]:
        logger.warning("\n⚠️  Action needed to maintain AI safety!")
        logger.warning(
            "   Consider reducing file count or improving component isolation."
        )


class AISafetyChecker:
    """Class for checking AI safety constraints during tests."""

    def __init__(
        self,
        max_total_files: int | None = None,
        max_component_files: int | None = None,
    ) -> None:
        from genesis.core.constants import AILimits

        if max_total_files is None:
            max_total_files = AILimits.get_max_project_files()
        if max_component_files is None:
            max_component_files = AILimits.get_max_component_files()

        self.max_total_files = max_total_files
        self.max_component_files = max_component_files

    def check_project(self, project_path: Path) -> dict[str, Any]:
        """Check entire project for AI safety."""
        return validate_ai_safety_limits(
            project_path, self.max_total_files, self.max_component_files
        )

    def check_component(self, component_path: Path) -> dict[str, Any]:
        """Check single component for AI safety."""
        file_count = count_files_in_directory(component_path)
        return {
            "component": component_path.name,
            "file_count": file_count,
            "max_files": self.max_component_files,
            "is_safe": file_count <= self.max_component_files,
        }

    def assert_project_safe(self, project_path: Path) -> None:
        """Assert project meets AI safety requirements."""
        result = self.check_project(project_path)
        assert result[
            "is_safe"
        ], f"Project unsafe: {result['total_files']} > {result['max_files']} files"
        assert result["all_components_safe"], "Some components exceed file limits"

    def assert_component_safe(self, component_path: Path) -> None:
        """Assert component meets AI safety requirements."""
        result = self.check_component(component_path)
        assert result[
            "is_safe"
        ], f"Component {result['component']} unsafe: {result['file_count']} > {result['max_files']} files"
