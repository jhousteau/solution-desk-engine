"""Genesis project templates.

This package contains template files for different project types
that Genesis can bootstrap.
"""
