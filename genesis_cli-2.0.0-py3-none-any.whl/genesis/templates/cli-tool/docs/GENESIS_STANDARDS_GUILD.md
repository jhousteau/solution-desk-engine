# Genesis Standards Guild
## The Authoritative Guide for Client Applications

**Version:** 1.0
**Audience:** Development Teams, Tech Leads, AI Engineers

---

## 🎯 Purpose & Scope

This document establishes the canonical standards for client applications using Genesis. It serves as:

- **The single source of truth** for Genesis usage patterns
- **Team onboarding guide** for new developers
- **Quality gate reference** for code reviews
- **AI safety compliance** checklist

**💡 Key Principle:** Genesis enforces consistency, safety, and productivity through structured patterns that scale from individual developers to enterprise teams.

---

## 📋 Table of Contents

1. [Project Initialization Standards](#project-initialization-standards)
2. [Directory Structure Standards](#directory-structure-standards)
3. [Worktree Organization Standards](#worktree-organization-standards)
4. [Genesis CLI Usage Patterns](#genesis-cli-usage-patterns)
5. [AI Safety Guidelines](#ai-safety-guidelines)
6. [Quality Gates & Validation](#quality-gates--validation)
7. [Environment Configuration](#environment-configuration)
8. [Team Collaboration Standards](#team-collaboration-standards)
9. [Troubleshooting & Best Practices](#troubleshooting--best-practices)

---

## 🚀 Project Initialization Standards

### Bootstrap Requirements

**✅ REQUIRED:** Always use Genesis bootstrap for new projects

```bash
# Standard bootstrap command
genesis bootstrap --type <project-type> <project-name>

# Available project types
genesis bootstrap --type python-api my-api-service
genesis bootstrap --type cli-tool my-cli-tool
genesis bootstrap --type typescript-service my-web-service
genesis bootstrap --type terraform-project my-infrastructure
```

### Post-Bootstrap Validation

**✅ MANDATORY:** Validate every bootstrapped project

```bash
cd your-project
make validate-bootstrap
```

**Expected Output:**
- 0 errors (❌) - Project cannot proceed with errors
- Warnings (⚠️) are acceptable but should be addressed

### Initial Setup Checklist

- [ ] `genesis bootstrap` completed successfully
- [ ] `make validate-bootstrap` passes (0 errors)
- [ ] `make setup` runs without errors
- [ ] Git repository initialized (`git init` if not done)
- [ ] Initial commit created
- [ ] Team access configured (GitHub, CI/CD)

---

## 📁 Directory Structure Standards

### Mandatory Project Layout

Genesis enforces this standard structure across all projects:

```
project-root/
├── src/                 # Source code ONLY
│   ├── project_name/    # Main application code
│   └── shared/          # Shared utilities (if needed)
├── tests/               # All test files
│   ├── unit/           # Unit tests
│   ├── integration/    # Integration tests
│   └── conftest.py     # Test configuration
├── docs/                # Documentation
│   ├── api/            # API documentation
│   ├── guides/         # User guides
│   └── architecture/   # Technical architecture
├── scripts/             # Executable utilities
├── config/              # Configuration files
├── .claude/             # Claude Code integration
├── scratch/             # Temporary files (git-ignored)
├── .gitignore          # Includes scratch/ by default
├── Makefile            # Standard automation
├── README.md           # Project overview
└── .mcp.json           # MCP server configuration
```

### File Organization Rules

**🚫 FORBIDDEN in Root Directory:**
- Source code files (`.py`, `.ts`, `.js`)
- Test files (`test_*.py`, `*.test.ts`)
- Configuration files (`.json`, `.yaml`, `.toml` except standard ones)
- Scripts or utilities (`.sh`, executable files)
- Temporary files or build artifacts

**✅ ALLOWED in Root Directory ONLY:**
- `README.md`, `CLAUDE.md`
- `Makefile`
- `pyproject.toml`, `package.json`, `Cargo.toml`
- `.gitignore`, `.envrc`, `.env.example`
- `LICENSE`, `SECURITY.md`
- `Dockerfile`, `docker-compose.yml`
- Infrastructure files (`main.tf`, `variables.tf`)

### Enforcement

Genesis provides automatic validation:

```bash
make check-org          # Check file organization
genesis autofix         # Fix common organization issues
```

---

## 🌿 Worktree Organization Standards

### AI Safety Through Worktrees

Genesis uses sparse worktrees to maintain AI safety by limiting context size. Each worktree contains ≤30 files.

### Worktree Naming Convention

```bash
# Format: <type>-<feature>-<ticket>
genesis worktree create api-user-auth-123 --focus src/auth/
genesis worktree create fix-memory-leak-456 --focus src/core/
genesis worktree create docs-api-update-789 --focus docs/api/
```

**Naming Rules:**
- **type:** `api`, `ui`, `cli`, `fix`, `feat`, `docs`, `test`, `config`
- **feature:** Brief description (2-3 words, kebab-case)
- **ticket:** Jira/GitHub issue number

### Focus Area Guidelines

**✅ GOOD Focus Areas (≤30 files):**
```bash
# Feature-specific focus
--focus src/auth/                    # Authentication module
--focus src/api/users/              # User management API
--focus docs/guides/               # Documentation section

# Cross-cutting concerns
--focus src/core/config/           # Configuration module
--focus tests/integration/auth/    # Auth integration tests
```

**❌ BAD Focus Areas (>30 files):**
```bash
# Too broad
--focus src/                       # Entire source directory
--focus tests/                     # All tests
--focus .                         # Entire project
```

### Worktree Lifecycle Management

```bash
# Create focused worktree
genesis worktree create feature-name --focus src/module/

# List active worktrees
genesis worktree list

# Switch between worktrees
cd ../feature-name-worktree

# Remove completed worktree
genesis worktree remove feature-name
```

### Team Worktree Standards

**🔒 Individual Developer Rules:**
- Maximum 3 active worktrees per developer
- Each worktree addresses single feature/fix
- Clean up worktrees within 1 week of PR merge

**👥 Team Coordination:**
- Document active worktrees in team channel
- Avoid overlapping focus areas between team members
- Use consistent naming conventions

---

## ⚙️ Genesis CLI Usage Patterns

### Daily Development Workflow

```bash
# Morning routine
genesis status                      # Check project health
genesis worktree list              # Review active work

# Feature development
genesis worktree create feat-name --focus src/module/
cd ../feat-name-worktree
# ... development work ...

# Quality assurance
genesis autofix                    # Fix formatting/linting
make validate-bootstrap           # Ensure project integrity
genesis commit                    # Smart commit with gates

# End of day cleanup
genesis clean                     # Remove old artifacts
```

### Commit Standards

**✅ ALWAYS use Genesis commit:**
```bash
genesis commit -m "feat: add user authentication endpoint"
genesis commit                    # Interactive mode for complex commits
```

**🚫 NEVER use direct git commit:**
```bash
# FORBIDDEN - bypasses quality gates
git commit -m "message"
git commit --no-verify
```

### Version Management

```bash
genesis version bump minor        # Semantic versioning
genesis version status           # Check current version
genesis sync                     # Update dependencies
```

---

## 🛡️ AI Safety Guidelines

### File Count Enforcement

Genesis automatically enforces AI safety limits:

- **Main workspace:** Can exceed 30 files (human development)
- **Worktrees:** Must be ≤30 files (AI development)
- **Context windows:** Optimized for AI comprehension

### Safe Development Patterns

**✅ AI-Safe Practices:**
- Use focused worktrees for AI collaboration
- Keep related files together in worktrees
- Follow single responsibility per worktree
- Regular cleanup of completed worktrees

**❌ AI-Unsafe Practices:**
- Working in main workspace with AI on large codebases
- Creating worktrees with >30 files
- Mixing unrelated changes in single worktree
- Long-lived worktrees (>1 week)

### Context Size Monitoring

```bash
# Check current context size
genesis worktree list --files      # Show file counts
genesis status --context          # Context size analysis
```

---

## ✅ Quality Gates & Validation

### Mandatory Quality Checks

Every Genesis project includes these quality gates:

```bash
make validate-bootstrap           # Project structure validation
make check-org                   # File organization check
make test                        # Run all tests
make lint                        # Code quality checks
make security                    # Security scans
```

### Pre-Commit Hooks

Genesis automatically configures:
- Code formatting (Black, Prettier, etc.)
- Linting (ESLint, Pylint, etc.)
- Security scanning (Bandit, GitLeaks)
- File organization validation

### Continuous Integration

**Required CI Checks:**
- All quality gates pass
- Bootstrap validation succeeds
- No hardcoded secrets or credentials
- Documentation is up-to-date

---

## 🌍 Environment Configuration

### Standard Environment Variables

Genesis projects use consistent environment patterns:

```bash
# Project identification
PROJECT_NAME="my-project"
PROJECT_TYPE="python-api"
PROJECT_MODE="development"

# AI safety settings
AI_SAFETY_MODE="enabled"
MAX_PROJECT_FILES="30"

# Development settings
LOG_LEVEL="info"
SERVICE_PORT="8000"
```

### Configuration Management

**✅ REQUIRED Patterns:**
```python
# Fail-fast configuration loading
DATABASE_URL = get_required_env("DATABASE_URL")
API_KEY = get_required_env("API_KEY")

# No hardcoded defaults
def connect_db(host: str, port: int, database: str):
    # All parameters must be explicit
    pass
```

**🚫 FORBIDDEN Patterns:**
```python
# Silent fallbacks hide configuration issues
database_url = os.environ.get("DATABASE_URL", "localhost:5432")
port = int(os.environ.get("PORT", "8080"))
```

---

## 👥 Team Collaboration Standards

### Code Review Requirements

**Before Review:**
- [ ] `genesis commit` used (not direct git commit)
- [ ] `make validate-bootstrap` passes
- [ ] All quality gates green
- [ ] Worktree properly focused (≤30 files)

**Review Checklist:**
- [ ] Genesis patterns followed consistently
- [ ] No hardcoded configuration values
- [ ] Appropriate file organization
- [ ] AI safety compliance

### Knowledge Sharing

**Team Practices:**
- Weekly Genesis usage review
- Share worktree organization patterns
- Document custom Genesis configurations
- Maintain team-specific Genesis extensions

### Onboarding New Developers

**Day 1 Checklist:**
- [ ] Genesis CLI installed and configured
- [ ] Read Genesis Standards Guild (this document)
- [ ] Complete sample project bootstrap
- [ ] Validate understanding with team lead

---

## 🔧 Troubleshooting & Best Practices

### Common Issues & Solutions

**Issue: "Permission denied" on scripts**
```bash
# Genesis automatically fixes this in new projects
# For existing projects:
chmod +x scripts/*.sh
```

**Issue: Worktree exceeds 30 files**
```bash
genesis worktree create feature-name --focus src/specific-module/
# Use more specific focus areas
```

**Issue: Bootstrap validation fails**
```bash
make validate-bootstrap
# Follow the specific error messages to fix issues
```

### Performance Optimization

**Faster Development:**
- Use worktrees for focused development
- Regular cleanup with `genesis clean`
- Leverage Genesis autofix for common issues

**CI/CD Optimization:**
- Cache Genesis dependencies
- Parallel quality gate execution
- Use Genesis container for consistent environments

### Advanced Configuration

**Custom MCP Servers:**
```json
{
  "mcpServers": {
    "Ref": {
      "type": "http",
      "url": "https://api.ref.tools/mcp?apiKey=your-key"
    },
    "CustomTool": {
      "type": "stdio",
      "command": "./custom-mcp-server"
    }
  }
}
```

---

## 📚 Additional Resources

### Documentation Links
- [Genesis CLI Reference](./CLI_REFERENCE.md)
- [Worktree Management Guide](./WORKTREE_GUIDE.md)
- [AI Safety Best Practices](./AI_SAFETY.md)
- [Troubleshooting Guide](./TROUBLESHOOTING.md)

### Support Channels
- **Technical Issues:** GitHub Issues
- **Best Practices:** Team Documentation
- **Feature Requests:** Genesis Roadmap

---

## 🔄 Document Maintenance

**Update Frequency:** Monthly or when major Genesis features are released
**Review Process:** Technical leads review and approve changes
**Distribution:** All development teams must have access to latest version

**Change Log:**
- v1.0: Initial Genesis Standards Guild
- [Future versions will be tracked here]

---

**✅ Compliance Statement:**
Projects following this Genesis Standards Guild are guaranteed to be consistent, maintainable, and AI-safe. Any deviation from these standards requires explicit team lead approval and documentation.
