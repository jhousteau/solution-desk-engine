# Genesis Core

Core Genesis functionality including CLI, error handling, and utilities.

## Components

- `cli.py` - Main CLI interface
- `core/` - Core utilities (errors, retry, health, config, container, monitoring)
- `commands/` - CLI command implementations (bootstrap, container, worktree, etc.)
- `testing/` - Testing utilities and AI safety

## Recent Improvements (v0.13.1)

### Dynamic Dependency Resolution
- **Hybrid resolver**: Local file → GitHub token → embedded manifest
- **Private repository support**: Works in containers and private repos
- **Zero hardcoded versions**: No more manual URL updates required
- **Auto-updating manifests**: Release process updates embedded dependencies

### Enhanced Core Modules
- **dependencies.py**: Dynamic package URL resolution for container environments
- **install.py**: Auto-installation utilities for missing dependencies
- **Improved CLI**: Better error handling and dependency management

### Container Compatibility
- **ModuleNotFoundError fixes**: Resolves shared-core import issues in containers
- **Release asset integration**: Packages distributed via GitHub releases
- **Authentication support**: Optional GITHUB_TOKEN for enhanced access

## Core Modules

### Monitoring (`core/monitoring/`)
- **hooks.py** - Pre/post hooks for capturing interactions
- **task_monitor.py** - Wrapper for monitoring Task tool calls

### Error Framework (`core/errors/`)
- Structured error handling with context management
- Correlation tracking for distributed operations

### Autofix (`core/autofix/`)
- Multi-stage convergent code fixing
- Automatic formatting and linting

## CLI Commands

<!-- auto-generated-start -->
```bash
# Main Commands
genesis autofix                   # Run autofix (formatting, linting) without committing changes
genesis bootstrap                 # Create new project with Genesis patterns and tooling
genesis branch                    # Manage Git branches
genesis checkout                  # Switch to a different branch or restore files
genesis clean                     # Clean workspace: remove old worktrees and build artifacts
genesis commit                    # Smart commit with quality gates and pre-commit hooks
genesis container                 # Manage Docker containers using docker-compose
genesis pull                      # Pull updates from remote repository
genesis reset                     # Reset current branch to a specific commit
genesis status                    # Check Genesis project health and component status
genesis sync                      # Update project support files from Genesis templates
genesis version                   # Show version information
genesis worktree                  # Manage AI-safe sparse worktrees for focused development
```
<!-- auto-generated-end -->

## Installation

```bash
# Install Genesis
pip install -e .

# Install enforcement hooks (recommended)
./scripts/install-genesis-hooks.sh
```

The hooks installation:
- Blocks direct `git commit` (enforces `genesis commit`)
- Ensures all commits go through quality gates
- See `.claude/hooks/block-bypass-commands.md` for Claude Code hook configuration

## CLI Commands

```bash
# General commands
genesis --help                   # Show help and all available commands
genesis status                   # Check Genesis project health
genesis clean                    # Clean workspace and remove old worktrees
genesis version                  # Version management utilities
genesis sync                     # Update shared components and dependencies

# Project management
genesis bootstrap my-project     # Create new project with Genesis patterns
genesis worktree create feature  # Manage AI-safe sparse worktrees
genesis commit -m "Add feature"  # Smart commit with quality gates
genesis commit -m "feat: add auth\n\nDetailed description"  # Multi-line commit
genesis autofix                  # Run formatting and linting without commit

# Container management
genesis container build          # Build Genesis development container
genesis container run            # Run Genesis container
genesis container shell          # Interactive shell in container
```
