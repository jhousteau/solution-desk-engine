# Genesis CLI Code Quality Scripts

Code quality and validation scripts for the Genesis CLI and core components.

## Available Scripts

### Code Quality Validation
- **check-ai-signatures.sh**: Check for forbidden AI attribution signatures in code
- **check-genesis-components.sh**: Ensure consistent use of Genesis components over standard library
- **check-variable-defaults.sh**: Check for variable default assignments that could be hardcoded values
- **find-hardcoded-values.sh**: Find hardcoded values and dangerous defaults in codebase
- **test-detection-scripts.sh**: Test all detection scripts for proper functionality

## Usage

Run scripts from the Genesis root directory:

```bash
# Check for AI signatures (should find none)
./genesis/scripts/check-ai-signatures.sh


# Ensure Genesis component usage
./genesis/scripts/check-genesis-components.sh

# Test all detection scripts
./genesis/scripts/test-detection-scripts.sh
```

## Quality Gates

These scripts enforce Genesis standards:
- **No AI attribution**: Professional code without AI signatures
- **Proper organization**: Files in correct directories (src/, scripts/, docs/, etc.)
- **Genesis components**: Use Genesis logger, retry, config instead of standard libraries
- **No hardcoded values**: All configuration must be explicit and environment-based
- **Fail-fast validation**: Clear errors when configuration is missing

## Integration

Scripts integrate with:
- Pre-commit hooks via `genesis commit`
- CI/CD pipelines for quality enforcement
- Genesis CLI autofix system
- Development workflow validation
