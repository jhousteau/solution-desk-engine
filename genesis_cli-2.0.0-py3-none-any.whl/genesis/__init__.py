"""
Genesis Development Toolkit

A unified development toolkit providing:
- CLI commands for project management
- Core utilities (config, health, logger, retry)
- Testing infrastructure
- Project templates and bootstrapping
- Infrastructure as code patterns

Usage:
    from genesis import get_logger, ConfigLoader
    from genesis.commands import bootstrap_project
"""

from pathlib import Path
from typing import Optional

# Import from genesis.core for consolidated package
from genesis.core import ConfigLoader, HealthCheck, get_logger

# Import version
from genesis.version import get_version

__version__ = get_version()
__author__ = "Genesis Team"


def find_genesis_root(start_path: Path | None = None) -> Path | None:
    """Find Genesis repository root by looking for key indicators.

    Args:
        start_path: Path to start search from (defaults to current working directory)

    Returns:
        Path to Genesis root directory, or None if not found
    """
    if start_path is None:
        start_path = Path.cwd()

    current = Path(start_path).resolve()

    # Look for Genesis indicators
    for parent in [current] + list(current.parents):
        # Check for Genesis-specific files
        if (parent / "genesis" / "cli.py").exists() and (
            parent / "pyproject.toml"
        ).exists():
            # Verify it's actually Genesis by checking pyproject.toml content
            try:
                pyproject_content = (parent / "pyproject.toml").read_text()
                if 'name = "genesis"' in pyproject_content:
                    return parent
            except (OSError, UnicodeDecodeError):
                continue

    return None


__all__ = [
    "get_logger",
    "ConfigLoader",
    "HealthCheck",
    "find_genesis_root",
    "__version__",
]
