"""Tests for Docker network conflict detection and resolution.

This test suite validates the network conflict detection functionality
added in issue #240 to provide clear error messages and automatic
subnet selection when Docker network conflicts are detected.
"""

import json
import os
import subprocess
from pathlib import Path
from unittest.mock import Mock, patch

import yaml

from genesis.commands.network_utils import (
    check_network_conflicts,
    format_conflict_message,
    get_available_subnet,
    get_existing_docker_networks,
    is_docker_running,
    parse_subnet_from_compose,
    resolve_network_conflicts,
    update_compose_subnet,
)
from genesis.core.constants import get_subnet_candidates


class TestDockerCheck:
    """Test Docker availability detection."""

    @patch("subprocess.run")
    def test_docker_running(self, mock_run: Mock) -> None:
        """Test detection of running Docker daemon."""
        mock_run.return_value = Mock(returncode=0)
        assert is_docker_running() is True
        mock_run.assert_called_once()

    @patch("subprocess.run")
    def test_docker_not_running(self, mock_run: Mock) -> None:
        """Test detection when Docker is not running."""
        mock_run.return_value = Mock(returncode=1)
        assert is_docker_running() is False

    @patch("subprocess.run")
    def test_docker_not_installed(self, mock_run: Mock) -> None:
        """Test detection when Docker is not installed."""
        mock_run.side_effect = FileNotFoundError()
        assert is_docker_running() is False

    @patch("subprocess.run")
    def test_docker_timeout(self, mock_run: Mock) -> None:
        """Test handling of Docker command timeout."""
        mock_run.side_effect = subprocess.TimeoutExpired("docker", 5)
        assert is_docker_running() is False


class TestNetworkDiscovery:
    """Test Docker network discovery."""

    @patch("genesis.commands.network_utils.is_docker_running")
    def test_get_networks_docker_not_running(self, mock_docker: Mock) -> None:
        """Test network discovery when Docker is not running."""
        mock_docker.return_value = False
        result = get_existing_docker_networks()
        assert result == {}

    @patch("subprocess.run")
    @patch("genesis.commands.network_utils.is_docker_running")
    def test_get_networks_success(self, mock_docker: Mock, mock_run: Mock) -> None:
        """Test successful network discovery."""
        mock_docker.return_value = True

        # Mock docker network ls output
        mock_ls_result = Mock(
            returncode=0, stdout='{"Name":"bridge"}\n{"Name":"custom_network"}\n'
        )

        # Mock docker network inspect outputs
        mock_inspect_bridge = Mock(
            returncode=0,
            stdout=json.dumps(
                [{"Name": "bridge", "IPAM": {"Config": [{"Subnet": "172.17.0.0/16"}]}}]
            ),
        )

        mock_inspect_custom = Mock(
            returncode=0,
            stdout=json.dumps(
                [
                    {
                        "Name": "custom_network",
                        "IPAM": {"Config": [{"Subnet": "10.89.0.0/24"}]},
                    }
                ]
            ),
        )

        mock_run.side_effect = [
            mock_ls_result,
            mock_inspect_bridge,
            mock_inspect_custom,
        ]

        result = get_existing_docker_networks()
        assert "bridge" in result
        assert "172.17.0.0/16" in result["bridge"]
        assert "custom_network" in result
        assert "10.89.0.0/24" in result["custom_network"]

    @patch("subprocess.run")
    @patch("genesis.commands.network_utils.is_docker_running")
    def test_get_networks_with_multiple_subnets(
        self, mock_docker: Mock, mock_run: Mock
    ) -> None:
        """Test network with multiple subnets."""
        mock_docker.return_value = True

        mock_ls_result = Mock(returncode=0, stdout='{"Name":"multi_subnet"}\n')

        mock_inspect = Mock(
            returncode=0,
            stdout=json.dumps(
                [
                    {
                        "Name": "multi_subnet",
                        "IPAM": {
                            "Config": [
                                {"Subnet": "10.1.0.0/24"},
                                {"Subnet": "10.2.0.0/24"},
                            ]
                        },
                    }
                ]
            ),
        )

        mock_run.side_effect = [mock_ls_result, mock_inspect]

        result = get_existing_docker_networks()
        assert "multi_subnet" in result
        assert len(result["multi_subnet"]) == 2
        assert "10.1.0.0/24" in result["multi_subnet"]
        assert "10.2.0.0/24" in result["multi_subnet"]

    @patch("subprocess.run")
    @patch("genesis.commands.network_utils.is_docker_running")
    def test_get_networks_handles_errors(
        self, mock_docker: Mock, mock_run: Mock
    ) -> None:
        """Test graceful handling of network inspection errors."""
        mock_docker.return_value = True

        mock_ls_result = Mock(returncode=0, stdout='{"Name":"error_network"}\n')

        # Simulate inspect failure
        mock_run.side_effect = [
            mock_ls_result,
            subprocess.CalledProcessError(1, "docker network inspect"),
        ]

        result = get_existing_docker_networks()
        assert result == {}


class TestComposeParser:
    """Test docker-compose.yml parsing."""

    def test_parse_subnet_from_compose(self, tmp_path: Path) -> None:
        """Test parsing subnet from compose file."""
        compose_file = tmp_path / "docker-compose.yml"
        compose_content = {
            "version": "3.8",
            "services": {"app": {"image": "myapp:latest"}},
            "networks": {"default": {"ipam": {"config": [{"subnet": "10.89.0.0/24"}]}}},
        }

        with open(compose_file, "w") as f:
            yaml.dump(compose_content, f)

        result = parse_subnet_from_compose(compose_file)
        assert result == "10.89.0.0/24"

    def test_parse_subnet_no_network_config(self, tmp_path: Path) -> None:
        """Test parsing when no network configuration exists."""
        compose_file = tmp_path / "docker-compose.yml"
        compose_content = {
            "version": "3.8",
            "services": {"app": {"image": "myapp:latest"}},
        }

        with open(compose_file, "w") as f:
            yaml.dump(compose_content, f)

        result = parse_subnet_from_compose(compose_file)
        assert result is None

    def test_parse_subnet_file_not_exists(self, tmp_path: Path) -> None:
        """Test parsing non-existent file."""
        compose_file = tmp_path / "nonexistent.yml"
        result = parse_subnet_from_compose(compose_file)
        assert result is None

    def test_parse_subnet_invalid_yaml(self, tmp_path: Path) -> None:
        """Test parsing invalid YAML file."""
        compose_file = tmp_path / "docker-compose.yml"
        with open(compose_file, "w") as f:
            f.write("invalid: yaml: content: [")

        result = parse_subnet_from_compose(compose_file)
        assert result is None


class TestConflictDetection:
    """Test network conflict detection."""

    @patch("genesis.commands.network_utils.is_docker_running")
    def test_no_conflict_docker_not_running(self, mock_docker: Mock) -> None:
        """Test no conflicts when Docker is not running."""
        mock_docker.return_value = False
        assert check_network_conflicts("10.89.0.0/24") is False

    @patch("genesis.commands.network_utils.is_docker_running")
    def test_conflict_detected(self, mock_docker: Mock) -> None:
        """Test conflict detection with overlapping subnets."""
        mock_docker.return_value = True

        existing = {"network1": ["10.89.0.0/24"], "network2": ["192.168.1.0/24"]}

        # Direct conflict
        assert check_network_conflicts("10.89.0.0/24", existing) is True
        # No conflict
        assert check_network_conflicts("10.88.0.0/24", existing) is False
        # Overlapping ranges
        assert check_network_conflicts("10.89.0.0/16", existing) is True

    @patch("genesis.commands.network_utils.is_docker_running")
    def test_invalid_subnet_treated_as_conflict(self, mock_docker: Mock) -> None:
        """Test that invalid subnets are treated as conflicts."""
        mock_docker.return_value = True
        assert check_network_conflicts("invalid.subnet", {}) is True


class TestSubnetSelection:
    """Test automatic subnet selection."""

    @patch("genesis.commands.network_utils.is_docker_running")
    def test_get_available_subnet_docker_not_running(self, mock_docker: Mock) -> None:
        """Test subnet selection when Docker is not running."""
        mock_docker.return_value = False
        result = get_available_subnet()
        assert result == get_subnet_candidates()[0]

    @patch("genesis.commands.network_utils.get_existing_docker_networks")
    @patch("genesis.commands.network_utils.is_docker_running")
    def test_get_available_subnet_first_available(
        self, mock_docker: Mock, mock_networks: Mock
    ) -> None:
        """Test selection of first available subnet."""
        mock_docker.return_value = True
        mock_networks.return_value = {
            "network1": ["10.89.0.0/24"],  # Conflicts with first candidate
        }

        result = get_available_subnet()
        assert result == "10.88.0.0/24"  # Second candidate

    @patch("genesis.commands.network_utils.get_existing_docker_networks")
    @patch("genesis.commands.network_utils.is_docker_running")
    def test_get_available_subnet_all_conflict(
        self, mock_docker: Mock, mock_networks: Mock
    ) -> None:
        """Test when all subnets conflict."""
        mock_docker.return_value = True
        # All default candidates conflict
        mock_networks.return_value = {
            f"network{i}": [subnet] for i, subnet in enumerate(get_subnet_candidates())
        }

        result = get_available_subnet()
        assert result is None

    @patch("genesis.commands.network_utils.get_existing_docker_networks")
    @patch("genesis.commands.network_utils.is_docker_running")
    def test_get_available_subnet_custom_candidates(
        self, mock_docker: Mock, mock_networks: Mock
    ) -> None:
        """Test with custom subnet candidates."""
        mock_docker.return_value = True
        mock_networks.return_value = {}

        custom_candidates = ["192.168.100.0/24", "192.168.101.0/24"]
        result = get_available_subnet(custom_candidates)
        assert result == "192.168.100.0/24"


class TestConflictResolution:
    """Test the main conflict resolution logic."""

    @patch.dict(os.environ, {"GENESIS_DOCKER_SUBNET": "10.99.0.0/24"})
    @patch("genesis.commands.network_utils.check_network_conflicts")
    def test_resolve_with_environment_override(
        self, mock_check: Mock, tmp_path: Path
    ) -> None:
        """Test resolution with GENESIS_DOCKER_SUBNET environment variable."""
        compose_file = tmp_path / "docker-compose.yml"
        compose_file.touch()

        mock_check.return_value = False

        has_conflict, current, suggested = resolve_network_conflicts(compose_file)
        assert has_conflict is False
        assert current == "10.99.0.0/24"
        assert suggested is None

    @patch("genesis.commands.network_utils.get_available_subnet")
    @patch("genesis.commands.network_utils.check_network_conflicts")
    @patch("genesis.commands.network_utils.parse_subnet_from_compose")
    def test_resolve_no_subnet_configured(
        self, mock_parse: Mock, mock_check: Mock, mock_available: Mock, tmp_path: Path
    ) -> None:
        """Test resolution when no subnet is configured."""
        compose_file = tmp_path / "docker-compose.yml"
        mock_parse.return_value = None
        mock_available.return_value = "10.89.0.0/24"

        has_conflict, current, suggested = resolve_network_conflicts(compose_file)
        assert has_conflict is False
        assert current is None
        assert suggested == "10.89.0.0/24"

    @patch("genesis.commands.network_utils.get_available_subnet")
    @patch("genesis.commands.network_utils.check_network_conflicts")
    @patch("genesis.commands.network_utils.parse_subnet_from_compose")
    def test_resolve_with_conflict(
        self, mock_parse: Mock, mock_check: Mock, mock_available: Mock, tmp_path: Path
    ) -> None:
        """Test resolution when conflict is detected."""
        compose_file = tmp_path / "docker-compose.yml"
        mock_parse.return_value = "10.89.0.0/24"
        mock_check.return_value = True
        mock_available.return_value = "10.88.0.0/24"

        has_conflict, current, suggested = resolve_network_conflicts(compose_file)
        assert has_conflict is True
        assert current == "10.89.0.0/24"
        assert suggested == "10.88.0.0/24"

    @patch("genesis.commands.network_utils.get_available_subnet")
    @patch("genesis.commands.network_utils.check_network_conflicts")
    @patch("genesis.commands.network_utils.parse_subnet_from_compose")
    def test_resolve_no_alternatives(
        self, mock_parse: Mock, mock_check: Mock, mock_available: Mock, tmp_path: Path
    ) -> None:
        """Test resolution when no alternatives are available."""
        compose_file = tmp_path / "docker-compose.yml"
        mock_parse.return_value = "10.89.0.0/24"
        mock_check.return_value = True
        mock_available.return_value = None

        has_conflict, current, suggested = resolve_network_conflicts(compose_file)
        assert has_conflict is True
        assert current == "10.89.0.0/24"
        assert suggested is None


class TestSubnetUpdate:
    """Test updating subnet in compose files."""

    def test_update_compose_subnet_success(self, tmp_path: Path) -> None:
        """Test successful subnet update."""
        compose_file = tmp_path / "docker-compose.yml"
        compose_content = {
            "version": "3.8",
            "services": {"app": {"image": "myapp"}},
            "networks": {"default": {"ipam": {"config": [{"subnet": "10.89.0.0/24"}]}}},
        }

        with open(compose_file, "w") as f:
            yaml.dump(compose_content, f)

        result = update_compose_subnet(compose_file, "10.88.0.0/24")
        assert result is True

        # Verify the update
        with open(compose_file) as f:
            updated = yaml.safe_load(f)

        subnet = updated["networks"]["default"]["ipam"]["config"][0]["subnet"]
        assert subnet == "10.88.0.0/24"

    def test_update_compose_subnet_add_new(self, tmp_path: Path) -> None:
        """Test adding subnet when none exists."""
        compose_file = tmp_path / "docker-compose.yml"
        compose_content = {
            "version": "3.8",
            "services": {"app": {"image": "myapp"}},
            "networks": {"default": {}},
        }

        with open(compose_file, "w") as f:
            yaml.dump(compose_content, f)

        result = update_compose_subnet(compose_file, "10.88.0.0/24")
        assert result is True

        # Verify the addition
        with open(compose_file) as f:
            updated = yaml.safe_load(f)

        subnet = updated["networks"]["default"]["ipam"]["config"][0]["subnet"]
        assert subnet == "10.88.0.0/24"

    def test_update_compose_subnet_file_not_exists(self, tmp_path: Path) -> None:
        """Test update with non-existent file."""
        compose_file = tmp_path / "nonexistent.yml"
        result = update_compose_subnet(compose_file, "10.88.0.0/24")
        assert result is False


class TestErrorMessages:
    """Test user-friendly error message formatting."""

    def test_format_conflict_message_with_details(self) -> None:
        """Test formatting with conflict details."""
        existing = {
            "my_project_default": ["10.89.0.0/24"],
            "other_network": ["192.168.1.0/24"],
        }

        message = format_conflict_message("10.89.0.0/24", "10.88.0.0/24", existing)

        assert "Docker network conflict detected" in message
        assert "10.89.0.0/24" in message
        assert "my_project_default" in message
        assert "10.88.0.0/24" in message
        assert "export GENESIS_DOCKER_SUBNET" in message

    def test_format_conflict_message_no_alternatives(self) -> None:
        """Test formatting when no alternatives available."""
        message = format_conflict_message("10.89.0.0/24", None, {})

        assert "Docker network conflict detected" in message
        assert "10.89.0.0/24" in message
        assert "export GENESIS_DOCKER_SUBNET=<your-subnet>" in message

    def test_format_conflict_message_many_conflicts(self) -> None:
        """Test formatting with many conflicting networks."""
        existing = {f"network_{i}": ["10.89.0.0/24"] for i in range(10)}

        message = format_conflict_message("10.89.0.0/24", "10.88.0.0/24", existing)

        # Should show first 3 and indicate there are more
        assert "network_0" in message
        assert "and 7 more" in message
