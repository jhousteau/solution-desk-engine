"""Tests for sync functionality with sync.yml configuration."""

import tempfile
from collections.abc import Generator
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml

from genesis.commands.sync import SyncManager


class TestSyncManager:
    """Test sync manager with sync.yml configuration."""

    @pytest.fixture
    def temp_project(self) -> Generator[Path]:
        """Create a temporary project directory for testing."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            # Create .genesis directory
            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            # Create pyproject.toml to identify as Python project
            pyproject_content = """
[tool.poetry]
name = "test-project"
version = "0.1.0"
description = "Test project"

[tool.poetry.dependencies]
python = "^3.11"
fastapi = "^0.100.0"
"""
            (project_path / "pyproject.toml").write_text(pyproject_content.strip())

            # Create sync.yml configuration
            sync_config = {
                "template_source": "templates/python-api",
                "sync_policies": [
                    {
                        "source": "Makefile.template",
                        "dest": "Makefile",
                        "policy": "if_unchanged",
                    },
                    {
                        "source": "README.md.template",
                        "dest": "README.md",
                        "policy": "never",
                    },
                ],
            }
            with open(genesis_dir / "sync.yml", "w") as f:
                yaml.dump(sync_config, f)

            yield project_path

    @pytest.fixture
    def mock_template_manager(self) -> MagicMock:
        """Mock template manager for testing."""
        manager = MagicMock()
        manager.get_template.return_value = "test: echo '{{project_name}}'"
        return manager

    def test_config_loading(self, temp_project: Path) -> None:
        """Test loading sync configuration from sync.yml."""
        manager = SyncManager(temp_project)
        config = manager.load_config()

        assert config["template_source"] == "templates/python-api"
        assert "sync_policies" in config
        assert len(config["sync_policies"]) == 2

    def test_config_missing_fails(self, temp_project: Path) -> None:
        """Test that missing sync.yml raises appropriate error."""
        # Remove sync.yml
        (temp_project / ".genesis" / "sync.yml").unlink()

        manager = SyncManager(temp_project)
        with pytest.raises(FileNotFoundError) as exc_info:
            manager.load_config()

        assert "Sync configuration not found" in str(exc_info.value)

    def test_template_variable_extraction(self, temp_project: Path) -> None:
        """Test extraction of template variables from project files."""
        manager = SyncManager(temp_project)
        variables = manager.get_template_variables()

        assert variables["project_name"] == "test-project"
        assert variables["module_name"] == "test_project"
        assert variables["project_description"] == "Test project"
        assert variables["project_version"] == "0.1.0"
        assert variables["python_version"] == "3.11"
        assert "app_port" in variables
        assert "subnet_octet" in variables

    def test_sync_policy_always(self, temp_project: Path) -> None:
        """Test that 'always' policy always syncs files."""
        manager = SyncManager(temp_project)

        # Test non-existent file
        dest_path = temp_project / "new_file.txt"
        assert manager._check_sync_policy(dest_path, "always") is True

        # Test existing file
        dest_path.write_text("existing content")
        assert manager._check_sync_policy(dest_path, "always") is True

    def test_sync_policy_never(self, temp_project: Path) -> None:
        """Test that 'never' policy only creates new files."""
        manager = SyncManager(temp_project)

        # Test non-existent file - should sync
        dest_path = temp_project / "new_file.txt"
        assert manager._check_sync_policy(dest_path, "never") is True

        # Test existing file - should not sync
        dest_path.write_text("existing content")
        assert manager._check_sync_policy(dest_path, "never") is False

    def test_sync_policy_if_unchanged(self, temp_project: Path) -> None:
        """Test that 'if_unchanged' policy only syncs new files."""
        manager = SyncManager(temp_project)

        # Test non-existent file - should sync
        dest_path = temp_project / "new_file.txt"
        assert manager._check_sync_policy(dest_path, "if_unchanged") is True

        # Test existing file - should not sync (simplified logic)
        dest_path.write_text("existing content")
        assert manager._check_sync_policy(dest_path, "if_unchanged") is False

    def test_template_processing(self, temp_project: Path) -> None:
        """Test template content processing with variables."""
        manager = SyncManager(temp_project)
        variables = {"project_name": "test-project", "version": "1.0.0"}

        template_content = "Project: {{project_name}}\nVersion: {{version}}"
        processed = manager.process_template(template_content, variables)

        assert processed == "Project: test-project\nVersion: 1.0.0"

    @patch("genesis.commands.sync.get_template_manager")
    def test_file_sync_dry_run(
        self,
        mock_get_manager: MagicMock,
        temp_project: Path,
        mock_template_manager: MagicMock,
    ) -> None:
        """Test file sync in dry run mode."""
        mock_get_manager.return_value = mock_template_manager

        manager = SyncManager(temp_project, dry_run=True)
        variables = manager.get_template_variables()

        result = manager.sync_file("Makefile.template", "Makefile", "always", variables)

        assert result is True
        assert "Makefile" in manager.synced_files
        assert not (
            temp_project / "Makefile"
        ).exists()  # No actual file created in dry run

    @patch("genesis.commands.sync.get_template_manager")
    def test_full_sync_workflow(
        self,
        mock_get_manager: MagicMock,
        temp_project: Path,
        mock_template_manager: MagicMock,
    ) -> None:
        """Test the complete sync workflow."""
        mock_get_manager.return_value = mock_template_manager

        manager = SyncManager(temp_project, dry_run=True)

        with patch("genesis.commands.sync.logger") as mock_logger:
            updated_count = manager.sync()

            # Should process sync policies
            assert updated_count >= 0
            mock_logger.info.assert_called()

    def test_force_sync_behavior(self, temp_project: Path) -> None:
        """Test that force flag bypasses policy restrictions."""
        manager = SyncManager(temp_project, force=True)

        # Create existing file that normally wouldn't sync with 'if_unchanged'
        dest_path = temp_project / "existing_file.txt"
        dest_path.write_text("existing content")

        # Force should override policy (except 'never')
        assert manager._should_sync_file_policy(dest_path, "if_unchanged") is True
        assert (
            manager._should_sync_file_policy(dest_path, "never") is False
        )  # Never is still respected

    def test_error_handling(self, temp_project: Path) -> None:
        """Test error handling during sync operations."""
        # Create invalid sync config
        invalid_config = {"invalid": "config"}
        with open(temp_project / ".genesis" / "sync.yml", "w") as f:
            yaml.dump(invalid_config, f)

        manager = SyncManager(temp_project)
        with pytest.raises(yaml.YAMLError, match="missing required field"):
            manager.load_config()
