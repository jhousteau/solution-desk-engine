# Tmpfs Integration Testing Guide

This document explains the comprehensive test suite for GitHub issue #268: "Container tmpfs fills up causing 'No space left on device' errors".

## Test Overview

The tmpfs test suite validates the complete solution including:

1. **Container Configuration Changes** - Increased tmpfs sizes and cache environment variables
2. **Cleanup Script Functionality** - Complete validation of cleanup-temp.sh
3. **Genesis CLI Integration** - tmpfs-cleanup command and clean command integration
4. **Tmpfs Monitoring** - Usage monitoring in genesis status
5. **AI Safety Integration** - Ensuring AI safety constraints work with tmpfs changes
6. **Real-World Scenarios** - Extended development workflows and stress testing

## Test Files

### Core Integration Tests
- `test_tmpfs_integration.py` - Main integration tests covering all components
- `test_tmpfs_suite.py` - Test suite runner and validation

### Component-Specific Tests
- `test_cleanup_script_integration.py` - Detailed cleanup script testing
- `test_container_tmpfs_cli.py` - CLI command integration testing
- `test_tmpfs_monitoring.py` - Usage monitoring and status integration
- `test_tmpfs_ai_safety_integration.py` - AI safety constraint validation
- `test_tmpfs_workflow_scenarios.py` - Real-world development scenarios

## Running the Tests

### Complete Test Suite
```bash
# Run all tmpfs-related tests
pytest genesis/tests/test_tmpfs_suite.py -v

# Run all tmpfs tests with coverage
pytest genesis/tests/test_tmpfs_*.py --cov=genesis --cov-report=html
```

### By Test Category
```bash
# Container configuration tests
pytest genesis/tests/test_tmpfs_integration.py::TestTmpfsContainerConfiguration -v

# Cleanup script tests
pytest genesis/tests/test_cleanup_script_integration.py -v

# CLI integration tests
pytest genesis/tests/test_container_tmpfs_cli.py -v

# Monitoring tests
pytest genesis/tests/test_tmpfs_monitoring.py -v

# AI safety integration tests
pytest genesis/tests/test_tmpfs_ai_safety_integration.py -v

# Workflow scenario tests
pytest genesis/tests/test_tmpfs_workflow_scenarios.py -v
```

### By Test Markers
```bash
# Integration tests only
pytest -m integration genesis/tests/test_tmpfs_*.py

# AI safety tests only
pytest -m ai_safety genesis/tests/test_tmpfs_*.py

# Slow tests (extended scenarios)
pytest -m slow genesis/tests/test_tmpfs_*.py

# Skip slow tests
pytest -m "not slow" genesis/tests/test_tmpfs_*.py
```

### Specific Test Areas
```bash
# Test docker-compose configuration
pytest genesis/tests/test_tmpfs_integration.py::TestTmpfsContainerConfiguration::test_docker_compose_tmpfs_sizes -v

# Test cleanup script options
pytest genesis/tests/test_cleanup_script_integration.py::TestCleanupScriptFunctionality::test_parameter_validation -v

# Test CLI command availability
pytest genesis/tests/test_container_tmpfs_cli.py::TestContainerTmpfsCleanupCommand::test_command_availability -v

# Test status monitoring
pytest genesis/tests/test_tmpfs_monitoring.py::TestTmpfsUsageMonitoring -v
```

## Test Environment Setup

### Prerequisites
```bash
# Ensure environment is loaded
source .envrc

# Install test dependencies
poetry install --with dev

# Verify Docker is available (for container tests)
docker --version
docker-compose --version || docker compose version
```

### Environment Variables for Testing
```bash
# Enable slow tests (optional)
export RUN_SLOW_TESTS=1

# Test environment
export ENV=test
export PROJECT_MODE=test
export LOG_LEVEL=info
```

## Test Categories Explained

### 1. Container Configuration Tests
Validates the docker-compose.yml changes:
- tmpfs sizes (500MB /tmp, 200MB /var/tmp)
- Environment variables (PYTEST_CACHE_DIR, PIP_NO_CACHE_DIR)
- Security settings preservation
- Profile configurations

### 2. Cleanup Script Tests
Comprehensive testing of scripts/cleanup-temp.sh:
- All command-line options (--max-age, --dry-run, --force, --verbose)
- File age filtering and preservation logic
- Safety checks for container environments
- Error handling and recovery
- Different file type cleanup (pytest, pip, logs, build artifacts)

### 3. CLI Integration Tests
Tests Genesis CLI integration:
- `genesis container tmpfs-cleanup` command
- Integration with `genesis clean --tmpfs`
- Error handling when container not running
- Docker compose version compatibility (v1 and v2)

### 4. Monitoring Tests
Tests tmpfs usage monitoring:
- Integration with `genesis status` command
- Usage detection and display
- Warning thresholds and color coding
- Performance and efficiency

### 5. AI Safety Integration Tests
Ensures AI safety constraints work with tmpfs changes:
- File count limits are maintained
- Worktree operations work correctly
- Cache configurations don't interfere with AI safety
- Monitoring systems coordinate properly

### 6. Workflow Scenario Tests
Real-world development scenarios:
- Extended development sessions (48+ hours)
- Multiple pytest runs with cache accumulation
- Package installation and cleanup workflows
- Error recovery scenarios
- Performance validation

## Expected Test Results

### Success Criteria
- All container configuration tests pass
- Cleanup script handles all options correctly
- CLI commands integrate properly
- Monitoring provides accurate information
- AI safety constraints are preserved
- Real-world scenarios complete without tmpfs issues

### Test Metrics
- **Container Configuration**: ~8 tests covering all docker-compose changes
- **Cleanup Script**: ~17 tests covering all functionality
- **CLI Integration**: ~21 tests covering command integration
- **Monitoring**: ~17 tests covering usage monitoring
- **AI Safety**: ~15 tests covering constraint preservation
- **Workflows**: ~18 tests covering real-world scenarios

### Performance Expectations
- Container configuration tests: < 5 seconds
- Cleanup script tests: < 10 seconds
- CLI integration tests: < 15 seconds
- Monitoring tests: < 10 seconds
- AI safety tests: < 10 seconds
- Workflow tests: < 20 seconds (excluding slow tests)

## Troubleshooting

### Common Issues

#### Docker Not Available
```bash
# Error: Docker not available
# Solution: Install Docker and ensure daemon is running
sudo systemctl start docker
docker --version
```

#### Container Not Running
```bash
# Error: Container not running tests fail
# Solution: These are expected failures when testing error conditions
# The tests validate proper error handling
```

#### Slow Test Timeouts
```bash
# Error: Tests timeout
# Solution: Increase timeout or skip slow tests
pytest -m "not slow" genesis/tests/test_tmpfs_*.py
```

#### Import Errors
```bash
# Error: Cannot import test modules
# Solution: Ensure environment is loaded and dependencies installed
source .envrc
poetry install --with dev
```

### Test Debugging

#### Verbose Output
```bash
# Get detailed test output
pytest genesis/tests/test_tmpfs_integration.py -v -s

# Show test execution details
pytest genesis/tests/test_tmpfs_integration.py -vv --tb=long
```

#### Individual Test Debugging
```bash
# Run single test with full output
pytest genesis/tests/test_tmpfs_integration.py::TestTmpfsContainerConfiguration::test_docker_compose_tmpfs_sizes -v -s --tb=long
```

#### Coverage Analysis
```bash
# Generate coverage report
pytest genesis/tests/test_tmpfs_*.py --cov=genesis.commands.container --cov=genesis.cli --cov-report=html

# View coverage report
open htmlcov/index.html
```

## Contributing to Tests

### Adding New Tests
1. Choose appropriate test file based on functionality
2. Follow existing test patterns and naming conventions
3. Use appropriate pytest markers (@pytest.mark.integration, @pytest.mark.ai_safety, etc.)
4. Include comprehensive docstrings explaining what is tested
5. Mock external dependencies appropriately
6. Update this documentation if adding new test categories

### Test Development Guidelines
- **Integration-first**: Test real system operations when possible
- **Comprehensive coverage**: Test both success and failure scenarios
- **Clear assertions**: Test messages should clearly indicate what failed
- **Proper cleanup**: Ensure tests don't leave artifacts or affect other tests
- **Performance conscious**: Tests should complete in reasonable time
- **AI safety aware**: Consider AI safety implications in all tests

## Related Documentation

- [GitHub Issue #268](https://github.com/organization/genesis/issues/268)
- [Container Configuration](../docker-compose.yml)
- [Cleanup Script](../scripts/cleanup-temp.sh)
- [Genesis CLI Commands](../genesis/commands/container.py)
- [Project Testing Guide](../../TESTING.md)
