"""
Integration tests for hash-based sync optimization (Phase 2).

Tests that the hash-based skip logic correctly optimizes sync operations
by skipping files whose hashes match the manifest.
"""

from pathlib import Path
from typing import Any
from unittest.mock import Mock

import yaml

from genesis.commands.sync import SyncManager
from genesis.core.hash_utils import calculate_file_hash


class TestHashBasedSyncIntegration:
    """Test hash-based sync optimization"""

    def test_hash_match_skips_sync(self, tmp_path: Path) -> None:
        """Test that files with matching hashes are skipped"""
        # Create a project directory
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        genesis_dir = project_dir / ".genesis"
        genesis_dir.mkdir()

        # Create a test file with known content
        test_file = project_dir / "test.txt"
        test_content = "Test content for hash matching\n"
        test_file.write_text(test_content)

        # Calculate the hash
        file_hash = calculate_file_hash(test_file)

        # Create sync.yml with hash
        sync_config = {
            "version": "1.0",
            "template_source": "test",
            "project": {"name": "test", "type": "test"},
            "variables": {},
            "sync_policies": [
                {
                    "source": "test.txt",
                    "dest": "test.txt",
                    "policy": "always",
                    "source_hash": file_hash,
                }
            ],
        }

        sync_yml = genesis_dir / "sync.yml"
        with open(sync_yml, "w") as f:
            yaml.dump(sync_config, f)

        # Create sync manager with mocked template manager
        mock_template_manager = Mock()
        mock_template_manager.get_template = Mock(return_value=test_content)

        sync_manager = SyncManager(
            project_path=project_dir,
            force=False,
            dry_run=False,
            preview=False,
            verbose=True,
            template_manager=mock_template_manager,
        )

        # Load config
        _ = sync_manager.load_config()

        # Manually populate source_hashes to test optimization in isolation
        sync_manager.source_hashes["test.txt"] = file_hash

        # Perform sync - should skip due to hash match
        sync_manager._perform_file_sync(
            source="test.txt", dest="test.txt", dest_path=test_file, variables={}
        )

        # Verify file was skipped (not synced)
        assert "test.txt" in sync_manager.skipped_files
        assert "test.txt" not in sync_manager.synced_files

        # Verify template was NOT fetched (optimization working)
        mock_template_manager.get_template.assert_not_called()

    def test_hash_mismatch_triggers_sync(self, tmp_path: Path) -> None:
        """Test that files with different hashes are synced"""
        # Create a project directory
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        genesis_dir = project_dir / ".genesis"
        genesis_dir.mkdir()

        # Create a test file with content
        test_file = project_dir / "test.txt"
        old_content = "Old content\n"
        test_file.write_text(old_content)

        # Use a different hash (simulating template change)
        new_content = "New content from template\n"

        # Create sync.yml with wrong hash
        sync_config = {
            "version": "1.0",
            "template_source": "test",
            "project": {"name": "test", "type": "test"},
            "variables": {},
            "sync_policies": [
                {
                    "source": "test.txt",
                    "dest": "test.txt",
                    "policy": "always",
                    "source_hash": f"sha256:{'0' * 64}",  # Wrong hash
                }
            ],
        }

        sync_yml = genesis_dir / "sync.yml"
        with open(sync_yml, "w") as f:
            yaml.dump(sync_config, f)

        # Create sync manager with mocked template manager
        mock_template_manager = Mock()
        mock_template_manager.get_template = Mock(return_value=new_content)

        sync_manager = SyncManager(
            project_path=project_dir,
            force=False,
            dry_run=False,
            preview=False,
            verbose=True,
            template_manager=mock_template_manager,
        )

        # Load config
        sync_manager.load_config()

        # Perform sync - should proceed because hash doesn't match
        sync_manager._perform_file_sync(
            source="test.txt", dest="test.txt", dest_path=test_file, variables={}
        )

        # Verify template WAS fetched (no optimization, hash mismatch)
        mock_template_manager.get_template.assert_called()

        # Verify file was synced (not skipped)
        assert "test.txt" in sync_manager.synced_files
        assert test_file.read_text() == new_content

    def test_backward_compatibility_without_hashes(self, tmp_path: Path) -> None:
        """Test that sync works without source_hash fields (backward compatibility)"""
        # Create a project directory
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        genesis_dir = project_dir / ".genesis"
        genesis_dir.mkdir()

        # Create a test file
        test_file = project_dir / "test.txt"
        old_content = "Old content\n"
        test_file.write_text(old_content)

        # Create sync.yml WITHOUT hash fields
        sync_config = {
            "version": "1.0",
            "template_source": "test",
            "project": {"name": "test", "type": "test"},
            "variables": {},
            "sync_policies": [
                {
                    "source": "test.txt",
                    "dest": "test.txt",
                    "policy": "always",
                    # NO source_hash field
                }
            ],
        }

        sync_yml = genesis_dir / "sync.yml"
        with open(sync_yml, "w") as f:
            yaml.dump(sync_config, f)

        # Create sync manager
        new_content = "New content\n"
        mock_template_manager = Mock()
        mock_template_manager.get_template = Mock(return_value=new_content)

        sync_manager = SyncManager(
            project_path=project_dir,
            force=False,
            dry_run=False,
            preview=False,
            verbose=True,
            template_manager=mock_template_manager,
        )

        # Load config - should work without hashes
        sync_manager.load_config()
        assert "test.txt" not in sync_manager.source_hashes

        # Perform sync - should work normally
        sync_manager._perform_file_sync(
            source="test.txt", dest="test.txt", dest_path=test_file, variables={}
        )

        # Verify template was fetched (no hash optimization available)
        mock_template_manager.get_template.assert_called()

        # Verify file was synced
        assert test_file.read_text() == new_content

    def test_performance_benefit_multiple_files(self, tmp_path: Path) -> None:
        """Test that hash optimization provides performance benefit with multiple files"""
        # Create a project directory
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()
        genesis_dir = project_dir / ".genesis"
        genesis_dir.mkdir()

        # Create multiple test files
        num_files = 10
        files_data: dict[str, dict[str, Any]] = {}
        sync_policies = []

        for i in range(num_files):
            filename = f"test_{i}.txt"
            content = f"Test content {i}\n"
            test_file = project_dir / filename
            test_file.write_text(content)
            file_hash = calculate_file_hash(test_file)

            files_data[filename] = {
                "path": test_file,
                "content": content,
                "hash": file_hash,
            }
            sync_policies.append(
                {
                    "source": filename,
                    "dest": filename,
                    "policy": "always",
                    "source_hash": file_hash,
                }
            )

        # Create sync.yml
        sync_config = {
            "version": "1.0",
            "template_source": "test",
            "project": {"name": "test", "type": "test"},
            "variables": {},
            "sync_policies": sync_policies,
        }

        sync_yml = genesis_dir / "sync.yml"
        with open(sync_yml, "w") as f:
            yaml.dump(sync_config, f)

        # Create sync manager with call tracking
        mock_template_manager = Mock()

        def get_template_side_effect(source: str) -> str:
            content = files_data[source]["content"]
            assert isinstance(content, str)
            return content

        mock_template_manager.get_template = Mock(side_effect=get_template_side_effect)

        sync_manager = SyncManager(
            project_path=project_dir,
            force=False,
            dry_run=False,
            preview=False,
            verbose=True,
            template_manager=mock_template_manager,
        )

        # Load config
        _ = sync_manager.load_config()

        # Manually populate source_hashes to test optimization
        for filename, data in files_data.items():
            file_hash = data["hash"]
            assert isinstance(file_hash, str)
            sync_manager.source_hashes[filename] = file_hash

        # Sync all files by calling _perform_file_sync for each
        for filename in files_data.keys():
            dest_path = files_data[filename]["path"]
            assert isinstance(dest_path, Path)
            sync_manager._perform_file_sync(
                source=filename,
                dest=filename,
                dest_path=dest_path,
                variables={},
            )

        # Verify NO template fetches happened (all skipped via hash optimization)
        assert mock_template_manager.get_template.call_count == 0, (
            f"Expected 0 template fetches but got {mock_template_manager.get_template.call_count}. "
            f"Hash optimization should skip all {num_files} files."
        )

        # Verify all files were skipped (not synced)
        assert (
            len(sync_manager.skipped_files) == num_files
        ), f"Expected {num_files} files skipped but got {len(sync_manager.skipped_files)}"
        assert (
            len(sync_manager.synced_files) == 0
        ), f"Expected 0 files synced but got {len(sync_manager.synced_files)}"
