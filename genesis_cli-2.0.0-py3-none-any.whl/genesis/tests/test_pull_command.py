"""Tests for Genesis pull command with real Git operations."""

import os
import subprocess
import tempfile
from pathlib import Path

from click.testing import CliRunner

from genesis.cli import cli


class TestPullCommand:
    """Test pull command with real Git operations."""

    def setup_method(self) -> None:
        """Set up test environment."""
        self.original_dir = os.getcwd()

    def teardown_method(self) -> None:
        """Restore original directory."""
        os.chdir(self.original_dir)

    def test_pull_in_clean_repo(self, tmp_path: Path) -> None:
        """Test pull in a clean repository with no changes."""
        # Create two repositories - origin and clone
        origin_path = tmp_path / "origin"
        clone_path = tmp_path / "clone"
        origin_path.mkdir()

        # Initialize origin repository
        os.chdir(origin_path)
        subprocess.run(["git", "init", "--bare"], capture_output=True, check=True)

        # Create a clone
        os.chdir(tmp_path)
        subprocess.run(
            ["git", "clone", str(origin_path), "clone"], capture_output=True, check=True
        )

        os.chdir(clone_path)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create initial commit
        test_file = clone_path / "test.txt"
        test_file.write_text("initial content")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], capture_output=True)
        subprocess.run(
            ["git", "push", "origin", "main"], capture_output=True, check=False
        )
        subprocess.run(
            ["git", "push", "origin", "master"], capture_output=True, check=False
        )

        runner = CliRunner()
        result = runner.invoke(cli, ["pull"])

        assert result.exit_code == 0
        # Should indicate already up to date
        assert (
            "up to date" in result.output.lower()
            or "up-to-date" in result.output.lower()
        )

    def test_pull_with_remote_changes(self, tmp_path: Path) -> None:
        """Test pulling actual changes from remote."""
        # Create origin and two clones
        origin_path = tmp_path / "origin"
        clone1_path = tmp_path / "clone1"
        clone2_path = tmp_path / "clone2"

        # Initialize bare origin repository
        origin_path.mkdir()
        os.chdir(origin_path)
        subprocess.run(["git", "init", "--bare"], capture_output=True, check=True)

        # Create first clone and make initial commit
        os.chdir(tmp_path)
        subprocess.run(
            ["git", "clone", str(origin_path), "clone1"],
            capture_output=True,
            check=True,
        )

        os.chdir(clone1_path)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        test_file = clone1_path / "test.txt"
        test_file.write_text("initial content")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], capture_output=True)

        # Try both main and master branch names
        push_result = subprocess.run(
            ["git", "push", "origin", "main"], capture_output=True
        )
        if push_result.returncode != 0:
            subprocess.run(["git", "push", "origin", "master"], capture_output=True)

        # Create second clone
        os.chdir(tmp_path)
        subprocess.run(
            ["git", "clone", str(origin_path), "clone2"],
            capture_output=True,
            check=True,
        )

        # Make changes in first clone and push
        os.chdir(clone1_path)
        new_file = clone1_path / "new.txt"
        new_file.write_text("new content")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Add new file"], capture_output=True)
        subprocess.run(["git", "push"], capture_output=True)

        # Pull changes in second clone
        os.chdir(clone2_path)
        runner = CliRunner()
        result = runner.invoke(cli, ["pull"])

        assert result.exit_code == 0
        # Verify new file was pulled
        assert (clone2_path / "new.txt").exists()
        assert (clone2_path / "new.txt").read_text() == "new content"

    def test_pull_with_merge_conflict(self, tmp_path: Path) -> None:
        """Test pull with merge conflicts."""
        # Create origin and two clones
        origin_path = tmp_path / "origin"
        clone1_path = tmp_path / "clone1"
        clone2_path = tmp_path / "clone2"

        # Setup repositories
        origin_path.mkdir()
        os.chdir(origin_path)
        subprocess.run(["git", "init", "--bare"], capture_output=True, check=True)

        # First clone with initial commit
        os.chdir(tmp_path)
        subprocess.run(
            ["git", "clone", str(origin_path), "clone1"],
            capture_output=True,
            check=True,
        )

        os.chdir(clone1_path)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        test_file = clone1_path / "test.txt"
        test_file.write_text("initial content")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], capture_output=True)

        # Push to origin (try both main and master)
        push_result = subprocess.run(
            ["git", "push", "origin", "main"], capture_output=True
        )
        if push_result.returncode != 0:
            subprocess.run(["git", "push", "origin", "master"], capture_output=True)

        # Create second clone
        os.chdir(tmp_path)
        subprocess.run(
            ["git", "clone", str(origin_path), "clone2"],
            capture_output=True,
            check=True,
        )
        os.chdir(clone2_path)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Make conflicting changes in both clones
        os.chdir(clone1_path)
        test_file.write_text("content from clone1")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(
            ["git", "commit", "-m", "Change from clone1"], capture_output=True
        )
        subprocess.run(["git", "push"], capture_output=True)

        os.chdir(clone2_path)
        test_file = clone2_path / "test.txt"
        test_file.write_text("content from clone2")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(
            ["git", "commit", "-m", "Change from clone2"], capture_output=True
        )

        # Try to pull - should result in conflict
        runner = CliRunner()
        result = runner.invoke(cli, ["pull"])

        # Pull should fail or report conflict
        if result.exit_code != 0:
            assert (
                "conflict" in result.output.lower()
                or "diverged" in result.output.lower()
            )

    def test_pull_with_rebase(self, tmp_path: Path) -> None:
        """Test pull with rebase option."""
        # Setup origin and clone
        origin_path = tmp_path / "origin"
        clone_path = tmp_path / "clone"

        origin_path.mkdir()
        os.chdir(origin_path)
        subprocess.run(["git", "init", "--bare"], capture_output=True, check=True)

        os.chdir(tmp_path)
        subprocess.run(
            ["git", "clone", str(origin_path), "clone"], capture_output=True, check=True
        )

        os.chdir(clone_path)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create initial commit
        test_file = clone_path / "test.txt"
        test_file.write_text("initial")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], capture_output=True)
        subprocess.run(
            ["git", "push", "origin", "main"], capture_output=True, check=False
        )
        subprocess.run(
            ["git", "push", "origin", "master"], capture_output=True, check=False
        )

        runner = CliRunner()
        result = runner.invoke(cli, ["pull", "--rebase"])

        # Should complete successfully
        assert result.exit_code == 0

    def test_pull_not_in_git_repo(self, tmp_path: Path) -> None:
        """Test pull command outside Git repository."""
        original_dir = Path.cwd()
        try:
            with tempfile.TemporaryDirectory(dir="/tmp") as temp_dir:
                os.chdir(temp_dir)

                runner = CliRunner()
                result = runner.invoke(cli, ["pull"])

                # Should fail when not in a git repository
                assert result.exit_code != 0
                assert (
                    "not a git repository" in result.output.lower()
                    or "fatal" in result.output.lower()
                )
        finally:
            os.chdir(original_dir)

    def test_pull_no_remote(self, tmp_path: Path) -> None:
        """Test pull in repository with no remote."""
        os.chdir(tmp_path)

        # Create local repository without remote
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        test_file = tmp_path / "test.txt"
        test_file.write_text("content")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], capture_output=True)

        runner = CliRunner()
        result = runner.invoke(cli, ["pull"])

        # Should fail or indicate no remote
        assert result.exit_code != 0
        assert (
            "no remote" in result.output.lower()
            or "no tracking" in result.output.lower()
        )

    def test_pull_specific_remote_and_branch(self, tmp_path: Path) -> None:
        """Test pulling from specific remote and branch."""
        # Create origin repository
        origin_path = tmp_path / "origin"
        clone_path = tmp_path / "clone"

        origin_path.mkdir()
        os.chdir(origin_path)
        subprocess.run(["git", "init", "--bare"], capture_output=True, check=True)

        # Clone and setup
        os.chdir(tmp_path)
        subprocess.run(
            ["git", "clone", str(origin_path), "clone"], capture_output=True, check=True
        )

        os.chdir(clone_path)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create initial commit
        test_file = clone_path / "test.txt"
        test_file.write_text("initial")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial"], capture_output=True)

        # Try to pull from specific remote and branch
        runner = CliRunner()
        result = runner.invoke(cli, ["pull", "origin", "main"])

        # Command should handle this appropriately
        assert result.exit_code in [0, 1]


class TestPullCommandIntegration:
    """Integration tests for pull command with other Git operations."""

    def test_pull_after_local_changes(self, tmp_path: Path) -> None:
        """Test pull after making local changes."""
        # Setup origin repo with an initial commit
        origin_path = tmp_path / "origin"
        origin_path.mkdir()
        os.chdir(origin_path)
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create initial commit in origin
        (origin_path / "README.md").write_text("Initial commit")
        subprocess.run(["git", "add", "."], capture_output=True, check=True)
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"], capture_output=True, check=True
        )

        # Clone the repository
        clone_path = tmp_path / "clone"
        os.chdir(tmp_path)
        subprocess.run(
            ["git", "clone", str(origin_path), "clone"], capture_output=True, check=True
        )

        os.chdir(clone_path)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Make local changes without committing
        test_file = clone_path / "test.txt"
        test_file.write_text("local changes")

        runner = CliRunner()
        result = runner.invoke(cli, ["pull"])

        # Should succeed since there are no remote changes to conflict with
        # or handle local changes appropriately
        assert result.exit_code in [0, 1]

        # If there are any error messages, they should be about git operations
        if result.exit_code != 0 and result.output:
            assert any(
                word in result.output.lower()
                for word in ["git", "pull", "fetch", "merge", "remote"]
            )
