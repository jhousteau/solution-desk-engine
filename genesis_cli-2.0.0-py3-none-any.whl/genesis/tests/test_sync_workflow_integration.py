"""End-to-end integration tests for Genesis sync workflow."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml

from genesis.commands.sync import SyncManager


@pytest.mark.integration
class TestSyncWorkflowIntegration:
    """End-to-end integration tests for the complete sync workflow."""

    def setup_test_project(self, tmp_path: Path) -> Path:
        """Set up a test project and Genesis templates structure."""
        # Create project directory
        project_path = tmp_path / "test_project"
        project_path.mkdir()

        # Create .genesis directory
        genesis_dir = project_path / ".genesis"
        genesis_dir.mkdir()

        # Create pyproject.toml to help with project type detection
        pyproject_content = """[tool.poetry]
name = "test-project"
version = "0.1.0"
description = "Test project for Genesis sync"

[tool.poetry.dependencies]
python = "^3.11"
fastapi = "^0.100.0"

[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
"""
        (project_path / "pyproject.toml").write_text(pyproject_content)

        # Create sync.yml configuration (required by new sync system)
        sync_config = {
            "template_source": "templates/python-api",
            "sync_policies": [
                {
                    "source": "Dockerfile.template",
                    "dest": "Dockerfile",
                    "policy": "always",
                },
                {
                    "source": ".gitignore.template",
                    "dest": ".gitignore",
                    "policy": "if_unchanged",
                },
                {
                    "source": "README.md.template",
                    "dest": "README.md",
                    "policy": "never",
                },
                {
                    "source": "config.yaml.template",
                    "dest": "config.yaml",
                    "policy": "if_unchanged",
                },
            ],
        }

        sync_yml_path = project_path / ".genesis" / "sync.yml"
        with open(sync_yml_path, "w") as f:
            yaml.dump(sync_config, f)

        return project_path

    @patch("genesis.commands.sync.get_template_manager")
    def test_sync_workflow_basic(
        self, mock_get_manager: MagicMock, tmp_path: Path
    ) -> None:
        """Test basic sync workflow with simple template."""
        project_path = self.setup_test_project(tmp_path)

        # Mock template manager
        mock_template_manager = MagicMock()
        mock_template_manager.get_template.return_value = (
            "FROM python:{{python_version}}\nWORKDIR /app"
        )
        mock_get_manager.return_value = mock_template_manager

        sync_manager = SyncManager(project_path, dry_run=True)
        updated_count = sync_manager.sync()

        assert updated_count >= 0
        assert len(sync_manager.synced_files) >= 0

    @patch("genesis.commands.sync.get_template_manager")
    def test_sync_with_force_flag(
        self, mock_get_manager: MagicMock, tmp_path: Path
    ) -> None:
        """Test sync with force flag."""
        project_path = self.setup_test_project(tmp_path)

        # Mock template manager
        mock_template_manager = MagicMock()
        mock_template_manager.get_template.return_value = "# Template content"
        mock_get_manager.return_value = mock_template_manager

        sync_manager = SyncManager(project_path, force=True, dry_run=True)
        updated_count = sync_manager.sync()

        assert updated_count >= 0

    @patch("genesis.commands.sync.get_template_manager")
    def test_sync_dry_run_mode(
        self, mock_get_manager: MagicMock, tmp_path: Path
    ) -> None:
        """Test sync in dry run mode."""
        project_path = self.setup_test_project(tmp_path)

        # Mock template manager
        mock_template_manager = MagicMock()
        mock_template_manager.get_template.return_value = "# Template content"
        mock_get_manager.return_value = mock_template_manager

        sync_manager = SyncManager(project_path, dry_run=True)
        updated_count = sync_manager.sync()

        assert updated_count >= 0
        # In dry run, no actual files should be created
        assert not (project_path / "Dockerfile").exists()

    def test_sync_config_validation(self, tmp_path: Path) -> None:
        """Test sync configuration validation."""
        project_path = self.setup_test_project(tmp_path)

        sync_manager = SyncManager(project_path)
        config = sync_manager.load_config()

        assert "template_source" in config
        assert "sync_policies" in config
        assert len(config["sync_policies"]) == 4

    def test_template_variable_extraction(self, tmp_path: Path) -> None:
        """Test template variable extraction from project files."""
        project_path = self.setup_test_project(tmp_path)

        sync_manager = SyncManager(project_path)
        variables = sync_manager.get_template_variables()

        assert variables["project_name"] == "test-project"
        assert variables["module_name"] == "test_project"
        assert variables["project_description"] == "Test project for Genesis sync"
        assert variables["project_version"] == "0.1.0"
        assert variables["python_version"] == "3.11"

    def test_sync_policies_behavior(self, tmp_path: Path) -> None:
        """Test different sync policy behaviors."""
        project_path = self.setup_test_project(tmp_path)

        sync_manager = SyncManager(project_path)

        # Test always policy
        dest_path = project_path / "always_file.txt"
        assert sync_manager._check_sync_policy(dest_path, "always") is True
        dest_path.write_text("existing content")
        assert sync_manager._check_sync_policy(dest_path, "always") is True

        # Test never policy
        dest_path = project_path / "never_file.txt"
        assert (
            sync_manager._check_sync_policy(dest_path, "never") is True
        )  # Creates new
        dest_path.write_text("existing content")
        assert (
            sync_manager._check_sync_policy(dest_path, "never") is False
        )  # Skips existing

        # Test if_unchanged policy
        dest_path = project_path / "if_unchanged_file.txt"
        assert (
            sync_manager._check_sync_policy(dest_path, "if_unchanged") is True
        )  # Creates new
        dest_path.write_text("existing content")
        assert (
            sync_manager._check_sync_policy(dest_path, "if_unchanged") is False
        )  # Skips existing

    @patch("genesis.commands.sync.get_template_manager")
    def test_template_processing_with_variables(
        self, mock_get_manager: MagicMock, tmp_path: Path
    ) -> None:
        """Test template processing with variable substitution."""
        project_path = self.setup_test_project(tmp_path)

        sync_manager = SyncManager(project_path)
        variables = {"project_name": "test-project", "version": "1.0.0"}

        template_content = "Project: {{project_name}}\nVersion: {{version}}"
        processed = sync_manager.process_template(template_content, variables)

        assert processed == "Project: test-project\nVersion: 1.0.0"

    def test_invalid_sync_config_handling(self, tmp_path: Path) -> None:
        """Test handling of invalid sync configuration."""
        project_path = self.setup_test_project(tmp_path)

        # Create invalid config
        invalid_config = {"invalid": "config"}
        sync_yml_path = project_path / ".genesis" / "sync.yml"
        with open(sync_yml_path, "w") as f:
            yaml.dump(invalid_config, f)

        sync_manager = SyncManager(project_path)
        with pytest.raises(
            yaml.YAMLError, match="Configuration missing required field"
        ):
            sync_manager.load_config()

    def test_missing_sync_config_handling(self, tmp_path: Path) -> None:
        """Test handling of missing sync configuration."""
        project_path = tmp_path / "test_project"
        project_path.mkdir()
        genesis_dir = project_path / ".genesis"
        genesis_dir.mkdir()

        sync_manager = SyncManager(project_path)
        with pytest.raises(FileNotFoundError) as exc_info:
            sync_manager.load_config()

        assert "Sync configuration not found" in str(exc_info.value)
