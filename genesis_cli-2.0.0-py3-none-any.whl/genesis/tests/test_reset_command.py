"""Tests for Genesis reset command with real Git operations."""

import os
import subprocess
import tempfile
from pathlib import Path

from click.testing import CliRunner

from genesis.cli import cli


class TestResetCommand:
    """Test reset command with real Git operations."""

    def setup_method(self) -> None:
        """Set up test environment."""
        self.original_dir = os.getcwd()

    def teardown_method(self) -> None:
        """Restore original directory."""
        os.chdir(self.original_dir)

    def test_reset_soft(self, tmp_path: Path) -> None:
        """Test soft reset that keeps changes in staging area."""
        os.chdir(tmp_path)

        # Create a real git repository
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create multiple commits
        test_file = tmp_path / "test.txt"
        test_file.write_text("commit 1")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "First commit"], capture_output=True)

        test_file.write_text("commit 2")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Second commit"], capture_output=True)

        test_file.write_text("commit 3")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Third commit"], capture_output=True)

        runner = CliRunner()
        result = runner.invoke(cli, ["reset", "--soft", "HEAD~1"])

        assert result.exit_code == 0

        # Check that changes are staged
        status = subprocess.run(
            ["git", "status", "--short"], capture_output=True, text=True, check=True
        )
        # File should be in staging area (M with space before it)
        assert "M " in status.stdout or "M  test.txt" in status.stdout

        # File content should still be "commit 3"
        assert test_file.read_text() == "commit 3"

    def test_reset_hard(self, tmp_path: Path) -> None:
        """Test hard reset that discards all changes."""
        os.chdir(tmp_path)

        # Create a real git repository
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create commits
        test_file = tmp_path / "test.txt"
        test_file.write_text("commit 1")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "First commit"], capture_output=True)

        test_file.write_text("commit 2")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Second commit"], capture_output=True)

        # Make uncommitted changes
        test_file.write_text("uncommitted changes")

        runner = CliRunner()
        result = runner.invoke(cli, ["reset", "--hard", "--confirm-hard", "HEAD~1"])

        assert result.exit_code == 0

        # File should be reset to first commit content
        assert test_file.read_text() == "commit 1"

        # No uncommitted changes should remain
        status = subprocess.run(
            ["git", "status", "--short"], capture_output=True, text=True, check=True
        )
        assert status.stdout.strip() == ""

    def test_reset_mixed_default(self, tmp_path: Path) -> None:
        """Test mixed reset (default) that unstages changes."""
        os.chdir(tmp_path)

        # Create a real git repository
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create commits
        test_file = tmp_path / "test.txt"
        test_file.write_text("commit 1")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "First commit"], capture_output=True)

        test_file.write_text("commit 2")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Second commit"], capture_output=True)

        runner = CliRunner()
        # Default reset (mixed)
        result = runner.invoke(cli, ["reset", "HEAD~1"])

        assert result.exit_code == 0

        # Changes should be unstaged but present
        status = subprocess.run(
            ["git", "status", "--short"], capture_output=True, text=True, check=True
        )
        # File should show as modified but not staged (M without space before it)
        assert " M " in status.stdout or " M test.txt" in status.stdout

        # File content should still be "commit 2"
        assert test_file.read_text() == "commit 2"

    def test_reset_to_specific_commit(self, tmp_path: Path) -> None:
        """Test resetting to a specific commit hash."""
        os.chdir(tmp_path)

        # Create a real git repository
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create multiple commits
        test_file = tmp_path / "test.txt"

        test_file.write_text("commit 1")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "First commit"], capture_output=True)

        # Get first commit hash
        first_commit = subprocess.run(
            ["git", "rev-parse", "HEAD"], capture_output=True, text=True, check=True
        ).stdout.strip()

        test_file.write_text("commit 2")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Second commit"], capture_output=True)

        test_file.write_text("commit 3")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Third commit"], capture_output=True)

        runner = CliRunner()
        # Reset to first commit
        result = runner.invoke(
            cli, ["reset", "--hard", "--confirm-hard", first_commit[:7]]
        )

        assert result.exit_code == 0

        # Should be back at first commit
        assert test_file.read_text() == "commit 1"

    def test_reset_file_specific(self, tmp_path: Path) -> None:
        """Test resetting specific files."""
        os.chdir(tmp_path)

        # Create a real git repository
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create initial commit with two files
        file1 = tmp_path / "file1.txt"
        file2 = tmp_path / "file2.txt"
        file1.write_text("file1 content")
        file2.write_text("file2 content")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], capture_output=True)

        # Modify both files and stage
        file1.write_text("file1 modified")
        file2.write_text("file2 modified")
        subprocess.run(["git", "add", "."], capture_output=True)

        runner = CliRunner()
        # Reset only file1
        result = runner.invoke(cli, ["reset", "HEAD", "file1.txt"])

        if result.exit_code == 0:
            # file1 should be unstaged, file2 should remain staged
            status = subprocess.run(
                ["git", "status", "--short"], capture_output=True, text=True, check=True
            )

            # file1 should show as modified but not staged
            assert " M file1.txt" in status.stdout
            # file2 should still be staged
            assert "M  file2.txt" in status.stdout

    def test_reset_not_in_git_repo(self, tmp_path: Path) -> None:
        """Test reset command outside Git repository."""
        original_dir = Path.cwd()
        try:
            with tempfile.TemporaryDirectory(dir="/tmp") as temp_dir:
                os.chdir(temp_dir)

                runner = CliRunner()
                result = runner.invoke(cli, ["reset"])

                # Should fail when not in a git repository
                assert result.exit_code != 0
                assert (
                    "not a git repository" in result.output.lower()
                    or "fatal" in result.output.lower()
                )
        finally:
            os.chdir(original_dir)

    def test_reset_with_uncommitted_changes(self, tmp_path: Path) -> None:
        """Test reset behavior with uncommitted changes."""
        os.chdir(tmp_path)

        # Create a real git repository
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create initial commits
        test_file = tmp_path / "test.txt"
        test_file.write_text("commit 1")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "First commit"], capture_output=True)

        test_file.write_text("commit 2")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Second commit"], capture_output=True)

        # Make uncommitted changes
        test_file.write_text("uncommitted changes")
        new_file = tmp_path / "new.txt"
        new_file.write_text("new file")

        runner = CliRunner()
        # Soft reset should preserve uncommitted changes
        result = runner.invoke(cli, ["reset", "--soft", "HEAD~1"])

        assert result.exit_code == 0
        # Uncommitted changes should still be there
        assert test_file.read_text() == "uncommitted changes"
        assert new_file.exists()

    def test_reset_to_origin_branch(self, tmp_path: Path) -> None:
        """Test resetting to match origin branch."""
        # Create origin and clone
        origin_path = tmp_path / "origin"
        clone_path = tmp_path / "clone"

        origin_path.mkdir()
        os.chdir(origin_path)
        subprocess.run(["git", "init", "--bare"], capture_output=True, check=True)

        os.chdir(tmp_path)
        subprocess.run(
            ["git", "clone", str(origin_path), "clone"], capture_output=True, check=True
        )

        os.chdir(clone_path)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create and push initial commit
        test_file = clone_path / "test.txt"
        test_file.write_text("origin content")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Origin commit"], capture_output=True)
        subprocess.run(
            ["git", "push", "origin", "main"], capture_output=True, check=False
        )
        subprocess.run(
            ["git", "push", "origin", "master"], capture_output=True, check=False
        )

        # Make local commits
        test_file.write_text("local change")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Local commit"], capture_output=True)

        runner = CliRunner()
        # Reset to origin/main or origin/master
        result = runner.invoke(
            cli, ["reset", "--hard", "--confirm-hard", "origin/main"]
        )
        if result.exit_code != 0:
            result = runner.invoke(
                cli, ["reset", "--hard", "--confirm-hard", "origin/master"]
            )

        assert result.exit_code == 0
        # Should be back to origin content
        assert test_file.read_text() == "origin content"


class TestResetCommandIntegration:
    """Integration tests for reset command with other Git operations."""

    def test_reset_after_merge(self, tmp_path: Path) -> None:
        """Test reset after a merge operation."""
        os.chdir(tmp_path)

        # Create repository with branches
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Main branch commit
        main_file = tmp_path / "main.txt"
        main_file.write_text("main content")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Main commit"], capture_output=True)

        # Create and switch to feature branch
        subprocess.run(["git", "checkout", "-b", "feature"], capture_output=True)
        feature_file = tmp_path / "feature.txt"
        feature_file.write_text("feature content")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Feature commit"], capture_output=True)

        # Switch back and merge
        subprocess.run(["git", "checkout", "main"], capture_output=True, check=False)
        subprocess.run(["git", "checkout", "master"], capture_output=True, check=False)
        subprocess.run(["git", "merge", "feature"], capture_output=True)

        # Reset to before merge
        runner = CliRunner()
        result = runner.invoke(cli, ["reset", "--hard", "--confirm-hard", "HEAD~1"])

        assert result.exit_code == 0
        # Feature file should be gone
        assert not feature_file.exists()
        # Main file should still exist
        assert main_file.exists()
