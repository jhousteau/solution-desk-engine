"""Tests for worktree tools functionality."""

import os
import subprocess
import tempfile
from collections.abc import Generator
from pathlib import Path

import pytest


@pytest.fixture
def temp_git_repo() -> Generator[Path]:
    """Create a temporary git repository for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo_path = Path(tmpdir) / "test-repo"
        repo_path.mkdir()
        original_cwd = os.getcwd()
        os.chdir(repo_path)

        try:
            # Initialize git repo
            subprocess.run(["git", "init"], check=True, capture_output=True)
            subprocess.run(["git", "config", "user.name", "Test User"], check=True)
            subprocess.run(
                ["git", "config", "user.email", "test@example.com"], check=True
            )

            # Create test file structure
            (repo_path / "src").mkdir()
            (repo_path / "src" / "auth").mkdir()
            (repo_path / "src" / "auth" / "login.py").write_text("# Login module")
            (repo_path / "tests").mkdir()
            (repo_path / "tests" / "test_auth.py").write_text("# Auth tests")
            (repo_path / "README.md").write_text("# Test repo")

            # Initial commit
            subprocess.run(["git", "add", "."], check=True)
            subprocess.run(["git", "commit", "-m", "Initial commit"], check=True)

            yield repo_path
        finally:
            os.chdir(original_cwd)


@pytest.fixture
def script_path() -> Path:
    """Path to the sparse worktree script."""
    # Script is now in .genesis/scripts/worktree/
    return (
        Path(__file__).parent.parent.parent.parent
        / ".genesis"
        / "scripts"
        / "worktree"
        / "create-sparse-worktree.sh"
    )


@pytest.fixture
def worktrees_dir(temp_git_repo: Path) -> Path:
    """Create worktrees directory for testing."""
    worktrees_dir = temp_git_repo.parent / "worktrees"
    worktrees_dir.mkdir(exist_ok=True)
    return worktrees_dir


def run_script(
    script_path: Path,
    args: list[str],
    cwd: Path | None = None,
    skip_on_git_error: bool = True,
) -> subprocess.CompletedProcess[str]:
    """Run script with args and handle git worktree limitations."""
    result = subprocess.run(
        ["bash", str(script_path)] + args, capture_output=True, text=True, cwd=cwd
    )

    if result.returncode != 0 and skip_on_git_error:
        if (
            "worktree" in result.stderr.lower()
            or "sparse-checkout" in result.stderr.lower()
        ):
            pytest.skip("Git worktree functionality not available in test environment")

    return result


class TestSparseWorktreeCreator:
    """Test sparse worktree creator script functionality."""

    def test_script_exists_and_executable(self, script_path: Path) -> None:
        """Test that the sparse worktree script exists and is executable."""
        assert script_path.exists(), "Sparse worktree script should exist"
        assert os.access(script_path, os.X_OK), "Script should be executable"

    def test_help_flag_works(self, script_path: Path) -> None:
        """Test that --help flag shows usage information."""
        result = run_script(script_path, ["--help"], skip_on_git_error=False)
        assert result.returncode == 0
        assert all(
            text in result.stdout
            for text in ["Usage:", "AI-safe sparse worktree", "Arguments:", "Options:"]
        )

    def test_insufficient_arguments_shows_usage(self, script_path: Path) -> None:
        """Test that insufficient arguments shows usage and exits with error."""
        result = run_script(script_path, [], skip_on_git_error=False)
        assert result.returncode == 1
        assert "Usage:" in result.stdout

    def test_nonexistent_focus_path_fails(
        self, script_path: Path, temp_git_repo: Path
    ) -> None:
        """Test that script fails when focus path doesn't exist."""
        result = run_script(
            script_path,
            ["test-worktree", "nonexistent/path"],
            cwd=temp_git_repo,
            skip_on_git_error=False,
        )
        assert result.returncode == 1
        assert "Focus path not found" in result.stdout

    def test_basic_worktree_creation_with_file(
        self, script_path: Path, temp_git_repo: Path, worktrees_dir: Path
    ) -> None:
        """Test basic worktree creation focusing on a single file."""
        result = run_script(
            script_path, ["test-auth", "src/auth/login.py"], cwd=temp_git_repo
        )
        assert "Creating AI-safe sparse worktree" in result.stdout
        assert "test-auth" in result.stdout
        assert "src/auth/login.py" in result.stdout

    def test_basic_worktree_creation_with_directory(
        self, script_path: Path, temp_git_repo: Path, worktrees_dir: Path
    ) -> None:
        """Test basic worktree creation focusing on a directory."""
        result = run_script(script_path, ["test-dir", "tests/"], cwd=temp_git_repo)
        assert "Creating AI-safe sparse worktree" in result.stdout
        assert "test-dir" in result.stdout
        assert "tests/" in result.stdout

    def test_max_files_option(
        self, script_path: Path, temp_git_repo: Path, worktrees_dir: Path
    ) -> None:
        """Test --max-files option works correctly."""
        result = run_script(
            script_path, ["test-limit", "src/", "--max-files", "5"], cwd=temp_git_repo
        )
        assert (
            "max-files" in result.stdout.lower() or "limit" in result.stdout
        ) and "5" in result.stdout

    def test_verify_option(
        self, script_path: Path, temp_git_repo: Path, worktrees_dir: Path
    ) -> None:
        """Test --verify option performs safety checks."""
        result = run_script(
            script_path, ["test-verify", "README.md", "--verify"], cwd=temp_git_repo
        )
        assert "verify" in result.stdout.lower() or "safety" in result.stdout.lower()

    def test_invalid_max_files_value(
        self, script_path: Path, temp_git_repo: Path
    ) -> None:
        """Test that invalid max-files values are rejected."""
        result = run_script(
            script_path,
            ["test-invalid", "README.md", "--max-files", "not-a-number"],
            cwd=temp_git_repo,
            skip_on_git_error=False,
        )
        assert result.returncode == 1
        assert "must be a number" in result.stdout

    def test_unknown_option_fails(self, script_path: Path, temp_git_repo: Path) -> None:
        """Test that unknown options cause script to fail with usage."""
        result = run_script(
            script_path,
            ["test-unknown", "README.md", "--unknown-option"],
            cwd=temp_git_repo,
            skip_on_git_error=False,
        )
        assert result.returncode == 1
        assert "Unknown option" in result.stdout
        assert "Usage:" in result.stdout

    def test_script_syntax_validation(self, script_path: Path) -> None:
        """Test that the script has valid bash syntax."""
        result = subprocess.run(
            ["bash", "-n", str(script_path)], capture_output=True, text=True
        )
        assert result.returncode == 0, f"Script has syntax errors: {result.stderr}"

    def test_line_count_meets_requirement(self, script_path: Path) -> None:
        """Test that script meets the ~350 line requirement."""
        with open(script_path) as f:
            lines = len(f.readlines())
        assert 300 <= lines <= 380, f"Script should be ~350 lines, got {lines}"

    def test_ai_safety_features_documented(self, script_path: Path) -> None:
        """Test that AI safety features are documented in the script."""
        with open(script_path) as f:
            content = f.read().lower()

        safety_features = ["ai-safety-manifest", "contamination", "depth"]
        file_count_features = ["file count", "file limit"]

        assert any(feature in content for feature in safety_features)
        assert any(feature in content for feature in file_count_features)
        assert "max" in content and "files" in content

    def test_color_output_functions(self, script_path: Path) -> None:
        """Test that color output is properly configured."""
        with open(script_path) as f:
            content = f.read()

        color_definitions = ["RED=", "GREEN=", "YELLOW=", "NC="]
        assert all(color in content for color in color_definitions)
        assert "${GREEN}" in content or "${RED}" in content


# TestWorktreeCLI removed - worktree is now integrated into genesis CLI
