"""Tests for Genesis worktree functionality."""
