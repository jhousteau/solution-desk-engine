"""Integration tests for ManifestParser functionality."""

from pathlib import Path
from typing import Any

import pytest
import yaml

from genesis.core.manifest_parser import ManifestParser


@pytest.mark.integration
class TestManifestParserIntegration:
    """Integration tests for ManifestParser with real manifest files."""

    def create_test_manifest(self, tmp_path: Path, manifest_data: dict) -> Path:
        """Create a test manifest file with the given data."""
        manifest_path = tmp_path / "manifest.yml"
        with open(manifest_path, "w", encoding="utf-8") as f:
            yaml.dump(manifest_data, f, default_flow_style=False)
        return manifest_path

    def test_parse_real_manifest_structure(self, tmp_path: Path) -> None:
        """Test parsing a real Genesis manifest structure."""
        manifest_data = {
            "shared_files": [
                {
                    "source": "Dockerfile.template",
                    "dest": "Dockerfile",
                    "sync": "always",
                    "description": "Universal hardened development container",
                },
                {
                    "source": ".gitignore.template",
                    "dest": ".gitignore",
                    "sync": "if_unchanged",
                    "description": "Comprehensive ignore patterns",
                },
                {
                    "source": ".envrc.template",
                    "dest": ".envrc",
                    "sync": "never",
                    "description": "Direnv configuration (user customizable)",
                },
            ],
            "claude_hooks": [
                {
                    "source": ".claude/hooks/pre-commit.yml",
                    "dest": ".claude/hooks/pre-commit.yml",
                    "description": "Pre-commit validation hook",
                }
            ],
            "claude_commands": [
                {
                    "source": ".claude/commands/test.yml",
                    "dest": ".claude/commands/test.yml",
                    "description": "Test execution command",
                }
            ],
            "template_variables": [
                {"name": "project_name", "description": "Project name"},
                {"name": "module_name", "description": "Python module name"},
            ],
            "conditionals": {"has_api": True, "has_cli": False},
            "sync_config": {
                "backup_changed_files": True,
                "backup_suffix": ".genesis-backup",
            },
        }

        manifest_path = self.create_test_manifest(tmp_path, manifest_data)
        parser = ManifestParser(manifest_path)

        # Test basic manifest loading
        assert parser.manifest_data is not None
        assert "shared_files" in parser.manifest_data
        assert "claude_hooks" in parser.manifest_data

    def test_get_files_by_sync_policy_integration(self, tmp_path: Path) -> None:
        """Test filtering files by sync policy."""
        manifest_data = {
            "shared_files": [
                {"source": "always1.txt", "dest": "always1.txt", "sync": "always"},
                {"source": "always2.txt", "dest": "always2.txt", "sync": "always"},
                {
                    "source": "unchanged1.txt",
                    "dest": "unchanged1.txt",
                    "sync": "if_unchanged",
                },
                {"source": "never1.txt", "dest": "never1.txt", "sync": "never"},
                {
                    "source": "unchanged2.txt",
                    "dest": "unchanged2.txt",
                    "sync": "if_unchanged",
                },
            ]
        }

        manifest_path = self.create_test_manifest(tmp_path, manifest_data)
        parser = ManifestParser(manifest_path)

        # Test 'always' policy
        always_files = parser.get_files_by_sync_policy("always")
        assert len(always_files) == 2
        always_sources = [f["source"] for f in always_files]
        assert "always1.txt" in always_sources
        assert "always2.txt" in always_sources

        # Test 'if_unchanged' policy
        if_unchanged_files = parser.get_files_by_sync_policy("if_unchanged")
        assert len(if_unchanged_files) == 2
        unchanged_sources = [f["source"] for f in if_unchanged_files]
        assert "unchanged1.txt" in unchanged_sources
        assert "unchanged2.txt" in unchanged_sources

        # Test 'never' policy
        never_files = parser.get_files_by_sync_policy("never")
        assert len(never_files) == 1
        assert never_files[0]["source"] == "never1.txt"

        # Test non-existent policy
        empty_files = parser.get_files_by_sync_policy("nonexistent")
        assert len(empty_files) == 0

    def test_claude_hooks_automatic_sync_policy(self, tmp_path: Path) -> None:
        """Test that Claude hooks get default 'always' sync policy when not specified."""
        manifest_data = {
            "claude_hooks": [
                {
                    "source": ".claude/hooks/pre-commit.yml",
                    "dest": ".claude/hooks/pre-commit.yml",
                    "description": "Pre-commit hook without explicit sync policy",
                },
                {
                    "source": ".claude/hooks/post-commit.yml",
                    "dest": ".claude/hooks/post-commit.yml",
                    "sync": "if_unchanged",  # This will be preserved
                    "description": "Post-commit hook with explicit sync policy",
                },
            ]
        }

        manifest_path = self.create_test_manifest(tmp_path, manifest_data)
        parser = ManifestParser(manifest_path)

        hooks = parser.get_claude_hooks()
        assert len(hooks) == 2

        # First hook should get default 'always' sync policy
        assert hooks[0]["sync"] == "always"
        # Second hook should preserve explicit 'if_unchanged' policy
        assert hooks[1]["sync"] == "if_unchanged"

    def test_claude_commands_automatic_sync_policy(self, tmp_path: Path) -> None:
        """Test that Claude commands get default 'always' sync policy when not specified."""
        manifest_data = {
            "claude_commands": [
                {
                    "source": ".claude/commands/test.yml",
                    "dest": ".claude/commands/test.yml",
                    "description": "Test command without explicit sync policy",
                },
                {
                    "source": ".claude/commands/build.yml",
                    "dest": ".claude/commands/build.yml",
                    "sync": "never",  # This will be preserved
                    "description": "Build command with explicit sync policy",
                },
            ]
        }

        manifest_path = self.create_test_manifest(tmp_path, manifest_data)
        parser = ManifestParser(manifest_path)

        commands = parser.get_claude_commands()
        assert len(commands) == 2

        # First command should get default 'always' sync policy
        assert commands[0]["sync"] == "always"
        # Second command should preserve explicit 'never' policy
        assert commands[1]["sync"] == "never"

    def test_get_all_files_integration(self, tmp_path: Path) -> None:
        """Test getting all files from all sections."""
        manifest_data = {
            "shared_files": [
                {"source": "shared1.txt", "dest": "shared1.txt", "sync": "always"},
                {
                    "source": "shared2.txt",
                    "dest": "shared2.txt",
                    "sync": "if_unchanged",
                },
            ],
            "claude_hooks": [
                {"source": ".claude/hooks/hook1.yml", "dest": ".claude/hooks/hook1.yml"}
            ],
            "claude_commands": [
                {
                    "source": ".claude/commands/cmd1.yml",
                    "dest": ".claude/commands/cmd1.yml",
                }
            ],
        }

        manifest_path = self.create_test_manifest(tmp_path, manifest_data)
        parser = ManifestParser(manifest_path)

        all_files = parser.get_all_files()
        assert len(all_files) == 4

        # Check that all expected sources are present
        sources = [f["source"] for f in all_files]
        assert "shared1.txt" in sources
        assert "shared2.txt" in sources
        assert ".claude/hooks/hook1.yml" in sources
        assert ".claude/commands/cmd1.yml" in sources

        # Check that Claude files have 'always' sync policy (unless explicitly overridden)
        claude_files = [f for f in all_files if ".claude/" in f["source"]]
        for claude_file in claude_files:
            # Claude files get 'always' as default, but explicit values are preserved
            assert claude_file["sync"] == "always"

    def test_sync_config_defaults(self, tmp_path: Path) -> None:
        """Test sync configuration with defaults."""
        # Test with minimal manifest
        manifest_data: dict[str, Any] = {"shared_files": []}
        manifest_path = self.create_test_manifest(tmp_path, manifest_data)
        parser = ManifestParser(manifest_path)

        sync_config = parser.get_sync_config()

        # Check default values
        assert sync_config["backup_changed_files"] is True
        assert sync_config["backup_suffix"] == ".genesis-backup"
        assert sync_config["create_directories"] is True
        assert sync_config["preserve_permissions"] is True
        assert sync_config["validate_templates"] is True

    def test_sync_config_overrides(self, tmp_path: Path) -> None:
        """Test sync configuration with custom values."""
        manifest_data = {
            "shared_files": [],
            "sync_config": {
                "backup_changed_files": False,
                "backup_suffix": ".bak",
                "create_directories": False,
                "custom_setting": "custom_value",
            },
        }

        manifest_path = self.create_test_manifest(tmp_path, manifest_data)
        parser = ManifestParser(manifest_path)

        sync_config = parser.get_sync_config()

        # Check overridden values
        assert sync_config["backup_changed_files"] is False
        assert sync_config["backup_suffix"] == ".bak"
        assert sync_config["create_directories"] is False
        assert sync_config["custom_setting"] == "custom_value"

        # Note: Current implementation doesn't merge defaults with custom sync_config
        # It returns the sync_config as-is if present
        assert "preserve_permissions" not in sync_config
        assert "validate_templates" not in sync_config

    def test_template_variables_integration(self, tmp_path: Path) -> None:
        """Test template variable parsing."""
        manifest_data = {
            "template_variables": [
                {
                    "name": "project_name",
                    "description": "Project name",
                    "default": "my-project",
                },
                {"name": "author", "description": "Project author", "required": True},
                {
                    "name": "version",
                    "description": "Initial version",
                    "default": "0.1.0",
                },
            ]
        }

        manifest_path = self.create_test_manifest(tmp_path, manifest_data)
        parser = ManifestParser(manifest_path)

        variables = parser.get_template_variables()
        assert len(variables) == 3

        # Check specific variables
        project_var = next(v for v in variables if v["name"] == "project_name")
        assert project_var["default"] == "my-project"

        author_var = next(v for v in variables if v["name"] == "author")
        assert author_var["required"] is True

    def test_conditionals_integration(self, tmp_path: Path) -> None:
        """Test conditional configuration parsing."""
        manifest_data = {
            "conditionals": {
                "has_api": True,
                "has_cli": False,
                "environment": "development",
                "features": ["auth", "metrics"],
            }
        }

        manifest_path = self.create_test_manifest(tmp_path, manifest_data)
        parser = ManifestParser(manifest_path)

        conditionals = parser.get_conditionals()
        assert conditionals["has_api"] is True
        assert conditionals["has_cli"] is False
        assert conditionals["environment"] == "development"
        assert conditionals["features"] == ["auth", "metrics"]

    def test_manifest_file_not_found(self, tmp_path: Path) -> None:
        """Test error handling when manifest file doesn't exist."""
        non_existent_path = tmp_path / "nonexistent.yml"

        with pytest.raises(FileNotFoundError, match="Manifest not found"):
            ManifestParser(non_existent_path)

    def test_invalid_yaml_handling(self, tmp_path: Path) -> None:
        """Test error handling for invalid YAML content."""
        manifest_path = tmp_path / "invalid.yml"
        with open(manifest_path, "w", encoding="utf-8") as f:
            f.write("invalid: yaml: content: [unclosed")

        with pytest.raises(ValueError, match="Invalid YAML in manifest"):
            ManifestParser(manifest_path)

    def test_empty_manifest_handling(self, tmp_path: Path) -> None:
        """Test handling of empty manifest file."""
        manifest_path = tmp_path / "empty.yml"
        manifest_path.touch()  # Create empty file

        parser = ManifestParser(manifest_path)

        # Should handle empty manifest gracefully
        assert parser.manifest_data == {}
        assert parser.get_files_by_sync_policy("always") == []
        assert parser.get_claude_hooks() == []
        assert parser.get_claude_commands() == []
        assert parser.get_all_files() == []

    @pytest.mark.ai_safety
    def test_manifest_parser_file_count_compliance(self, tmp_path: Path) -> None:
        """Test that ManifestParser operations comply with AI safety file limits."""
        # Create a large manifest that would be realistic in production
        large_manifest_data = {
            "shared_files": [
                {
                    "source": f"file_{i}.txt",
                    "dest": f"file_{i}.txt",
                    "sync": (
                        "always"
                        if i % 3 == 0
                        else "if_unchanged" if i % 3 == 1 else "never"
                    ),
                }
                for i in range(40)  # Just under AI safety limit
            ],
            "claude_hooks": [
                {
                    "source": f".claude/hooks/hook_{i}.yml",
                    "dest": f".claude/hooks/hook_{i}.yml",
                }
                for i in range(3)
            ],
            "claude_commands": [
                {
                    "source": f".claude/commands/cmd_{i}.yml",
                    "dest": f".claude/commands/cmd_{i}.yml",
                }
                for i in range(2)
            ],
        }

        manifest_path = self.create_test_manifest(tmp_path, large_manifest_data)
        parser = ManifestParser(manifest_path)

        # Verify parsing works with large manifests
        all_files = parser.get_all_files()
        assert len(all_files) == 45  # Should be exactly at the limit

        # Verify filtering still works efficiently
        always_files = parser.get_files_by_sync_policy("always")
        if_unchanged_files = parser.get_files_by_sync_policy("if_unchanged")
        never_files = parser.get_files_by_sync_policy("never")

        # Check that shared_files are properly categorized
        # Note: Claude hooks and commands are not included in get_files_by_sync_policy()
        # since they are in separate sections, only shared_files are filtered
        shared_files_count = len(large_manifest_data["shared_files"])
        total_categorized = (
            len(always_files) + len(if_unchanged_files) + len(never_files)
        )
        assert total_categorized == shared_files_count == 40

        # But all_files should include everything (shared + claude hooks + commands)
        assert len(all_files) == 45
