"""Core package-based sync system integration tests.

Focused testing for GitHub issue #252:
- Package installation and template access
- Init workflow (creates sync.yml)
- Basic sync operations
- Migration from legacy system
"""

import os
import tempfile
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import yaml
from click.testing import CliRunner

from genesis.cli import cli


@contextmanager
def chdir(path: Path) -> Generator[None]:
    """Context manager to change directory temporarily."""
    original_cwd = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(original_cwd)


class TestPackageBasedSync:
    """Core integration tests for package-based sync system."""

    def test_package_templates_accessible(self) -> None:
        """Verify templates are accessible from installed package."""
        runner = CliRunner()

        with tempfile.TemporaryDirectory() as temp_dir:
            # Test that sync command can access templates without local filesystem
            with chdir(Path(temp_dir)):
                result = runner.invoke(
                    cli, ["sync", "--preview"], catch_exceptions=False
                )

            # Should fail gracefully with helpful message, not crash
            assert result.exit_code != 0
            assert (
                "sync.yml" in result.output
                or "not initialized" in result.output
                or "Genesis configuration not found" in result.output
                or "Not a Genesis project" in result.output
            )

    def test_init_creates_sync_yml(self) -> None:
        """Test genesis init creates proper sync.yml configuration."""
        runner = CliRunner()

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create basic project structure
            (temp_path / "pyproject.toml").write_text("[tool.poetry]\nname = 'test'\n")

            # Run init
            with chdir(Path(temp_dir)):
                result = runner.invoke(cli, ["init"], catch_exceptions=False)

            if result.exit_code == 0:
                # Verify sync.yml was created
                sync_yml = temp_path / ".genesis" / "sync.yml"
                assert (
                    sync_yml.exists()
                ), f"sync.yml not created. Output: {result.output}"

                # Verify it's valid YAML
                config = yaml.safe_load(sync_yml.read_text())
                # Check for project type in new structure
                assert "project" in config or "project_type" in config
                if "project" in config:
                    assert "type" in config["project"]
                assert "files" in config

    def test_sync_workflow_basic(self) -> None:
        """Test basic sync workflow with minimal configuration."""
        runner = CliRunner()

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create minimal sync.yml
            genesis_dir = temp_path / ".genesis"
            genesis_dir.mkdir()

            sync_config = {
                "version": "1.0",
                "template_source": "python-api",  # Required field for sync command
                "project": {
                    "type": "python-api",
                    "name": "test-project",
                    "module_name": "test_project",
                },
                "variables": {
                    "project_name": "test-project",
                    "module_name": "test_project",
                },
                "sync_policies": [  # This should be sync_policies, not files
                    {
                        "source": "Dockerfile.template",
                        "dest": "Dockerfile",
                        "policy": "always",
                    },
                    {
                        "source": "pyproject.toml.template",
                        "dest": "pyproject.toml",
                        "policy": "if_unchanged",
                    },
                    {
                        "source": "README.md.template",
                        "dest": "README.md",
                        "policy": "never",
                    },
                ],
            }

            (genesis_dir / "sync.yml").write_text(yaml.dump(sync_config))

            # Test preview mode
            with chdir(Path(temp_dir)):
                result = runner.invoke(
                    cli, ["sync", "--preview"], catch_exceptions=False
                )

            # Should work without errors
            assert result.exit_code == 0 or "would create" in result.output

    def test_migrate_from_legacy(self) -> None:
        """Test migration from sync-state.json to sync.yml."""
        runner = CliRunner()

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create legacy sync-state.json
            legacy_state = {
                "project_type": "python-api",
                "template_path": "templates/python-api",
                "variables": {"project_name": "legacy-project"},
            }

            (temp_path / ".genesis-sync-state.json").write_text(
                str(legacy_state).replace("'", '"')
            )

            # Run migrate (if command exists)
            with chdir(Path(temp_dir)):
                result = runner.invoke(cli, ["migrate"], catch_exceptions=False)

            # Command might not exist yet, so check output
            if result.exit_code == 0:
                # Should create sync.yml
                sync_yml = temp_path / ".genesis" / "sync.yml"
                if sync_yml.exists():
                    config = yaml.safe_load(sync_yml.read_text())
                    # Check for project type in either location (root or under project)
                    if "project" in config:
                        assert config["project"]["type"] == "python-api"
                    else:
                        assert config.get("project_type") == "python-api"


class TestSyncPolicies:
    """Test sync policy enforcement."""

    def _create_test_project(self, project_path: Path, extra_config: dict) -> None:
        """Helper to create test project with sync.yml."""
        genesis_dir = project_path / ".genesis"
        genesis_dir.mkdir()

        base_config: dict[str, Any] = {
            "version": "1.0",
            "template_source": "python-api",  # Required field for sync command
            "project": {
                "type": "python-api",
                "name": "test",
                "module_name": "test",
            },
            "variables": {
                "project_name": "test",
                "module_name": "test",
            },
            "sync_policies": [],  # Default empty sync_policies list
        }

        # Handle the old files format and convert to sync_policies
        if "files" in extra_config:
            files_config = extra_config.pop("files")
            sync_policies: list[dict[str, Any]] = []

            # Convert old format to new format
            for policy_type, file_list in files_config.items():
                for file_name in file_list:
                    sync_policies.append(
                        {
                            "source": f"{file_name}.template",
                            "dest": file_name,
                            "policy": policy_type,
                        }
                    )

            base_config["sync_policies"] = sync_policies

        base_config.update(extra_config)

        (genesis_dir / "sync.yml").write_text(yaml.dump(base_config))

    def test_sync_policy_always(self) -> None:
        """Test 'always' policy overwrites files."""
        runner = CliRunner()

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create project with sync.yml
            self._create_test_project(temp_path, {"files": {"always": ["test.txt"]}})

            # Create existing file
            (temp_path / "test.txt").write_text("existing content")

            # Run sync in preview mode
            with chdir(Path(temp_dir)):
                result = runner.invoke(
                    cli, ["sync", "--preview"], catch_exceptions=False
                )

            # Should indicate file would be overwritten
            assert result.exit_code == 0 or "would update" in result.output

    def test_sync_policy_never(self) -> None:
        """Test 'never' policy preserves existing files."""
        runner = CliRunner()

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create project with sync.yml
            self._create_test_project(temp_path, {"files": {"never": ["user.txt"]}})

            # Create existing file
            user_file = temp_path / "user.txt"
            user_file.write_text("user content")

            # Run sync in preview mode
            with chdir(Path(temp_dir)):
                result = runner.invoke(
                    cli, ["sync", "--preview"], catch_exceptions=False
                )

            # Should indicate file would be skipped
            assert result.exit_code == 0 or "would skip" in result.output


class TestErrorHandling:
    """Test error handling scenarios."""

    def test_missing_sync_yml_error(self) -> None:
        """Test clear error when sync.yml missing."""
        runner = CliRunner()

        with tempfile.TemporaryDirectory() as temp_dir:
            with chdir(Path(temp_dir)):
                result = runner.invoke(cli, ["sync"], catch_exceptions=False)

            # Should fail with helpful error
            assert result.exit_code != 0
            # More generic error message checks
            assert (
                "sync.yml" in result.output.lower()
                or "not initialized" in result.output.lower()
                or "genesis init" in result.output.lower()
                or "configuration" in result.output.lower()
                or "not found" in result.output.lower()
                or "missing" in result.output.lower()
            )

    def test_invalid_sync_yml_error(self) -> None:
        """Test handling of malformed sync.yml."""
        runner = CliRunner()

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create invalid YAML
            genesis_dir = temp_path / ".genesis"
            genesis_dir.mkdir()
            (genesis_dir / "sync.yml").write_text("invalid: yaml: content: {\n")

            with chdir(Path(temp_dir)):
                result = runner.invoke(cli, ["sync"], catch_exceptions=False)

            # Should fail with helpful error
            assert result.exit_code != 0
            assert "yaml" in result.output.lower() or "config" in result.output.lower()
