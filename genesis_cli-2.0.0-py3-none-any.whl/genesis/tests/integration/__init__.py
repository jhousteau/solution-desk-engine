"""Integration tests for Genesis package-based sync system.

This package contains comprehensive integration tests that verify end-to-end
workflows for the Genesis sync system, from package installation through
sync operations.
"""
