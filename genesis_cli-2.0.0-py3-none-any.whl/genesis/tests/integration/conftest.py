"""Shared fixtures for integration tests.

Simplified fixtures focused on core package-based sync testing.
"""

import tempfile
from collections.abc import Generator
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner, Result


@pytest.fixture
def temp_project_dir() -> Generator[Path]:
    """Create temporary directory for test projects."""
    with tempfile.TemporaryDirectory() as temp_dir:
        yield Path(temp_dir)


@pytest.fixture
def integration_runner() -> CliRunner:
    """Click test runner for integration tests."""
    return CliRunner()


def assert_file_exists(file_path: Path, message: str = "") -> None:
    """Assert that a file exists with helpful error message."""
    assert file_path.exists(), f"File {file_path} does not exist. {message}"


def assert_sync_yml_valid(sync_yml_path: Path) -> None:
    """Assert that sync.yml exists and contains valid configuration."""
    assert_file_exists(sync_yml_path, "sync.yml should exist")

    try:
        config = yaml.safe_load(sync_yml_path.read_text())
        assert isinstance(config, dict), "sync.yml should contain a dictionary"
        assert "project_type" in config, "sync.yml should have project_type"
        assert "variables" in config, "sync.yml should have variables"
    except yaml.YAMLError as e:
        pytest.fail(f"sync.yml contains invalid YAML: {e}")


def run_genesis_command(
    args: list[str], cwd: Path | None = None, runner: CliRunner | None = None
) -> Result:
    """Helper to run genesis commands with proper error handling."""
    from genesis.cli import cli

    if runner is None:
        runner = CliRunner()

    result = runner.invoke(
        cli, args, catch_exceptions=False, cwd=str(cwd) if cwd else None
    )
    return result
