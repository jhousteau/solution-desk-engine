"""Testing conftest for genesis/tests directory."""

import os
import subprocess
from collections.abc import Generator
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest


@pytest.fixture
def genesis_root() -> Path:
    """Get the Genesis repository root."""
    # Go up three levels from genesis/tests/ to get to root
    return Path(__file__).parent.parent.parent


@pytest.fixture(autouse=True)
def setup_test_env() -> Generator[None]:
    """Load safe environment variables from .envrc for authentic testing."""
    # Store original values to restore after test
    original_env: dict[str, str | None] = {}

    # Define sensitive variable patterns to exclude from test environment
    SENSITIVE_PATTERNS = {
        "TOKEN",
        "KEY",
        "SECRET",
        "PASSWORD",
        "PASS",
        "CREDENTIAL",
        "AUTH",
        "GITHUB_TOKEN",
        "API_KEY",
        "PRIVATE_KEY",
        "ACCESS_TOKEN",
    }

    # Get the project root
    project_root = Path(__file__).parent.parent.parent
    envrc_path = project_root / ".envrc"

    if envrc_path.exists():
        # Source .envrc using bash and capture the environment
        try:
            result = subprocess.run(
                ["bash", "-c", f"set -a; source {envrc_path}; env"],
                capture_output=True,
                text=True,
                cwd=project_root,
                check=True,
            )

            # Parse environment variables from output
            for line in result.stdout.strip().split("\n"):
                if "=" in line and not line.startswith("_"):  # Skip bash internals
                    key, value = line.split("=", 1)

                    # Security: Filter out sensitive environment variables
                    if any(pattern in key.upper() for pattern in SENSITIVE_PATTERNS):
                        continue

                    # Only set if not already in environment (preserve existing values)
                    if key not in os.environ:
                        original_env[key] = None
                        os.environ[key] = value

        except subprocess.CalledProcessError:
            # Fall back to minimal test environment if .envrc fails
            pass

    # Ensure critical test environment variables are set
    test_overrides = {
        "ENV": "test",  # Override to test environment
        "PROJECT_MODE": "test",
        "LOG_LEVEL": "info",  # Required by shared logger
    }

    for key, value in test_overrides.items():
        original_env[key] = os.environ.get(key)
        os.environ[key] = value

    yield

    # Restore original environment
    for key, original_value in original_env.items():
        if original_value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = original_value


@pytest.fixture
def mock_container_environment() -> Generator[dict[str, Any]]:
    """Mock the container environment for tmpfs-cleanup and other container commands."""
    with patch("genesis.commands.container.get_compose_file") as mock_get_file:
        with patch("genesis.commands.container.detect_service_name") as mock_detect:
            with patch(
                "genesis.commands.container.get_container_profile"
            ) as mock_profile:
                with patch(
                    "genesis.commands.container.get_project_name"
                ) as mock_project:
                    # Set up default mocks
                    mock_get_file.return_value = "/path/to/docker-compose.yml"
                    mock_detect.return_value = "agent"
                    mock_profile.return_value = "agent"
                    mock_project.return_value = "test-project"

                    yield {
                        "get_compose_file": mock_get_file,
                        "detect_service_name": mock_detect,
                        "get_container_profile": mock_profile,
                        "get_project_name": mock_project,
                    }
