"""
Integration tests for Genesis 1.5 release validation.

This module provides comprehensive integration tests to validate that Genesis 1.5
is ready for production deployment, covering:
- Version consistency across all components
- Package building and installation
- Documentation accuracy and completeness
- CLI command functionality
- Migration and configuration compatibility

Test Categories:
- @pytest.mark.integration: Integration tests across components
- @pytest.mark.ai_safety: AI safety constraint validation
- @pytest.mark.requires_git: Tests requiring git operations
- @pytest.mark.slow: Tests that may take more than 2 seconds
"""

import os
import subprocess
import tomllib
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner

from genesis import get_version
from genesis.cli import cli
from genesis.core import get_logger

logger = get_logger(__name__)


class TestGenesis15VersionConsistency:
    """Test version consistency across Genesis 1.5 components."""

    @pytest.mark.integration
    def test_pyproject_toml_version_is_1_5_0(self) -> None:
        """Verify pyproject.toml shows version 1.5.0."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"

        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)

        version = data["tool"]["poetry"]["version"]
        assert version == "1.5.0", f"Expected version 1.5.0, got {version}"

    @pytest.mark.integration
    def test_genesis_version_command_returns_1_5_0(self, runner: CliRunner) -> None:
        """Verify 'genesis version' command returns 1.5.0."""
        result = runner.invoke(cli, ["version"])

        assert result.exit_code == 0, f"Command failed: {result.output}"
        assert (
            "1.5.0" in result.output
        ), f"Version 1.5.0 not found in output: {result.output}"

    @pytest.mark.integration
    def test_python_api_version_is_1_5_0(self) -> None:
        """Verify get_version() returns 1.5.0."""
        version = get_version()
        assert version == "1.5.0", f"Expected version 1.5.0, got {version}"

    @pytest.mark.integration
    def test_hardcoded_version_fallback_updated(self) -> None:
        """Verify fallback version in genesis/version.py is updated."""
        version_file = Path(__file__).parent.parent / "version.py"
        content = version_file.read_text()

        # Check that hardcoded version is reasonable (not ancient)
        lines = content.split("\n")
        version_line = next(line for line in lines if "__version__ = " in line)

        # Extract version from line like: __version__ = "0.13.1"
        version = version_line.split('"')[1]

        # Should be at least 1.0.0 for a 1.5 release
        major, minor, patch = version.split(".")
        assert int(major) >= 1, f"Hardcoded version should be >= 1.0.0, got {version}"

    @pytest.mark.integration
    def test_shared_core_version_compatibility(self) -> None:
        """Verify shared-core dependency version is compatible."""
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"

        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)

        # Check dev dependency has local path
        dev_deps = data["tool"]["poetry"]["group"]["dev"]["dependencies"]
        shared_core_dep = dev_deps.get("genesis-shared-core")

        assert (
            shared_core_dep is not None
        ), "genesis-shared-core not found in dev dependencies"
        assert "path" in shared_core_dep, "shared-core should use local path in dev"
        assert (
            shared_core_dep["path"] == "shared-python"
        ), f"Wrong path: {shared_core_dep['path']}"


class TestGenesis15PackageBuild:
    """Test package building and installation for Genesis 1.5."""

    @pytest.mark.integration
    @pytest.mark.slow
    def test_package_builds_successfully(self, tmp_path: Path) -> None:
        """Test that the package builds successfully with version 1.5.0."""
        genesis_root = Path(__file__).parent.parent.parent

        # Run poetry build
        result = subprocess.run(
            ["poetry", "build", "--format", "wheel"],
            cwd=genesis_root,
            capture_output=True,
            text=True,
            timeout=120,  # 2 minute timeout
        )

        assert result.returncode == 0, f"Poetry build failed: {result.stderr}"

        # Verify wheel was created
        dist_dir = genesis_root / "dist"
        wheel_files = list(dist_dir.glob("genesis_cli-1.5.0-*.whl"))

        assert (
            len(wheel_files) > 0
        ), f"No wheel file found for version 1.5.0 in {dist_dir}"

        # Verify wheel name contains correct version
        wheel_file = wheel_files[0]
        assert (
            "1.5.0" in wheel_file.name
        ), f"Wheel name doesn't contain 1.5.0: {wheel_file.name}"

    @pytest.mark.integration
    @pytest.mark.slow
    def test_built_wheel_contains_correct_metadata(self, tmp_path: Path) -> None:
        """Verify the built wheel contains correct version metadata."""
        genesis_root = Path(__file__).parent.parent.parent
        dist_dir = genesis_root / "dist"

        # Find the wheel file
        wheel_files = list(dist_dir.glob("genesis_cli-1.5.0-*.whl"))
        if not wheel_files:
            pytest.skip("No wheel file found - run build test first")

        wheel_file = wheel_files[0]

        # Extract and examine metadata
        import zipfile

        with zipfile.ZipFile(wheel_file, "r") as zip_ref:
            # Look for METADATA file
            metadata_files = [f for f in zip_ref.namelist() if f.endswith("METADATA")]
            assert len(metadata_files) > 0, "No METADATA file found in wheel"

            metadata_content = zip_ref.read(metadata_files[0]).decode("utf-8")

            # Verify version in metadata
            assert (
                "Version: 1.5.0" in metadata_content
            ), "Version 1.5.0 not found in metadata"
            assert (
                "Name: genesis-cli" in metadata_content
            ), "Incorrect package name in metadata"

    @pytest.mark.integration
    @pytest.mark.slow
    def test_wheel_installation_in_clean_environment(self, tmp_path: Path) -> None:
        """Test package installation from wheel in a clean environment."""
        genesis_root = Path(__file__).parent.parent.parent
        dist_dir = genesis_root / "dist"

        # Find the wheel file
        wheel_files = list(dist_dir.glob("genesis_cli-1.5.0-*.whl"))
        if not wheel_files:
            pytest.skip("No wheel file found - run build test first")

        wheel_file = wheel_files[0]

        # Create a temporary virtual environment
        venv_path = tmp_path / "test_venv"

        try:
            # Create virtual environment
            result = subprocess.run(
                ["python", "-m", "venv", str(venv_path)],
                capture_output=True,
                text=True,
                timeout=60,
            )
            assert result.returncode == 0, f"Failed to create venv: {result.stderr}"

            # Install wheel in virtual environment
            pip_exe = (
                venv_path / "bin" / "pip"
                if os.name != "nt"
                else venv_path / "Scripts" / "pip.exe"
            )

            # Check if pip is executable
            if not os.access(pip_exe, os.X_OK):
                pytest.skip(
                    "Permission denied on pip executable - test environment issue"
                )

            result = subprocess.run(
                [str(pip_exe), "install", str(wheel_file)],
                capture_output=True,
                text=True,
                timeout=120,
            )
            assert result.returncode == 0, f"Failed to install wheel: {result.stderr}"

            # Verify genesis command is available
            genesis_exe = (
                venv_path / "bin" / "genesis"
                if os.name != "nt"
                else venv_path / "Scripts" / "genesis.exe"
            )

            result = subprocess.run(
                [str(genesis_exe), "--version"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            assert result.returncode == 0, f"Genesis command failed: {result.stderr}"
            assert (
                "1.5.0" in result.stdout
            ), f"Version 1.5.0 not found in output: {result.stdout}"

        except PermissionError as e:
            pytest.skip(f"Permission denied during venv creation/usage: {e}")


class TestGenesis15DocumentationValidation:
    """Test documentation accuracy and completeness for Genesis 1.5."""

    @pytest.mark.integration
    def test_changelog_has_1_5_0_section(self) -> None:
        """Verify CHANGELOG.md has proper 1.5.0 section."""
        changelog_path = Path(__file__).parent.parent.parent / "CHANGELOG.md"
        content = changelog_path.read_text()

        # Look for version 1.5.0 section
        assert "## [1.5.0]" in content, "CHANGELOG.md missing ## [1.5.0] section"

        # Should have release date
        lines = content.split("\n")
        version_line_idx = next(
            i for i, line in enumerate(lines) if "## [1.5.0]" in line
        )
        version_line = lines[version_line_idx]

        # Should have date format like ## [1.5.0] - 2025-09-19
        assert " - " in version_line, f"Version line missing date: {version_line}"

    @pytest.mark.integration
    def test_readme_references_genesis_1_5_consistently(self) -> None:
        """Verify README.md references Genesis 1.5 consistently."""
        readme_path = Path(__file__).parent.parent.parent / "README.md"
        content = readme_path.read_text()

        # Should reference version 1.5.0 in installation commands
        assert "1.5.0" in content, "README.md should reference version 1.5.0"

        # Check for common installation patterns
        installation_patterns = ["genesis-cli==1.5.0", "genesis-cli>=1.5.0", "v1.5.0"]

        has_installation_ref = any(
            pattern in content for pattern in installation_patterns
        )
        assert (
            has_installation_ref
        ), "README.md should have installation reference to 1.5.0"

    @pytest.mark.integration
    def test_docs_getting_started_has_1_5_0_commands(self) -> None:
        """Verify docs/guides/getting-started.md has 1.5.0 installation commands."""
        docs_path = Path(__file__).parent.parent.parent / "docs"
        if not docs_path.exists():
            pytest.skip("docs directory not found")

        getting_started_files = list(docs_path.rglob("getting-started.md"))
        if not getting_started_files:
            getting_started_files = list(docs_path.rglob("*getting*started*"))

        if not getting_started_files:
            pytest.skip("getting-started.md not found in docs")

        content = getting_started_files[0].read_text()

        # Should reference current version in installation
        installation_patterns = ["1.5.0", "genesis-cli", "pip install"]

        for pattern in installation_patterns:
            assert (
                pattern in content
            ), f"Pattern '{pattern}' not found in getting started docs"

    @pytest.mark.integration
    def test_documentation_links_are_valid(self) -> None:
        """Test that critical documentation links and references are valid."""
        Path(__file__).parent.parent.parent / "docs"
        readme_path = Path(__file__).parent.parent.parent / "README.md"

        # Check that main documentation files exist
        critical_docs = [
            readme_path,
        ]

        missing_critical_docs = []
        for doc_path in critical_docs:
            if not doc_path.exists():
                missing_critical_docs.append(str(doc_path))

        assert (
            len(missing_critical_docs) == 0
        ), f"Critical documentation missing: {missing_critical_docs}"

        # Check that README contains key sections
        if readme_path.exists():
            readme_content = readme_path.read_text()

            # Should have installation and usage information
            key_sections = ["install", "usage", "genesis"]

            for section in key_sections:
                assert (
                    section.lower() in readme_content.lower()
                ), f"README.md missing key section: {section}"


class TestGenesis15CLICommands:
    """Test CLI command functionality for Genesis 1.5."""

    @pytest.mark.integration
    def test_all_cli_commands_load_without_error(self, runner: CliRunner) -> None:
        """Verify all CLI commands load without import errors."""
        # Test help to ensure all commands are importable
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0, f"CLI help failed: {result.output}"

        # Check that main commands are listed
        expected_commands = [
            "bootstrap",
            "sync",
            "version",
            "status",
            "clean",
            "worktree",
            "container",
            "commit",
            "autofix",
        ]

        for command in expected_commands:
            assert (
                command in result.output
            ), f"Command '{command}' not found in help output"

    @pytest.mark.integration
    def test_genesis_status_command_works(self, runner: CliRunner) -> None:
        """Test genesis status command functionality."""
        result = runner.invoke(cli, ["status"])
        assert result.exit_code == 0, f"Status command failed: {result.output}"

    @pytest.mark.integration
    def test_genesis_version_command_detailed_output(self, runner: CliRunner) -> None:
        """Test detailed version command output."""
        result = runner.invoke(cli, ["version"])
        assert result.exit_code == 0, f"Version command failed: {result.output}"

        # Should contain version information
        assert (
            "1.5.0" in result.output
        ), f"Version 1.5.0 not found in output: {result.output}"

    @pytest.mark.integration
    @pytest.mark.requires_git
    def test_genesis_clean_command_works(
        self, runner: CliRunner, tmp_path: Path
    ) -> None:
        """Test genesis clean command functionality."""
        # Change to tmp directory to avoid affecting real workspace
        original_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)

            result = runner.invoke(cli, ["clean", "--help"])
            # Should show help even in non-Genesis directory
            assert result.exit_code == 0, f"Clean help command failed: {result.output}"
            assert (
                "Clean workspace" in result.output
            ), "Clean command description missing"
        finally:
            os.chdir(original_cwd)

    @pytest.mark.integration
    def test_command_help_text_consistency(self, runner: CliRunner) -> None:
        """Test that command help text is consistent and complete."""
        # Test help for major commands
        commands_to_test = ["bootstrap", "sync", "version", "status", "clean"]

        for command in commands_to_test:
            result = runner.invoke(cli, [command, "--help"])
            assert (
                result.exit_code == 0
            ), f"Help for '{command}' failed: {result.output}"

            # Should contain description and usage
            assert "Usage:" in result.output, f"Help for '{command}' missing usage"
            assert len(result.output.strip()) > 50, f"Help for '{command}' too short"


class TestGenesis15MigrationCompatibility:
    """Test migration and configuration compatibility for Genesis 1.5."""

    @pytest.mark.integration
    def test_sync_yml_configuration_still_works(self, tmp_path: Path) -> None:
        """Test that existing sync.yml configurations still work."""
        # Create a sample sync.yml configuration
        sync_config = {
            "version": "1.0",
            "templates": {
                "shared": [
                    {
                        "source": "CLAUDE.md.template",
                        "dest": "CLAUDE.md",
                        "sync": "never",
                    }
                ]
            },
        }

        config_file = tmp_path / "sync.yml"
        with open(config_file, "w") as f:
            yaml.dump(sync_config, f)

        # Verify config can be parsed
        with open(config_file) as f:
            loaded_config = yaml.safe_load(f)

        assert loaded_config["version"] == "1.0"
        assert "templates" in loaded_config
        assert "shared" in loaded_config["templates"]

    @pytest.mark.integration
    def test_legacy_configuration_detection(
        self, runner: CliRunner, tmp_path: Path
    ) -> None:
        """Test detection and handling of legacy configurations."""
        original_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)

            # Create legacy .genesis directory structure
            genesis_dir = tmp_path / ".genesis"
            genesis_dir.mkdir()

            # Create old-style config
            old_config = {"project_type": "python-api", "version": "0.12.0"}
            config_file = genesis_dir / "config.yml"
            with open(config_file, "w") as f:
                yaml.dump(old_config, f)

            # Test that status command handles legacy config gracefully
            result = runner.invoke(cli, ["status"])
            # Should not crash on legacy config
            assert result.exit_code in [
                0,
                1,
            ], f"Status failed on legacy config: {result.output}"

        finally:
            os.chdir(original_cwd)

    @pytest.mark.integration
    def test_new_init_and_migrate_commands_exist(self, runner: CliRunner) -> None:
        """Verify genesis init and genesis migrate commands exist and work."""
        # Test init command exists
        result = runner.invoke(cli, ["init", "--help"])
        assert result.exit_code == 0, f"Init command not found: {result.output}"

        # Test migrate command exists
        result = runner.invoke(cli, ["migrate", "--help"])
        assert result.exit_code == 0, f"Migrate command not found: {result.output}"

    @pytest.mark.integration
    def test_package_based_template_access(self, tmp_path: Path) -> None:
        """Test that templates can be accessed from package installation."""
        # This tests that templates are properly included in the package
        # when installed via pip rather than being in development mode

        from genesis.commands.bootstrap import get_template_path

        # Test that template discovery works for known project types
        test_types = ["python-api", "cli-tool", "typescript-service"]

        for project_type in test_types:
            template_path = get_template_path(project_type)
            # Should either find the template or return None gracefully
            # (depends on whether templates are available in current environment)
            assert template_path is None or isinstance(
                template_path, Path
            ), f"Template path for {project_type} should be Path or None"


class TestGenesis15NewFeatures:
    """Test new features specifically introduced in Genesis 1.5."""

    @pytest.mark.integration
    def test_enhanced_sync_system_features(self, runner: CliRunner) -> None:
        """Test enhanced sync system features in 1.5."""
        # Test sync command with new options
        result = runner.invoke(cli, ["sync", "--help"])
        assert result.exit_code == 0, f"Sync help failed: {result.output}"

        # Should have enhanced options mentioned in 1.5 docs
        help_text = result.output.lower()
        expected_features = ["dry-run", "force", "preview", "verbose"]

        for feature in expected_features:
            assert (
                feature in help_text
            ), f"Enhanced sync feature '{feature}' not found in help"

    @pytest.mark.integration
    def test_improved_error_handling(self, runner: CliRunner) -> None:
        """Test improved error handling and messaging in 1.5."""
        # Test a command that should fail gracefully
        result = runner.invoke(cli, ["bootstrap", ""], catch_exceptions=False)

        # Should fail with helpful error message, not crash
        assert result.exit_code != 0, "Empty bootstrap should fail"

        # Error message should be helpful (not just a stack trace)
        assert len(result.output) > 0, "Should have error output"
        assert (
            "Error:" in result.output or "error" in result.output.lower()
        ), f"Should have clear error message: {result.output}"

    @pytest.mark.integration
    @pytest.mark.ai_safety
    def test_ai_safety_features_maintained(
        self, runner: CliRunner, tmp_path: Path
    ) -> None:
        """Test that AI safety features are maintained in 1.5."""
        original_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)

            # Test worktree command (AI safety feature)
            result = runner.invoke(cli, ["worktree", "--help"])
            assert result.exit_code == 0, f"Worktree command missing: {result.output}"

            # Should mention AI safety or file limits
            help_text = result.output.lower()
            ai_safety_keywords = ["limit", "safety", "sparse", "files"]

            has_ai_safety_ref = any(
                keyword in help_text for keyword in ai_safety_keywords
            )
            assert (
                has_ai_safety_ref
            ), f"Worktree help should mention AI safety features: {result.output}"

        finally:
            os.chdir(original_cwd)


# Fixtures for integration tests
@pytest.fixture
def runner() -> CliRunner:
    """Provide a Click test runner for CLI testing."""
    return CliRunner()


@pytest.fixture
def temp_genesis_project(tmp_path: Path) -> Path:
    """Create a temporary Genesis project for testing."""
    project_dir = tmp_path / "test_project"
    project_dir.mkdir()

    # Create basic Genesis project structure
    genesis_dir = project_dir / ".genesis"
    genesis_dir.mkdir()

    config = {
        "project_type": "python-api",
        "project_name": "test-project",
        "version": "1.5.0",
    }

    config_file = genesis_dir / "config.yml"
    with open(config_file, "w") as f:
        yaml.dump(config, f)

    return project_dir


# Test execution markers
pytestmark = [
    pytest.mark.integration,
    pytest.mark.requires_git,
]
