"""Tests for Genesis sync command user control features (Issue #250).

Tests the enhanced sync command with:
- --preview: Show detailed diff of changes
- --dry-run: Preview changes without applying
- --files: Sync only specific files
- --exclude: Exclude files from sync
- --reset: Reset files to template defaults
- --force: Force update all files regardless of policy
- --verbose: Show detailed processing information
"""

import os
import tempfile
from collections.abc import Generator
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import click
import pytest
import yaml
from click.testing import CliRunner

from genesis.commands.sync import SyncManager, sync

# Set dev mode for tests to find templates
os.environ["GENESIS_DEV_MODE"] = "true"

# MOVED: This test has been moved to testing/tests/ due to Pure Module Isolation violation (issue #354)
# This file violates isolation by importing from genesis.commands module
# Integration tests should be in testing/tests/ where cross-module dependencies are allowed


class TestSyncUserControls:
    """Test the enhanced sync command user control features."""

    @pytest.fixture
    def temp_project(self) -> Generator[Path]:
        """Create a temporary project directory for testing."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            # Create pyproject.toml to identify as Python project
            pyproject_content = """
[tool.poetry]
name = "test-project"
version = "0.1.0"
description = "Test project"

[tool.poetry.dependencies]
python = "^3.11"
"""
            (project_path / "pyproject.toml").write_text(pyproject_content.strip())

            # Create .genesis directory
            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            yield project_path

    @pytest.fixture
    def sample_sync_config(self) -> dict[str, Any]:
        """Sample sync configuration with multiple files."""
        return {
            "template_source": "python-api",
            "sync_policies": [
                {
                    "source": "Dockerfile.template",
                    "dest": "Dockerfile",
                    "policy": "always",
                    "description": "Docker container configuration",
                },
                {
                    "source": "docker-compose.yml.template",
                    "dest": "docker-compose.yml",
                    "policy": "if_unchanged",
                    "description": "Docker compose configuration",
                },
                {
                    "source": ".envrc.template",
                    "dest": ".envrc",
                    "policy": "never",
                    "description": "Environment configuration",
                },
                {
                    "source": "scripts/setup.sh.template",
                    "dest": "scripts/setup.sh",
                    "policy": "always",
                    "executable": True,
                    "description": "Setup script",
                },
            ],
        }

    @pytest.fixture
    def mock_template_manager(self) -> Generator[MagicMock]:
        """Mock template manager for testing."""
        with patch("genesis.commands.sync.get_template_manager") as mock:
            template_manager = MagicMock()

            # Mock template content - handle both with and without 'shared/' prefix
            def get_template_content(source: str) -> str:
                # Strip 'shared/' prefix if present to normalize the key
                normalized_source = (
                    source.replace("shared/", "")
                    if source.startswith("shared/")
                    else source
                )
                templates = {
                    "Dockerfile.template": "FROM python:3.11\nCOPY . /app\nWORKDIR /app",
                    "docker-compose.yml.template": 'version: "3.8"\nservices:\n  app:\n    build: .',
                    ".envrc.template": "export ENV=development\nexport LOG_LEVEL=info",
                    "scripts/setup.sh.template": '#!/bin/bash\necho "Setting up {{project_name}}"',
                }
                # Return the template content or a default with development in it
                if normalized_source in templates:
                    return templates[normalized_source]
                else:
                    # For unknown templates, return content with 'development' for test compatibility
                    return f"Template content for {source}\nexport ENV=development"

            template_manager.get_template.side_effect = get_template_content

            mock.return_value = template_manager
            yield template_manager

    def test_preview_mode_shows_diff(
        self,
        temp_project: Path,
        sample_sync_config: dict[str, Any],
        mock_template_manager: MagicMock,
    ) -> None:
        """Test that --preview shows colored diff without applying changes."""
        # Create sync configuration
        sync_config_path = temp_project / ".genesis" / "sync.yml"
        with open(sync_config_path, "w") as f:
            yaml.dump(sample_sync_config, f)

        # Create existing file with different content
        existing_file = temp_project / "Dockerfile"
        existing_file.write_text("FROM python:3.9\nOLD CONTENT")

        manager = SyncManager(temp_project, preview=True, verbose=True)

        result = manager.sync()

        # Should detect changes but not apply them
        assert len(manager.diffs) > 0
        assert (
            existing_file.read_text() == "FROM python:3.9\nOLD CONTENT"
        )  # File unchanged
        assert result > 0  # Files with changes detected

    def test_dry_run_mode(
        self,
        temp_project: Path,
        sample_sync_config: dict[str, Any],
        mock_template_manager: MagicMock,
    ) -> None:
        """Test that --dry-run shows what would be synced without applying."""
        # Create sync configuration
        sync_config_path = temp_project / ".genesis" / "sync.yml"
        with open(sync_config_path, "w") as f:
            yaml.dump(sample_sync_config, f)

        manager = SyncManager(temp_project, dry_run=True)

        result = manager.sync()

        # Should report files that would be synced
        assert result > 0
        assert len(manager.synced_files) > 0
        # But no files should actually be created
        assert not (temp_project / "Dockerfile").exists()

    def test_files_filter_specific_files(
        self,
        temp_project: Path,
        sample_sync_config: dict[str, Any],
        mock_template_manager: MagicMock,
    ) -> None:
        """Test that --files only syncs specified files."""
        # Create sync configuration
        sync_config_path = temp_project / ".genesis" / "sync.yml"
        with open(sync_config_path, "w") as f:
            yaml.dump(sample_sync_config, f)

        manager = SyncManager(temp_project, files=["Dockerfile", "docker-compose.yml"])

        manager.sync()

        # Should only sync specified files
        assert (temp_project / "Dockerfile").exists()
        assert (temp_project / "docker-compose.yml").exists()
        assert not (temp_project / ".envrc").exists()
        assert not (temp_project / "scripts" / "setup.sh").exists()

    def test_exclude_filter(
        self,
        temp_project: Path,
        sample_sync_config: dict[str, Any],
        mock_template_manager: MagicMock,
    ) -> None:
        """Test that --exclude skips specified files."""
        # Create sync configuration
        sync_config_path = temp_project / ".genesis" / "sync.yml"
        with open(sync_config_path, "w") as f:
            yaml.dump(sample_sync_config, f)

        manager = SyncManager(temp_project, exclude=[".envrc", "scripts/setup.sh"])

        manager.sync()

        # Should sync files except excluded ones
        assert (temp_project / "Dockerfile").exists()
        assert (temp_project / "docker-compose.yml").exists()
        assert not (temp_project / ".envrc").exists()
        assert not (temp_project / "scripts" / "setup.sh").exists()

    def test_reset_mode_ignores_policies(
        self,
        temp_project: Path,
        sample_sync_config: dict[str, Any],
        mock_template_manager: MagicMock,
    ) -> None:
        """Test that --reset ignores sync policies and resets all files."""
        # Create sync configuration
        sync_config_path = temp_project / ".genesis" / "sync.yml"
        with open(sync_config_path, "w") as f:
            yaml.dump(sample_sync_config, f)

        # Create existing file that normally wouldn't be synced (policy: never)
        envrc_file = temp_project / ".envrc"
        envrc_file.write_text("export OLD_ENV=production")

        manager = SyncManager(temp_project, reset=True)
        manager.template_manager = mock_template_manager

        manager.sync()

        # Should reset file despite 'never' policy
        assert envrc_file.exists()
        assert "development" in envrc_file.read_text()  # Template content applied

    def test_force_mode_overrides_policies(
        self,
        temp_project: Path,
        sample_sync_config: dict[str, Any],
        mock_template_manager: MagicMock,
    ) -> None:
        """Test that --force updates files regardless of policy."""
        # Create sync configuration
        sync_config_path = temp_project / ".genesis" / "sync.yml"
        with open(sync_config_path, "w") as f:
            yaml.dump(sample_sync_config, f)

        # Create existing modified file
        compose_file = temp_project / "docker-compose.yml"
        compose_file.write_text("version: '3.8'\n# User modified content")

        manager = SyncManager(temp_project, force=True)

        manager.sync()

        # Should update file despite being modified
        assert "User modified" not in compose_file.read_text()

    def test_verbose_mode_shows_details(
        self,
        temp_project: Path,
        sample_sync_config: dict[str, Any],
        mock_template_manager: MagicMock,
    ) -> None:
        """Test that --verbose shows detailed processing information."""
        # Create sync configuration
        sync_config_path = temp_project / ".genesis" / "sync.yml"
        with open(sync_config_path, "w") as f:
            yaml.dump(sample_sync_config, f)

        with patch("genesis.commands.sync.logger") as mock_logger:
            manager = SyncManager(temp_project, verbose=True)

            manager.sync()

            # Should log detailed information
            mock_logger.info.assert_any_call("📢 Verbose mode enabled")

    def test_invalid_file_names_error(
        self,
        temp_project: Path,
        sample_sync_config: dict[str, Any],
        mock_template_manager: MagicMock,
    ) -> None:
        """Test that invalid file names in --files raise clear error."""
        # Create sync configuration
        sync_config_path = temp_project / ".genesis" / "sync.yml"
        with open(sync_config_path, "w") as f:
            yaml.dump(sample_sync_config, f)

        manager = SyncManager(
            temp_project, files=["invalid-file.txt", "another-invalid.yml"]
        )

        with pytest.raises(click.ClickException) as exc_info:
            manager.sync()

        # Should list invalid files and available options
        error_msg = str(exc_info.value)
        assert "invalid-file.txt" in error_msg
        assert "another-invalid.yml" in error_msg
        assert "Available files:" in error_msg

    def test_combining_options(
        self,
        temp_project: Path,
        sample_sync_config: dict[str, Any],
        mock_template_manager: MagicMock,
    ) -> None:
        """Test combining multiple options."""
        # Create sync configuration
        sync_config_path = temp_project / ".genesis" / "sync.yml"
        with open(sync_config_path, "w") as f:
            yaml.dump(sample_sync_config, f)

        manager = SyncManager(
            temp_project, preview=True, files=["Dockerfile"], verbose=True
        )

        manager.sync()

        # Should work with combined options
        assert len(manager.diffs) <= 1  # Only one file requested
        assert not (temp_project / "Dockerfile").exists()  # Preview mode, no changes

    def test_cli_option_validation(self) -> None:
        """Test CLI option validation."""
        runner = CliRunner()

        # Test conflicting options
        with patch("genesis.commands.sync._get_project_path") as mock_path:
            mock_path.return_value = Path("/tmp")
            result = runner.invoke(sync, ["--preview", "--dry-run"])

            assert result.exit_code != 0
            assert "Cannot use --preview and --dry-run together" in result.output

    def test_generate_diff_new_file(self, temp_project: Path) -> None:
        """Test diff generation for new file."""
        manager = SyncManager(temp_project)

        new_content = "line1\nline2\nline3"
        dest_path = temp_project / "new_file.txt"

        diff = manager.generate_diff(dest_path, new_content)

        assert diff is not None
        assert "+line1" in diff
        assert "+line2" in diff

    def test_generate_diff_modified_file(self, temp_project: Path) -> None:
        """Test diff generation for modified file."""
        manager = SyncManager(temp_project)

        # Create existing file
        existing_file = temp_project / "existing.txt"
        existing_file.write_text("old line1\nold line2")

        new_content = "new line1\nold line2\nnew line3"

        diff = manager.generate_diff(existing_file, new_content)

        assert diff is not None
        assert "-old line1" in diff
        assert "+new line1" in diff
        assert "+new line3" in diff

    def test_generate_diff_no_changes(self, temp_project: Path) -> None:
        """Test diff generation when no changes needed."""
        manager = SyncManager(temp_project)

        # Create existing file
        existing_file = temp_project / "same.txt"
        content = "same content\nsame lines"
        existing_file.write_text(content)

        diff = manager.generate_diff(existing_file, content)

        assert diff is None  # No changes

    def test_executable_permissions(
        self, temp_project: Path, mock_template_manager: MagicMock
    ) -> None:
        """Test that executable files get proper permissions."""
        # Create sync configuration with executable file
        sync_config = {
            "template_source": "shared",
            "sync_policies": [
                {
                    "source": "setup.sh.template",
                    "dest": "setup.sh",
                    "policy": "always",
                    "executable": True,
                }
            ],
        }

        sync_config_path = temp_project / ".genesis" / "sync.yml"
        with open(sync_config_path, "w") as f:
            yaml.dump(sync_config, f)

        manager = SyncManager(temp_project)
        manager.sync()

        setup_file = temp_project / "setup.sh"
        assert setup_file.exists()

        # Check that file has executable permissions
        file_mode = setup_file.stat().st_mode
        assert file_mode & 0o755  # Should have executable permissions
