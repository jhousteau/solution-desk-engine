"""Focused integration tests for the cleanup-temp.sh script.

Tests the cleanup script functionality in detail including:
- All command-line options and parameter validation
- File age filtering and preservation logic
- Safety checks and container environment detection
- Cleanup of different file types (pytest, pip, logs, artifacts)
- Error handling and edge cases
"""

import os
import subprocess
import time
from pathlib import Path
from unittest.mock import patch

import pytest


@pytest.mark.integration
class TestCleanupScriptFunctionality:
    """Comprehensive tests for cleanup-temp.sh script functionality."""

    @pytest.fixture
    def cleanup_script(self, genesis_root: Path) -> Path:
        """Get path to cleanup script and verify it exists."""
        script_path = genesis_root / "scripts" / "cleanup-temp.sh"
        assert script_path.exists(), f"Cleanup script not found at {script_path}"
        assert script_path.is_file(), "Cleanup script is not a file"
        return script_path

    @pytest.fixture
    def container_env(self) -> dict[str, str]:
        """Mock container environment variables."""
        return {"AGENT_JAILED": "true", "WORKSPACE_LOCKED": "true"}

    def test_script_permissions_and_structure(self, cleanup_script: Path) -> None:
        """Test cleanup script has correct permissions and structure.

        This test verifies:
        - Script is executable
        - Has proper shebang
        - Contains expected functions and configuration
        """
        # Check script is readable
        assert cleanup_script.stat().st_mode & 0o444, "Script should be readable"

        # Read script content to verify structure
        content = cleanup_script.read_text()

        # Check shebang
        assert content.startswith("#!/bin/bash"), "Script should have bash shebang"

        # Check for key components
        assert (
            "set -euo pipefail" in content
        ), "Script should have strict error handling"
        assert "usage()" in content, "Script should have usage function"
        assert "log_info()" in content, "Script should have logging functions"
        assert "clean_pytest_cache()" in content, "Script should have pytest cleanup"
        assert "clean_pip_remnants()" in content, "Script should have pip cleanup"
        assert "main()" in content, "Script should have main function"

    def test_help_output_completeness(self, cleanup_script: Path) -> None:
        """Test help output contains all required information.

        This test verifies:
        - All command-line options are documented
        - Usage examples are provided
        - Purpose and scope are clearly explained
        """
        result = subprocess.run(
            [str(cleanup_script), "--help"], capture_output=True, text=True
        )

        assert result.returncode == 0, "Help should exit successfully"

        help_output = result.stdout

        # Check for all options
        required_options = [
            "--help",
            "-h",
            "--verbose",
            "-v",
            "--dry-run",
            "-n",
            "--max-age",
            "-a",
            "--force",
            "-f",
        ]

        for option in required_options:
            assert option in help_output, f"Help missing option: {option}"

        # Check for usage examples
        assert "EXAMPLES:" in help_output, "Help should include examples"
        assert (
            "Pytest cache" in help_output or "pytest cache" in help_output.lower()
        ), "Help should mention pytest cache"
        assert (
            "Pip" in help_output or "pip" in help_output.lower()
        ), "Help should mention pip cleanup"
        assert (
            "No space left on device" in help_output
        ), "Help should reference the issue"

    def test_parameter_validation(
        self, cleanup_script: Path, container_env: dict[str, str]
    ) -> None:
        """Test parameter validation and error handling.

        This test verifies:
        - Invalid max-age values are rejected
        - Unknown options are rejected with helpful messages
        - Valid parameter combinations work correctly
        """
        env = {**os.environ, **container_env}

        # Test invalid max-age
        result = subprocess.run(
            [str(cleanup_script), "--max-age", "invalid", "--force"],
            capture_output=True,
            text=True,
            env=env,
        )

        assert result.returncode == 1, "Invalid max-age should fail"
        assert (
            "Invalid max age" in result.stdout
        ), "Should show specific error for invalid max-age"

        # Test negative max-age
        result = subprocess.run(
            [str(cleanup_script), "--max-age", "-5", "--force"],
            capture_output=True,
            text=True,
            env=env,
        )

        assert result.returncode == 1, "Negative max-age should fail"

        # Test unknown option
        result = subprocess.run(
            [str(cleanup_script), "--unknown-option"],
            capture_output=True,
            text=True,
            env=env,
        )

        assert result.returncode == 1, "Unknown option should fail"
        assert "Unknown option" in result.stdout, "Should show error for unknown option"

    def test_dry_run_mode_comprehensive(
        self, cleanup_script: Path, tmp_path: Path, container_env: dict[str, str]
    ) -> None:
        """Test dry-run mode thoroughly without making changes.

        This test verifies:
        - Dry-run identifies files correctly
        - No actual file modifications occur
        - Output clearly indicates dry-run mode
        - File counts and size estimates are shown
        """
        env = {**os.environ, **container_env}

        # Create test environment
        test_tmp = tmp_path / "tmp"
        test_var_tmp = tmp_path / "var" / "tmp"
        test_tmp.mkdir(parents=True)
        test_var_tmp.mkdir(parents=True)

        # Create old test files
        old_time = time.time() - (8 * 3600)  # 8 hours ago

        # Pytest cache files
        pytest_dir = test_tmp / "pytest-of-developer"
        pytest_dir.mkdir()
        old_cache = pytest_dir / "test_cache.log"
        old_cache.write_text("test cache data")
        os.utime(old_cache, (old_time, old_time))

        # Run dry-run with mocked paths
        with patch.dict("os.environ", env):
            with patch("os.path.exists", return_value=True):
                with patch("glob.glob") as mock_glob:
                    mock_glob.return_value = [str(pytest_dir)]

                    result = subprocess.run(
                        [str(cleanup_script), "--dry-run", "--verbose", "--force"],
                        capture_output=True,
                        text=True,
                        env=env,
                    )

                    assert result.returncode == 0, "Dry-run should succeed"
                    assert (
                        "DRY RUN MODE" in result.stdout
                    ), "Should clearly indicate dry-run"
                    assert "No files will be actually removed" in result.stdout

    def test_verbose_output_detail(
        self, cleanup_script: Path, container_env: dict[str, str]
    ) -> None:
        """Test verbose mode provides detailed output.

        This test verifies:
        - Verbose mode shows scanning details
        - File-by-file processing is logged
        - Size calculations are displayed
        - Directory operations are traced
        """
        env = {**os.environ, **container_env}

        result = subprocess.run(
            [str(cleanup_script), "--verbose", "--dry-run", "--force"],
            capture_output=True,
            text=True,
            env=env,
        )

        # Should succeed and show verbose information
        assert result.returncode == 0, "Verbose dry-run should succeed"

        output = result.stdout
        assert "[VERBOSE]" in output or "Scanning" in output, "Should show verbose logs"

    def test_max_age_filtering(
        self, cleanup_script: Path, tmp_path: Path, container_env: dict[str, str]
    ) -> None:
        """Test max-age parameter correctly filters files by age.

        This test verifies:
        - Files older than max-age are targeted
        - Files newer than max-age are preserved
        - Age calculation works correctly
        - Edge cases around the age boundary
        """
        env = {**os.environ, **container_env}

        # Test different max-age values
        for max_age in ["1", "6", "24"]:
            result = subprocess.run(
                [str(cleanup_script), "--max-age", max_age, "--dry-run", "--force"],
                capture_output=True,
                text=True,
                env=env,
            )

            assert result.returncode == 0, f"Should succeed with max-age {max_age}"
            assert f"Max file age: {max_age} hours" in result.stdout

    def test_force_mode_behavior(
        self, cleanup_script: Path, container_env: dict[str, str]
    ) -> None:
        """Test force mode bypasses confirmation prompts.

        This test verifies:
        - Force mode skips interactive confirmation
        - Non-force mode would prompt for confirmation
        - Force mode works with other options
        """
        env = {**os.environ, **container_env}

        # Test force mode (should not prompt)
        result = subprocess.run(
            [str(cleanup_script), "--force", "--dry-run"],
            capture_output=True,
            text=True,
            env=env,
            timeout=5,  # Should not hang waiting for input
        )

        assert result.returncode == 0, "Force mode should complete without prompts"

    def test_safety_checks_outside_container(self, cleanup_script: Path) -> None:
        """Test safety checks when running outside container environment.

        This test verifies:
        - Script detects non-container environments
        - Appropriate warnings are shown
        - User can choose to proceed or cancel
        """
        # Remove container environment variables
        env = os.environ.copy()
        env.pop("AGENT_JAILED", None)
        env.pop("WORKSPACE_LOCKED", None)

        # Test cancellation
        result = subprocess.run(
            [str(cleanup_script), "--force"],
            input="n\n",  # Choose not to continue
            capture_output=True,
            text=True,
            env=env,
        )

        assert result.returncode == 0, "Should exit cleanly when cancelled"
        assert "containerized environments" in result.stdout
        assert "Cleanup cancelled for safety" in result.stdout

        # Test proceeding anyway
        result = subprocess.run(
            [str(cleanup_script), "--force"],
            input="y\n",  # Choose to continue
            capture_output=True,
            text=True,
            env=env,
        )

        # Should proceed (may succeed or fail based on environment)
        assert result.returncode in [0, 1], "Should attempt to proceed when confirmed"

    def test_tmpfs_usage_display(
        self, cleanup_script: Path, container_env: dict[str, str]
    ) -> None:
        """Test tmpfs usage monitoring and display.

        This test verifies:
        - Current tmpfs usage is shown before cleanup
        - Usage is shown after cleanup
        - Proper handling when tmpfs not available
        """
        env = {**os.environ, **container_env}
        # Ensure we simulate a container environment
        env["AGENT_JAILED"] = "true"

        # Run the actual script with dry-run to check output
        result = subprocess.run(
            [str(cleanup_script), "--dry-run", "--force"],
            capture_output=True,
            text=True,
            env=env,
        )

        assert result.returncode == 0
        # Output should include cleanup information in dry-run mode
        # Note: actual tmpfs usage display depends on system state
        assert (
            "dry run" in result.stdout.lower()
            or "cleaning" in result.stdout.lower()
            or "cleanup" in result.stdout.lower()
        )

    @pytest.mark.parametrize(
        "file_type,pattern",
        [
            ("pytest", "pytest-of-*"),
            ("pip", "pip-*"),
            ("build", "build-*"),
            ("logs", "*.log"),
        ],
    )
    def test_cleanup_targets_by_type(
        self,
        cleanup_script: Path,
        file_type: str,
        pattern: str,
        container_env: dict[str, str],
    ) -> None:
        """Test cleanup correctly targets different file types.

        This test verifies:
        - Each cleanup function targets appropriate files
        - File patterns match expected locations
        - Cleanup is selective and safe
        """
        env = {**os.environ, **container_env}

        result = subprocess.run(
            [str(cleanup_script), "--dry-run", "--verbose", "--force"],
            capture_output=True,
            text=True,
            env=env,
        )

        assert result.returncode == 0
        # Should complete successfully in dry-run mode
        # Specific output varies by system state

    def test_concurrent_execution_safety(
        self, cleanup_script: Path, container_env: dict[str, str]
    ) -> None:
        """Test script handles concurrent execution safely.

        This test verifies:
        - Script doesn't corrupt files during concurrent runs
        - Proper locking or collision detection
        - Graceful handling of simultaneous execution
        """
        env = {**os.environ, **container_env}

        # Run multiple instances with dry-run to test safety
        processes = []
        for _ in range(3):
            proc = subprocess.Popen(
                [str(cleanup_script), "--dry-run", "--force"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=env,
            )
            processes.append(proc)

        # Wait for all to complete
        results = []
        for proc in processes:
            stdout, stderr = proc.communicate(timeout=10)
            results.append((proc.returncode, stdout, stderr))

        # All should complete successfully
        for returncode, _stdout, stderr in results:
            assert returncode == 0, f"Concurrent execution failed: {stderr}"

    def test_error_recovery_and_logging(
        self, cleanup_script: Path, container_env: dict[str, str]
    ) -> None:
        """Test error recovery and comprehensive logging.

        This test verifies:
        - Script continues after individual file failures
        - Comprehensive error logging
        - Graceful recovery from permission errors
        - Final status reporting includes warnings
        """
        env = {**os.environ, **container_env}

        # Test with verbose logging to see error handling
        result = subprocess.run(
            [str(cleanup_script), "--verbose", "--dry-run", "--force"],
            capture_output=True,
            text=True,
            env=env,
        )

        assert result.returncode == 0
        # Should include status information
        assert (
            "completed" in result.stdout.lower() or "cleanup" in result.stdout.lower()
        )

    def test_workspace_preservation(
        self, cleanup_script: Path, tmp_path: Path, container_env: dict[str, str]
    ) -> None:
        """Test that workspace files are never touched by cleanup.

        This test verifies:
        - Files in /workspace are never targeted
        - Only tmpfs locations are cleaned
        - Workspace cache directories are preserved
        """
        env = {**os.environ, **container_env}

        # Create workspace structure
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        workspace_cache = workspace / ".pytest_cache"
        workspace_cache.mkdir()
        workspace_file = workspace_cache / "important.cache"
        workspace_file.write_text("important workspace data")

        # The script should never target workspace files
        result = subprocess.run(
            [str(cleanup_script), "--dry-run", "--verbose", "--force"],
            capture_output=True,
            text=True,
            env=env,
        )

        assert result.returncode == 0
        # Workspace preservation should be mentioned or implied
        assert (
            "workspace" not in result.stdout.lower()
            or "/workspace" not in result.stdout
        )

    def test_configuration_display(
        self, cleanup_script: Path, container_env: dict[str, str]
    ) -> None:
        """Test configuration settings are properly displayed.

        This test verifies:
        - Configuration summary is shown before execution
        - All parameter values are displayed
        - Mode indicators (dry-run, verbose) are clear
        """
        env = {**os.environ, **container_env}

        result = subprocess.run(
            [
                str(cleanup_script),
                "--max-age",
                "12",
                "--verbose",
                "--dry-run",
                "--force",
            ],
            capture_output=True,
            text=True,
            env=env,
        )

        assert result.returncode == 0
        output = result.stdout

        # Should show configuration
        assert "Configuration:" in output or "Max file age:" in output
        assert "12" in output  # max-age value
        assert "verbose" in output.lower() or "Verbose" in output


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
