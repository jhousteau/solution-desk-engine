"""
Performance and resource management integration tests for Genesis 1.5.

This module tests performance characteristics, resource usage, and
efficiency improvements in Genesis 1.5, ensuring the release maintains
high performance standards.
"""

import gc
import subprocess
import time
from collections.abc import Generator
from pathlib import Path

import psutil
import pytest
from click.testing import CliRunner

from genesis.cli import cli


class TestGenesis15Performance:
    """Test performance characteristics of Genesis 1.5."""

    @pytest.mark.integration
    @pytest.mark.performance
    def test_cli_startup_time_under_threshold(self, runner: CliRunner) -> None:
        """Test that CLI startup time is under acceptable threshold."""
        start_time = time.time()

        result = runner.invoke(cli, ["--help"])

        end_time = time.time()
        startup_time = end_time - start_time

        assert result.exit_code == 0, "CLI help should succeed"
        assert (
            startup_time < 2.0
        ), f"CLI startup too slow: {startup_time:.2f}s (should be < 2s)"

    @pytest.mark.integration
    @pytest.mark.performance
    def test_version_command_response_time(self, runner: CliRunner) -> None:
        """Test that version command responds quickly."""
        times = []

        # Run multiple times to get average
        for _ in range(5):
            start_time = time.time()
            result = runner.invoke(cli, ["version"])
            end_time = time.time()

            assert result.exit_code == 0, "Version command should succeed"
            times.append(end_time - start_time)

        avg_time = sum(times) / len(times)
        assert (
            avg_time < 1.0
        ), f"Version command too slow: {avg_time:.2f}s (should be < 1s)"

    @pytest.mark.integration
    @pytest.mark.performance
    @pytest.mark.slow
    def test_memory_usage_within_limits(self, runner: CliRunner) -> None:
        """Test that Genesis commands stay within memory limits."""
        process = psutil.Process()
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB

        # Run several commands that might use memory
        commands = [
            ["--help"],
            ["version"],
            ["status"],
            [
                "clean",
                "--help",
            ],  # Use --help instead of --dry-run since that option doesn't exist
        ]

        max_memory_used = initial_memory

        for command in commands:
            gc.collect()  # Force garbage collection

            result = runner.invoke(cli, command)
            assert result.exit_code in [0, 1], f"Command {command} failed unexpectedly"

            current_memory = process.memory_info().rss / 1024 / 1024  # MB
            max_memory_used = max(max_memory_used, current_memory)

        memory_increase = max_memory_used - initial_memory
        assert (
            memory_increase < 100
        ), f"Memory usage too high: {memory_increase:.1f}MB increase"


class TestGenesis15ResourceManagement:
    """Test resource management and cleanup in Genesis 1.5."""

    @pytest.mark.integration
    @pytest.mark.performance
    def test_temporary_file_cleanup(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test that Genesis properly cleans up temporary files."""
        import os
        import tempfile

        # Count initial temp files
        temp_dir = Path(tempfile.gettempdir())
        initial_genesis_files = list(temp_dir.glob("*genesis*"))
        initial_count = len(initial_genesis_files)

        # Run commands that might create temporary files
        original_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)

            commands = [["status"], ["clean", "--dry-run"], ["version", "--verbose"]]

            for command in commands:
                runner.invoke(cli, command)
                # Don't assert success - focus on cleanup

        finally:
            os.chdir(original_cwd)

        # Check for temp file cleanup
        final_genesis_files = list(temp_dir.glob("*genesis*"))
        final_count = len(final_genesis_files)

        # Should not have significantly more temp files
        assert (
            final_count <= initial_count + 2
        ), f"Too many temp files created: {final_count - initial_count} new files"

    @pytest.mark.integration
    @pytest.mark.performance
    def test_file_descriptor_management(self, runner: CliRunner) -> None:
        """Test that Genesis properly manages file descriptors."""
        process = psutil.Process()
        initial_fds = process.num_fds() if hasattr(process, "num_fds") else 0

        # Run commands that open files
        commands = [["version"], ["status"], ["--help"]]

        for command in commands:
            runner.invoke(cli, command)
            # Don't assert success - focus on FD management

        if hasattr(process, "num_fds"):
            final_fds = process.num_fds()
            fd_increase = final_fds - initial_fds

            # Should not leak significant file descriptors
            assert fd_increase < 10, f"Too many file descriptors leaked: {fd_increase}"

    @pytest.mark.integration
    @pytest.mark.performance
    @pytest.mark.slow
    def test_subprocess_timeout_handling(
        self, runner: CliRunner, tmp_path: Path
    ) -> None:
        """Test that Genesis properly handles subprocess timeouts."""
        import os

        original_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)

            # Create a mock git repository to test git operations
            subprocess.run(["git", "init"], capture_output=True, timeout=10)

            # Test commands that might use subprocesses
            start_time = time.time()
            runner.invoke(cli, ["status"])
            end_time = time.time()

            execution_time = end_time - start_time

            # Should complete within reasonable time even if git operations are involved
            assert execution_time < 30, f"Command took too long: {execution_time:.1f}s"

        except subprocess.TimeoutExpired:
            pytest.fail("Command timed out - subprocess management issue")
        finally:
            os.chdir(original_cwd)


class TestGenesis15ScalabilityLimits:
    """Test scalability and limits handling in Genesis 1.5."""

    @pytest.mark.integration
    @pytest.mark.ai_safety
    @pytest.mark.slow
    def test_large_directory_handling(self, runner: CliRunner, tmp_path: Path) -> None:
        """Test Genesis behavior with large directory structures."""
        import os

        # Create a directory with many files (but within AI safety limits)
        large_dir = tmp_path / "large_project"
        large_dir.mkdir()

        # Create 40 files (under the 45 file AI safety limit)
        for i in range(40):
            (large_dir / f"file_{i:03d}.txt").write_text(f"Content {i}")

        original_cwd = os.getcwd()
        try:
            os.chdir(large_dir)

            # Test that Genesis handles this appropriately
            start_time = time.time()
            runner.invoke(cli, ["status"])
            end_time = time.time()

            execution_time = end_time - start_time

            # Should complete within reasonable time
            assert (
                execution_time < 10
            ), f"Large directory handling too slow: {execution_time:.1f}s"

        finally:
            os.chdir(original_cwd)

    @pytest.mark.integration
    @pytest.mark.ai_safety
    def test_ai_safety_file_count_enforcement(
        self, runner: CliRunner, tmp_path: Path
    ) -> None:
        """Test that AI safety file count limits are properly enforced."""
        import os

        # Create a directory with too many files (over AI safety limit)
        large_dir = tmp_path / "oversized_project"
        large_dir.mkdir()

        # Create 50 files (over the 45 file AI safety limit)
        for i in range(50):
            (large_dir / f"file_{i:03d}.txt").write_text(f"Content {i}")

        original_cwd = os.getcwd()
        try:
            os.chdir(large_dir)

            # Test that Genesis detects and handles this appropriately
            result = runner.invoke(cli, ["status"])

            # Should either warn about file count or suggest worktree usage
            output_lower = result.output.lower()
            ai_safety_indicators = ["file", "limit", "worktree", "safety", "sparse"]

            any(indicator in output_lower for indicator in ai_safety_indicators)

            # Note: This might succeed or fail depending on AI safety enforcement mode
            # The important thing is that it handles the situation gracefully
            assert result.exit_code in [
                0,
                1,
            ], "Should handle large directories gracefully"

        finally:
            os.chdir(original_cwd)


class TestGenesis15Dependencies:
    """Test dependency loading and performance in Genesis 1.5."""

    @pytest.mark.integration
    @pytest.mark.performance
    def test_import_time_performance(self) -> None:
        """Test that Genesis imports complete within reasonable time."""
        import subprocess
        import sys

        start_time = time.time()

        # Test importing the main CLI module
        result = subprocess.run(
            [sys.executable, "-c", "from genesis.cli import cli"],
            capture_output=True,
            text=True,
            timeout=10,
        )

        end_time = time.time()
        import_time = end_time - start_time

        assert result.returncode == 0, f"Import failed: {result.stderr}"
        assert (
            import_time < 3.0
        ), f"Import too slow: {import_time:.2f}s (should be < 3s)"

    @pytest.mark.integration
    @pytest.mark.performance
    def test_shared_core_dependency_resolution(self) -> None:
        """Test that shared-core dependency resolution is efficient."""
        start_time = time.time()

        # Import shared_core - should work via dependency resolution
        from genesis.core import get_logger

        end_time = time.time()
        resolution_time = end_time - start_time

        logger = get_logger(__name__)
        assert logger is not None, "Logger should be created successfully"
        assert (
            resolution_time < 2.0
        ), f"Dependency resolution too slow: {resolution_time:.2f}s"

    @pytest.mark.integration
    @pytest.mark.performance
    def test_lazy_loading_behavior(self, runner: CliRunner) -> None:
        """Test that Genesis uses lazy loading where appropriate."""
        # This tests that not all modules are loaded on simple commands
        import sys

        # Clear any previously imported Genesis modules
        genesis_modules = [
            name for name in sys.modules.keys() if name.startswith("genesis.")
        ]
        initial_module_count = len(genesis_modules)

        # Run a simple command
        result = runner.invoke(cli, ["version"])
        assert result.exit_code == 0, "Version command should succeed"

        # Check module loading
        final_genesis_modules = [
            name for name in sys.modules.keys() if name.startswith("genesis.")
        ]
        final_module_count = len(final_genesis_modules)

        # Should not load excessive modules for simple version command
        modules_loaded = final_module_count - initial_module_count
        assert (
            modules_loaded < 20
        ), f"Too many modules loaded for simple command: {modules_loaded}"


# Performance test fixtures
@pytest.fixture(scope="module")
def performance_monitor() -> Generator[dict[str, float]]:
    """Monitor system performance during tests."""
    process = psutil.Process()
    initial_stats = {
        "memory": process.memory_info().rss / 1024 / 1024,  # MB
        "cpu_percent": process.cpu_percent(),
        "num_fds": process.num_fds() if hasattr(process, "num_fds") else 0,
    }

    yield initial_stats

    # Could add cleanup/validation here if needed


# Fixtures for integration tests
@pytest.fixture
def runner() -> CliRunner:
    """Provide a Click test runner for CLI testing."""
    return CliRunner()


# Test markers
pytestmark = [
    pytest.mark.integration,
    pytest.mark.performance,
]
