"""Tests for genesis update-templates CLI command."""

from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner

from genesis.commands.update_templates import update_templates


class TestUpdateTemplatesCommand:
    """Test suite for genesis update-templates CLI command."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create a Click CLI test runner."""
        return CliRunner()

    @pytest.fixture
    def temp_templates_dir(self, tmp_path: Path) -> Path:
        """Create a temporary templates/shared directory structure."""
        templates_dir = tmp_path / "templates" / "shared"
        templates_dir.mkdir(parents=True)
        return templates_dir

    @pytest.fixture
    def sample_manifest(self, temp_templates_dir: Path) -> Path:
        """Create a sample manifest.yml file."""
        manifest_path = temp_templates_dir / "manifest.yml"
        manifest_data = {
            "shared_files": [],
            "template_variables": [],
            "sync_config": {
                "backup_changed_files": True,
                "create_directories": True,
                "preserve_permissions": True,
            },
        }
        with open(manifest_path, "w") as f:
            yaml.dump(manifest_data, f, default_flow_style=False, sort_keys=False)
        return manifest_path

    def test_command_exists(self, runner: CliRunner) -> None:
        """Test that the update-templates command is available."""
        result = runner.invoke(update_templates, ["--help"])
        assert result.exit_code == 0
        assert "update-templates" in result.output or "Update" in result.output

    def test_command_dry_run_flag(
        self, runner: CliRunner, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that --dry-run flag prevents file modifications."""
        # Create test file
        test_file = temp_templates_dir / "test.txt"
        test_file.write_text("test content")

        # Read original manifest
        with open(sample_manifest) as f:
            original_content = f.read()

        # Run with dry-run
        result = runner.invoke(
            update_templates,
            [
                "--dry-run",
                "--templates-dir",
                str(temp_templates_dir),
                "--manifest",
                str(sample_manifest),
            ],
        )

        assert result.exit_code == 0
        assert "DRY RUN" in result.output or "Preview" in result.output

        # Manifest should be unchanged
        with open(sample_manifest) as f:
            current_content = f.read()
        assert current_content == original_content

    def test_command_updates_manifest(
        self, runner: CliRunner, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that command updates manifest with discovered files."""
        # Create test files
        (temp_templates_dir / "file1.txt").write_text("content1")
        (temp_templates_dir / "file2.sh").write_text("#!/bin/bash")

        # Run command
        result = runner.invoke(
            update_templates,
            [
                "--templates-dir",
                str(temp_templates_dir),
                "--manifest",
                str(sample_manifest),
            ],
        )

        assert result.exit_code == 0
        assert "updated successfully" in result.output or "changes" in result.output

        # Verify manifest was updated
        with open(sample_manifest) as f:
            manifest = yaml.safe_load(f)

        sources = [item["source"] for item in manifest["shared_files"]]
        assert "file1.txt" in sources
        assert "file2.sh" in sources

    def test_command_reports_added_files(
        self, runner: CliRunner, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that command reports newly added files."""
        # Create test file
        (temp_templates_dir / "new_file.txt").write_text("new content")

        # Run command
        result = runner.invoke(
            update_templates,
            [
                "--templates-dir",
                str(temp_templates_dir),
                "--manifest",
                str(sample_manifest),
            ],
        )

        assert result.exit_code == 0
        assert "new_file.txt" in result.output
        assert "Added" in result.output or "+" in result.output

    def test_command_reports_removed_files(
        self, runner: CliRunner, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that command reports removed files."""
        # Add a file to manifest but don't create it
        with open(sample_manifest, "w") as f:
            yaml.dump(
                {
                    "shared_files": [
                        {
                            "source": "removed_file.txt",
                            "dest": "removed_file.txt",
                            "sync": "always",
                            "source_hash": "sha256:abc123",
                            "description": "Removed file",
                        }
                    ],
                    "template_variables": [],
                    "sync_config": {},
                },
                f,
            )

        # Run command
        result = runner.invoke(
            update_templates,
            [
                "--templates-dir",
                str(temp_templates_dir),
                "--manifest",
                str(sample_manifest),
            ],
        )

        assert result.exit_code == 0
        assert "removed_file.txt" in result.output
        assert "Removed" in result.output or "-" in result.output

    def test_command_reports_changed_files(
        self, runner: CliRunner, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that command reports files with changed hashes."""
        # Create file
        test_file = temp_templates_dir / "changed.txt"
        test_file.write_text("new content")

        # Add to manifest with old hash
        with open(sample_manifest, "w") as f:
            yaml.dump(
                {
                    "shared_files": [
                        {
                            "source": "changed.txt",
                            "dest": "changed.txt",
                            "sync": "always",
                            "source_hash": "sha256:old_hash_value",
                            "description": "Changed file",
                        }
                    ],
                    "template_variables": [],
                    "sync_config": {},
                },
                f,
            )

        # Run command
        result = runner.invoke(
            update_templates,
            [
                "--templates-dir",
                str(temp_templates_dir),
                "--manifest",
                str(sample_manifest),
            ],
        )

        assert result.exit_code == 0
        assert "changed.txt" in result.output
        assert "Changed" in result.output or "~" in result.output

    def test_command_no_changes_message(
        self, runner: CliRunner, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that command shows appropriate message when no changes are needed."""
        # Create file and sync manifest
        test_file = temp_templates_dir / "test.txt"
        test_file.write_text("content")

        # First run to sync
        runner.invoke(
            update_templates,
            [
                "--templates-dir",
                str(temp_templates_dir),
                "--manifest",
                str(sample_manifest),
            ],
        )

        # Second run should show no changes
        result = runner.invoke(
            update_templates,
            [
                "--templates-dir",
                str(temp_templates_dir),
                "--manifest",
                str(sample_manifest),
            ],
        )

        assert result.exit_code == 0
        assert (
            "up to date" in result.output.lower()
            or "no changes" in result.output.lower()
        )

    def test_command_auto_discovers_templates_dir(self, runner: CliRunner) -> None:
        """Test that command can auto-discover templates directory."""
        # This test will fail if not in Genesis project, which is expected
        result = runner.invoke(update_templates, ["--dry-run"])

        # Should either succeed (if in Genesis project) or show clear error
        if result.exit_code != 0:
            assert (
                "Could not find templates directory" in result.output
                or "not found" in result.output
            )

    def test_command_with_explicit_manifest_path(
        self, runner: CliRunner, temp_templates_dir: Path, tmp_path: Path
    ) -> None:
        """Test that command accepts explicit manifest path."""
        # Create test file
        (temp_templates_dir / "test.txt").write_text("content")

        # Create manifest in different location
        manifest_path = tmp_path / "custom_manifest.yml"
        manifest_path.write_text("shared_files: []\n")

        # Run command
        result = runner.invoke(
            update_templates,
            [
                "--templates-dir",
                str(temp_templates_dir),
                "--manifest",
                str(manifest_path),
            ],
        )

        assert result.exit_code == 0
        assert manifest_path.exists()

        # Verify custom manifest was updated
        with open(manifest_path) as f:
            manifest = yaml.safe_load(f)
        assert len(manifest.get("shared_files", [])) > 0

    def test_command_handles_missing_templates_dir(self, runner: CliRunner) -> None:
        """Test that command handles missing templates directory gracefully."""
        result = runner.invoke(
            update_templates, ["--templates-dir", "/nonexistent/path"]
        )

        assert result.exit_code != 0

    def test_command_preserves_custom_descriptions(
        self, runner: CliRunner, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that command preserves custom descriptions in manifest."""
        # Create file
        test_file = temp_templates_dir / "test.txt"
        test_file.write_text("content")

        # Add to manifest with custom description
        custom_desc = "My custom description for this file"
        with open(sample_manifest, "w") as f:
            yaml.dump(
                {
                    "shared_files": [
                        {
                            "source": "test.txt",
                            "dest": "test.txt",
                            "sync": "always",
                            "source_hash": "sha256:old_hash",
                            "description": custom_desc,
                        }
                    ],
                    "template_variables": [],
                    "sync_config": {},
                },
                f,
            )

        # Run command
        result = runner.invoke(
            update_templates,
            [
                "--templates-dir",
                str(temp_templates_dir),
                "--manifest",
                str(sample_manifest),
            ],
        )

        assert result.exit_code == 0

        # Verify custom description preserved
        with open(sample_manifest) as f:
            manifest = yaml.safe_load(f)

        test_entry = next(
            item for item in manifest["shared_files"] if item["source"] == "test.txt"
        )
        assert test_entry["description"] == custom_desc

    def test_command_detects_sync_policies(
        self, runner: CliRunner, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that command correctly detects sync policies for different file types."""
        # Create files with different expected policies
        (temp_templates_dir / "README.md").write_text("# README")  # never
        scripts_dir = temp_templates_dir / ".genesis" / "scripts"
        scripts_dir.mkdir(parents=True)
        (scripts_dir / "setup.sh").write_text("#!/bin/bash")  # always
        (temp_templates_dir / ".envrc").write_text("export VAR=1")  # if_unchanged

        # Run command
        result = runner.invoke(
            update_templates,
            [
                "--templates-dir",
                str(temp_templates_dir),
                "--manifest",
                str(sample_manifest),
            ],
        )

        assert result.exit_code == 0

        # Verify sync policies
        with open(sample_manifest) as f:
            manifest = yaml.safe_load(f)

        entries_by_source = {item["source"]: item for item in manifest["shared_files"]}

        assert entries_by_source["README.md"]["sync"] == "never"
        assert entries_by_source[".genesis/scripts/setup.sh"]["sync"] == "always"
        assert entries_by_source[".envrc"]["sync"] == "if_unchanged"

    def test_command_calculates_hashes(
        self, runner: CliRunner, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that command calculates SHA-256 hashes for files."""
        # Create test file
        test_file = temp_templates_dir / "test.txt"
        test_file.write_text("test content")

        # Run command
        result = runner.invoke(
            update_templates,
            [
                "--templates-dir",
                str(temp_templates_dir),
                "--manifest",
                str(sample_manifest),
            ],
        )

        assert result.exit_code == 0

        # Verify hash was calculated
        with open(sample_manifest) as f:
            manifest = yaml.safe_load(f)

        test_entry = next(
            item for item in manifest["shared_files"] if item["source"] == "test.txt"
        )
        assert "source_hash" in test_entry
        assert test_entry["source_hash"].startswith("sha256:")
        assert len(test_entry["source_hash"]) > 10  # Has actual hash value
