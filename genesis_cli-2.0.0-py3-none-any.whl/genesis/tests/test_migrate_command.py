"""Tests for Genesis migrate command."""

import json
from pathlib import Path
from typing import Any
from unittest.mock import patch

from click.testing import CliRunner

from genesis.commands.migrate import (
    MigrationDetector,
    VariableExtractor,
    migrate_command,
)


class TestMigrationDetector:
    """Test migration strategy detection."""

    def test_detect_already_migrated(self, tmp_path: Path) -> None:
        """Test detection of already migrated project."""
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()
        (genesis_dir / "sync.yml").write_text("version: 1.0\n")

        strategy, metadata = MigrationDetector.detect_migration_strategy(tmp_path)

        assert strategy == "already_migrated"
        assert "config_file" in metadata

    def test_detect_sync_state_migration(self, tmp_path: Path) -> None:
        """Test detection of sync-state.json migration needed."""
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()

        sync_state = {
            "last_sync": "2024-01-01T00:00:00Z",
            "files": {"Dockerfile": {"hash": "abc123"}},
        }
        (genesis_dir / "sync-state.json").write_text(json.dumps(sync_state))

        strategy, metadata = MigrationDetector.detect_migration_strategy(tmp_path)

        assert strategy == "migrate_from_sync_state"
        assert "sync_state" in metadata
        assert metadata["sync_state"]["files"]["Dockerfile"]["hash"] == "abc123"

    def test_detect_partial_migration(self, tmp_path: Path) -> None:
        """Test detection of partial Genesis configuration."""
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()

        scripts_dir = genesis_dir / "scripts"
        scripts_dir.mkdir()
        (scripts_dir / "validate.sh").write_text("#!/bin/bash\necho 'validate'")

        strategy, metadata = MigrationDetector.detect_migration_strategy(tmp_path)

        assert strategy == "migrate_from_partial"
        assert metadata["has_scripts"] is True

    def test_detect_legacy_migration(self, tmp_path: Path) -> None:
        """Test detection of legacy project structure."""
        # Create legacy structure indicators
        (tmp_path / "Dockerfile").write_text("FROM python:3.11")
        claude_dir = tmp_path / ".claude" / "commands"
        claude_dir.mkdir(parents=True)
        (claude_dir / "test.md").write_text("# Test command")

        strategy, metadata = MigrationDetector.detect_migration_strategy(tmp_path)

        assert strategy == "migrate_from_legacy"
        assert "legacy_files" in metadata
        assert len(metadata["legacy_files"]) > 0

    def test_detect_no_genesis_config(self, tmp_path: Path) -> None:
        """Test detection when no Genesis configuration exists."""
        strategy, metadata = MigrationDetector.detect_migration_strategy(tmp_path)

        assert strategy == "no_genesis_config"
        assert metadata == {}


class TestVariableExtractor:
    """Test template variable extraction."""

    def test_extract_basic_variables(self, tmp_path: Path) -> None:
        """Test extraction of basic project variables."""
        variables = VariableExtractor.extract_variables(tmp_path)

        assert "project_name" in variables
        assert "module_name" in variables
        assert variables["project_name"] == tmp_path.name
        assert variables["module_name"] == tmp_path.name.replace("-", "_")

    def test_extract_from_pyproject_toml(self, tmp_path: Path) -> None:
        """Test extraction from pyproject.toml."""
        pyproject_content = """
[tool.poetry]
name = "test-project"
version = "0.1.0"
description = "A test project"
authors = ["John Doe <john@example.com>"]

[tool.poetry.dependencies]
python = "^3.11"
        """
        (tmp_path / "pyproject.toml").write_text(pyproject_content)

        variables = VariableExtractor.extract_variables(tmp_path)

        assert variables["author_name"] == "John Doe"
        assert variables["author_email"] == "john@example.com"
        assert variables["project_description"] == "A test project"
        assert variables["python_version"] == "^3.11"

    def test_extract_from_docker_compose(self, tmp_path: Path) -> None:
        """Test extraction from docker-compose.yml."""
        compose_content = """
version: '3.8'
services:
  app:
    build: .
    ports:
      - "8000:8000"
networks:
  default:
    ipam:
      config:
        - subnet: 172.20.0.0/16
        """
        (tmp_path / "docker-compose.yml").write_text(compose_content)

        variables = VariableExtractor.extract_variables(tmp_path)

        assert variables["docker_subnet"] == "172.20.0.0/16"
        assert variables["app_port"] == "8000"

    def test_extract_from_package_json(self, tmp_path: Path) -> None:
        """Test extraction from package.json."""
        package_content = """
{
  "name": "test-project",
  "description": "A TypeScript test project",
  "author": {
    "name": "Jane Smith",
    "email": "jane@example.com"
  }
}
        """
        (tmp_path / "package.json").write_text(package_content)

        variables = VariableExtractor.extract_variables(tmp_path)

        assert variables["project_description"] == "A TypeScript test project"
        assert variables["author_name"] == "Jane Smith"
        assert variables["author_email"] == "jane@example.com"


class TestMigrateCommand:
    """Test the migrate CLI command."""

    def test_migrate_command_no_genesis_config(self, tmp_path: Path) -> None:
        """Test migrate command with no Genesis configuration."""
        runner = CliRunner()

        with runner.isolated_filesystem():
            result = runner.invoke(migrate_command, ["--dry-run"])

            assert result.exit_code != 0
            assert "No Genesis configuration found" in result.output

    def test_migrate_command_already_migrated(self, tmp_path: Path) -> None:
        """Test migrate command with already migrated project."""
        runner = CliRunner()

        with runner.isolated_filesystem():
            # Create .genesis directory with sync.yml in the isolated filesystem
            genesis_dir = Path(".genesis")
            genesis_dir.mkdir()
            (genesis_dir / "sync.yml").write_text("version: 1.0\n")

            result = runner.invoke(migrate_command, ["--dry-run"])

            assert result.exit_code != 0
            assert "already migrated" in result.output

    def test_migrate_command_force_option(self, tmp_path: Path) -> None:
        """Test migrate command with force option."""
        runner = CliRunner()

        with patch("genesis.commands.migrate.MigrationExecutor") as mock_executor:
            # Mock the executor to avoid file system operations
            mock_instance = mock_executor.return_value
            mock_instance.migrate_from_partial.return_value = {
                "strategy": "migrate_from_partial",
                "project_type": "python-api",
                "variables_extracted": 2,
                "files_analyzed": 0,
                "backup_created": None,
                "dry_run": True,
            }

            with runner.isolated_filesystem():
                # Create .genesis directory with sync.yml
                genesis_dir = Path(".genesis")
                genesis_dir.mkdir()
                (genesis_dir / "sync.yml").write_text("version: 1.0\n")

                # Create a minimal project structure
                Path("pyproject.toml").write_text(
                    """
[tool.poetry]
name = "test-project"
version = "0.1.0"
                """
                )

                result = runner.invoke(migrate_command, ["--dry-run", "--force"])

                assert result.exit_code == 0
                assert "Migration Report" in result.output

    @patch("genesis.commands.migrate.Path.home")
    def test_migrate_command_genesis_root_detection(
        self, mock_home: Any, tmp_path: Path
    ) -> None:
        """Test Genesis root detection in migrate command."""
        runner = CliRunner()

        with patch("genesis.commands.migrate.MigrationExecutor") as mock_executor:
            mock_instance = mock_executor.return_value
            mock_instance.migrate_from_sync_state.return_value = {
                "strategy": "migrate_from_sync_state",
                "project_type": "python-api",
                "variables_extracted": 1,
                "files_analyzed": 0,
                "customizations_found": 0,
                "backup_created": None,
                "dry_run": True,
            }

            with runner.isolated_filesystem():
                # Mock home directory
                mock_home.return_value = Path.cwd() / "home"

                # Create a mock Genesis installation
                genesis_path = Path.cwd() / "home" / "projects" / "genesis"
                genesis_path.mkdir(parents=True)
                (genesis_path / "templates").mkdir()
                (genesis_path / "genesis").mkdir()

                # Create a project with sync-state.json
                genesis_dir = Path(".genesis")
                genesis_dir.mkdir()

                sync_state: dict[str, Any] = {"files": {}, "last_sync": None}
                (genesis_dir / "sync-state.json").write_text(json.dumps(sync_state))

                result = runner.invoke(migrate_command, ["--dry-run"])

                assert result.exit_code == 0
                assert "migrate_from_sync_state" in result.output
