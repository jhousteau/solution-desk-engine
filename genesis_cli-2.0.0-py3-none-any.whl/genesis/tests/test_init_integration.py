"""Integration tests for the Genesis init command.

These tests verify the complete end-to-end workflow of the genesis init command,
including CLI integration, project detection, sync configuration generation,
and cross-component compatibility.
"""

import json
import os
import subprocess
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner

from genesis.cli import cli


class TestInitCommandIntegration:
    """Integration tests for genesis init command end-to-end workflows."""

    def setup_method(self) -> None:
        """Set up test environment before each test."""
        self.runner = CliRunner()

    @pytest.fixture
    def python_api_project(self, tmp_path: Path) -> Path:
        """Create a realistic Python API project structure."""
        project_dir = tmp_path / "test-api"
        project_dir.mkdir()

        # Create pyproject.toml
        pyproject_content = """
[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"

[tool.poetry]
name = "test-api"
version = "0.1.0"
description = "Test API project"
authors = ["Test User <test@example.com>"]
readme = "README.md"

[tool.poetry.dependencies]
python = "^3.11"
fastapi = "^0.100.0"
uvicorn = "^0.23.0"
sqlalchemy = "^2.0.0"
alembic = "^1.11.0"

[tool.poetry.group.dev.dependencies]
pytest = "^7.4.0"
black = "^23.7.0"
flake8 = "^6.0.0"
mypy = "^1.5.0"
"""
        (project_dir / "pyproject.toml").write_text(pyproject_content)

        # Create basic project structure
        (project_dir / "README.md").write_text("# Test API\n\nA test API project.")
        (project_dir / "src").mkdir()
        (project_dir / "src" / "test_api").mkdir()
        (project_dir / "src" / "test_api" / "__init__.py").write_text("")
        (project_dir / "src" / "test_api" / "main.py").write_text(
            """
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def read_root():
    return {"Hello": "World"}
"""
        )
        (project_dir / "tests").mkdir()
        (project_dir / "tests" / "__init__.py").write_text("")

        return project_dir

    @pytest.fixture
    def cli_tool_project(self, tmp_path: Path) -> Path:
        """Create a realistic CLI tool project structure."""
        project_dir = tmp_path / "my-cli"
        project_dir.mkdir()

        # Create pyproject.toml for CLI tool
        pyproject_content = """
[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"

[tool.poetry]
name = "my-cli"
version = "0.1.0"
description = "Test CLI tool"
authors = ["Test User <test@example.com>"]

[tool.poetry.dependencies]
python = "^3.11"
click = "^8.1.0"
typer = "^0.9.0"

[tool.poetry.scripts]
my-cli = "my_cli.main:app"

[tool.poetry.group.dev.dependencies]
pytest = "^7.4.0"
"""
        (project_dir / "pyproject.toml").write_text(pyproject_content)

        # Create CLI project structure
        (project_dir / "my_cli").mkdir()
        (project_dir / "my_cli" / "__init__.py").write_text("")
        (project_dir / "my_cli" / "main.py").write_text(
            """
import click

@click.command()
def main():
    click.echo("Hello CLI!")

if __name__ == "__main__":
    main()
"""
        )

        return project_dir

    @pytest.fixture
    def typescript_service_project(self, tmp_path: Path) -> Path:
        """Create a realistic TypeScript service project structure."""
        project_dir = tmp_path / "my-service"
        project_dir.mkdir()

        # Create package.json
        package_json = {
            "name": "my-service",
            "version": "1.0.0",
            "description": "Test TypeScript service",
            "main": "dist/index.js",
            "scripts": {
                "build": "tsc",
                "start": "node dist/index.js",
                "dev": "ts-node src/index.ts",
                "test": "jest",
            },
            "dependencies": {"express": "^4.18.0", "cors": "^2.8.5"},
            "devDependencies": {
                "typescript": "^5.0.0",
                "@types/node": "^20.0.0",
                "@types/express": "^4.17.0",
                "ts-node": "^10.9.0",
                "jest": "^29.5.0",
                "@types/jest": "^29.5.0",
            },
        }
        (project_dir / "package.json").write_text(json.dumps(package_json, indent=2))

        # Create TypeScript config
        tsconfig = {
            "compilerOptions": {
                "target": "ES2020",
                "module": "commonjs",
                "outDir": "./dist",
                "rootDir": "./src",
                "strict": True,
                "esModuleInterop": True,
            },
            "include": ["src/**/*"],
            "exclude": ["node_modules", "dist"],
        }
        (project_dir / "tsconfig.json").write_text(json.dumps(tsconfig, indent=2))

        # Create source structure
        (project_dir / "src").mkdir()
        (project_dir / "src" / "index.ts").write_text(
            """
import express from 'express';

const app = express();
const port = 3000;

app.get('/', (req, res) => {
  res.json({ message: 'Hello TypeScript!' });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
"""
        )

        return project_dir

    @pytest.fixture
    def terraform_project(self, tmp_path: Path) -> Path:
        """Create a realistic Terraform project structure."""
        project_dir = tmp_path / "terraform-infra"
        project_dir.mkdir()

        # Create main.tf
        main_tf = """
terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

resource "aws_s3_bucket" "app_bucket" {
  bucket = "${var.project_name}-bucket"

  tags = {
    Environment = var.environment
    Project     = var.project_name
  }
}

resource "aws_s3_bucket_versioning" "app_bucket_versioning" {
  bucket = aws_s3_bucket.app_bucket.id
  versioning_configuration {
    status = "Enabled"
  }
}
"""
        (project_dir / "main.tf").write_text(main_tf)

        # Create variables.tf
        variables_tf = """
variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment name"
  type        = string
  default     = "dev"
}

variable "project_name" {
  description = "Name of the project"
  type        = string
}
"""
        (project_dir / "variables.tf").write_text(variables_tf)

        # Create outputs.tf
        outputs_tf = """
output "bucket_name" {
  description = "Name of the S3 bucket"
  value       = aws_s3_bucket.app_bucket.bucket
}

output "bucket_arn" {
  description = "ARN of the S3 bucket"
  value       = aws_s3_bucket.app_bucket.arn
}
"""
        (project_dir / "outputs.tf").write_text(outputs_tf)

        return project_dir

    def test_init_python_api_project_detection(self, python_api_project: Path) -> None:
        """Test init command with Python API project detection."""
        with self.runner.isolated_filesystem():
            # Copy project to isolated filesystem
            project_dir = Path.cwd() / "test-api"
            project_dir.mkdir()

            # Copy pyproject.toml for detection
            pyproject_content = (python_api_project / "pyproject.toml").read_text()
            (project_dir / "pyproject.toml").write_text(pyproject_content)

            # Change to project directory
            os.chdir(project_dir)

            # Run genesis init
            result = self.runner.invoke(cli, ["init"])

            # Verify command succeeded
            assert result.exit_code == 0, f"Init failed: {result.output}"
            # Note: Logging output goes to stderr/logging, not Click's result.output
            # We verify success by checking the created files instead

            # Verify .genesis directory and sync.yml created
            genesis_dir = project_dir / ".genesis"
            sync_file = genesis_dir / "sync.yml"
            assert genesis_dir.exists()
            assert sync_file.exists()

            # Verify sync configuration content
            config = yaml.safe_load(sync_file.read_text())
            assert str(config["version"]) == "1.0"
            assert config["project"]["name"] == "test-api"
            assert config["project"]["type"] == "python-api"
            assert config["variables"]["project_name"] == "test-api"
            assert config["variables"]["module_name"] == "test_api"

            # Verify API-specific files are included
            file_patterns = [f["pattern"] for f in config["files"]]
            assert "scripts/test-api.sh" in file_patterns
            assert "alembic.ini" in file_patterns
            assert "pytest.ini" in file_patterns

    def test_init_cli_tool_project_detection(self, cli_tool_project: Path) -> None:
        """Test init command with CLI tool project detection."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "my-cli"
            project_dir.mkdir()

            # Copy pyproject.toml for detection
            pyproject_content = (cli_tool_project / "pyproject.toml").read_text()
            (project_dir / "pyproject.toml").write_text(pyproject_content)

            os.chdir(project_dir)

            result = self.runner.invoke(cli, ["init"])

            assert result.exit_code == 0

            # Verify configuration
            sync_file = project_dir / ".genesis" / "sync.yml"
            config = yaml.safe_load(sync_file.read_text())
            assert config["project"]["type"] == "cli-tool"
            assert config["variables"]["command_name"] == "my-cli"

            # Verify CLI-specific files
            file_patterns = [f["pattern"] for f in config["files"]]
            assert "scripts/build-cli.sh" in file_patterns
            assert "setup.cfg" in file_patterns

    def test_init_typescript_service_detection(
        self, typescript_service_project: Path
    ) -> None:
        """Test init command with TypeScript service detection."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "my-service"
            project_dir.mkdir()

            # Copy package.json for detection
            package_content = (typescript_service_project / "package.json").read_text()
            (project_dir / "package.json").write_text(package_content)

            os.chdir(project_dir)

            result = self.runner.invoke(cli, ["init"])

            assert result.exit_code == 0

            # Verify configuration
            sync_file = project_dir / ".genesis" / "sync.yml"
            config = yaml.safe_load(sync_file.read_text())
            assert config["project"]["type"] == "typescript-service"
            assert config["variables"]["language_extension"] == "ts"

            # Verify TypeScript-specific files
            file_patterns = [f["pattern"] for f in config["files"]]
            assert "scripts/build-ts.sh" in file_patterns
            assert "tsconfig.json" in file_patterns
            assert "jest.config.js" in file_patterns

    def test_init_terraform_project_detection(self, terraform_project: Path) -> None:
        """Test init command with Terraform project detection."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "terraform-infra"
            project_dir.mkdir()

            # Copy Terraform files for detection
            (project_dir / "main.tf").write_text(
                (terraform_project / "main.tf").read_text()
            )
            (project_dir / "variables.tf").write_text(
                (terraform_project / "variables.tf").read_text()
            )

            os.chdir(project_dir)

            result = self.runner.invoke(cli, ["init"])

            assert result.exit_code == 0

            # Verify configuration
            sync_file = project_dir / ".genesis" / "sync.yml"
            config = yaml.safe_load(sync_file.read_text())
            assert config["project"]["type"] == "terraform-project"
            assert config["variables"]["cloud_provider"] == "aws"

            # Verify Terraform-specific files
            file_patterns = [f["pattern"] for f in config["files"]]
            assert "scripts/terraform-*.sh" in file_patterns
            assert "terraform.tfvars.example" in file_patterns

    def test_init_with_explicit_type_override(self, python_api_project: Path) -> None:
        """Test init command with explicit type override."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "test-project"
            project_dir.mkdir()

            # Copy pyproject.toml (would be detected as python-api)
            pyproject_content = (python_api_project / "pyproject.toml").read_text()
            (project_dir / "pyproject.toml").write_text(pyproject_content)

            os.chdir(project_dir)

            # Override to cli-tool type
            result = self.runner.invoke(cli, ["init", "--type", "cli-tool"])

            assert result.exit_code == 0

            # Verify override worked
            sync_file = project_dir / ".genesis" / "sync.yml"
            config = yaml.safe_load(sync_file.read_text())
            assert config["project"]["type"] == "cli-tool"

    def test_init_with_custom_project_name(self, python_api_project: Path) -> None:
        """Test init command with custom project name."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "test-api"
            project_dir.mkdir()

            pyproject_content = (python_api_project / "pyproject.toml").read_text()
            (project_dir / "pyproject.toml").write_text(pyproject_content)

            os.chdir(project_dir)

            # Use custom name
            result = self.runner.invoke(cli, ["init", "--name", "custom-api-name"])

            assert result.exit_code == 0

            # Verify custom name used
            sync_file = project_dir / ".genesis" / "sync.yml"
            config = yaml.safe_load(sync_file.read_text())
            assert config["project"]["name"] == "custom-api-name"
            assert config["variables"]["project_name"] == "custom-api-name"
            assert config["variables"]["module_name"] == "custom_api_name"

    def test_init_with_custom_name_and_cli_type(self, python_api_project: Path) -> None:
        """Test init with custom name and CLI tool type updates module_name correctly."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "test-api"
            project_dir.mkdir()

            pyproject_content = (python_api_project / "pyproject.toml").read_text()
            (project_dir / "pyproject.toml").write_text(pyproject_content)

            os.chdir(project_dir)

            # Use custom name with CLI tool type
            result = self.runner.invoke(
                cli, ["init", "--type", "cli-tool", "--name", "my-custom-tool"]
            )

            assert result.exit_code == 0

            # Verify both project name and module name are updated correctly
            sync_file = project_dir / ".genesis" / "sync.yml"
            config = yaml.safe_load(sync_file.read_text())
            assert config["project"]["name"] == "my-custom-tool"
            assert config["project"]["type"] == "cli-tool"
            assert config["variables"]["project_name"] == "my-custom-tool"
            assert config["variables"]["module_name"] == "my_custom_tool"

    def test_init_force_flag_overwrites_existing(
        self, python_api_project: Path
    ) -> None:
        """Test that --force flag overwrites existing configuration."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "test-api"
            project_dir.mkdir()

            pyproject_content = (python_api_project / "pyproject.toml").read_text()
            (project_dir / "pyproject.toml").write_text(pyproject_content)

            os.chdir(project_dir)

            # Create initial configuration
            result1 = self.runner.invoke(cli, ["init"])
            assert result1.exit_code == 0

            # Try to init again without force (should fail)
            result2 = self.runner.invoke(cli, ["init"])
            assert result2.exit_code == 1

            # Use force flag (should succeed)
            result3 = self.runner.invoke(cli, ["init", "--force"])
            assert result3.exit_code == 0

    def test_init_extracts_git_username(self, python_api_project: Path) -> None:
        """Test that git username is extracted when available."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "test-api"
            project_dir.mkdir()

            pyproject_content = (python_api_project / "pyproject.toml").read_text()
            (project_dir / "pyproject.toml").write_text(pyproject_content)

            os.chdir(project_dir)

            # Initialize git repository and set user
            subprocess.run(["git", "init"], check=True, capture_output=True)
            subprocess.run(
                ["git", "config", "user.name", "Test User"],
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["git", "config", "user.email", "test@example.com"],
                check=True,
                capture_output=True,
            )

            result = self.runner.invoke(cli, ["init"])
            assert result.exit_code == 0

            # Verify git username extracted
            sync_file = project_dir / ".genesis" / "sync.yml"
            config = yaml.safe_load(sync_file.read_text())
            assert config["variables"].get("github_user") == "Test User"

    def test_init_yaml_format_and_comments(self, python_api_project: Path) -> None:
        """Test that generated YAML has proper format and helpful comments."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "test-api"
            project_dir.mkdir()

            pyproject_content = (python_api_project / "pyproject.toml").read_text()
            (project_dir / "pyproject.toml").write_text(pyproject_content)

            os.chdir(project_dir)

            result = self.runner.invoke(cli, ["init"])
            assert result.exit_code == 0

            # Verify YAML format and comments
            sync_file = project_dir / ".genesis" / "sync.yml"
            yaml_content = sync_file.read_text()

            # Check for helpful comments
            assert "# Genesis Sync Configuration" in yaml_content
            assert "# Project metadata" in yaml_content
            assert "# Template variables used for file generation" in yaml_content
            assert "# File synchronization rules" in yaml_content
            assert "# Sync policies:" in yaml_content
            assert "#   - always:" in yaml_content
            assert "#   - if_unchanged:" in yaml_content
            assert "#   - never:" in yaml_content
            assert "#   - local_override:" in yaml_content

            # Verify YAML is valid
            config = yaml.safe_load(yaml_content)
            assert isinstance(config, dict)
            assert "version" in config
            assert "project" in config
            assert "variables" in config
            assert "files" in config
            assert "exclude" in config
            assert "sync_options" in config

    def test_init_in_empty_directory_unknown_type(self) -> None:
        """Test init command in empty directory (unknown project type)."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "empty-project"
            project_dir.mkdir()
            os.chdir(project_dir)

            result = self.runner.invoke(cli, ["init"])

            assert result.exit_code == 0

            # Verify configuration created with unknown type
            sync_file = project_dir / ".genesis" / "sync.yml"
            config = yaml.safe_load(sync_file.read_text())
            assert config["project"]["type"] == "unknown"
            assert config["variables"]["project_name"] == "empty-project"


class TestInitCommandEdgeCases:
    """Edge case tests for the init command."""

    def setup_method(self) -> None:
        """Set up test environment before each test."""
        self.runner = CliRunner()

    def test_init_with_special_characters_in_project_name(self) -> None:
        """Test init with special characters in project name."""
        with self.runner.isolated_filesystem():
            # Create project with special characters
            project_dir = Path.cwd() / "project-with-special@chars"
            project_dir.mkdir()
            os.chdir(project_dir)

            result = self.runner.invoke(
                cli, ["init", "--name", "project-with-special@chars"]
            )

            assert result.exit_code == 0

            # Verify YAML handles special characters properly
            sync_file = project_dir / ".genesis" / "sync.yml"
            yaml_content = sync_file.read_text()
            config = yaml.safe_load(yaml_content)
            assert config["variables"]["project_name"] == "project-with-special@chars"

    def test_init_with_spaces_in_project_path(self) -> None:
        """Test init with spaces in project path."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "project with spaces"
            project_dir.mkdir()
            os.chdir(project_dir)

            result = self.runner.invoke(cli, ["init"])

            assert result.exit_code == 0

            # Verify configuration created successfully
            sync_file = project_dir / ".genesis" / "sync.yml"
            assert sync_file.exists()
            config = yaml.safe_load(sync_file.read_text())
            assert config["variables"]["project_name"] == "project with spaces"

    def test_init_with_mixed_project_types(self) -> None:
        """Test init with mixed project indicators (should pick first match)."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "mixed-project"
            project_dir.mkdir()

            # Create both Python and TypeScript indicators
            pyproject_content = """
[tool.poetry]
name = "mixed-project"
[tool.poetry.dependencies]
python = "^3.11"
fastapi = "^0.100.0"
"""
            (project_dir / "pyproject.toml").write_text(pyproject_content)

            package_json = {
                "name": "mixed-project",
                "dependencies": {"express": "^4.18.0", "typescript": "^5.0.0"},
            }
            (project_dir / "package.json").write_text(json.dumps(package_json))

            os.chdir(project_dir)

            result = self.runner.invoke(cli, ["init"])

            assert result.exit_code == 0
            # Should detect Python first (implementation precedence)
            sync_file = project_dir / ".genesis" / "sync.yml"
            config = yaml.safe_load(sync_file.read_text())
            assert config["project"]["type"] == "python-api"

    def test_init_permission_error_handling(self) -> None:
        """Test init handles permission errors gracefully."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "readonly-project"
            project_dir.mkdir()
            os.chdir(project_dir)

            # Make directory read-only to simulate permission error
            project_dir.chmod(0o444)

            try:
                result = self.runner.invoke(cli, ["init"])

                # Command should handle the error and exit with error code
                assert result.exit_code != 0
                # Actual error handling depends on implementation details
                # At minimum, it shouldn't crash with unhandled exception

            finally:
                # Restore permissions for cleanup
                project_dir.chmod(0o755)

    def test_init_corrupted_project_files(self) -> None:
        """Test init with corrupted project files."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "corrupted-project"
            project_dir.mkdir()

            # Create invalid JSON in package.json
            (project_dir / "package.json").write_text("{ invalid json content")

            os.chdir(project_dir)

            result = self.runner.invoke(cli, ["init"])

            # Should handle corruption gracefully and fall back to unknown type
            assert result.exit_code == 0
            sync_file = project_dir / ".genesis" / "sync.yml"
            config = yaml.safe_load(sync_file.read_text())
            assert config["project"]["type"] == "unknown"

    def test_init_large_project_name_handling(self) -> None:
        """Test init with very long project names."""
        with self.runner.isolated_filesystem():
            # Create very long project name
            long_name = "a" * 200  # 200 character name
            project_dir = Path.cwd() / long_name
            project_dir.mkdir()
            os.chdir(project_dir)

            result = self.runner.invoke(cli, ["init"])

            assert result.exit_code == 0
            sync_file = project_dir / ".genesis" / "sync.yml"
            config = yaml.safe_load(sync_file.read_text())
            assert config["variables"]["project_name"] == long_name


class TestInitCLIIntegration:
    """Test CLI integration and argument parsing for init command."""

    def setup_method(self) -> None:
        """Set up test environment before each test."""
        self.runner = CliRunner()

    def test_init_command_registered_in_cli(self) -> None:
        """Test that init command is properly registered in CLI."""
        result = self.runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "init" in result.output

    def test_init_command_help(self) -> None:
        """Test init command help output."""
        result = self.runner.invoke(cli, ["init", "--help"])
        assert result.exit_code == 0
        assert "Initialize Genesis sync configuration" in result.output
        assert "--force" in result.output
        assert "--type" in result.output
        assert "--name" in result.output

    def test_init_invalid_project_type(self) -> None:
        """Test init with invalid project type."""
        with self.runner.isolated_filesystem():
            project_dir = Path.cwd() / "test-project"
            project_dir.mkdir()
            os.chdir(project_dir)

            result = self.runner.invoke(cli, ["init", "--type", "invalid-type"])

            # Should handle gracefully - invalid types are allowed but will use default
            assert result.exit_code == 0
            sync_file = project_dir / ".genesis" / "sync.yml"
            config = yaml.safe_load(sync_file.read_text())
            assert config["project"]["type"] == "invalid-type"


class TestInitSyncCompatibility:
    """Test compatibility between init command and existing sync command."""

    def setup_method(self) -> None:
        """Set up test environment before each test."""
        self.runner = CliRunner()

    def test_init_generated_config_is_valid_for_sync(self, tmp_path: Path) -> None:
        """Test that init-generated config is valid for sync command."""
        project_dir = tmp_path / "test-project"
        project_dir.mkdir()

        # Create a Python API project
        pyproject_content = """
[tool.poetry]
name = "test-project"
[tool.poetry.dependencies]
python = "^3.11"
fastapi = "^0.100.0"
"""
        (project_dir / "pyproject.toml").write_text(pyproject_content)

        os.chdir(project_dir)

        # Run init to create configuration
        result = self.runner.invoke(cli, ["init"])
        assert result.exit_code == 0

        # Verify sync can read the generated configuration
        sync_file = project_dir / ".genesis" / "sync.yml"
        assert sync_file.exists()

        # Load and validate the configuration structure
        config = yaml.safe_load(sync_file.read_text())

        # Verify all required fields for sync are present
        required_fields = [
            "version",
            "project",
            "variables",
            "files",
            "exclude",
            "sync_options",
        ]
        for field in required_fields:
            assert field in config, f"Missing required field: {field}"

        # Verify project metadata structure
        assert "name" in config["project"]
        assert "type" in config["project"]

        # Verify files structure
        assert isinstance(config["files"], list)
        if config["files"]:  # If files exist, check structure
            for file_config in config["files"]:
                assert "pattern" in file_config
                assert "sync" in file_config
                assert file_config["sync"] in [
                    "always",
                    "if_unchanged",
                    "never",
                    "local_override",
                ]

        # Verify exclude patterns
        assert isinstance(config["exclude"], list)

        # Verify sync options
        sync_options = config["sync_options"]
        expected_options = [
            "create_backups",
            "show_diff",
            "auto_format",
            "preserve_executable",
        ]
        for option in expected_options:
            assert option in sync_options
            assert isinstance(sync_options[option], bool)

    def test_init_config_follows_manifest_patterns(self, tmp_path: Path) -> None:
        """Test that init-generated config follows the same patterns as manifest.yml."""
        project_dir = tmp_path / "test-project"
        project_dir.mkdir()

        # Create a Python API project
        pyproject_content = """
[tool.poetry]
name = "test-project"
[tool.poetry.dependencies]
python = "^3.11"
fastapi = "^0.100.0"
"""
        (project_dir / "pyproject.toml").write_text(pyproject_content)

        os.chdir(project_dir)

        # Run init
        result = self.runner.invoke(cli, ["init"])
        assert result.exit_code == 0

        # Load the generated config
        sync_file = project_dir / ".genesis" / "sync.yml"
        config = yaml.safe_load(sync_file.read_text())

        # Verify sync policies match expected patterns from SyncConfigGenerator
        file_policies = {f["pattern"]: f["sync"] for f in config["files"]}

        # Check some key patterns that should be present
        always_patterns = [".claude/agents/**", ".genesis/scripts/**", "Dockerfile"]
        for pattern in always_patterns:
            if pattern in file_policies:
                assert file_policies[pattern] == "always"

        if_unchanged_patterns = [".pre-commit-config.yaml", ".gitignore", "Makefile"]
        for pattern in if_unchanged_patterns:
            if pattern in file_policies:
                assert file_policies[pattern] == "if_unchanged"

        never_patterns = ["pyproject.toml", "README.md", "src/**"]
        for pattern in never_patterns:
            if pattern in file_policies:
                assert file_policies[pattern] == "never"
