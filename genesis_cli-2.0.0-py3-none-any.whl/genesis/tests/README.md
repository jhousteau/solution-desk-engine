# Genesis Tests

Comprehensive test suite for the Genesis CLI and core functionality.

## Test Structure

### CLI Command Tests
Tests for all Genesis CLI commands with real functionality (minimal mocking):

- **test_cli.py** - Main CLI entry point and command registration
- **test_branch_command.py** - Git branch management operations
- **test_checkout_command.py** - Git checkout functionality
- **test_container_command.py** - Docker container operations
- **test_pull_command.py** - Git pull and remote sync
- **test_reset_command.py** - Git reset operations
- **test_bootstrap_command.py** - Project bootstrapping

### Core Module Tests
Tests for Genesis core functionality:

- **test_autofix.py** - Multi-stage code fixing system
- **test_context_management.py** - Request and trace context handling
- **test_dependencies.py** - Dependency resolution system
- **test_smart_sync.py** - Template synchronization
- **test_solve_sizer.py** - SOLVE constraint sizing
- **test_hardcoded_detection.py** - Hardcoded value detection

## Running Tests

```bash
# Run all tests
make test

# Run specific test file
poetry run pytest genesis/tests/test_cli.py

# Run with verbose output
poetry run pytest -v

# Run specific test
poetry run pytest genesis/tests/test_cli.py::TestCLICommands::test_cli_version
```

## Test Philosophy

These tests prioritize:
1. **Real functionality** - Actual Git operations, file I/O, command execution
2. **Minimal mocking** - Only mock external services (network, Docker daemon)
3. **Integration testing** - Test complete workflows
4. **Error cases** - Verify proper handling of failures

## Coverage

All CLI commands have test coverage:
- ✅ autofix
- ✅ bootstrap
- ✅ branch
- ✅ checkout
- ✅ clean
- ✅ commit
- ✅ container
- ✅ pull
- ✅ reset
- ✅ solve
- ✅ status
- ✅ sync
- ✅ version
- ✅ worktree

## Adding New Tests

When adding new tests:
1. Use real operations wherever possible
2. Create actual files, directories, Git repos
3. Test both success and failure cases
4. Clean up resources in teardown
5. Use descriptive test names
