"""Tests for sync.yml to manifest.yml migration tooling (issue #458.5)."""

import logging
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml
from _pytest.logging import LogCaptureFixture

from genesis.commands.sync import SyncManager


class TestSyncYmlDeprecationWarnings:
    """Test deprecation warnings when sync.yml is detected."""

    def test_sync_shows_deprecation_warning_when_using_sync_yml(
        self, tmp_path: Path
    ) -> None:
        """Test that sync operations show deprecation warning when using sync.yml."""
        # Arrange: Create project with sync.yml (no manifest.yml)
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()

        sync_yml = genesis_dir / "sync.yml"
        sync_yml.write_text(
            """
template_source: shared
files:
  - source: test.template
    dest: test.txt
    policy: always
"""
        )

        # Act: Load config and capture logger calls
        # Use patch to mock the logger and verify the warning was called
        with patch("genesis.commands.sync.logger") as mock_logger:
            manager = SyncManager(tmp_path)
            config = manager.load_config()

            # Assert: Deprecation warning logged
            # Check that logger.warning was called with deprecation message
            warning_calls = [call[0][0] for call in mock_logger.warning.call_args_list]
            warning_text = " ".join(warning_calls).lower()

            assert (
                "deprecation" in warning_text or "deprecated" in warning_text
            ), f"Expected deprecation warning not found. Warning calls: {warning_calls}"
            assert "manifest" in warning_text
            assert config is not None

    def test_sync_no_warning_when_using_manifest_yml(
        self, tmp_path: Path, caplog: LogCaptureFixture
    ) -> None:
        """Test that no deprecation warning shown when using manifest.yml."""
        # Arrange: Create project with manifest.yml
        caplog.set_level(logging.WARNING)

        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()

        manifest_yml = genesis_dir / "manifest.yml"
        manifest_yml.write_text(
            """
shared_files:
  - source: test.template
    dest: test.txt
    sync: always
"""
        )

        # Act: Load config
        manager = SyncManager(tmp_path)
        config = manager.load_config()

        # Assert: No deprecation warning
        assert "deprecated" not in caplog.text.lower()
        assert config is not None


class TestSyncYmlToManifestMigration:
    """Test sync.yml to manifest.yml migration functionality."""

    def test_convert_sync_yml_to_manifest_format(self, tmp_path: Path) -> None:
        """Test conversion of sync.yml format to manifest.yml format."""
        # Arrange: Create sync.yml with various policy types
        sync_config = {
            "template_source": "shared",
            "files": [
                {
                    "source": "Dockerfile.template",
                    "dest": "Dockerfile",
                    "policy": "always",
                    "description": "Container config",
                },
                {
                    "source": "Makefile.template",
                    "dest": "Makefile",
                    "policy": "if_unchanged",
                    "description": "Build automation",
                },
                {
                    "source": "CLAUDE.md.template",
                    "dest": "CLAUDE.md",
                    "policy": "never",
                    "description": "AI instructions",
                },
                {
                    "source": "setup.sh.template",
                    "dest": ".genesis/scripts/setup/setup.sh",
                    "policy": "always",
                    "executable": True,
                    "description": "Setup script",
                },
            ],
        }

        # Act: Convert to manifest format
        from genesis.commands.migrate_sync import convert_sync_to_manifest

        manifest_config = convert_sync_to_manifest(sync_config)

        # Assert: Proper manifest structure
        assert "shared_files" in manifest_config
        assert len(manifest_config["shared_files"]) == 4

        # Check field conversions
        first_file = manifest_config["shared_files"][0]
        assert first_file["source"] == "Dockerfile.template"
        assert first_file["dest"] == "Dockerfile"
        assert first_file["sync"] == "always"  # policy -> sync
        assert first_file["description"] == "Container config"

        # Check executable preservation
        exec_file = manifest_config["shared_files"][3]
        assert exec_file["executable"] is True

    def test_migration_preserves_all_metadata(self, tmp_path: Path) -> None:
        """Test that migration preserves all metadata fields."""
        # Arrange
        sync_config = {
            "template_source": "shared",
            "files": [
                {
                    "source": "test.template",
                    "dest": "test.txt",
                    "policy": "if_unchanged",
                    "description": "Test file",
                    "source_hash": "sha256:abc123",
                    "executable": True,
                }
            ],
        }

        # Act
        from genesis.commands.migrate_sync import convert_sync_to_manifest

        manifest = convert_sync_to_manifest(sync_config)

        # Assert: All fields preserved
        file_entry = manifest["shared_files"][0]
        assert file_entry["source_hash"] == "sha256:abc123"
        assert file_entry["executable"] is True
        assert file_entry["description"] == "Test file"

    def test_migration_handles_old_sync_policies_format(self, tmp_path: Path) -> None:
        """Test migration handles old sync_policies format (not files list)."""
        # Arrange: Old format with sync_policies instead of files
        sync_config = {
            "template_source": "shared",
            "sync_policies": [  # Old field name
                {
                    "source": "test.template",
                    "pattern": "test.txt",  # Old field name for dest
                    "sync": "always",  # Old field name for policy
                }
            ],
        }

        # Act
        from genesis.commands.migrate_sync import convert_sync_to_manifest

        manifest = convert_sync_to_manifest(sync_config)

        # Assert: Properly converted
        assert len(manifest["shared_files"]) == 1
        assert manifest["shared_files"][0]["dest"] == "test.txt"
        assert manifest["shared_files"][0]["sync"] == "always"


class TestMigrateSyncCommand:
    """Test genesis migrate-sync CLI command."""

    def test_migrate_sync_creates_manifest_yml(self, tmp_path: Path) -> None:
        """Test that migrate-sync command creates manifest.yml from sync.yml."""
        # Arrange: Create project with sync.yml
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()

        sync_yml = genesis_dir / "sync.yml"
        sync_yml.write_text(
            """
template_source: shared
files:
  - source: test.template
    dest: test.txt
    policy: always
"""
        )

        # Act: Run migration
        from genesis.commands.migrate_sync import migrate_sync_yml_to_manifest

        result = migrate_sync_yml_to_manifest(tmp_path, dry_run=False)

        # Assert: manifest.yml created
        manifest_yml = genesis_dir / "manifest.yml"
        assert manifest_yml.exists()

        manifest = yaml.safe_load(manifest_yml.read_text())
        assert "shared_files" in manifest
        assert result["success"] is True

    def test_migrate_sync_creates_backup_of_sync_yml(self, tmp_path: Path) -> None:
        """Test that migration creates backup of original sync.yml."""
        # Arrange
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()

        sync_yml = genesis_dir / "sync.yml"
        original_content = """
template_source: shared
files:
  - source: test.template
    dest: test.txt
    policy: always
"""
        sync_yml.write_text(original_content)

        # Act
        from genesis.commands.migrate_sync import migrate_sync_yml_to_manifest

        result = migrate_sync_yml_to_manifest(tmp_path, dry_run=False)

        # Assert: Backup created
        backup_file = genesis_dir / "sync.yml.backup"
        assert backup_file.exists()
        assert backup_file.read_text() == original_content
        assert result["backup_created"] is True

    def test_migrate_sync_dry_run_shows_changes(self, tmp_path: Path) -> None:
        """Test that dry-run mode shows changes without modifying files."""
        # Arrange
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()

        sync_yml = genesis_dir / "sync.yml"
        sync_yml.write_text(
            """
template_source: shared
files:
  - source: test.template
    dest: test.txt
    policy: always
"""
        )

        # Act: Dry run
        from genesis.commands.migrate_sync import migrate_sync_yml_to_manifest

        result = migrate_sync_yml_to_manifest(tmp_path, dry_run=True)

        # Assert: No files created
        manifest_yml = genesis_dir / "manifest.yml"
        assert not manifest_yml.exists()
        assert result["dry_run"] is True
        assert "would_create_manifest" in result

    def test_migrate_sync_preserves_project_configuration(self, tmp_path: Path) -> None:
        """Test that migration preserves project-specific configuration."""
        # Arrange: sync.yml with project metadata
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()

        sync_yml = genesis_dir / "sync.yml"
        sync_yml.write_text(
            """
template_source: python-api
project:
  name: my-project
  type: python-api
variables:
  project_name: my-project
  module_name: my_project
files:
  - source: test.template
    dest: test.txt
    policy: always
"""
        )

        # Act
        from genesis.commands.migrate_sync import migrate_sync_yml_to_manifest

        result = migrate_sync_yml_to_manifest(tmp_path, dry_run=False)

        # Assert: Project configuration preserved in result
        assert result["project_metadata"]["name"] == "my-project"
        assert result["project_metadata"]["type"] == "python-api"

    def test_migrate_sync_fails_if_no_sync_yml_exists(self, tmp_path: Path) -> None:
        """Test that migration fails gracefully if sync.yml doesn't exist."""
        # Arrange: No sync.yml
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()

        # Act & Assert
        from genesis.commands.migrate_sync import migrate_sync_yml_to_manifest

        with pytest.raises(FileNotFoundError, match="sync.yml not found"):
            migrate_sync_yml_to_manifest(tmp_path, dry_run=False)

    def test_migrate_sync_warns_if_manifest_already_exists(
        self, tmp_path: Path
    ) -> None:
        """Test that migration warns if manifest.yml already exists."""
        # Arrange: Both files exist
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()

        sync_yml = genesis_dir / "sync.yml"
        sync_yml.write_text("template_source: shared\nfiles: []")

        manifest_yml = genesis_dir / "manifest.yml"
        manifest_yml.write_text("shared_files: []")

        # Act
        from genesis.commands.migrate_sync import migrate_sync_yml_to_manifest

        result = migrate_sync_yml_to_manifest(tmp_path, dry_run=False, force=False)

        # Assert: Migration skipped
        assert result["skipped"] is True
        assert "manifest.yml already exists" in result["message"]


class TestBackwardCompatibility:
    """Test that backward compatibility is maintained during transition."""

    def test_sync_command_works_with_sync_yml(self, tmp_path: Path) -> None:
        """Test that genesis sync still works with sync.yml (with warning)."""
        # Arrange
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()

        sync_yml = genesis_dir / "sync.yml"
        sync_yml.write_text(
            """
template_source: shared
files:
  - source: test.template
    dest: test.txt
    policy: always
"""
        )

        # Act: Run sync
        manager = SyncManager(tmp_path)
        with patch.object(manager, "template_manager"):
            config = manager.load_config()

        # Assert: Config loaded successfully
        assert config is not None
        assert config["template_source"] == "shared"
        assert len(config["files"]) == 1

    def test_sync_command_prefers_manifest_over_sync_yml(self, tmp_path: Path) -> None:
        """Test that sync command prefers manifest.yml when both exist."""
        # Arrange: Both files exist
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()

        sync_yml = genesis_dir / "sync.yml"
        sync_yml.write_text(
            """
template_source: shared
files:
  - source: old.template
    dest: old.txt
    policy: always
"""
        )

        manifest_yml = genesis_dir / "manifest.yml"
        manifest_yml.write_text(
            """
shared_files:
  - source: new.template
    dest: new.txt
    sync: always
"""
        )

        # Act
        manager = SyncManager(tmp_path)
        with patch.object(manager, "template_manager"):
            config = manager.load_config()

        # Assert: manifest.yml used
        assert config["files"][0]["source"] == "new.template"
        assert config["files"][0]["dest"] == "new.txt"
