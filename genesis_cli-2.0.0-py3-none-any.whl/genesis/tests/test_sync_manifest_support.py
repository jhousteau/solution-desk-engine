"""Tests for manifest.yml support in sync command (Feature 458.4)."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml

from genesis.commands.sync import SyncManager


@pytest.fixture
def project_with_manifest(tmp_path: Path) -> Path:
    """Create a temporary project with manifest.yml."""
    project_path = tmp_path / "test_project"
    project_path.mkdir()

    # Create .genesis directory
    genesis_dir = project_path / ".genesis"
    genesis_dir.mkdir()

    # Create manifest.yml with hash-based configuration
    manifest_config = {
        "shared_files": [
            {
                "source": "Dockerfile.template",
                "dest": "Dockerfile",
                "sync": "always",
                "source_hash": "sha256:abc123def456",
                "description": "Test Dockerfile",
            },
            {
                "source": "README.md.template",
                "dest": "README.md",
                "sync": "never",
                "source_hash": "sha256:def456abc123",
                "description": "Project README",
            },
        ]
    }

    manifest_path = genesis_dir / "manifest.yml"
    with open(manifest_path, "w") as f:
        yaml.dump(manifest_config, f)

    return project_path


@pytest.fixture
def project_with_sync_yml(tmp_path: Path) -> Path:
    """Create a temporary project with sync.yml (legacy format)."""
    project_path = tmp_path / "test_project"
    project_path.mkdir()

    # Create .genesis directory
    genesis_dir = project_path / ".genesis"
    genesis_dir.mkdir()

    # Create sync.yml without hashes
    sync_config = {
        "template_source": "shared",
        "sync_policies": [
            {"source": "Dockerfile.template", "dest": "Dockerfile", "sync": "always"}
        ],
    }

    sync_path = genesis_dir / "sync.yml"
    with open(sync_path, "w") as f:
        yaml.dump(sync_config, f)

    return project_path


@pytest.fixture
def project_with_both_configs(tmp_path: Path) -> Path:
    """Create a project with both manifest.yml and sync.yml."""
    project_path = tmp_path / "test_project"
    project_path.mkdir()

    # Create .genesis directory
    genesis_dir = project_path / ".genesis"
    genesis_dir.mkdir()

    # Create manifest.yml
    manifest_config = {
        "shared_files": [
            {
                "source": "Dockerfile.template",
                "dest": "Dockerfile",
                "sync": "always",
                "source_hash": "sha256:abc123def456",
                "description": "From manifest",
            }
        ]
    }

    manifest_path = genesis_dir / "manifest.yml"
    with open(manifest_path, "w") as f:
        yaml.dump(manifest_config, f)

    # Create sync.yml
    sync_config = {
        "template_source": "shared",
        "sync_policies": [
            {"source": "README.md.template", "dest": "README.md", "sync": "never"}
        ],
    }

    sync_path = genesis_dir / "sync.yml"
    with open(sync_path, "w") as f:
        yaml.dump(sync_config, f)

    return project_path


class TestLoadFromManifest:
    """Test loading configuration from manifest.yml."""

    def test_load_from_manifest_exists(self, project_with_manifest: Path) -> None:
        """Test that _load_from_manifest() loads config when manifest exists."""
        manager = SyncManager(project_with_manifest)

        # This should succeed with manifest.yml
        config = manager._load_from_manifest()

        assert config is not None
        # manifest.yml is converted to sync format, so check 'files' not 'shared_files'
        assert "files" in config
        assert len(config["files"]) == 2
        assert config["files"][0]["source"] == "Dockerfile.template"
        assert config["files"][0]["source_hash"] == "sha256:abc123def456"

    def test_load_from_manifest_missing(self, project_with_sync_yml: Path) -> None:
        """Test that _load_from_manifest() returns None when manifest missing."""
        manager = SyncManager(project_with_sync_yml)

        # Should return None when manifest.yml doesn't exist
        config = manager._load_from_manifest()

        assert config is None

    def test_load_from_manifest_invalid_yaml(self, tmp_path: Path) -> None:
        """Test that _load_from_manifest() handles invalid YAML gracefully."""
        project_path = tmp_path / "test_project"
        project_path.mkdir()
        genesis_dir = project_path / ".genesis"
        genesis_dir.mkdir()

        # Create invalid YAML
        manifest_path = genesis_dir / "manifest.yml"
        manifest_path.write_text("invalid: yaml: content: [")

        manager = SyncManager(project_path)

        # Should return None or raise appropriate error
        config = manager._load_from_manifest()
        assert config is None

    def test_manifest_converts_to_sync_format(
        self, project_with_manifest: Path
    ) -> None:
        """Test that manifest.yml is converted to sync.yml format."""
        manager = SyncManager(project_with_manifest)

        config = manager._load_from_manifest()
        assert config is not None

        # Should have template_source field
        assert "template_source" in config
        assert config["template_source"] == "shared"

        # Should have files list (converted from shared_files)
        assert "files" in config
        assert len(config["files"]) == 2

        # Files should have policy field (converted from sync)
        assert "policy" in config["files"][0]
        assert config["files"][0]["policy"] == "always"


class TestHashBasedChangeDetection:
    """Test hash-based change detection functionality."""

    def test_should_sync_file_hash_with_matching_hash(
        self, project_with_manifest: Path
    ) -> None:
        """Test that files with matching hashes are skipped."""
        manager = SyncManager(project_with_manifest)

        # Create a destination file
        dest_file = project_with_manifest / "Dockerfile"
        dest_file.write_text("test content")

        # Mock the hash to match
        with patch("genesis.commands.sync.hashes_match", return_value=True):
            # Load source hash
            manager.source_hashes["Dockerfile.template"] = "sha256:abc123def456"

            # Should return False (skip sync) when hashes match
            should_sync = manager._should_sync_file_hash(
                "Dockerfile.template", dest_file, "always"
            )

            assert should_sync is False

    def test_should_sync_file_hash_with_mismatched_hash(
        self, project_with_manifest: Path
    ) -> None:
        """Test that files with mismatched hashes are synced."""
        manager = SyncManager(project_with_manifest)

        # Create a destination file
        dest_file = project_with_manifest / "Dockerfile"
        dest_file.write_text("modified content")

        # Mock the hash to not match
        with patch("genesis.commands.sync.hashes_match", return_value=False):
            # Load source hash
            manager.source_hashes["Dockerfile.template"] = "sha256:abc123def456"

            # Should return True (sync) when hashes don't match
            should_sync = manager._should_sync_file_hash(
                "Dockerfile.template", dest_file, "always"
            )

            assert should_sync is True

    def test_should_sync_file_hash_no_hash_available(
        self, project_with_manifest: Path
    ) -> None:
        """Test that files without hashes fall back to regular sync logic."""
        manager = SyncManager(project_with_manifest)

        dest_file = project_with_manifest / "Dockerfile"
        dest_file.write_text("content")

        # No hash in source_hashes dict
        # Should fall back to regular policy-based logic
        should_sync = manager._should_sync_file_hash(
            "unknown_file.txt", dest_file, "always"
        )

        # Should use regular policy (always = True)
        assert should_sync is True

    def test_should_sync_file_hash_new_file(self, project_with_manifest: Path) -> None:
        """Test that new files (not existing) are always synced."""
        manager = SyncManager(project_with_manifest)

        # File doesn't exist
        dest_file = project_with_manifest / "newfile.txt"

        manager.source_hashes["newfile.template"] = "sha256:abc123def456"

        # Should return True for new files
        should_sync = manager._should_sync_file_hash(
            "newfile.template", dest_file, "always"
        )

        assert should_sync is True


class TestFallbackToSyncYml:
    """Test fallback behavior when manifest.yml is not present."""

    def test_load_config_uses_manifest_when_available(
        self, project_with_both_configs: Path
    ) -> None:
        """Test that load_config() prefers manifest.yml over sync.yml."""
        manager = SyncManager(project_with_both_configs)

        config = manager.load_config()

        # Should have loaded from manifest.yml
        assert "files" in config
        assert len(config["files"]) == 1
        assert config["files"][0]["source"] == "Dockerfile.template"
        # Should have source_hash from manifest
        assert "source_hash" in config["files"][0]

    def test_load_config_falls_back_to_sync_yml(
        self, project_with_sync_yml: Path
    ) -> None:
        """Test that load_config() falls back to sync.yml when no manifest."""
        manager = SyncManager(project_with_sync_yml)

        config = manager.load_config()

        # Should have loaded from sync.yml
        assert "sync_policies" in config
        assert config["template_source"] == "shared"
        # Should not have source_hash (sync.yml doesn't have them)
        assert "source_hash" not in config["sync_policies"][0]

    def test_load_config_no_configs_raises_error(self, tmp_path: Path) -> None:
        """Test that load_config() raises error when neither config exists."""
        project_path = tmp_path / "test_project"
        project_path.mkdir()
        genesis_dir = project_path / ".genesis"
        genesis_dir.mkdir()

        manager = SyncManager(project_path)

        # Should raise FileNotFoundError
        with pytest.raises(FileNotFoundError, match="Sync configuration not found"):
            manager.load_config()


class TestBackwardCompatibility:
    """Test backward compatibility with existing sync.yml behavior."""

    def test_sync_yml_without_hashes_still_works(
        self, project_with_sync_yml: Path
    ) -> None:
        """Test that sync.yml without hashes continues to work."""
        # Mock template manager
        mock_template_manager = MagicMock()
        mock_template_manager.get_template.return_value = "test content"

        manager = SyncManager(
            project_with_sync_yml, template_manager=mock_template_manager
        )

        # Should be able to load config
        config = manager.load_config()
        assert config is not None
        assert "sync_policies" in config

        # Should be able to sync without errors
        # (even without hashes)
        with patch.object(manager, "_process_sync_policies"):
            manager.sync()

    def test_manifest_fields_preserved(self, project_with_manifest: Path) -> None:
        """Test that all manifest.yml fields are preserved during conversion."""
        manager = SyncManager(project_with_manifest)

        config = manager._load_from_manifest()
        assert config is not None

        # Check all fields are present
        first_file = config["files"][0]
        assert "source" in first_file
        assert "dest" in first_file
        assert "policy" in first_file
        assert "source_hash" in first_file
        assert "description" in first_file


class TestHashPerformanceOptimization:
    """Test that hash-based sync provides performance benefits."""

    def test_hash_check_skips_template_fetch(self, project_with_manifest: Path) -> None:
        """Test that matching hashes skip expensive template fetch."""
        mock_template_manager = MagicMock()
        mock_template_manager.get_template.return_value = "template content"

        manager = SyncManager(
            project_with_manifest, template_manager=mock_template_manager
        )

        # Create destination file
        dest_file = project_with_manifest / "Dockerfile"
        dest_file.write_text("existing content")

        # Set up hash to match
        manager.source_hashes["Dockerfile.template"] = "sha256:abc123def456"

        with patch("genesis.commands.sync.hashes_match", return_value=True):
            # Sync the file
            result = manager.sync_file(
                "Dockerfile.template", "Dockerfile", "always", {}
            )

        # Should not have called get_template (performance optimization)
        assert result is False  # Skipped due to hash match
        # Template fetch should be skipped when hash matches
        # (we'll verify this in the implementation)

    def test_hash_mismatch_triggers_full_sync(
        self, project_with_manifest: Path
    ) -> None:
        """Test that hash mismatches trigger normal sync behavior."""
        mock_template_manager = MagicMock()
        mock_template_manager.get_template.return_value = "new template content"

        manager = SyncManager(
            project_with_manifest,
            template_manager=mock_template_manager,
            dry_run=True,  # Avoid actual file writes
        )

        # Create destination file
        dest_file = project_with_manifest / "Dockerfile"
        dest_file.write_text("old content")

        # Set up hash to not match
        manager.source_hashes["Dockerfile.template"] = "sha256:abc123def456"

        with patch("genesis.commands.sync.hashes_match", return_value=False):
            # Sync the file
            result = manager.sync_file(
                "Dockerfile.template", "Dockerfile", "always", {}
            )

        # Should have called get_template (hash mismatch requires full check)
        mock_template_manager.get_template.assert_called_once()
        # Should indicate sync would happen
        assert result is True


class TestHashLoadingFromManifest:
    """Test that hashes are loaded from manifest.yml into source_hashes."""

    def test_source_hashes_populated_from_manifest(
        self, project_with_manifest: Path
    ) -> None:
        """Test that source_hashes dict is populated when loading manifest."""
        manager = SyncManager(project_with_manifest)

        # Load config (should populate source_hashes)
        manager.load_config()

        # Check that source_hashes are populated
        assert len(manager.source_hashes) > 0
        assert "Dockerfile.template" in manager.source_hashes
        assert manager.source_hashes["Dockerfile.template"] == "sha256:abc123def456"

    def test_source_hashes_empty_for_sync_yml(
        self, project_with_sync_yml: Path
    ) -> None:
        """Test that source_hashes remain empty when using sync.yml."""
        manager = SyncManager(project_with_sync_yml)

        # Load config from sync.yml
        manager.load_config()

        # source_hashes should be empty (no hashes in sync.yml)
        assert len(manager.source_hashes) == 0


class TestManifestPathFieldSupport:
    """Test support for manifest entries using 'path' field instead of source/dest."""

    def test_convert_manifest_entry_with_path_field(self, tmp_path: Path) -> None:
        """Test that manifest entries with 'path' field are converted correctly."""
        manager = SyncManager(tmp_path)

        # Test entry with 'path' field (legacy format)
        entry_with_path = {
            "path": ".genesis/sync.yml",
            "sync": "always",
            "source_hash": "sha256:abc123",
            "description": "Sync config",
        }

        result = manager._convert_manifest_entry(entry_with_path)

        # Should use 'path' value for both source and dest
        assert result["source"] == ".genesis/sync.yml"
        assert result["dest"] == ".genesis/sync.yml"
        assert result["policy"] == "always"
        assert result["source_hash"] == "sha256:abc123"
        assert result["description"] == "Sync config"

    def test_convert_manifest_entry_with_source_dest_fields(
        self, tmp_path: Path
    ) -> None:
        """Test that manifest entries with source/dest fields work correctly."""
        manager = SyncManager(tmp_path)

        # Test entry with 'source' and 'dest' fields (new format)
        entry_with_source_dest = {
            "source": "template.txt",
            "dest": "output.txt",
            "sync": "if_unchanged",
            "source_hash": "sha256:def456",
            "description": "Test file",
        }

        result = manager._convert_manifest_entry(entry_with_source_dest)

        # Should use source and dest as-is
        assert result["source"] == "template.txt"
        assert result["dest"] == "output.txt"
        assert result["policy"] == "if_unchanged"
        assert result["source_hash"] == "sha256:def456"
        assert result["description"] == "Test file"

    def test_load_manifest_with_mixed_path_and_source_dest(
        self, tmp_path: Path
    ) -> None:
        """Test loading manifest with both 'path' and 'source/dest' entries."""
        project_path = tmp_path / "test_project"
        project_path.mkdir()
        genesis_dir = project_path / ".genesis"
        genesis_dir.mkdir()

        # Create manifest with both formats
        manifest_config = {
            "shared_files": [
                {
                    "path": ".genesis/sync.yml",
                    "sync": "always",
                    "source_hash": "sha256:abc123",
                    "description": "Using path field",
                },
                {
                    "source": "template.txt",
                    "dest": "output.txt",
                    "sync": "if_unchanged",
                    "source_hash": "sha256:def456",
                    "description": "Using source/dest fields",
                },
            ]
        }

        manifest_path = genesis_dir / "manifest.yml"
        with open(manifest_path, "w") as f:
            yaml.dump(manifest_config, f)

        manager = SyncManager(project_path)
        config = manager._load_from_manifest()

        assert config is not None
        assert len(config["files"]) == 2

        # First entry (path field)
        assert config["files"][0]["source"] == ".genesis/sync.yml"
        assert config["files"][0]["dest"] == ".genesis/sync.yml"
        assert config["files"][0]["policy"] == "always"

        # Second entry (source/dest fields)
        assert config["files"][1]["source"] == "template.txt"
        assert config["files"][1]["dest"] == "output.txt"
        assert config["files"][1]["policy"] == "if_unchanged"
