"""
Test manifest hash validation functionality for Phase 1 implementation.

Tests the new source_hash field in manifest.yml and validation logic.
"""

import hashlib
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from genesis.commands.sync import SyncManager


class TestManifestHashValidation:
    """Test hash field validation in manifest.yml"""

    def test_manifest_has_hash_fields(self) -> None:
        """Test that all files in manifest.yml have source_hash fields"""
        # Load the manifest
        test_file_path = Path(__file__)
        if "worktrees" in str(test_file_path):
            # Running from worktree - navigate to main project
            manifest_path = (
                test_file_path.parent.parent.parent.parent.parent
                / "templates"
                / "shared"
                / "manifest.yml"
            )
        else:
            # Running from main project
            manifest_path = (
                test_file_path.parent.parent.parent
                / "templates"
                / "shared"
                / "manifest.yml"
            )

        assert manifest_path.exists(), f"Manifest not found at {manifest_path}"

        with open(manifest_path) as f:
            manifest = yaml.safe_load(f)

        # Verify structure
        assert "shared_files" in manifest
        assert len(manifest["shared_files"]) > 0

        # Check that all files have source_hash field
        missing_hashes = []
        invalid_hashes = []

        for file_entry in manifest["shared_files"]:
            assert "source" in file_entry
            assert "dest" in file_entry
            assert "sync" in file_entry
            assert "description" in file_entry

            # Check for source_hash field
            if "source_hash" not in file_entry:
                missing_hashes.append(file_entry["source"])
                continue

            # Validate hash format (sha256:64_hex_chars)
            hash_value = file_entry["source_hash"]
            if not hash_value.startswith("sha256:"):
                invalid_hashes.append(f"{file_entry['source']}: missing sha256 prefix")
                continue

            hash_hex = hash_value[7:]  # Remove "sha256:" prefix
            if len(hash_hex) != 64:
                invalid_hashes.append(
                    f"{file_entry['source']}: invalid length {len(hash_hex)}"
                )
                continue

            # Validate hex format
            try:
                int(hash_hex, 16)
            except ValueError:
                invalid_hashes.append(f"{file_entry['source']}: invalid hex format")

        # Report failures
        if missing_hashes:
            pytest.fail(f"Files missing source_hash field: {missing_hashes}")
        if invalid_hashes:
            pytest.fail(f"Files with invalid hash format: {invalid_hashes}")

    def test_manifest_hash_accuracy(self) -> None:
        """Test that hash values in manifest match actual file content"""
        # Load the manifest
        test_file_path = Path(__file__)
        if "worktrees" in str(test_file_path):
            # Running from worktree - navigate to main project
            templates_dir = (
                test_file_path.parent.parent.parent.parent.parent
                / "templates"
                / "shared"
            )
        else:
            # Running from main project
            templates_dir = test_file_path.parent.parent.parent / "templates" / "shared"

        manifest_path = templates_dir / "manifest.yml"

        with open(manifest_path) as f:
            manifest = yaml.safe_load(f)

        # Check a sample of files (first 5 to keep test fast)
        mismatched_hashes = []

        for file_entry in manifest["shared_files"][:5]:
            source = file_entry["source"]
            expected_hash = file_entry["source_hash"]

            # Calculate actual file hash
            template_path = templates_dir / source
            if not template_path.exists():
                mismatched_hashes.append(f"{source}: file not found")
                continue

            sha256_hash = hashlib.sha256()
            with open(template_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(chunk)

            actual_hash = f"sha256:{sha256_hash.hexdigest()}"

            if actual_hash != expected_hash:
                mismatched_hashes.append(
                    f"{source}: expected {expected_hash}, got {actual_hash}"
                )

        if mismatched_hashes:
            pytest.fail(f"Hash mismatches found: {mismatched_hashes}")

    def test_manifest_backward_compatibility(self) -> None:
        """Test that manifest still works without source_hash fields"""
        # Create a minimal manifest without hashes
        manifest_without_hashes = {
            "shared_files": [
                {
                    "source": "Dockerfile.template",
                    "dest": "Dockerfile",
                    "sync": "always",
                    "description": "Test file",
                }
            ]
        }

        # Mock the sync manager to test parsing
        with patch(
            "genesis.commands.sync.discover_shared_templates_path"
        ) as mock_discover:
            mock_discover.return_value = Path("/fake/path")

            _ = SyncManager(
                project_path=Path("/fake/project"),
                preview=True,
                dry_run=True,
                force=False,
                verbose=False,
            )

            # This should not raise an exception even without source_hash fields
            # The sync system should handle missing hash fields gracefully
            try:
                # Would normally call _load_manifest_data but that's not public
                # So we test the structure validation indirectly
                assert "shared_files" in manifest_without_hashes
                for file_entry in manifest_without_hashes["shared_files"]:
                    assert "source" in file_entry
                    assert "dest" in file_entry
                    assert "sync" in file_entry
                    # source_hash is optional for backward compatibility

            except Exception as e:
                pytest.fail(f"Backward compatibility test failed: {e}")
