"""Tests for template discovery automation script.

This module tests the discover-templates.py script that scans templates/shared/
and automatically updates manifest.yml with discovered files.
"""

import hashlib
from pathlib import Path
from typing import Any

import pytest
import yaml


class TestTemplateDiscovery:
    """Test suite for template discovery functionality."""

    @pytest.fixture
    def temp_templates_dir(self, tmp_path: Path) -> Path:
        """Create a temporary templates/shared directory structure."""
        templates_dir = tmp_path / "templates" / "shared"
        templates_dir.mkdir(parents=True)
        return templates_dir

    @pytest.fixture
    def sample_manifest(self, temp_templates_dir: Path) -> Path:
        """Create a sample manifest.yml file."""
        manifest_path = temp_templates_dir / "manifest.yml"
        manifest_data = {
            "shared_files": [
                {
                    "source": "existing.txt",
                    "dest": "existing.txt",
                    "sync": "always",
                    "source_hash": "sha256:old_hash",
                    "description": "Existing file with custom description",
                }
            ],
            "template_variables": [],
            "sync_config": {
                "backup_changed_files": True,
                "create_directories": True,
                "preserve_permissions": True,
            },
        }
        with open(manifest_path, "w") as f:
            yaml.dump(manifest_data, f, default_flow_style=False, sort_keys=False)
        return manifest_path

    def test_discover_genesis_source_files(self, temp_templates_dir: Path) -> None:
        """Test that Genesis source files are discovered from working directory."""
        # Create test structure mimicking Genesis
        (temp_templates_dir / ".claude").mkdir()
        (temp_templates_dir / ".claude" / "settings.json").write_text("{}")
        (temp_templates_dir / ".genesis").mkdir()
        (temp_templates_dir / ".genesis" / "scripts").mkdir(parents=True)
        (temp_templates_dir / ".genesis" / "scripts" / "setup.sh").write_text(
            "#!/bin/bash"
        )
        (temp_templates_dir / ".envrc").write_text("export VAR=value")

        from genesis.scripts.build.discover_templates import (
            discover_genesis_source_files,
        )

        files = discover_genesis_source_files(temp_templates_dir)

        # Should return list of (Path, needs_suffix) tuples
        assert len(files) >= 3
        paths = [f[0] for f in files]
        relative_paths = [str(p.relative_to(temp_templates_dir)) for p in paths]
        assert ".claude/settings.json" in relative_paths
        assert ".genesis/scripts/setup.sh" in relative_paths
        assert ".envrc" in relative_paths

    def test_calculate_file_hash(self, temp_templates_dir: Path) -> None:
        """Test SHA-256 hash calculation for files."""
        test_file = temp_templates_dir / "test.txt"
        test_content = b"test content for hashing"
        test_file.write_bytes(test_content)

        from genesis.scripts.build.discover_templates import calculate_file_hash

        file_hash = calculate_file_hash(test_file)

        expected_hash = hashlib.sha256(test_content).hexdigest()
        assert file_hash == f"sha256:{expected_hash}"

    def test_detect_sync_policy_always(self, temp_templates_dir: Path) -> None:
        """Test sync policy detection for 'always' files."""
        from genesis.scripts.build.discover_templates import detect_sync_policy

        # Scripts should be 'always'
        script_file = temp_templates_dir / ".genesis" / "scripts" / "setup.sh"
        script_file.parent.mkdir(parents=True)
        script_file.write_text("#!/bin/bash")
        assert detect_sync_policy(script_file, temp_templates_dir) == "always"

        # Hooks should be 'always'
        hook_file = temp_templates_dir / ".genesis" / "hooks" / "pre-commit"
        hook_file.parent.mkdir(parents=True)
        hook_file.write_text("#!/bin/bash")
        assert detect_sync_policy(hook_file, temp_templates_dir) == "always"

    def test_detect_sync_policy_never(self, temp_templates_dir: Path) -> None:
        """Test sync policy detection for 'never' files (user customizable)."""
        from genesis.scripts.build.discover_templates import detect_sync_policy

        # README should be 'never'
        readme = temp_templates_dir / "README.md"
        readme.write_text("# README")
        assert detect_sync_policy(readme, temp_templates_dir) == "never"

        # pyproject.toml should be 'never'
        pyproject = temp_templates_dir / "pyproject.toml"
        pyproject.write_text("[tool.poetry]")
        assert detect_sync_policy(pyproject, temp_templates_dir) == "never"

        # CLAUDE.md should be 'never'
        claude_md = temp_templates_dir / "CLAUDE.md"
        claude_md.write_text("# CLAUDE")
        assert detect_sync_policy(claude_md, temp_templates_dir) == "never"

    def test_detect_sync_policy_if_unchanged(self, temp_templates_dir: Path) -> None:
        """Test sync policy detection for 'if_unchanged' files."""
        from genesis.scripts.build.discover_templates import detect_sync_policy

        # .envrc should be 'if_unchanged'
        envrc = temp_templates_dir / ".envrc"
        envrc.write_text("export VAR=value")
        assert detect_sync_policy(envrc, temp_templates_dir) == "if_unchanged"

        # Makefile should be 'if_unchanged'
        makefile = temp_templates_dir / "Makefile"
        makefile.write_text("all: build")
        assert detect_sync_policy(makefile, temp_templates_dir) == "if_unchanged"

    @pytest.mark.skip(reason="Needs update for new Genesis source discovery approach")
    def test_update_manifest_adds_new_files(
        self, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that new files are added to manifest."""
        # Needs update to create Genesis source files (.claude/, .genesis/, etc.)
        pass

    @pytest.mark.skip(reason="Needs update for new Genesis source discovery approach")
    def test_update_manifest_updates_changed_hashes(
        self, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that file hashes are updated when files change."""
        # Needs update to create Genesis source files (.claude/, .genesis/, etc.)
        pass

    @pytest.mark.skip(reason="Needs update for new Genesis source discovery approach")
    def test_update_manifest_preserves_descriptions(
        self, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that custom descriptions are preserved during update."""
        # Needs update to create Genesis source files (.claude/, .genesis/, etc.)
        pass

    def test_update_manifest_removes_deleted_files(
        self, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that files no longer in templates/ are removed from manifest."""
        # Don't create the existing.txt file, so it should be removed
        from genesis.scripts.build.discover_templates import update_manifest

        update_manifest(temp_templates_dir, sample_manifest, dry_run=False)

        with open(sample_manifest) as f:
            manifest = yaml.safe_load(f)

        sources = [item["source"] for item in manifest["shared_files"]]
        assert "existing.txt" not in sources

    @pytest.mark.skip(reason="Needs update for new Genesis source discovery approach")
    def test_dry_run_mode_no_changes(
        self, temp_templates_dir: Path, sample_manifest: Path
    ) -> None:
        """Test that dry-run mode doesn't modify the manifest file."""
        # Needs update to create Genesis source files (.claude/, .genesis/, etc.)
        pass

    def test_generate_description_from_path(self, temp_templates_dir: Path) -> None:
        """Test automatic description generation based on file path."""
        from genesis.scripts.build.discover_templates import generate_description

        # Test script descriptions
        script = temp_templates_dir / ".genesis" / "scripts" / "setup" / "setup.sh"
        desc = generate_description(script, temp_templates_dir)
        assert "setup" in desc.lower() or "script" in desc.lower()

        # Test hook descriptions
        hook = temp_templates_dir / ".genesis" / "hooks" / "pre-commit"
        desc = generate_description(hook, temp_templates_dir)
        assert "hook" in desc.lower() or "pre-commit" in desc.lower()

    def test_report_changes(self, temp_templates_dir: Path, capsys: Any) -> None:
        """Test that changes are reported correctly."""
        from genesis.scripts.build.discover_templates import report_changes

        changes = {
            "added": ["new_file.txt", "another.sh"],
            "removed": ["old_file.txt"],
            "changed": ["updated_file.txt"],
        }

        report_changes(changes)

        captured = capsys.readouterr()
        assert "new_file.txt" in captured.out
        assert "another.sh" in captured.out
        assert "old_file.txt" in captured.out
        assert "updated_file.txt" in captured.out

    def test_excludes_patterns(self, temp_templates_dir: Path) -> None:
        """Test that excluded patterns are not discovered."""
        # Create files that should be excluded
        (temp_templates_dir / "Makefile").write_text("all: build")
        docs = temp_templates_dir / "docs"
        docs.mkdir()
        (docs / "guide.md").write_text("# Guide")

        from genesis.scripts.build.discover_templates import (
            discover_genesis_source_files,
        )

        files = discover_genesis_source_files(temp_templates_dir)

        paths = [f[0] for f in files]
        relative_paths = [str(p.relative_to(temp_templates_dir)) for p in paths]

        # Makefile and docs/ should be excluded
        assert "Makefile" not in relative_paths
        assert not any("docs/" in p for p in relative_paths)

    def test_handles_template_suffix(self, temp_templates_dir: Path) -> None:
        """Test that .template suffix is handled correctly in dest field."""
        template_file = temp_templates_dir / "config.yaml.template"
        template_file.write_text("key: value")

        from genesis.scripts.build.discover_templates import generate_dest_path

        dest = generate_dest_path("config.yaml.template")
        assert dest == "config.yaml"

        # Non-template files should keep their name
        dest = generate_dest_path("regular.txt")
        assert dest == "regular.txt"
