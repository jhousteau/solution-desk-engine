"""Test that init.py sync config generation includes all files from manifest.yml.

This test checks that SyncConfigGenerator.generate_sync_config() includes
all files that are in the shared manifest, particularly claude_agents files
that are currently missing from the hardcoded DEFAULT_POLICIES.
"""

from pathlib import Path

from genesis.commands.init import SyncConfigGenerator


class TestInitSyncManifestCompleteness:
    """Test that init command includes all manifest files."""

    def test_generate_sync_config_includes_claude_agents_files(
        self, tmp_path: Path
    ) -> None:
        """Test that generated sync config includes specific claude_agents files.

        This test demonstrates the bug where init.py uses hardcoded DEFAULT_POLICIES
        that miss claude_agents files which should be included from manifest.yml.

        The manifest.yml defines specific claude_agents files like:
        - .claude/agents/bloat-detector.md
        - .claude/agents/build-validator.md
        - .claude/agents/complexity-auditor.md
        etc.

        But init.py only has a generic ".claude/agents/**" pattern.
        """
        variables = {
            "project_name": "test-project",
            "module_name": "test_project",
        }

        # Generate sync config using init.py approach
        config = SyncConfigGenerator.generate_sync_config(
            "python-api", variables, tmp_path
        )

        # Extract source patterns from sync policies
        sync_patterns = {policy["source"] for policy in config["sync_policies"]}

        # Expected specific claude_agents files from manifest.yml
        expected_claude_agents_files = {
            ".claude/agents/bloat-detector.md",
            ".claude/agents/build-validator.md",
            ".claude/agents/complexity-auditor.md",
            ".claude/agents/dependency-tracker.md",
            ".claude/agents/documentation-minimalist.md",
            ".claude/agents/issue-analyst.md",
            ".claude/agents/lean-implementer.md",
            ".claude/agents/performance-monitor.md",
            ".claude/agents/refactoring-specialist.md",
            ".claude/agents/scope-guardian.md",
            ".claude/agents/test-designer.md",
        }

        # This should pass but currently fails - init.py only has ".claude/agents/**"
        # instead of the specific files from manifest.yml
        for expected_file in expected_claude_agents_files:
            assert expected_file in sync_patterns, (
                f"init.py sync config missing specific claude_agents file: {expected_file}. "
                f"Current patterns include '.claude/agents/**' but should include "
                f"individual files from manifest.yml. Found patterns: {sorted(sync_patterns)}"
            )
