"""Tests for the Genesis init command."""

import json
from pathlib import Path
from unittest import mock

import pytest
import yaml

from genesis.commands.init import (
    ProjectDetector,
    SyncConfigGenerator,
    init,
)


class TestProjectDetector:
    """Tests for project type detection."""

    def test_detect_python_api_project(self, tmp_path: Path) -> None:
        """Test detection of Python API projects."""
        pyproject_content = """
[tool.poetry]
name = "test-api"
version = "0.1.0"

[tool.poetry.dependencies]
python = "^3.11"
fastapi = "^0.100.0"
uvicorn = "^0.23.0"
"""
        (tmp_path / "pyproject.toml").write_text(pyproject_content)

        project_type, variables = ProjectDetector.detect_project_type(tmp_path)

        assert project_type == "python-api"
        assert variables["project_name"] == "test-api"
        assert variables["module_name"] == "test_api"

    def test_detect_cli_tool_project(self, tmp_path: Path) -> None:
        """Test detection of CLI tool projects."""
        pyproject_content = """
[tool.poetry]
name = "my-cli"
version = "0.1.0"

[tool.poetry.dependencies]
python = "^3.11"
click = "^8.1.0"
"""
        (tmp_path / "pyproject.toml").write_text(pyproject_content)

        project_type, variables = ProjectDetector.detect_project_type(tmp_path)

        assert project_type == "cli-tool"
        assert variables["project_name"] == "my-cli"
        assert variables["module_name"] == "my_cli"
        assert variables["command_name"] == "my-cli"

    def test_detect_typescript_service(self, tmp_path: Path) -> None:
        """Test detection of TypeScript service projects."""
        package_json = {
            "name": "my-service",
            "version": "1.0.0",
            "dependencies": {"express": "^4.18.0", "typescript": "^5.0.0"},
        }
        (tmp_path / "package.json").write_text(json.dumps(package_json))

        project_type, variables = ProjectDetector.detect_project_type(tmp_path)

        assert project_type == "typescript-service"
        assert variables["project_name"] == "my-service"
        assert variables["language_extension"] == "ts"

    def test_detect_terraform_project(self, tmp_path: Path) -> None:
        """Test detection of Terraform projects."""
        main_tf = """
provider "aws" {
  region = var.aws_region
}

resource "aws_s3_bucket" "example" {
  bucket = var.bucket_name
}
"""
        (tmp_path / "main.tf").write_text(main_tf)

        project_type, variables = ProjectDetector.detect_project_type(tmp_path)

        assert project_type == "terraform-project"
        assert variables["project_name"] == tmp_path.name
        assert variables.get("cloud_provider") == "aws"

    def test_detect_unknown_project(self, tmp_path: Path) -> None:
        """Test handling of unknown project types."""
        (tmp_path / "README.md").write_text("# My Project")

        project_type, variables = ProjectDetector.detect_project_type(tmp_path)

        assert project_type == "unknown"
        assert variables["project_name"] == tmp_path.name

    def test_detect_python_with_django(self, tmp_path: Path) -> None:
        """Test detection of Django projects."""
        pyproject_content = """
[tool.poetry]
name = "django-app"
version = "0.1.0"

[tool.poetry.dependencies]
python = "^3.11"
django = "^4.2.0"
"""
        (tmp_path / "pyproject.toml").write_text(pyproject_content)

        project_type, variables = ProjectDetector.detect_project_type(tmp_path)

        assert project_type == "python-django"
        assert variables["project_name"] == "django-app"

    def test_detect_python_generic(self, tmp_path: Path) -> None:
        """Test detection of generic Python projects."""
        pyproject_content = """
[tool.poetry]
name = "python-lib"
version = "0.1.0"

[tool.poetry.dependencies]
python = "^3.11"
requests = "^2.31.0"
"""
        (tmp_path / "pyproject.toml").write_text(pyproject_content)

        project_type, variables = ProjectDetector.detect_project_type(tmp_path)

        assert project_type == "python"
        assert variables["project_name"] == "python-lib"


class TestSyncConfigGenerator:
    """Tests for sync configuration generation."""

    def test_generate_base_config(self, tmp_path: Path) -> None:
        """Test generation of base sync configuration."""
        variables = {
            "project_name": "test-project",
            "module_name": "test_project",
        }

        config = SyncConfigGenerator.generate_sync_config(
            "python-api", variables, tmp_path
        )

        assert config["version"] == "1.0"
        assert config["project"]["name"] == "test-project"
        assert config["project"]["type"] == "python-api"
        assert config["variables"]["project_name"] == "test-project"
        assert config["variables"]["module_name"] == "test_project"
        assert isinstance(config["sync_policies"], list)
        assert len(config["sync_policies"]) > 0
        assert "exclude" in config
        assert "sync_options" in config

    def test_generate_config_includes_template_source(self, tmp_path: Path) -> None:
        """Test that sync config includes required template_source field."""
        variables = {"project_name": "test-project"}

        config = SyncConfigGenerator.generate_sync_config(
            "python-api", variables, tmp_path
        )

        assert "template_source" in config
        assert config["template_source"] == "python-api"

    def test_template_source_matches_project_type_for_different_types(
        self, tmp_path: Path
    ) -> None:
        """Test template_source field matches project type for various project types."""
        variables = {"project_name": "test-project"}

        # Test python-api
        config = SyncConfigGenerator.generate_sync_config(
            "python-api", variables, tmp_path
        )
        assert config["template_source"] == "python-api"

        # Test cli-tool
        config = SyncConfigGenerator.generate_sync_config(
            "cli-tool", variables, tmp_path
        )
        assert config["template_source"] == "cli-tool"

        # Test typescript-service
        config = SyncConfigGenerator.generate_sync_config(
            "typescript-service", variables, tmp_path
        )
        assert config["template_source"] == "typescript-service"

    def test_project_specific_files(self, tmp_path: Path) -> None:
        """Test that project-specific files are included."""
        # Test Python API files - note: python-api doesn't have additional specific files in current PROJECT_FILES
        config = SyncConfigGenerator.generate_sync_config(
            "python-api", {"project_name": "api"}, tmp_path
        )

        api_files = [f["dest"] for f in config["sync_policies"]]
        # Python API gets the shared files but doesn't have project-specific additions currently
        assert len(api_files) > 0  # Should have shared files at least

        # Test CLI tool files - note: CLI tools don't have additional specific files in current PROJECT_FILES
        config = SyncConfigGenerator.generate_sync_config(
            "cli-tool", {"project_name": "cli"}, tmp_path
        )

        cli_files = [f["dest"] for f in config["sync_policies"]]
        # CLI tools get the shared files but don't have project-specific additions currently
        assert len(cli_files) > 0  # Should have shared files at least

        # Test TypeScript service files
        config = SyncConfigGenerator.generate_sync_config(
            "typescript-service", {"project_name": "ts"}, tmp_path
        )

        ts_files = [f["dest"] for f in config["sync_policies"]]
        assert "scripts/build-ts.sh" in ts_files
        assert "tsconfig.json" in ts_files
        assert "jest.config.js" in ts_files

    def test_sync_policies(self, tmp_path: Path) -> None:
        """Test that files have appropriate sync policies."""
        config = SyncConfigGenerator.generate_sync_config(
            "python-api", {"project_name": "api"}, tmp_path
        )

        # Build file_policies dict, handling both old and new formats
        file_policies = {}
        for f in config["sync_policies"]:
            if isinstance(f, dict) and "dest" in f:
                # Handle items with dest and sync/policy fields
                policy_key = (
                    "sync" if "sync" in f else "policy" if "policy" in f else None
                )
                if policy_key:
                    file_policies[f["dest"]] = f[policy_key]
            elif isinstance(f, str):
                # Handle simple string entries (like 'src/**')
                # These don't have policies, so skip them
                continue

        # Always sync Genesis-managed files
        # Note: .claude/agents/ files are not currently added by init command

        # Only check files that exist in the policies
        if "Dockerfile" in file_policies:
            assert file_policies["Dockerfile"] == "always"

        # Conditionally sync configuration files
        if ".pre-commit-config.yaml" in file_policies:
            assert file_policies[".pre-commit-config.yaml"] == "if_unchanged"
        if ".gitignore" in file_policies:
            assert file_policies[".gitignore"] == "if_unchanged"

        # Never auto-update user-owned files
        if "pyproject.toml" in file_policies:
            assert file_policies["pyproject.toml"] == "never"
        if "README.md" in file_policies:
            assert file_policies["README.md"] == "never"
        # Note: 'src/**' is not a file but a pattern, may not be in policies
        if "src/**" in file_policies:
            assert file_policies["src/**"] == "never"

        # Local override for customizable files
        if ".env.example" in file_policies:
            assert file_policies[".env.example"] == "local_override"
        if "docker-compose.yml" in file_policies:
            assert file_policies["docker-compose.yml"] == "local_override"

    def test_helpful_comments_in_yaml(self) -> None:
        """Test that generated YAML includes helpful comments."""
        config = {
            "version": "1.0",
            "template_source": "python-api",
            "project": {
                "name": "test",
                "type": "python",
                "genesis_version": "0.1.0",
            },
            "variables": {"project_name": "test"},
            "sync_policies": [
                {
                    "source": ".claude/**",
                    "dest": ".claude/**",
                    "sync": "always",
                    "description": "Claude files",
                    "executable": False,
                }
            ],
            "exclude": ["*.pyc"],
            "sync_options": {
                "create_backups": True,
                "show_diff": True,
                "auto_format": True,
                "preserve_executable": True,
            },
        }

        yaml_output = SyncConfigGenerator.add_helpful_comments(config)

        assert "# Genesis Sync Configuration" in yaml_output
        assert "template_source: python-api" in yaml_output
        assert "# Template type for sync operations" in yaml_output
        assert "# Project metadata" in yaml_output
        assert "# Template variables" in yaml_output
        assert "# File synchronization rules" in yaml_output
        assert "# Sync policies:" in yaml_output
        assert "#   - always:" in yaml_output
        assert "#   - if_unchanged:" in yaml_output
        assert "#   - never:" in yaml_output
        assert "#   - local_override:" in yaml_output


class TestInitCommand:
    """Tests for the init command itself."""

    def test_init_creates_genesis_directory(self, tmp_path: Path) -> None:
        """Test that init creates .genesis directory."""
        with mock.patch("genesis.commands.init.Path.cwd", return_value=tmp_path):
            mock.Mock()
            mock.Mock()

            # Create a basic project file for detection
            (tmp_path / "pyproject.toml").write_text(
                """
[tool.poetry]
name = "test-project"
"""
            )

            init(force=False, project_type=None, project_name=None)

            genesis_dir = tmp_path / ".genesis"
            assert genesis_dir.exists()
            assert (genesis_dir / "sync.yml").exists()

    def test_init_respects_force_flag(self, tmp_path: Path) -> None:
        """Test that --force flag overwrites existing config."""
        genesis_dir = tmp_path / ".genesis"
        genesis_dir.mkdir()
        sync_file = genesis_dir / "sync.yml"
        sync_file.write_text("# Old config")

        with mock.patch("genesis.commands.init.Path.cwd", return_value=tmp_path):
            # Should fail without --force
            with pytest.raises(Exception, match="ClickException|already exists|force"):
                init(force=False, project_type=None, project_name=None)

            # Should succeed with --force
            result = init(force=True, project_type=None, project_name=None)
            assert result is None  # Success (no return value)

            # Check that file was overwritten
            content = sync_file.read_text()
            assert "# Old config" not in content
            assert "Genesis Sync Configuration" in content

    def test_init_with_explicit_type(self, tmp_path: Path) -> None:
        """Test specifying project type explicitly."""
        with mock.patch("genesis.commands.init.Path.cwd", return_value=tmp_path):
            init(force=False, project_type="python-api", project_name=None)

            sync_file = tmp_path / ".genesis" / "sync.yml"
            content = yaml.safe_load(sync_file.read_text())
            assert content["project"]["type"] == "python-api"

    def test_init_with_custom_name(self, tmp_path: Path) -> None:
        """Test overriding project name."""
        with mock.patch("genesis.commands.init.Path.cwd", return_value=tmp_path):
            init(force=False, project_type=None, project_name="custom-name")

            sync_file = tmp_path / ".genesis" / "sync.yml"
            content = yaml.safe_load(sync_file.read_text())
            assert content["project"]["name"] == "custom-name"
            assert content["variables"]["project_name"] == "custom-name"

    def test_init_extracts_git_username(self, tmp_path: Path) -> None:
        """Test that Git username is extracted if available."""
        with mock.patch("genesis.commands.init.Path.cwd", return_value=tmp_path):
            with mock.patch("genesis.commands.init.subprocess.run") as mock_run:
                mock_result = mock.Mock()
                mock_result.returncode = 0
                mock_result.stdout = "John Doe"
                mock_run.return_value = mock_result

                init(force=False, project_type=None, project_name=None)

                sync_file = tmp_path / ".genesis" / "sync.yml"
                content = yaml.safe_load(sync_file.read_text())
                assert content["variables"].get("github_user") == "John Doe"

    def test_init_includes_template_source_field(self, tmp_path: Path) -> None:
        """Test that init command generates sync.yml with template_source field."""
        # Create a pyproject.toml to trigger python-api detection
        pyproject_content = """
[tool.poetry]
name = "test-api"
version = "0.1.0"

[tool.poetry.dependencies]
python = "^3.11"
fastapi = "^0.100.0"
"""
        (tmp_path / "pyproject.toml").write_text(pyproject_content)

        with mock.patch("genesis.commands.init.Path.cwd", return_value=tmp_path):
            init(force=False, project_type=None, project_name=None)

            sync_file = tmp_path / ".genesis" / "sync.yml"
            content = yaml.safe_load(sync_file.read_text())

            assert "template_source" in content
            assert content["template_source"] == "python-api"

    def test_init_template_source_matches_explicit_project_type(
        self, tmp_path: Path
    ) -> None:
        """Test that template_source matches explicitly specified project type."""
        with mock.patch("genesis.commands.init.Path.cwd", return_value=tmp_path):
            init(force=False, project_type="cli-tool", project_name=None)

            sync_file = tmp_path / ".genesis" / "sync.yml"
            content = yaml.safe_load(sync_file.read_text())

            assert "template_source" in content
            assert content["template_source"] == "cli-tool"
