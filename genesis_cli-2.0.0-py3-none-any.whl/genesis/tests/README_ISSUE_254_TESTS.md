# Integration Tests for GitHub Issue #254: Enhanced Build and Install Workflow

This directory contains comprehensive integration tests for the enhanced build and install workflow implemented to address GitHub issue #254: "Improve build and install workflow for Genesis CLI".

## Overview

The enhanced build and install workflow introduces significant improvements to Genesis CLI's build automation, client installation convenience, and version management consistency. These tests ensure all components work together seamlessly while maintaining backward compatibility and Genesis's high quality standards.

## Test Architecture

### Test Organization

The integration tests are organized into five main test files, each focusing on specific aspects of the enhanced workflow:

```
genesis/tests/
├── test_build_workflow_integration.py      # Build process automation
├── test_cicd_workflow_integration.py       # CI/CD workflow automation
├── test_client_install_integration.py      # Client installation process
├── test_version_management_integration.py  # Version management system
├── test_e2e_build_install_workflow.py      # End-to-end workflows
└── test_issue_254_integration_suite.py     # Master test coordinator
```

### Key Testing Areas

1. **Build Process Integration** (`test_build_workflow_integration.py`)
   - `make build` auto-uploads to GitHub releases using current version
   - Automatic version detection from pyproject.toml
   - Build artifact generation and validation
   - Error handling and recovery mechanisms

2. **CI/CD Workflow Integration** (`test_cicd_workflow_integration.py`)
   - GitHub Actions workflow triggers and automation
   - Version change detection accuracy
   - Automated release creation and asset management
   - Workflow security and permissions validation

3. **Client Install Process** (`test_client_install_integration.py`)
   - `make install-genesis` installs latest from GitHub releases
   - `make install-genesis-version VERSION=vX.Y.Z` installs specific versions
   - Uninstall → download → install → cleanup workflow
   - Network error handling and retry mechanisms

4. **Version Management** (`test_version_management_integration.py`)
   - Automatic version extraction from pyproject.toml
   - Manifest updates (releases.json and embedded manifest)
   - Version consistency across Genesis components
   - Dependency resolution with version handling

5. **End-to-End Workflows** (`test_e2e_build_install_workflow.py`)
   - Complete Genesis development workflow validation
   - Client project install/update scenarios
   - Rollback scenarios and error recovery
   - Backward compatibility preservation

## Test Categories and Markers

The tests use pytest markers to categorize different types of tests:

### Primary Markers
- `@pytest.mark.integration` - Integration tests across components
- `@pytest.mark.build` - Build process tests
- `@pytest.mark.install` - Installation process tests
- `@pytest.mark.cicd` - CI/CD workflow tests
- `@pytest.mark.version` - Version management tests
- `@pytest.mark.e2e` - End-to-end workflow tests

### Secondary Markers
- `@pytest.mark.performance` - Performance and load tests
- `@pytest.mark.security` - Security validation tests
- `@pytest.mark.network` - Network-dependent tests
- `@pytest.mark.ai_safety` - AI safety compliance tests

## Running the Tests

### Complete Test Suite

Run all issue #254 tests:
```bash
# Run complete integration test suite
pytest genesis/tests/test_issue_254_integration_suite.py -v

# Run all individual test files
pytest genesis/tests/test_*_integration.py -v --tb=short
```

### Category-Specific Tests

Run tests by category:
```bash
# Build process tests
pytest -m "build" genesis/tests/ -v

# Installation process tests
pytest -m "install" genesis/tests/ -v

# CI/CD workflow tests
pytest -m "cicd" genesis/tests/ -v

# Version management tests
pytest -m "version" genesis/tests/ -v

# End-to-end workflow tests
pytest -m "e2e" genesis/tests/ -v
```

### Performance and Security Tests

Run specialized test categories:
```bash
# Performance tests
pytest -m "performance" genesis/tests/ -v

# Security validation tests
pytest -m "security" genesis/tests/ -v

# AI safety compliance tests
pytest -m "ai_safety" genesis/tests/ -v

# Network-dependent tests (may require connectivity)
pytest -m "network" genesis/tests/ -v
```

### Individual Test Files

Run specific test files:
```bash
# Build workflow tests
pytest genesis/tests/test_build_workflow_integration.py -v

# CI/CD workflow tests
pytest genesis/tests/test_cicd_workflow_integration.py -v

# Client install tests
pytest genesis/tests/test_client_install_integration.py -v

# Version management tests
pytest genesis/tests/test_version_management_integration.py -v

# End-to-end workflow tests
pytest genesis/tests/test_e2e_build_install_workflow.py -v
```

## Test Implementation Philosophy

### Integration-First Approach

These tests follow Genesis's integration-first testing philosophy:

- **Real System Operations**: Tests use actual subprocess calls and file operations where possible
- **Minimal Mocking**: Mocking is used only for external services (GitHub API, network calls)
- **End-to-End Validation**: Tests validate complete workflows from start to finish
- **Error Scenario Coverage**: Comprehensive testing of failure modes and recovery

### AI Safety Compliance

All tests respect Genesis's AI safety constraints:

- **File Count Limits**: Tests operate within the 45-file boundary for AI-safe development
- **Component Isolation**: Tests validate worktree-based development patterns
- **Resource Management**: Proper cleanup and resource management in all test scenarios

### Security and Reliability

Security and reliability are core focus areas:

- **Credential Protection**: Tests validate environment variable filtering
- **Input Validation**: Version string validation and injection prevention
- **Error Handling**: Comprehensive error scenario testing
- **Recovery Mechanisms**: Rollback and cleanup validation

## Enhanced Workflow Features Tested

### Build Process Enhancements

1. **Auto-Upload to GitHub Releases**
   - `make build` automatically uploads packages using current version
   - Version extracted from pyproject.toml via `poetry version -s`
   - Creates GitHub releases with proper tagging

2. **Complete Release Workflow**
   - `make release` orchestrates bump → build → publish → tag
   - Automated version bumping with Git integration
   - Release notes generation and asset management

### Client Installation Improvements

1. **Convenient Makefile Targets**
   - `make install-genesis` for latest version installation
   - `make install-genesis-version VERSION=vX.Y.Z` for specific versions
   - `make update-genesis` for upgrading existing installations

2. **Robust Install Script**
   - Automatic latest version detection from GitHub API
   - Uninstall → download → install → cleanup workflow
   - Network error handling with retry mechanisms

### CI/CD Automation

1. **GitHub Actions Integration**
   - Auto-detection of version changes in pyproject.toml
   - Automated release creation and asset upload
   - Proper permissions and security configuration

2. **Version Management**
   - Consistent version handling across all components
   - Manifest updates (releases.json and embedded)
   - Dependency resolution with version constraints

## Test Data and Fixtures

### Mock Repository Structures

Tests create comprehensive mock repository structures:

```
mock_genesis/
├── pyproject.toml              # Main package configuration
├── shared-python/
│   └── pyproject.toml         # Shared core configuration
├── scripts/
│   ├── build.sh               # Enhanced build script
│   ├── release.sh             # Complete release workflow
│   └── update-releases-manifest.sh
├── .github/workflows/
│   └── auto-release.yml       # GitHub Actions workflow
├── releases.json              # Release manifest
└── dist/                      # Build artifacts
```

### Test Environment Setup

Tests use proper environment setup:

- **Temporary Directories**: All tests use `tmp_path` fixtures for isolation
- **Mock External Services**: GitHub API and network calls are mocked
- **Environment Variables**: Proper environment variable handling and cleanup
- **Process Management**: Subprocess mocking with realistic return values

## Success Criteria

### Build Process Success
- ✅ `make build` auto-uploads to GitHub releases using current version
- ✅ Version extraction from pyproject.toml works reliably
- ✅ Build artifacts are generated in correct locations
- ✅ Error handling prevents broken releases

### Release Workflow Success
- ✅ `make release` completes bump → build → publish → tag workflow
- ✅ Git operations (commit, tag, push) work correctly
- ✅ GitHub release creation and asset upload succeed
- ✅ Release notes are generated automatically

### Client Installation Success
- ✅ `make install-genesis` installs latest version reliably
- ✅ Version-specific installation works with proper validation
- ✅ Uninstall → download → install → cleanup workflow is robust
- ✅ Network error handling and retry mechanisms function

### Version Management Success
- ✅ Automatic version extraction from pyproject.toml
- ✅ Manifest updates maintain consistency
- ✅ Version validation prevents injection attacks
- ✅ Cross-component version consistency

### Integration Success
- ✅ Complete development workflow functions end-to-end
- ✅ Backward compatibility is preserved
- ✅ Error recovery and rollback mechanisms work
- ✅ Performance meets Genesis quality standards

## Contributing to Tests

### Adding New Tests

When adding new tests for issue #254 enhancements:

1. **Choose Appropriate Test File**: Add tests to the most relevant existing file
2. **Use Proper Markers**: Apply appropriate pytest markers for categorization
3. **Follow Naming Convention**: Use descriptive test method names
4. **Include Documentation**: Add comprehensive docstrings
5. **Test Both Success and Failure**: Cover positive and negative scenarios

### Test Structure Pattern

Follow this pattern for new tests:

```python
@pytest.mark.integration
@pytest.mark.build  # or appropriate marker
def test_specific_feature_scenario_expected_outcome(self, test_fixture):
    """Test description explaining what is being validated.

    This test verifies:
    - Specific behavior being tested
    - Edge cases covered
    - Integration points validated
    """
    # Arrange: Set up test environment and prerequisites
    with patch('subprocess.run') as mock_run:
        mock_run.return_value = Mock(returncode=0)

        # Act: Execute the operation being tested
        result = subprocess.run(['command'], capture_output=True)

        # Assert: Verify expected outcomes and side effects
        assert result.returncode == 0
        # Additional assertions...
```

### Best Practices

- **Use Descriptive Names**: Test names should clearly indicate what is being tested
- **Test One Thing**: Each test should focus on a single aspect or workflow
- **Include Error Cases**: Test failure modes and recovery mechanisms
- **Validate Side Effects**: Check that operations have expected side effects
- **Clean Up Resources**: Ensure proper cleanup in fixtures and tests

## Maintenance and Updates

These tests should be updated when:

- Build workflow components are modified
- New installation methods are added
- Version management logic changes
- CI/CD workflows are updated
- Security requirements are enhanced

The tests serve as both validation and documentation of the enhanced build and install workflow, ensuring Genesis maintains its high quality standards while improving developer and user experience.
