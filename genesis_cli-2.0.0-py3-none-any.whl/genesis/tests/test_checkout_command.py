"""Tests for Genesis checkout command with real Git operations."""

import os
import subprocess
import tempfile
from pathlib import Path

from click.testing import CliRunner

from genesis.cli import cli


class TestCheckoutCommand:
    """Test checkout command with real Git operations."""

    def setup_method(self) -> None:
        """Set up test environment."""
        self.original_dir = os.getcwd()

    def teardown_method(self) -> None:
        """Restore original directory."""
        os.chdir(self.original_dir)

    def test_checkout_existing_branch(self, tmp_path: Path) -> None:
        """Test checking out an existing branch."""
        os.chdir(tmp_path)

        # Create a real git repository with branches
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create initial commit
        test_file = tmp_path / "test.txt"
        test_file.write_text("initial content")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], capture_output=True)

        # Create a new branch
        subprocess.run(["git", "branch", "feature-branch"], capture_output=True)

        runner = CliRunner()
        result = runner.invoke(cli, ["checkout", "feature-branch"])

        assert result.exit_code == 0

        # Verify we're on the new branch
        current_branch = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
        )
        assert current_branch.stdout.strip() == "feature-branch"

    def test_checkout_create_new_branch(self, tmp_path: Path) -> None:
        """Test creating and checking out a new branch using branch command."""
        os.chdir(tmp_path)

        # Create a real git repository
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        test_file = tmp_path / "test.txt"
        test_file.write_text("initial")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], capture_output=True)

        # Create new branch using git directly since genesis checkout doesn't support -b
        subprocess.run(
            ["git", "checkout", "-b", "new-feature"], capture_output=True, check=True
        )

        runner = CliRunner()
        # Create another branch to checkout to
        subprocess.run(
            ["git", "checkout", "-b", "another-feature"],
            capture_output=True,
            check=True,
        )

        # Test switching back to new-feature using genesis checkout
        result = runner.invoke(cli, ["checkout", "new-feature"])

        assert result.exit_code == 0

        # Verify we're on the correct branch
        current_branch = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
        )
        assert current_branch.stdout.strip() == "new-feature"

    def test_checkout_specific_file(self, tmp_path: Path) -> None:
        """Test checking out a specific file from another branch."""
        os.chdir(tmp_path)

        # Create a real git repository
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create initial commit
        test_file = tmp_path / "test.txt"
        test_file.write_text("main branch content")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], capture_output=True)

        # Create feature branch with different content
        subprocess.run(["git", "checkout", "-b", "feature"], capture_output=True)
        test_file.write_text("feature branch content")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Feature change"], capture_output=True)

        # Go back to main branch
        subprocess.run(["git", "checkout", "main"], capture_output=True, check=False)
        subprocess.run(["git", "checkout", "master"], capture_output=True, check=False)

        # File should have main branch content
        assert test_file.read_text() == "main branch content"

        runner = CliRunner()
        # Try to checkout the file from feature branch
        result = runner.invoke(cli, ["checkout", "feature", "--", "test.txt"])

        if result.exit_code == 0:
            # File should now have feature branch content
            assert test_file.read_text() == "feature branch content"

    def test_checkout_previous_branch(self, tmp_path: Path) -> None:
        """Test checking out the previous branch using '-'."""
        os.chdir(tmp_path)

        # Create a real git repository with branches
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        test_file = tmp_path / "test.txt"
        test_file.write_text("initial")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], capture_output=True)

        # Create and switch to feature branch
        subprocess.run(["git", "checkout", "-b", "feature"], capture_output=True)

        # Get current branch (should be feature)
        current = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"], capture_output=True, text=True
        )
        assert current.stdout.strip() == "feature"

        runner = CliRunner()
        # Switch back to previous branch using -
        result = runner.invoke(cli, ["checkout", "-"])

        if result.exit_code == 0:
            # Should be back on main/master branch
            current = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True,
                text=True,
            )
            assert current.stdout.strip() in ["main", "master"]

    def test_checkout_nonexistent_branch(self, tmp_path: Path) -> None:
        """Test checking out a branch that doesn't exist."""
        os.chdir(tmp_path)

        # Create a real git repository
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        test_file = tmp_path / "test.txt"
        test_file.write_text("initial")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], capture_output=True)

        runner = CliRunner()
        result = runner.invoke(cli, ["checkout", "nonexistent-branch"])

        # Should fail
        assert result.exit_code != 0
        assert (
            "error" in result.output.lower() or "did not match" in result.output.lower()
        )

    def test_checkout_not_in_git_repo(self, tmp_path: Path) -> None:
        """Test checkout command outside Git repository."""
        original_dir = Path.cwd()
        try:
            with tempfile.TemporaryDirectory(dir="/tmp") as temp_dir:
                os.chdir(temp_dir)

                runner = CliRunner()
                result = runner.invoke(cli, ["checkout", "some-branch"])

                # Should fail when not in a git repository
                assert result.exit_code != 0
                assert (
                    "not a git repository" in result.output.lower()
                    or "fatal" in result.output.lower()
                )
        finally:
            os.chdir(original_dir)

    def test_checkout_with_uncommitted_changes(self, tmp_path: Path) -> None:
        """Test checkout behavior with uncommitted changes."""
        os.chdir(tmp_path)

        # Create a real git repository
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        test_file = tmp_path / "test.txt"
        test_file.write_text("initial")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], capture_output=True)

        # Create a branch
        subprocess.run(["git", "branch", "other-branch"], capture_output=True)

        # Make uncommitted changes
        test_file.write_text("modified content")

        runner = CliRunner()
        result = runner.invoke(cli, ["checkout", "other-branch"])

        # Git might warn about uncommitted changes or carry them over
        # Check if the command handled it appropriately
        if result.exit_code == 0:
            # If successful, we switched branches
            current = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True,
                text=True,
            )
            assert current.stdout.strip() == "other-branch"
        else:
            # If failed, we should still be on original branch
            assert (
                "uncommitted" in result.output.lower()
                or "changes" in result.output.lower()
            )


class TestCheckoutCommandWithTags:
    """Test checkout command with Git tags."""

    def test_checkout_tag(self, tmp_path: Path) -> None:
        """Test checking out a specific tag."""
        os.chdir(tmp_path)

        # Create a real git repository with tags
        subprocess.run(["git", "init"], capture_output=True, check=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"], capture_output=True
        )
        subprocess.run(["git", "config", "user.name", "Test User"], capture_output=True)

        # Create commits and tags
        (tmp_path / "v1.txt").write_text("version 1")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Version 1"], capture_output=True)
        subprocess.run(["git", "tag", "v1.0.0"], capture_output=True)

        (tmp_path / "v2.txt").write_text("version 2")
        subprocess.run(["git", "add", "."], capture_output=True)
        subprocess.run(["git", "commit", "-m", "Version 2"], capture_output=True)
        subprocess.run(["git", "tag", "v2.0.0"], capture_output=True)

        runner = CliRunner()
        # Checkout the v1.0.0 tag
        result = runner.invoke(cli, ["checkout", "v1.0.0"])

        assert result.exit_code == 0

        # Verify we're in detached HEAD state at v1.0.0
        # v2.txt should not exist
        assert not (tmp_path / "v2.txt").exists()
        assert (tmp_path / "v1.txt").exists()
