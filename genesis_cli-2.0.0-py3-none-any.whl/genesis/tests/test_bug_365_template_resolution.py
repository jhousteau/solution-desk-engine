"""Regression test for bug #365: Missing script files in shared_patterns.

Bug #365: The _resolve_template_path() method has an incomplete shared_patterns list
missing 6 script files that exist in templates/shared/scripts/:
- scripts/common-setup-functions.sh
- scripts/common-check-functions.sh
- .genesis/scripts/validation/check-genesis-components.sh
- .genesis/scripts/validation/check-variable-defaults.sh
- .genesis/scripts/validation/check-file-organization.sh
- .genesis/scripts/validation/check-ai-signatures.sh
- .genesis/scripts/validation/find-hardcoded-values.sh
- .genesis/scripts/validation/validate-components.sh
- .genesis/scripts/validation/validate-bootstrap.sh

These files are incorrectly resolved to project-specific paths causing
"Template not found" errors during sync operations.
"""

import tempfile
from collections.abc import Generator
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
import yaml

from genesis.commands.sync import SyncManager

try:
    from genesis.core import get_logger

    logger = get_logger(__name__)
except ImportError:
    import logging

    logger = logging.getLogger(__name__)


class TestBug365TemplateResolution:
    """Regression test for bug #365: Missing script files in shared_patterns."""

    @pytest.fixture
    def temp_project(self) -> Generator[Path]:
        """Create a temporary project directory for testing."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            # Create pyproject.toml
            pyproject_content = """
[tool.poetry]
name = "test-project"
version = "0.1.0"
description = "Test project"

[tool.poetry.dependencies]
python = "^3.11"
"""
            (project_path / "pyproject.toml").write_text(pyproject_content.strip())

            # Create .genesis directory with sync config
            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            yield project_path

    @pytest.fixture
    def sync_config_with_missing_scripts(self) -> dict[str, Any]:
        """Sync configuration that includes the 6 missing script files."""
        return {
            "template_source": "python-api",
            "sync_policies": [
                {
                    "source": "scripts/common-setup-functions.sh",
                    "dest": "scripts/common-setup-functions.sh",
                    "policy": "always",
                },
                {
                    "source": "scripts/common-check-functions.sh",
                    "dest": "scripts/common-check-functions.sh",
                    "policy": "always",
                },
                {
                    "source": ".genesis/scripts/validation/check-genesis-components.sh",
                    "dest": ".genesis/scripts/validation/check-genesis-components.sh",
                    "policy": "always",
                },
                {
                    "source": ".genesis/scripts/validation/check-variable-defaults.sh",
                    "dest": ".genesis/scripts/validation/check-variable-defaults.sh",
                    "policy": "always",
                },
                {
                    "source": ".genesis/scripts/validation/check-file-organization.sh",
                    "dest": ".genesis/scripts/validation/check-file-organization.sh",
                    "policy": "always",
                },
                {
                    "source": ".genesis/scripts/validation/find-hardcoded-values.sh",
                    "dest": ".genesis/scripts/validation/find-hardcoded-values.sh",
                    "policy": "always",
                },
            ],
        }

    @pytest.mark.unit
    def test_missing_script_files_in_shared_patterns_bug_365(
        self, temp_project: Path, sync_config_with_missing_scripts: dict[str, Any]
    ) -> None:
        """Test that demonstrates bug #365: missing script files in shared_patterns.

        This test FAILS before the fix because the 6 script files are not in the
        shared_patterns list, causing them to be resolved incorrectly to project-specific
        paths instead of shared paths, resulting in "Template not found" errors.

        After the fix (adding the 6 script files to shared_patterns), this test will PASS.
        """
        # Setup sync config
        sync_yml = temp_project / ".genesis" / "sync.yml"
        with open(sync_yml, "w") as f:
            yaml.dump(sync_config_with_missing_scripts, f)

        # Mock the template manager to track which paths are requested
        mock_template_manager = MagicMock()

        # Track all template paths that are requested
        requested_paths = []

        def track_template_requests(source_path: str) -> str:
            requested_paths.append(source_path)
            # Simulate template found for shared paths, not found for project-specific
            if source_path.startswith("shared/"):
                return f"Mock content for {source_path}"
            else:
                # This simulates the bug - project-specific paths fail
                raise FileNotFoundError(f"Template not found: {source_path}")

        mock_template_manager.get_template.side_effect = track_template_requests

        with patch(
            "genesis.core.templates.get_template_manager",
            return_value=mock_template_manager,
        ):
            manager = SyncManager(temp_project, verbose=True)

            # This will fail due to bug #365 until the shared_patterns list is fixed
            manager.sync()

            # Verify the bug: script files should be resolved to shared/ paths
            # but due to missing entries in shared_patterns, they're resolved incorrectly

            # These are the expected correct shared paths (after fix)
            expected_shared_paths = [
                "shared/scripts/common-setup-functions.sh.template",
                "shared/scripts/common-check-functions.sh.template",
                "shared/.genesis/scripts/validation/check-genesis-components.sh.template",
                "shared/.genesis/scripts/validation/check-variable-defaults.sh.template",
                "shared/.genesis/scripts/validation/check-file-organization.sh.template",
                "shared/.genesis/scripts/validation/find-hardcoded-values.sh.template",
            ]

            # Log what paths were actually requested for debugging
            logger.info(f"Requested template paths: {requested_paths}")

            # The bug causes these to be resolved to incorrect project-specific paths
            # After the fix, all requested paths should start with "shared/"
            shared_path_requests = [
                p for p in requested_paths if p.startswith("shared/")
            ]
            non_shared_requests = [
                p for p in requested_paths if not p.startswith("shared/")
            ]

            logger.info(f"Shared path requests: {shared_path_requests}")
            logger.info(
                f"Non-shared requests (these indicate the bug): {non_shared_requests}"
            )

            # The test passes when ALL script files are correctly resolved to shared paths
            # Due to bug #365, some files are incorrectly resolved to project-specific paths

            # Check that all expected shared paths were requested
            for expected_path in expected_shared_paths:
                assert expected_path in requested_paths, (
                    f"Bug #365: Script file {expected_path} was not resolved to shared path. "
                    f"This indicates the file is missing from shared_patterns list in "
                    f"_resolve_template_path() method."
                )

            # Additional check: no project-specific script paths should be requested
            # (this would indicate the bug is present)
            project_specific_script_paths = [
                p
                for p in requested_paths
                if "scripts/" in p and not p.startswith("shared/")
            ]

            assert len(project_specific_script_paths) == 0, (
                f"Bug #365: Found project-specific script paths {project_specific_script_paths}. "
                f"These should be resolved to shared/ paths instead. "
                f"Add missing script patterns to shared_patterns list in _resolve_template_path()."
            )

    @pytest.mark.unit
    def test_template_path_resolution_for_scripts(self, temp_project: Path) -> None:
        """Test that script files are correctly resolved to shared paths.

        This test directly validates the _resolve_template_path method behavior.
        """
        manager = SyncManager(temp_project)

        # Test the 6 script files that were missing from shared_patterns
        script_files = [
            "scripts/common-setup-functions.sh",
            "scripts/common-check-functions.sh",
            ".genesis/scripts/validation/check-genesis-components.sh",
            ".genesis/scripts/validation/check-variable-defaults.sh",
            ".genesis/scripts/validation/check-file-organization.sh",
            ".genesis/scripts/validation/find-hardcoded-values.sh",
        ]

        template_source = "python-api"

        for script_file in script_files:
            resolved_path = manager._resolve_template_path(script_file, template_source)

            # After fix: all script files should resolve to shared/ paths
            expected_path = f"shared/{script_file}.template"

            assert resolved_path == expected_path, (
                f"Bug #365: Script file '{script_file}' resolved to '{resolved_path}' "
                f"instead of expected '{expected_path}'. "
                f"This indicates the file is missing from shared_patterns list."
            )

            logger.info(f"✓ {script_file} correctly resolved to {resolved_path}")
