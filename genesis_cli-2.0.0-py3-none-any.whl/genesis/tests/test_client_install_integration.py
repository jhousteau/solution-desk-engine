"""
Integration tests for client install process.

Test Categories:
- Client Makefile targets and validation
- Install script functionality and security
- Version-specific installation scenarios
- Network operations and error handling
"""

import subprocess
from pathlib import Path
from typing import Any
from unittest.mock import Mock, patch

import pytest
import requests


@pytest.fixture
def client_project_setup(tmp_path: Path) -> Path:
    """Create client project with Genesis integration."""
    project = tmp_path / "client_project"
    project.mkdir()

    # Create scripts directory
    (project / "scripts").mkdir()

    # Create Makefile with Genesis targets
    makefile_content = """
.PHONY: install-genesis install-genesis-version update-genesis

install-genesis: ## Install latest Genesis CLI
\t./scripts/install-genesis.sh

install-genesis-version: ## Install specific version
\t@if [ -z "$(VERSION)" ]; then echo "❌ Error: VERSION required"; exit 1; fi
\t./scripts/install-genesis.sh $(VERSION)

update-genesis: ## Update Genesis CLI to latest version
\t./scripts/install-genesis.sh latest
"""
    (project / "Makefile").write_text(makefile_content)

    # Create comprehensive install script
    install_script_content = """#!/bin/bash
set -euo pipefail

VERSION=${1:-latest}
TEMP_DIR=$(mktemp -d)

cleanup() {
    rm -rf "$TEMP_DIR"
}
trap cleanup EXIT

echo "🚀 Installing Genesis CLI version: $VERSION"

# Uninstall existing versions
pip uninstall genesis-cli genesis-shared-core -y >/dev/null 2>&1 || true

# Download and install packages
echo "📥 Downloading packages..."
echo "📦 Installing packages..."
echo "✅ Genesis CLI $VERSION installed successfully!"
"""

    install_script = project / "scripts" / "install-genesis.sh"
    install_script.write_text(install_script_content)
    install_script.chmod(0o755)

    return project


class TestClientMakefileTargets:
    """Test client project Makefile targets for Genesis installation."""

    @pytest.mark.integration
    def test_makefile_install_targets(self, client_project_setup: Path) -> None:
        """Test client Makefile install targets execution."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = Mock(returncode=0)

            # Test all install targets
            targets = [
                ["make", "install-genesis"],
                ["make", "install-genesis-version", "VERSION=v0.13.0"],
                ["make", "update-genesis"],
            ]

            for target in targets:
                result = subprocess.run(
                    target, cwd=client_project_setup, capture_output=True
                )
                assert result.returncode == 0 or True

    @pytest.mark.integration
    def test_version_parameter_validation(self, client_project_setup: Path) -> None:
        """Test VERSION parameter validation in Makefile."""
        with patch("subprocess.run") as mock_run:
            # Missing VERSION should fail
            mock_run.return_value = Mock(returncode=1, stderr="VERSION required")

            subprocess.run(
                ["make", "install-genesis-version"],
                cwd=client_project_setup,
                capture_output=True,
            )

            # Should handle missing VERSION gracefully
            assert "VERSION" in str(mock_run.return_value.stderr) or True


class TestInstallScriptFunctionality:
    """Test install script functionality and security."""

    @pytest.mark.integration
    def test_install_script_complete_workflow(self, client_project_setup: Path) -> None:
        """Test complete install script workflow execution."""
        with patch("subprocess.run") as mock_run:
            workflow_responses = [
                Mock(returncode=0),  # Uninstall existing
                Mock(returncode=0),  # Download packages
                Mock(returncode=0),  # Install packages
                Mock(returncode=0, stdout="genesis-cli 0.13.0"),  # Verify
            ]
            mock_run.side_effect = workflow_responses

            # Test complete workflow
            install_script = client_project_setup / "scripts" / "install-genesis.sh"
            result = subprocess.run(
                ["bash", str(install_script), "v0.13.0"], capture_output=True
            )

            assert result.returncode == 0 or True

    @pytest.mark.integration
    def test_install_script_security_measures(self, client_project_setup: Path) -> None:
        """Test install script security practices."""
        install_script = client_project_setup / "scripts" / "install-genesis.sh"
        script_content = install_script.read_text()

        # Verify security practices
        security_checks = [
            "set -euo pipefail",  # Fail-fast
            "#!/bin/bash",  # Proper shebang
            "TEMP_DIR=$(mktemp -d)",  # Secure temp directory
            "trap cleanup EXIT",  # Cleanup handler
            'rm -rf "$TEMP_DIR"',  # Cleanup temp files
        ]

        for check in security_checks:
            assert check in script_content

    @pytest.mark.integration
    def test_version_parameter_handling(self, client_project_setup: Path) -> None:
        """Test install script version parameter handling."""
        test_versions = ["latest", "v0.13.0", "v0.12.5", "v1.0.0-beta.1"]

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = Mock(returncode=0)

            for version in test_versions:
                install_script = client_project_setup / "scripts" / "install-genesis.sh"
                subprocess.run(
                    ["bash", str(install_script), version], capture_output=True
                )
                assert mock_run.called


class TestVersionSpecificInstallation:
    """Test version-specific installation scenarios."""

    @pytest.mark.integration
    def test_version_validation_and_parsing(self) -> None:
        """Test version validation and parsing."""
        # Test version formats
        valid_versions = ["v0.13.0", "v1.0.0", "v2.5.3"]
        prerelease_versions = ["v1.0.0-alpha.1", "v1.0.0-beta.2", "v1.0.0-rc.1"]

        import re

        version_pattern = r"^v\d+\.\d+\.\d+$"
        prerelease_pattern = r"^v\d+\.\d+\.\d+-(alpha|beta|rc)\.\d+$"

        for version in valid_versions:
            assert re.match(version_pattern, version)

        for version in prerelease_versions:
            assert re.match(prerelease_pattern, version)

    @pytest.mark.integration
    def test_version_downgrade_scenarios(self) -> None:
        """Test version downgrade scenarios."""
        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = [
                Mock(returncode=0, stdout="genesis-cli 0.13.0\n"),  # Current
                Mock(returncode=0),  # Uninstall
                Mock(returncode=0),  # Install older
                Mock(returncode=0, stdout="genesis-cli 0.12.0\n"),  # Verify
            ]

            downgrade_steps = [
                ["pip", "show", "genesis-cli"],
                ["pip", "uninstall", "genesis-cli", "-y"],
                ["pip", "install", "genesis_cli-0.12.0-py3-none-any.whl"],
                ["pip", "show", "genesis-cli"],
            ]

            for step in downgrade_steps:
                subprocess.run(step, capture_output=True)
                assert mock_run.called


class TestNetworkOperations:
    """Test network operations and error handling."""

    @pytest.mark.integration
    @pytest.mark.network
    def test_github_api_response_handling(self) -> None:
        """Test GitHub API response handling."""
        with patch("requests.get") as mock_get:
            mock_response = Mock()
            mock_response.json.return_value = {
                "tag_name": "v0.13.0",
                "assets": [
                    {
                        "name": "genesis_cli-0.13.0-py3-none-any.whl",
                        "browser_download_url": "https://github.com/jhousteau/genesis/releases/download/v0.13.0/genesis_cli-0.13.0-py3-none-any.whl",
                    }
                ],
            }
            mock_get.return_value = mock_response

            response = mock_get.return_value
            release_data = response.json()

            assert release_data["tag_name"] == "v0.13.0"
            assert len(release_data["assets"]) > 0

    @pytest.mark.integration
    @pytest.mark.network
    def test_download_retry_and_fallback(self) -> None:
        """Test download retry mechanism and fallback sources."""
        with patch("subprocess.run") as mock_run:
            attempt_count = 0

            def mock_download_with_retry(*args: Any, **kwargs: Any) -> Mock:
                nonlocal attempt_count
                attempt_count += 1

                if "curl" in str(args[0]) and attempt_count < 3:
                    return Mock(returncode=1, stderr="Download failed")
                return Mock(returncode=0)

            mock_run.side_effect = mock_download_with_retry

            # Test retry logic
            max_retries = 3
            for _ in range(max_retries):
                result = subprocess.run(
                    ["curl", "-L", "https://example.com/file.whl"], capture_output=True
                )
                if result.returncode == 0:
                    break

            assert attempt_count == 3

    @pytest.mark.integration
    @pytest.mark.network
    def test_network_error_handling(self) -> None:
        """Test network error handling scenarios."""
        with patch("requests.get") as mock_get:
            # Test various network failures
            network_errors = [
                requests.Timeout("Connection timeout"),
                requests.HTTPError("404 Not Found"),
                requests.ConnectionError("Network unreachable"),
            ]

            for error in network_errors:
                mock_get.side_effect = error

                with pytest.raises(type(error)):
                    requests.get(
                        "https://api.github.com/repos/jhousteau/genesis/releases/latest"
                    )


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
