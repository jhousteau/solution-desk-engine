"""
Consolidated Bootstrap Sync Tests - Issues #248, #264, #391.

This file consolidates all bootstrap sync tests into a single, maintainable module:
- sync.yml integration tests (formerly test_bootstrap_sync_yml_integration.py)
- v1.0 format compliance tests (formerly test_bootstrap_sync_v1_format_compliance.py)
- regression tests (formerly test_bootstrap_sync_regression.py)

All tests ensure bootstrap command creates sync.yml in the correct v1.0 format
and maintains backward compatibility while preventing regressions.
"""

from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from genesis.commands.bootstrap import (
    bootstrap_project,
    create_initial_sync_config,
    generate_sync_config,
    get_template_path,
    validate_project_name,
)

# Import common fixtures from the dedicated fixtures module
from genesis.tests.fixtures_bootstrap import (
    create_shared_manifest,
    create_shared_templates,
)

# =============================================================================
# SYNC YML INTEGRATION TESTS
# =============================================================================


class TestBootstrapSyncYmlIntegration:
    """Integration tests for bootstrap command sync.yml creation."""

    def test_creates_sync_yml_instead_of_legacy_format(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test that bootstrap creates sync.yml instead of sync-state.json."""
        project_dir = temp_workspace / "test-project"

        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            bootstrap_project(
                name="test-project",
                project_type="python-api",
                target_path=str(temp_workspace),
            )

        # Verify sync.yml exists and sync-state.json doesn't
        sync_yml = project_dir / ".genesis" / "sync.yml"
        sync_state_json = project_dir / ".genesis" / "sync-state.json"

        assert sync_yml.exists(), "sync.yml should be created"
        assert not sync_state_json.exists(), "sync-state.json should not be created"

        # Verify sync.yml has correct v1.0 format
        with open(sync_yml) as f:
            sync_config = yaml.safe_load(f)

        assert "sync_policies" in sync_config, "sync_policies key should exist"
        assert isinstance(
            sync_config["sync_policies"], dict
        ), "sync_policies should be a dictionary"
        assert "always" in sync_config["sync_policies"], "always policy should exist"
        assert (
            "if_unchanged" in sync_config["sync_policies"]
        ), "if_unchanged policy should exist"
        assert "never" in sync_config["sync_policies"], "never policy should exist"

    def test_sync_yml_v1_format_compliance(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test that sync.yml follows v1.0 format specification."""
        project_dir = temp_workspace / "test-project"

        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            bootstrap_project(
                name="test-project",
                project_type="cli-tool",
                target_path=str(temp_workspace),
            )

        sync_yml = project_dir / ".genesis" / "sync.yml"
        with open(sync_yml) as f:
            sync_config = yaml.safe_load(f)

        # Verify v1.0 format structure
        assert sync_config.get("version") == "1.0", "Version should be 1.0"
        assert isinstance(
            sync_config["sync_policies"], dict
        ), "sync_policies should be dictionary"

        # Verify all policy types exist with file lists
        for policy in ["always", "if_unchanged", "never"]:
            assert (
                policy in sync_config["sync_policies"]
            ), f"{policy} policy should exist"
            assert isinstance(
                sync_config["sync_policies"][policy], list
            ), f"{policy} should be a list"

        # Verify file structure integrity
        all_files = []
        for policy_files in sync_config["sync_policies"].values():
            all_files.extend(policy_files)

        assert len(all_files) > 0, "Should have files in sync policies"
        assert len(set(all_files)) == len(
            all_files
        ), "No duplicate files across policies"

    def test_all_project_types_create_valid_sync_yml(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test that all project types create valid sync.yml files."""
        project_types = [
            "python-api",
            "cli-tool",
            "typescript-service",
            "terraform-project",
        ]

        for project_type in project_types:
            project_dir = temp_workspace / f"test-{project_type}"

            with patch(
                "genesis.commands.bootstrap.get_genesis_root",
                return_value=complete_genesis_templates,
            ):
                bootstrap_project(
                    name=f"test-{project_type}",
                    project_type=project_type,
                    target_path=str(temp_workspace),
                )

            sync_yml = project_dir / ".genesis" / "sync.yml"
            assert sync_yml.exists(), f"sync.yml should exist for {project_type}"

            with open(sync_yml) as f:
                sync_config = yaml.safe_load(f)

            assert (
                sync_config.get("version") == "1.0"
            ), f"Version should be 1.0 for {project_type}"
            assert isinstance(
                sync_config["sync_policies"], dict
            ), f"sync_policies should be dict for {project_type}"

    def test_shared_files_properly_categorized(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test that shared files are properly categorized in sync policies."""
        project_dir = temp_workspace / "test-project"

        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            bootstrap_project(
                name="test-project",
                project_type="python-api",
                target_path=str(temp_workspace),
            )

        sync_yml = project_dir / ".genesis" / "sync.yml"
        with open(sync_yml) as f:
            sync_config = yaml.safe_load(f)

        # Check specific file categorizations
        always_files = sync_config["sync_policies"]["always"]
        if_unchanged_files = sync_config["sync_policies"]["if_unchanged"]
        never_files = sync_config["sync_policies"]["never"]

        assert "Dockerfile" in always_files, "Dockerfile should be in always policy"
        assert "CLAUDE.md" in never_files, "CLAUDE.md should be in never policy"
        assert (
            "Makefile" in if_unchanged_files
        ), "Makefile should be in if_unchanged policy"

    def test_project_specific_files_included(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test that project-specific files are included in sync.yml."""
        project_types_files = {
            "python-api": ["pyproject.toml", "src/__module_name__/main.py"],
            "cli-tool": ["pyproject.toml", "__module_name__/cli.py"],
            "typescript-service": ["package.json", "src/index.ts"],
            "terraform-project": ["main.tf", "variables.tf"],
        }

        for project_type, expected_files in project_types_files.items():
            project_dir = temp_workspace / f"test-{project_type}"

            with patch(
                "genesis.commands.bootstrap.get_genesis_root",
                return_value=complete_genesis_templates,
            ):
                bootstrap_project(
                    name=f"test-{project_type}",
                    project_type=project_type,
                    target_path=str(temp_workspace),
                )

            sync_yml = project_dir / ".genesis" / "sync.yml"
            with open(sync_yml) as f:
                sync_config = yaml.safe_load(f)

            all_files = []
            for policy_files in sync_config["sync_policies"].values():
                all_files.extend(policy_files)

            for expected_file in expected_files:
                assert (
                    expected_file in all_files
                ), f"{expected_file} should be in sync.yml for {project_type}"


# =============================================================================
# V1.0 FORMAT COMPLIANCE TESTS
# =============================================================================


class TestSyncYmlV1FormatCompliance:
    """Test sync.yml v1.0 format compliance in bootstrap operations."""

    def test_sync_config_generation_v1_format(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test generate_sync_config creates v1.0 format."""
        project_dir = temp_workspace / "test-project"
        project_dir.mkdir()

        sync_config = generate_sync_config(
            project_path=project_dir,
            project_type="python-api",
        )

        assert sync_config["version"] == "1.0", "Version should be 1.0"
        assert isinstance(
            sync_config["sync_policies"], dict
        ), "sync_policies should be dictionary"
        assert set(sync_config["sync_policies"].keys()) == {
            "always",
            "if_unchanged",
            "never",
        }, "All policy types should exist"

    def test_initial_sync_config_creation_v1_format(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test create_initial_sync_config creates v1.0 format."""
        project_dir = temp_workspace / "test-project"
        project_dir.mkdir()
        genesis_dir = project_dir / ".genesis"
        genesis_dir.mkdir()

        create_initial_sync_config(
            project_path=project_dir,
            project_type="cli-tool",
        )

        sync_yml = genesis_dir / "sync.yml"
        assert sync_yml.exists(), "sync.yml should be created"

        with open(sync_yml) as f:
            sync_config = yaml.safe_load(f)

        assert sync_config["version"] == "1.0", "Version should be 1.0"
        assert isinstance(
            sync_config["sync_policies"], dict
        ), "sync_policies should be dictionary"

    def test_no_legacy_sync_state_json_created(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test that no legacy sync-state.json is created."""
        project_dir = temp_workspace / "test-project"

        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            bootstrap_project(
                name="test-project",
                project_type="python-api",
                target_path=str(temp_workspace),
            )

        genesis_dir = project_dir / ".genesis"
        sync_state_json = genesis_dir / "sync-state.json"

        assert not sync_state_json.exists(), "sync-state.json should not be created"

    def test_sync_policies_structure_compliance(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test that sync_policies follows v1.0 structure."""
        project_dir = temp_workspace / "test-project"

        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            bootstrap_project(
                name="test-project",
                project_type="terraform-project",
                target_path=str(temp_workspace),
            )

        sync_yml = project_dir / ".genesis" / "sync.yml"
        with open(sync_yml) as f:
            sync_config = yaml.safe_load(f)

        sync_policies = sync_config["sync_policies"]

        # Verify structure
        assert isinstance(sync_policies, dict), "sync_policies should be dictionary"
        assert all(
            isinstance(policy_files, list) for policy_files in sync_policies.values()
        ), "All policies should contain lists"
        assert all(
            isinstance(filepath, str)
            for policy_files in sync_policies.values()
            for filepath in policy_files
        ), "All file paths should be strings"

    def test_metadata_fields_included(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test that required metadata fields are included in sync.yml."""
        project_dir = temp_workspace / "test-project"

        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            bootstrap_project(
                name="test-project",
                project_type="typescript-service",
                target_path=str(temp_workspace),
            )

        sync_yml = project_dir / ".genesis" / "sync.yml"
        with open(sync_yml) as f:
            sync_config = yaml.safe_load(f)

        # Verify required metadata
        assert "version" in sync_config, "version field should exist"
        assert "project_type" in sync_config, "project_type field should exist"
        assert "created_at" in sync_config, "created_at field should exist"
        assert (
            sync_config["project_type"] == "typescript-service"
        ), "project_type should match"


# =============================================================================
# REGRESSION TESTS
# =============================================================================


class TestBootstrapRegressionWorkflows:
    """Regression tests for complete bootstrap workflows."""

    def test_python_api_bootstrap_workflow(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test complete Python API bootstrap workflow."""
        project_dir = temp_workspace / "my-api"

        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            bootstrap_project(
                name="my-api",
                project_type="python-api",
                target_path=str(temp_workspace),
            )

        # Verify core files exist
        assert (project_dir / "README.md").exists()
        assert (project_dir / "pyproject.toml").exists()
        assert (project_dir / "src" / "my_api" / "main.py").exists()
        assert (project_dir / "tests" / "test_main.py").exists()
        assert (project_dir / ".genesis" / "sync.yml").exists()

    def test_cli_tool_bootstrap_workflow(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test complete CLI tool bootstrap workflow."""
        project_dir = temp_workspace / "my-cli"

        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            bootstrap_project(
                name="my-cli",
                project_type="cli-tool",
                target_path=str(temp_workspace),
            )

        # Verify core files exist
        assert (project_dir / "README.md").exists()
        assert (project_dir / "pyproject.toml").exists()
        assert (project_dir / "my_cli" / "cli.py").exists()
        assert (project_dir / "tests" / "test_cli.py").exists()
        assert (project_dir / ".genesis" / "sync.yml").exists()

    def test_typescript_service_bootstrap_workflow(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test complete TypeScript service bootstrap workflow."""
        project_dir = temp_workspace / "my-service"

        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            bootstrap_project(
                name="my-service",
                project_type="typescript-service",
                target_path=str(temp_workspace),
            )

        # Verify core files exist
        assert (project_dir / "README.md").exists()
        assert (project_dir / "package.json").exists()
        assert (project_dir / "tsconfig.json").exists()
        assert (project_dir / "src" / "index.ts").exists()
        assert (project_dir / ".genesis" / "sync.yml").exists()

    def test_terraform_project_bootstrap_workflow(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test complete Terraform project bootstrap workflow."""
        project_dir = temp_workspace / "my-infra"

        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            bootstrap_project(
                name="my-infra",
                project_type="terraform-project",
                target_path=str(temp_workspace),
            )

        # Verify core files exist
        assert (project_dir / "README.md").exists()
        assert (project_dir / "main.tf").exists()
        assert (project_dir / "variables.tf").exists()
        assert (project_dir / "outputs.tf").exists()
        assert (project_dir / ".genesis" / "sync.yml").exists()

    def test_project_name_validation_still_works(self) -> None:
        """Test that project name validation still works after changes."""
        from genesis.core.errors import ValidationError

        # Valid names (should not raise exceptions)
        try:
            validate_project_name("my-project")
            validate_project_name("test123")
            validate_project_name("a-b-c")
        except ValidationError:
            pytest.fail("Valid project names should not raise ValidationError")

        # Invalid names (should raise ValidationError)
        with pytest.raises(ValidationError, match="Project name cannot be empty"):
            validate_project_name("")

        with pytest.raises(
            ValidationError, match="must contain only letters, numbers, and hyphens"
        ):
            validate_project_name("My Project")  # spaces

        with pytest.raises(
            ValidationError, match="must contain only letters, numbers, and hyphens"
        ):
            validate_project_name("my_project")  # underscores

        with pytest.raises(ValidationError, match="cannot start or end with hyphen"):
            validate_project_name("-project")  # starts with dash

        with pytest.raises(ValidationError, match="cannot start or end with hyphen"):
            validate_project_name("project-")  # ends with dash

    def test_template_path_resolution(self, complete_genesis_templates: Path) -> None:
        """Test that template path resolution still works."""
        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            python_api_path = get_template_path("python-api")
            cli_tool_path = get_template_path("cli-tool")

            assert python_api_path is not None and python_api_path.exists()
            assert cli_tool_path is not None and cli_tool_path.exists()
            assert python_api_path is not None and python_api_path.name == "python-api"
            assert cli_tool_path is not None and cli_tool_path.name == "cli-tool"


class TestBootstrapBackwardsCompatibility:
    """Tests for backwards compatibility with existing projects."""

    def test_existing_project_structures_preserved(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test that existing project structures are preserved."""
        # This would be expanded with more specific backwards compatibility tests
        # For now, ensure basic bootstrap still works
        project_dir = temp_workspace / "test-project"

        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            bootstrap_project(
                name="test-project",
                project_type="python-api",
                target_path=str(temp_workspace),
            )

        # Verify the project was created successfully
        assert project_dir.exists()
        assert (project_dir / ".genesis" / "sync.yml").exists()


class TestBootstrapPerformanceRegression:
    """Performance regression tests to ensure changes don't slow down bootstrap."""

    def test_bootstrap_completes_in_reasonable_time(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test that bootstrap completes in reasonable time."""
        import time

        start_time = time.time()

        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            bootstrap_project(
                name="perf-test",
                project_type="python-api",
                target_path=str(temp_workspace),
            )

        end_time = time.time()
        duration = end_time - start_time

        # Bootstrap should complete in under 5 seconds for reasonable template sizes
        assert duration < 5.0, f"Bootstrap took {duration:.2f}s, which is too long"


# =============================================================================
# ERROR HANDLING AND EDGE CASES
# =============================================================================


class TestBootstrapSyncErrorHandling:
    """Test error handling in bootstrap sync operations."""

    def test_malformed_shared_manifest_handling(
        self, genesis_root: Path, temp_workspace: Path
    ) -> None:
        """Test handling of malformed shared manifest."""
        # Create malformed manifest
        shared_dir = genesis_root / "templates" / "shared"
        shared_dir.mkdir(parents=True)

        manifest_path = shared_dir / "manifest.yml"
        manifest_path.write_text("invalid: yaml: content: [")

        with patch(
            "genesis.commands.bootstrap.get_genesis_root", return_value=genesis_root
        ):
            with pytest.raises((yaml.YAMLError, FileNotFoundError, KeyError)):
                bootstrap_project(
                    name="test-project",
                    project_type="python-api",
                    target_path=str(temp_workspace),
                )

    def test_missing_template_directory_handling(
        self, genesis_root: Path, temp_workspace: Path
    ) -> None:
        """Test handling of missing template directory."""
        # Don't create python-api template directory
        shared_dir = genesis_root / "templates" / "shared"
        shared_dir.mkdir(parents=True)
        create_shared_manifest(shared_dir)
        create_shared_templates(shared_dir)

        with patch(
            "genesis.commands.bootstrap.get_genesis_root", return_value=genesis_root
        ):
            with pytest.raises((FileNotFoundError, NotADirectoryError)):
                bootstrap_project(
                    name="test-project",
                    project_type="python-api",
                    target_path=str(temp_workspace),
                )

    def test_invalid_project_type_handling(
        self, complete_genesis_templates: Path, temp_workspace: Path
    ) -> None:
        """Test handling of invalid project type."""
        with patch(
            "genesis.commands.bootstrap.get_genesis_root",
            return_value=complete_genesis_templates,
        ):
            with pytest.raises((ValueError, FileNotFoundError)):
                bootstrap_project(
                    name="test-project",
                    project_type="invalid-type",
                    target_path=str(temp_workspace),
                )
