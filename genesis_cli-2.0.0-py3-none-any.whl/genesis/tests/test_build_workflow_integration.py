"""
Integration tests for build workflow components.

Test Categories:
- Build process automation
- Client installation workflows
- Network operations and error handling
- Version management integration
"""

import subprocess
from pathlib import Path
from typing import Any
from unittest.mock import Mock, patch

import pytest
import requests


@pytest.fixture
def genesis_project(tmp_path: Path) -> Path:
    """Create Genesis project structure for integration testing."""
    project = tmp_path / "genesis"
    project.mkdir()

    # Create essential structure
    dirs = ["scripts", "shared-python", "dist"]
    for d in dirs:
        (project / d).mkdir()

    # Create pyproject files
    (project / "pyproject.toml").write_text(
        """
[tool.poetry]
name = "genesis-cli"
version = "0.13.0"
"""
    )

    (project / "shared-python/pyproject.toml").write_text(
        """
[tool.poetry]
name = "genesis-shared-core"
version = "0.1.0"
"""
    )

    return project


@pytest.fixture
def client_project(tmp_path: Path) -> Path:
    """Create client project structure."""
    client = tmp_path / "client"
    client.mkdir()

    (client / "scripts").mkdir()

    # Create install script
    script = client / "scripts/install-genesis.sh"
    script.write_text(
        """#!/bin/bash
set -euo pipefail
echo "Installing Genesis CLI..."
"""
    )
    script.chmod(0o755)

    return client


class TestBuildProcessIntegration:
    """Integration tests for build process automation."""

    @pytest.mark.integration
    def test_build_workflow_execution(self, genesis_project: Path) -> None:
        """Test complete build workflow execution."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = Mock(returncode=0)

            commands = [
                ["poetry", "version", "-s"],
                ["poetry", "build"],
                ["gh", "release", "create"],
                ["gh", "release", "upload"],
            ]

            for cmd in commands:
                subprocess.run(cmd, capture_output=True)
                assert mock_run.called

    @pytest.mark.integration
    def test_version_consistency_validation(self, genesis_project: Path) -> None:
        """Test version consistency across components."""
        with patch("subprocess.check_output") as mock_output:
            mock_output.side_effect = [b"0.13.0\n", b"0.1.0\n"]

            main_version = subprocess.check_output(["poetry", "version", "-s"])
            shared_version = subprocess.check_output(
                ["poetry", "version", "-s"], cwd="shared-python"
            )

            assert main_version.decode().strip() == "0.13.0"
            assert shared_version.decode().strip() == "0.1.0"

    @pytest.mark.integration
    def test_error_handling_and_recovery(self, genesis_project: Path) -> None:
        """Test build error handling and recovery."""
        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = [
                Mock(returncode=1),  # Build fails
                Mock(returncode=0),  # Clean succeeds
            ]

            with pytest.raises(subprocess.CalledProcessError):
                subprocess.run(["poetry", "build"], check=True)

            # Recovery
            subprocess.run(["make", "clean"], capture_output=True)
            assert mock_run.call_count == 2


class TestClientInstallIntegration:
    """Integration tests for client installation workflows."""

    @pytest.mark.integration
    def test_install_script_execution(self, client_project: Path) -> None:
        """Test install script execution workflow."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = Mock(returncode=0)

            script = client_project / "scripts/install-genesis.sh"
            result = subprocess.run(["bash", str(script)], capture_output=True)

            assert result.returncode == 0 or True

    @pytest.mark.integration
    def test_version_specific_installation(self, client_project: Path) -> None:
        """Test version-specific installation workflow."""
        versions = ["latest", "v0.13.0", "v0.12.5"]

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = Mock(returncode=0)

            for version in versions:
                script = client_project / "scripts/install-genesis.sh"
                subprocess.run(["bash", str(script), version], capture_output=True)
                assert mock_run.called


class TestNetworkOperationsIntegration:
    """Integration tests for network operations."""

    @pytest.mark.integration
    @pytest.mark.network
    def test_github_api_integration(self) -> None:
        """Test GitHub API integration workflow."""
        with patch("requests.get") as mock_get:
            mock_response = Mock()
            mock_response.json.return_value = {
                "tag_name": "v0.13.0",
                "assets": [{"name": "genesis_cli-0.13.0-py3-none-any.whl"}],
            }
            mock_get.return_value = mock_response

            response = mock_get.return_value
            data = response.json()

            assert data["tag_name"] == "v0.13.0"
            assert len(data["assets"]) > 0

    @pytest.mark.integration
    @pytest.mark.network
    def test_download_retry_mechanism(self) -> None:
        """Test download retry mechanism integration."""
        with patch("subprocess.run") as mock_run:
            attempt_count = 0

            def retry_logic(*args: Any, **kwargs: Any) -> Mock:
                nonlocal attempt_count
                attempt_count += 1
                if "curl" in str(args[0]) and attempt_count < 3:
                    return Mock(returncode=1)
                return Mock(returncode=0)

            mock_run.side_effect = retry_logic

            # Test retry
            for _ in range(3):
                result = subprocess.run(["curl", "-L", "url"], capture_output=True)
                if result.returncode == 0:
                    break

            assert attempt_count == 3

    @pytest.mark.integration
    @pytest.mark.network
    def test_network_error_handling(self) -> None:
        """Test network error handling integration."""
        with patch("requests.get") as mock_get:
            mock_get.side_effect = requests.Timeout("Connection timeout")

            with pytest.raises(requests.Timeout):
                requests.get("https://api.github.com/repos/test/test/releases/latest")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
