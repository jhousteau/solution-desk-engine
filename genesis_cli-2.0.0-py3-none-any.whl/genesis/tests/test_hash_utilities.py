"""
Test hash calculation and validation utilities for Phase 2 implementation.

Tests the production utility functions for calculating and comparing file hashes.
"""

import hashlib
import tempfile
from pathlib import Path

from genesis.core.hash_utils import (
    calculate_file_hash,
    extract_hash_value,
    hashes_match,
    validate_hash_format,
)


class TestHashUtilities:
    """Test hash calculation and validation utilities"""

    def test_calculate_file_hash(self) -> None:
        """Test calculating SHA-256 hash of a file"""
        # Create a temporary file with known content
        test_content = b"Hello, Genesis sync system!\nThis is a test file.\n"
        expected_hash = hashlib.sha256(test_content).hexdigest()

        with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
            tmp_file.write(test_content)
            tmp_file.flush()

            # Calculate hash using our utility function
            calculated_hash = calculate_file_hash(Path(tmp_file.name))

            # Clean up
            Path(tmp_file.name).unlink()

        assert calculated_hash == f"sha256:{expected_hash}"

    def test_validate_hash_format(self) -> None:
        """Test validating hash string format"""
        # Valid hashes
        valid_hashes = [
            "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",  # empty string
            "sha256:2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",  # "foo"
            "sha256:fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",  # "bar"
        ]

        for hash_str in valid_hashes:
            assert validate_hash_format(hash_str), f"Valid hash rejected: {hash_str}"

        # Invalid hashes
        invalid_hashes = [
            "md5:5d41402abc4b2a76b9719d911017c592",  # wrong algorithm
            "sha256:invalid_hex_characters",  # invalid hex
            "sha256:abc123",  # too short
            "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855ff",  # too long
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",  # missing prefix
            "",  # empty string
            "sha256:",  # missing hash
        ]

        for hash_str in invalid_hashes:
            assert not validate_hash_format(
                hash_str
            ), f"Invalid hash accepted: {hash_str}"

    def test_hashes_match(self) -> None:
        """Test checking if file hash matches expected value"""
        # Create a temporary file with known content
        test_content = b"Test content for hash matching\n"
        expected_hash = f"sha256:{hashlib.sha256(test_content).hexdigest()}"

        with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
            tmp_file.write(test_content)
            tmp_file.flush()
            tmp_path = Path(tmp_file.name)

            # Test matching hash
            assert hashes_match(tmp_path, expected_hash)

            # Test non-matching hash
            wrong_hash = "sha256:0000000000000000000000000000000000000000000000000000000000000000"
            assert not hashes_match(tmp_path, wrong_hash)

            # Clean up
            tmp_path.unlink()

        # Test non-existent file
        assert not hashes_match(Path("/nonexistent/file.txt"), expected_hash)

    def test_extract_hash_value(self) -> None:
        """Test extracting hex value from hash string"""
        hash_str = (
            "sha256:abc123def4567890123456789012345678901234567890123456789012345678"
        )
        expected_hex = (
            "abc123def4567890123456789012345678901234567890123456789012345678"
        )

        result = extract_hash_value(hash_str)
        assert result == expected_hex
        assert len(result) == 64

        # Test invalid format
        assert extract_hash_value("invalid") is None
        assert extract_hash_value("md5:abc123") is None
