"""Comprehensive integration tests for TemplateManager class.

This test suite consolidates template manager testing from 2 locations into a single
comprehensive file. It validates:
- Dual-mode operation (package vs development)
- Error handling and edge cases
- Performance under load
- Integration with real Genesis templates
- Path validation and explicit path handling

Consolidates:
- tests/test_template_manager.py (53 lines)
- genesis/tests/test_template_manager.py (757 lines)
"""

import tempfile
import time
from collections.abc import Generator
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# Import the module under test
from genesis.core.templates import (
    TemplateManager,
    get_template,
    get_template_bytes,
    get_template_manager,
    list_templates,
    template_exists,
)


class TestTemplateManagerDevelopmentMode:
    """Test TemplateManager in development mode (filesystem access)."""

    @pytest.fixture
    def temp_templates_dir(self) -> Generator[Path]:
        """Create temporary templates directory structure for testing."""
        with tempfile.TemporaryDirectory() as temp_dir:
            templates_path = Path(temp_dir) / "templates"
            templates_path.mkdir()

            # Create shared directory and manifest
            shared_dir = templates_path / "shared"
            shared_dir.mkdir()
            (shared_dir / "manifest.yml").write_text(
                "# Test manifest\nshared_files:\n  - test: example\n"
            )
            (shared_dir / "Dockerfile.template").write_text(
                "FROM ubuntu:22.04\nRUN echo 'Hello {{project_name}}'\n"
            )

            # Create python-api directory with templates
            python_api_dir = templates_path / "python-api"
            python_api_dir.mkdir()
            (python_api_dir / "pyproject.toml.template").write_text(
                "[tool.poetry]\nname = '{{project_name}}'\nversion = '0.1.0'\n"
            )
            (python_api_dir / "README.md.template").write_text(
                "# {{project_name}}\n\nA Python API project.\n"
            )

            # Create subdirectory with nested template
            docs_dir = python_api_dir / "docs"
            docs_dir.mkdir()
            (docs_dir / "GUIDE.md.template").write_text("# Documentation Guide\n")

            # Create binary file for testing
            (shared_dir / "binary_file.bin").write_bytes(b"\x00\x01\x02\x03\xff")

            yield templates_path

    @pytest.fixture
    def dev_mode_manager(
        self, temp_templates_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> Generator[TemplateManager]:
        """Create TemplateManager in development mode with temp directory."""
        # Set development mode
        monkeypatch.setenv("GENESIS_DEV_MODE", "true")

        # Create manager and override templates_path directly
        manager = TemplateManager()
        manager.templates_path = temp_templates_dir
        yield manager

    def test_dev_mode_initialization(
        self, temp_templates_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test TemplateManager initialization in development mode."""
        monkeypatch.setenv("GENESIS_DEV_MODE", "true")

        # Mock Path to return our temp directory
        with patch("genesis.core.templates.Path") as mock_path:
            mock_path.return_value.parent.parent.parent = temp_templates_dir.parent
            mock_path.return_value.__truediv__ = lambda self, other: temp_templates_dir

            manager = TemplateManager()
            assert manager.dev_mode is True
            assert manager.templates_path == temp_templates_dir

    def test_dev_mode_missing_templates_directory(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test error handling when templates directory doesn't exist in dev mode."""
        monkeypatch.setenv("GENESIS_DEV_MODE", "true")

        with patch("genesis.core.templates.Path") as mock_path:
            # Mock non-existent templates directory
            mock_templates_path = MagicMock()
            mock_templates_path.exists.return_value = False
            mock_path.return_value.parent.parent.parent.__truediv__.return_value = (
                mock_templates_path
            )

            with pytest.raises(
                RuntimeError,
                match="Development mode enabled but templates directory not found",
            ):
                TemplateManager()

    def test_get_template_success(self, dev_mode_manager: TemplateManager) -> None:
        """Test successful template retrieval in development mode."""
        content = dev_mode_manager.get_template("shared/manifest.yml")
        assert "# Test manifest" in content
        assert "shared_files:" in content

    def test_get_template_nested_path(self, dev_mode_manager: TemplateManager) -> None:
        """Test template retrieval from nested directory."""
        content = dev_mode_manager.get_template("python-api/docs/GUIDE.md.template")
        assert "# Documentation Guide" in content

    def test_get_template_not_found(self, dev_mode_manager: TemplateManager) -> None:
        """Test FileNotFoundError for non-existent template."""
        with pytest.raises(
            FileNotFoundError, match="Template not found: nonexistent.txt"
        ):
            dev_mode_manager.get_template("nonexistent.txt")

    def test_get_template_directory_not_file(
        self, dev_mode_manager: TemplateManager
    ) -> None:
        """Test error when trying to read a directory as a template."""
        with pytest.raises(
            FileNotFoundError, match="Template path is not a file: shared"
        ):
            dev_mode_manager.get_template("shared")

    def test_get_template_bytes_success(
        self, dev_mode_manager: TemplateManager
    ) -> None:
        """Test successful binary template retrieval."""
        content = dev_mode_manager.get_template_bytes("shared/binary_file.bin")
        assert content == b"\x00\x01\x02\x03\xff"

    def test_get_template_bytes_text_file(
        self, dev_mode_manager: TemplateManager
    ) -> None:
        """Test get_template_bytes works with text files too."""
        content = dev_mode_manager.get_template_bytes("shared/manifest.yml")
        text_content = content.decode("utf-8")
        assert "# Test manifest" in text_content

    def test_list_templates_root(self, dev_mode_manager: TemplateManager) -> None:
        """Test listing all templates from root."""
        templates = dev_mode_manager.list_templates()

        # Should include all files across all directories
        expected_files = [
            "python-api/README.md.template",
            "python-api/docs/GUIDE.md.template",
            "python-api/pyproject.toml.template",
            "shared/Dockerfile.template",
            "shared/binary_file.bin",
            "shared/manifest.yml",
        ]

        for expected in expected_files:
            assert expected in templates

        # Should be sorted
        assert templates == sorted(templates)

    def test_list_templates_specific_directory(
        self, dev_mode_manager: TemplateManager
    ) -> None:
        """Test listing templates in specific directory."""
        templates = dev_mode_manager.list_templates("shared")

        expected_files = [
            "shared/Dockerfile.template",
            "shared/binary_file.bin",
            "shared/manifest.yml",
        ]

        for expected in expected_files:
            assert expected in templates

    def test_list_templates_directory_not_found(
        self, dev_mode_manager: TemplateManager
    ) -> None:
        """Test error for non-existent directory."""
        with pytest.raises(
            FileNotFoundError, match="Template directory not found: nonexistent"
        ):
            dev_mode_manager.list_templates("nonexistent")

    def test_template_exists_true(self, dev_mode_manager: TemplateManager) -> None:
        """Test template_exists returns True for existing templates."""
        assert dev_mode_manager.template_exists("shared/manifest.yml") is True
        assert (
            dev_mode_manager.template_exists("python-api/pyproject.toml.template")
            is True
        )

    def test_template_exists_false(self, dev_mode_manager: TemplateManager) -> None:
        """Test template_exists returns False for non-existent templates."""
        assert dev_mode_manager.template_exists("nonexistent.txt") is False
        assert dev_mode_manager.template_exists("shared/nonexistent.yml") is False

    def test_template_exists_directory(self, dev_mode_manager: TemplateManager) -> None:
        """Test template_exists returns False for directories."""
        assert dev_mode_manager.template_exists("shared") is False


class TestTemplateManagerPackageMode:
    """Test TemplateManager in package mode (importlib.resources)."""

    @pytest.fixture
    def package_mode_manager(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> Generator[TemplateManager]:
        """Create TemplateManager in package mode."""
        monkeypatch.setenv("GENESIS_DEV_MODE", "false")
        manager = TemplateManager()
        assert manager.dev_mode is False
        assert manager.templates_path is None
        yield manager

    @pytest.fixture
    def mock_importlib_resources(self) -> Generator[dict]:
        """Mock importlib.resources for package mode testing."""
        with patch("genesis.core.templates.files") as mock_files:
            # Create mock resource structure
            mock_templates_pkg = MagicMock()
            mock_files.return_value = mock_templates_pkg

            # Mock shared directory and files
            mock_shared = MagicMock()
            mock_shared.name = "shared"
            mock_shared.is_file.return_value = False
            mock_shared.is_dir.return_value = True

            mock_manifest = MagicMock()
            mock_manifest.name = "manifest.yml"
            mock_manifest.is_file.return_value = True
            mock_manifest.read_text.return_value = (
                "# Mock manifest\nshared_files:\n  - test: example\n"
            )
            mock_manifest.read_bytes.return_value = (
                b"# Mock manifest\nshared_files:\n  - test: example\n"
            )

            mock_dockerfile = MagicMock()
            mock_dockerfile.name = "Dockerfile.template"
            mock_dockerfile.is_file.return_value = True
            mock_dockerfile.read_text.return_value = (
                "FROM ubuntu:22.04\nRUN echo 'Hello {{project_name}}'\n"
            )

            # Mock python-api directory
            mock_python_api = MagicMock()
            mock_python_api.name = "python-api"
            mock_python_api.is_file.return_value = False
            mock_python_api.is_dir.return_value = True

            mock_pyproject = MagicMock()
            mock_pyproject.name = "pyproject.toml.template"
            mock_pyproject.is_file.return_value = True
            mock_pyproject.read_text.return_value = (
                "[tool.poetry]\nname = '{{project_name}}'\n"
            )

            # Set up directory structure
            mock_shared.iterdir.return_value = [mock_manifest, mock_dockerfile]
            mock_python_api.iterdir.return_value = [mock_pyproject]
            mock_templates_pkg.iterdir.return_value = [mock_shared, mock_python_api]

            # Create templates root mock
            mock_templates_root = MagicMock()
            mock_templates_root.iterdir.return_value = [mock_shared, mock_python_api]

            # Set up path navigation
            mock_templates_pkg.__truediv__ = lambda self, name: {
                "templates": mock_templates_root,
            }.get(name, mock_templates_root)

            mock_templates_root.__truediv__ = lambda self, name: {
                "shared": mock_shared,
                "python-api": mock_python_api,
            }[name]

            mock_shared.__truediv__ = lambda self, name: {
                "manifest.yml": mock_manifest,
                "Dockerfile.template": mock_dockerfile,
            }[name]

            mock_python_api.__truediv__ = lambda self, name: {
                "pyproject.toml.template": mock_pyproject,
            }[name]

            yield {
                "mock_files": mock_files,
                "mock_templates_pkg": mock_templates_pkg,
                "mock_templates_root": mock_templates_root,
                "mock_shared": mock_shared,
                "mock_manifest": mock_manifest,
                "mock_dockerfile": mock_dockerfile,
                "mock_python_api": mock_python_api,
                "mock_pyproject": mock_pyproject,
            }

    def test_package_mode_initialization(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test TemplateManager initialization in package mode."""
        monkeypatch.setenv("GENESIS_DEV_MODE", "false")
        manager = TemplateManager()
        assert manager.dev_mode is False
        assert manager.templates_path is None

    def test_get_template_success(
        self, package_mode_manager: TemplateManager, mock_importlib_resources: dict
    ) -> None:
        """Test successful template retrieval in package mode."""
        with patch(
            "genesis.core.templates.files", mock_importlib_resources["mock_files"]
        ):
            content = package_mode_manager.get_template("shared/manifest.yml")
            assert "# Mock manifest" in content

    def test_get_template_not_found(
        self, package_mode_manager: TemplateManager
    ) -> None:
        """Test FileNotFoundError for non-existent template in package mode."""
        with patch("genesis.core.templates.files") as mock_files:
            mock_files.return_value.__truediv__.side_effect = FileNotFoundError(
                "Not found"
            )

            with pytest.raises(
                FileNotFoundError,
                match="Template not found in package: nonexistent.txt",
            ):
                package_mode_manager.get_template("nonexistent.txt")

    def test_get_template_bytes_success(
        self, package_mode_manager: TemplateManager, mock_importlib_resources: dict
    ) -> None:
        """Test successful binary template retrieval in package mode."""
        with patch(
            "genesis.core.templates.files", mock_importlib_resources["mock_files"]
        ):
            content = package_mode_manager.get_template_bytes("shared/manifest.yml")
            assert content == b"# Mock manifest\nshared_files:\n  - test: example\n"

    def test_list_templates_root(
        self, package_mode_manager: TemplateManager, mock_importlib_resources: dict
    ) -> None:
        """Test listing all templates from root in package mode."""
        with patch(
            "genesis.core.templates.files", mock_importlib_resources["mock_files"]
        ):
            templates = package_mode_manager.list_templates()

            expected = [
                "python-api/pyproject.toml.template",
                "shared/Dockerfile.template",
                "shared/manifest.yml",
            ]

            for expected_file in expected:
                assert expected_file in templates

    def test_list_templates_specific_directory(
        self, package_mode_manager: TemplateManager, mock_importlib_resources: dict
    ) -> None:
        """Test listing templates in specific directory in package mode."""
        with patch(
            "genesis.core.templates.files", mock_importlib_resources["mock_files"]
        ):
            templates = package_mode_manager.list_templates("shared")

            expected = ["shared/Dockerfile.template", "shared/manifest.yml"]
            for expected_file in expected:
                assert expected_file in templates

    def test_template_exists_true(
        self, package_mode_manager: TemplateManager, mock_importlib_resources: dict
    ) -> None:
        """Test template_exists returns True for existing templates in package mode."""
        with patch(
            "genesis.core.templates.files", mock_importlib_resources["mock_files"]
        ):
            assert package_mode_manager.template_exists("shared/manifest.yml") is True

    def test_template_exists_false(self, package_mode_manager: TemplateManager) -> None:
        """Test template_exists returns False for non-existent templates in package mode."""
        with patch("genesis.core.templates.files") as mock_files:
            mock_files.return_value.__truediv__.side_effect = FileNotFoundError(
                "Not found"
            )
            assert package_mode_manager.template_exists("nonexistent.txt") is False


class TestTemplateManagerValidation:
    """Test path validation and security features."""

    @pytest.fixture
    def manager(self, monkeypatch: pytest.MonkeyPatch) -> TemplateManager:
        """Create a basic TemplateManager for validation testing."""
        monkeypatch.setenv("GENESIS_DEV_MODE", "false")
        return TemplateManager()

    def test_validate_path_normal(self, manager: TemplateManager) -> None:
        """Test validation of normal paths."""
        assert manager._validate_path("shared/manifest.yml") == "shared/manifest.yml"
        assert (
            manager._validate_path("python-api/pyproject.toml.template")
            == "python-api/pyproject.toml.template"
        )
        assert manager._validate_path("nested/dir/file.txt") == "nested/dir/file.txt"

    def test_validate_path_leading_slash(self, manager: TemplateManager) -> None:
        """Test validation removes leading slash."""
        assert manager._validate_path("/shared/manifest.yml") == "shared/manifest.yml"
        assert (
            manager._validate_path("/python-api/template.txt")
            == "python-api/template.txt"
        )

    def test_validate_path_directory_traversal(self, manager: TemplateManager) -> None:
        """Test validation blocks directory traversal attempts."""
        dangerous_paths = [
            "../../../etc/passwd",
            "shared/../../../etc/passwd",
            "dir/../../../sensitive.txt",
            "normal/../../etc/passwd",
        ]

        for path in dangerous_paths:
            with pytest.raises(ValueError, match="directory traversal not allowed"):
                manager._validate_path(path)

    def test_template_exists_invalid_path(self, manager: TemplateManager) -> None:
        """Test template_exists returns False for invalid paths."""
        assert manager.template_exists("../../../etc/passwd") is False

    def test_get_template_invalid_path(self, manager: TemplateManager) -> None:
        """Test get_template raises ValueError for invalid paths."""
        with pytest.raises(ValueError, match="directory traversal not allowed"):
            manager.get_template("../../../etc/passwd")

    def test_get_template_bytes_invalid_path(self, manager: TemplateManager) -> None:
        """Test get_template_bytes raises ValueError for invalid paths."""
        with pytest.raises(ValueError, match="directory traversal not allowed"):
            manager.get_template_bytes("../../../etc/passwd")

    def test_list_templates_invalid_path(self, manager: TemplateManager) -> None:
        """Test list_templates raises ValueError for invalid paths."""
        with pytest.raises(ValueError, match="directory traversal not allowed"):
            manager.list_templates("../../../etc")


class TestTemplateManagerConvenienceFunctions:
    """Test module-level convenience functions."""

    def test_get_template_manager_singleton(self) -> None:
        """Test that get_template_manager returns singleton instance."""
        manager1 = get_template_manager()
        manager2 = get_template_manager()
        assert manager1 is manager2

    @patch("genesis.core.templates.get_template_manager")
    def test_get_template_function(self, mock_get_manager: MagicMock) -> None:
        """Test get_template convenience function."""
        mock_manager = MagicMock()
        mock_manager.get_template.return_value = "template content"
        mock_get_manager.return_value = mock_manager

        result = get_template("test.template")

        mock_manager.get_template.assert_called_once_with("test.template")
        assert result == "template content"

    @patch("genesis.core.templates.get_template_manager")
    def test_get_template_bytes_function(self, mock_get_manager: MagicMock) -> None:
        """Test get_template_bytes convenience function."""
        mock_manager = MagicMock()
        mock_manager.get_template_bytes.return_value = b"binary content"
        mock_get_manager.return_value = mock_manager

        result = get_template_bytes("test.bin")

        mock_manager.get_template_bytes.assert_called_once_with("test.bin")
        assert result == b"binary content"

    @patch("genesis.core.templates.get_template_manager")
    def test_list_templates_function(self, mock_get_manager: MagicMock) -> None:
        """Test list_templates convenience function."""
        mock_manager = MagicMock()
        mock_manager.list_templates.return_value = ["file1.txt", "file2.txt"]
        mock_get_manager.return_value = mock_manager

        result = list_templates("shared")

        mock_manager.list_templates.assert_called_once_with("shared")
        assert result == ["file1.txt", "file2.txt"]

    @patch("genesis.core.templates.get_template_manager")
    def test_template_exists_function(self, mock_get_manager: MagicMock) -> None:
        """Test template_exists convenience function."""
        mock_manager = MagicMock()
        mock_manager.template_exists.return_value = True
        mock_get_manager.return_value = mock_manager

        result = template_exists("test.template")

        mock_manager.template_exists.assert_called_once_with("test.template")
        assert result is True


class TestTemplateManagerPerformance:
    """Test performance requirements for TemplateManager."""

    @pytest.fixture
    def performance_manager(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> Generator[TemplateManager]:
        """Create TemplateManager for performance testing."""
        monkeypatch.setenv("GENESIS_DEV_MODE", "false")
        manager = TemplateManager()

        # Mock fast template access
        with patch("genesis.core.templates.files") as mock_files:
            mock_resource = MagicMock()
            mock_resource.read_text.return_value = "Fast template content"
            mock_resource.read_bytes.return_value = b"Fast binary content"
            mock_resource.is_file.return_value = True

            mock_files.return_value.__truediv__.return_value = mock_resource
            yield manager

    def test_get_template_performance(
        self, performance_manager: TemplateManager
    ) -> None:
        """Test that template access is under 100ms."""
        with patch("genesis.core.templates.files") as mock_files:
            # Create a chain of mock objects to simulate importlib.resources behavior
            mock_final_resource = MagicMock()
            mock_final_resource.read_text.return_value = "Fast template content"

            mock_shared = MagicMock()
            mock_shared.__truediv__.return_value = mock_final_resource

            mock_templates = MagicMock()
            mock_templates.__truediv__.return_value = mock_shared

            mock_templates_pkg = MagicMock()
            mock_templates_pkg.__truediv__.return_value = mock_templates

            mock_files.return_value = mock_templates_pkg

            start_time = time.time()
            content = performance_manager.get_template("shared/test.template")
            end_time = time.time()

            assert content == "Fast template content"
            assert (end_time - start_time) < 0.1  # Less than 100ms

    def test_get_template_bytes_performance(
        self, performance_manager: TemplateManager
    ) -> None:
        """Test that binary template access is under 100ms."""
        with patch("genesis.core.templates.files") as mock_files:
            # Create a chain of mock objects to simulate importlib.resources behavior
            mock_final_resource = MagicMock()
            mock_final_resource.read_bytes.return_value = b"Fast binary content"

            mock_shared = MagicMock()
            mock_shared.__truediv__.return_value = mock_final_resource

            mock_templates = MagicMock()
            mock_templates.__truediv__.return_value = mock_shared

            mock_templates_pkg = MagicMock()
            mock_templates_pkg.__truediv__.return_value = mock_templates

            mock_files.return_value = mock_templates_pkg

            start_time = time.time()
            content = performance_manager.get_template_bytes("shared/test.bin")
            end_time = time.time()

            assert content == b"Fast binary content"
            assert (end_time - start_time) < 0.1  # Less than 100ms

    def test_template_exists_performance(
        self, performance_manager: TemplateManager
    ) -> None:
        """Test that template existence check is under 100ms."""
        with patch("genesis.core.templates.files") as mock_files:
            # Create a chain of mock objects to simulate importlib.resources behavior
            mock_final_resource = MagicMock()
            mock_final_resource.is_file.return_value = True

            mock_shared = MagicMock()
            mock_shared.__truediv__.return_value = mock_final_resource

            mock_templates = MagicMock()
            mock_templates.__truediv__.return_value = mock_shared

            mock_templates_pkg = MagicMock()
            mock_templates_pkg.__truediv__.return_value = mock_templates

            mock_files.return_value = mock_templates_pkg

            start_time = time.time()
            exists = performance_manager.template_exists("shared/test.template")
            end_time = time.time()

            assert exists is True
            assert (end_time - start_time) < 0.1  # Less than 100ms


class TestTemplateManagerIntegration:
    """Integration tests with actual Genesis templates."""

    @pytest.fixture
    def real_dev_manager(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> Generator[TemplateManager]:
        """Create TemplateManager that uses real Genesis templates."""
        monkeypatch.setenv("GENESIS_DEV_MODE", "true")

        # Check if we're in the Genesis repository
        genesis_root = Path(__file__).parent.parent.parent
        templates_path = genesis_root / "templates"

        if not templates_path.exists():
            pytest.skip("Real Genesis templates not available")

        manager = TemplateManager()
        yield manager

    @pytest.mark.integration
    def test_real_shared_manifest_exists(
        self, real_dev_manager: TemplateManager
    ) -> None:
        """Test that real shared manifest.yml exists and is readable."""
        assert real_dev_manager.template_exists("shared/manifest.yml")

        content = real_dev_manager.get_template("shared/manifest.yml")
        assert "shared_files:" in content
        assert "template_variables:" in content

    @pytest.mark.integration
    def test_real_dockerfile_template_exists(
        self, real_dev_manager: TemplateManager
    ) -> None:
        """Test that real Dockerfile.template exists."""
        assert real_dev_manager.template_exists("shared/Dockerfile.template")

        content = real_dev_manager.get_template("shared/Dockerfile.template")
        assert "FROM" in content

    @pytest.mark.integration
    def test_real_python_api_templates_exist(
        self, real_dev_manager: TemplateManager
    ) -> None:
        """Test that Python API templates exist."""
        expected_templates = [
            "python-api/pyproject.toml.template",
            "python-api/README.md.template",
            "python-api/template.json",
        ]

        for template in expected_templates:
            assert real_dev_manager.template_exists(
                template
            ), f"Template {template} should exist"

    @pytest.mark.integration
    def test_real_list_templates_comprehensive(
        self, real_dev_manager: TemplateManager
    ) -> None:
        """Test listing all real templates returns expected structure."""
        all_templates = real_dev_manager.list_templates()

        # Should have templates from multiple directories
        shared_templates = [t for t in all_templates if t.startswith("shared/")]
        python_api_templates = [t for t in all_templates if t.startswith("python-api/")]
        cli_tool_templates = [t for t in all_templates if t.startswith("cli-tool/")]

        assert len(shared_templates) > 0, "Should have shared templates"
        assert len(python_api_templates) > 0, "Should have python-api templates"
        assert len(cli_tool_templates) > 0, "Should have cli-tool templates"

    @pytest.mark.integration
    def test_real_template_content_not_corrupted(
        self, real_dev_manager: TemplateManager
    ) -> None:
        """Test that real templates can be read without corruption."""
        # Test text template
        manifest_content = real_dev_manager.get_template("shared/manifest.yml")
        manifest_bytes = real_dev_manager.get_template_bytes("shared/manifest.yml")

        # Text and bytes should decode to same content
        assert manifest_content == manifest_bytes.decode("utf-8")

        # Should be valid YAML structure
        assert manifest_content.strip().startswith("# Genesis")
        assert "shared_files:" in manifest_content


class TestTemplateManagerEdgeCases:
    """Test edge cases and error conditions."""

    def test_unicode_handling_dev_mode(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test handling of Unicode content in development mode."""
        monkeypatch.setenv("GENESIS_DEV_MODE", "true")

        # Create template with Unicode content
        unicode_file = tmp_path / "unicode.template"
        unicode_content = "Hello 世界! 🚀 Testing Unicode: café, naïve, résumé"
        unicode_file.write_text(unicode_content, encoding="utf-8")

        manager = TemplateManager()
        manager.templates_path = tmp_path
        content = manager.get_template("unicode.template")
        assert content == unicode_content

    def test_binary_file_as_text_error(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test error when trying to read binary file as text."""
        monkeypatch.setenv("GENESIS_DEV_MODE", "true")

        # Create binary file
        binary_file = tmp_path / "binary.bin"
        binary_file.write_bytes(b"\x00\x01\x02\x03\xff\xfe\xfd")

        manager = TemplateManager()
        manager.templates_path = tmp_path

        # Should raise ValueError with helpful message
        with pytest.raises(
            ValueError, match="not a valid text file.*Use get_template_bytes"
        ):
            manager.get_template("binary.bin")

    def test_empty_file_handling(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test handling of empty template files."""
        monkeypatch.setenv("GENESIS_DEV_MODE", "true")

        # Create empty file
        empty_file = tmp_path / "empty.template"
        empty_file.write_text("")

        manager = TemplateManager()
        manager.templates_path = tmp_path

        # Should return empty string, not error
        content = manager.get_template("empty.template")
        assert content == ""

        # Bytes should also work
        content_bytes = manager.get_template_bytes("empty.template")
        assert content_bytes == b""

    def test_very_long_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test handling of very long template paths."""
        monkeypatch.setenv("GENESIS_DEV_MODE", "false")
        manager = TemplateManager()

        # Create very long but valid path (with leading slash)
        long_path = "/" + "/".join([f"dir{i}" for i in range(10)]) + "/file.template"

        # Should not raise validation error
        normalized = manager._validate_path(long_path)
        assert normalized == long_path[1:]  # Leading slash removed

    def test_special_characters_in_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test handling of special characters in template paths."""
        monkeypatch.setenv("GENESIS_DEV_MODE", "false")
        manager = TemplateManager()

        # Test various special characters that should be allowed
        valid_paths = [
            "dir_with_underscores/file.template",
            "dir-with-hyphens/file.template",
            "dir.with.dots/file.template",
            "dir with spaces/file.template",
            "dir@special/file.template",
        ]

        for path in valid_paths:
            # Should not raise validation error
            normalized = manager._validate_path(path)
            assert normalized == path


class TestTemplateManagerExplicitPath:
    """Test TemplateManager with explicit template paths (consolidated from tests/)."""

    def test_template_manager_with_explicit_path(self) -> None:
        """Test creating TemplateManager with explicit templates_path."""
        with tempfile.TemporaryDirectory() as temp_dir:
            test_dir = Path(temp_dir)

            # Create a subdirectory and template
            api_dir = test_dir / "python-api"
            api_dir.mkdir()

            template_file = api_dir / "test.template"
            template_file.write_text("Hello {{project_name}}!")

            # Test explicit path creation
            manager = TemplateManager(templates_path=test_dir)

            # Verify manager properties
            assert manager.templates_path == test_dir
            assert hasattr(manager, "dev_mode")

            # Test template loading
            content = manager.get_template("python-api/test.template")
            assert content == "Hello {{project_name}}!"

    def test_path_validation_returns_string(self) -> None:
        """Test that _validate_path returns proper string, not MagicMock."""
        with tempfile.TemporaryDirectory() as temp_dir:
            test_dir = Path(temp_dir)

            # Create test structure
            api_dir = test_dir / "python-api"
            api_dir.mkdir()
            template_file = api_dir / "test.template"
            template_file.write_text("test content")

            manager = TemplateManager(templates_path=test_dir)

            # Test path validation
            validated = manager._validate_path("python-api/test.template")

            # Ensure it's a proper string, not a mock object
            assert isinstance(validated, str)
            assert validated == "python-api/test.template"


# Pytest configuration and markers
pytestmark = [
    pytest.mark.integration,  # Mark all tests as integration tests
]
