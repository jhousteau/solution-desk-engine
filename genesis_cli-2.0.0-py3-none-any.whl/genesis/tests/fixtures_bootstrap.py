"""
Bootstrap test fixtures - Extracted from consolidated bootstrap sync tests.

This module contains common fixtures and template creation utilities
used across bootstrap test modules. Centralizing these reduces duplication
and makes maintenance easier.
"""

import os
import shutil
import tempfile
from collections.abc import Iterator
from pathlib import Path

import pytest
import yaml


@pytest.fixture
def temp_workspace() -> Iterator[Path]:
    """Create a temporary workspace for tests."""
    temp_dir = tempfile.mkdtemp()
    yield Path(temp_dir)
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)


@pytest.fixture
def genesis_root(temp_workspace: Path) -> Path:
    """Create mock Genesis root directory structure."""
    genesis_root = temp_workspace / "genesis"
    genesis_root.mkdir()
    return genesis_root


@pytest.fixture
def complete_genesis_templates(genesis_root: Path) -> Path:
    """Create comprehensive mock Genesis templates for all project types."""
    templates_dir = genesis_root / "templates"
    project_types = [
        "shared",
        "python-api",
        "cli-tool",
        "typescript-service",
        "terraform-project",
    ]

    for project_type in project_types:
        project_dir = templates_dir / project_type
        project_dir.mkdir(parents=True)

    # Create shared manifest with comprehensive file list
    create_shared_manifest(templates_dir / "shared")
    create_shared_templates(templates_dir / "shared")

    # Create project-specific templates
    create_python_api_templates(templates_dir / "python-api")
    create_cli_tool_templates(templates_dir / "cli-tool")
    create_typescript_templates(templates_dir / "typescript-service")
    create_terraform_templates(templates_dir / "terraform-project")

    return genesis_root


def create_shared_manifest(shared_dir: Path) -> None:
    """Create comprehensive shared manifest."""
    manifest_content = {
        "shared_files": [
            {
                "source": "Dockerfile.template",
                "dest": "Dockerfile",
                "sync": "always",
                "description": "Development container configuration",
            },
            {
                "source": "CLAUDE.md.template",
                "dest": "CLAUDE.md",
                "sync": "never",
                "description": "AI assistant instructions",
            },
            {
                "source": ".genesis/scripts/setup/setup.sh.template",
                "dest": ".genesis/scripts/setup/setup.sh",
                "sync": "if_unchanged",
                "executable": True,
                "description": "Project setup script",
            },
            {
                "source": ".gitignore.template",
                "dest": ".gitignore",
                "sync": "if_unchanged",
                "description": "Git ignore patterns",
            },
            {
                "source": "Makefile.template",
                "dest": "Makefile",
                "sync": "if_unchanged",
                "description": "Build automation",
            },
            {
                "source": ".pre-commit-config.yaml.template",
                "dest": ".pre-commit-config.yaml",
                "sync": "if_unchanged",
                "description": "Pre-commit hooks configuration",
            },
        ],
        "claude_hooks": [
            {
                "source": ".claude/hooks/validate-bash-command.sh.template",
                "dest": ".claude/hooks/validate-bash-command.sh",
                "sync": "always",
                "executable": True,
            }
        ],
        "claude_commands": [
            {
                "source": ".claude/settings.json.template",
                "dest": ".claude/settings.json",
                "sync": "if_unchanged",
            }
        ],
    }

    manifest_path = shared_dir / "manifest.yml"
    with open(manifest_path, "w") as f:
        yaml.dump(manifest_content, f)


def create_shared_templates(shared_dir: Path) -> None:
    """Create shared template files."""
    (shared_dir / "Dockerfile.template").write_text(
        "FROM python:{{python_version}}\nWORKDIR /app\nCOPY . .\nEXPOSE {{app_port}}\n"
    )
    (shared_dir / "CLAUDE.md.template").write_text(
        "# {{project_name}}\n\nAI instructions for {{project_name}} project.\nProject type: {{project_type}}\n"
    )

    genesis_scripts_dir = shared_dir / ".genesis" / "scripts" / "setup"
    genesis_scripts_dir.mkdir(parents=True, exist_ok=True)
    (genesis_scripts_dir / "setup.sh.template").write_text(
        "#!/bin/bash\necho 'Setting up {{project_name}}'\n"
    )

    (shared_dir / ".gitignore.template").write_text(
        "*.pyc\n__pycache__/\n.env\n.DS_Store\n"
    )
    (shared_dir / "Makefile.template").write_text(
        ".PHONY: help\nhelp:\n\t@echo 'Available commands for {{project_name}}'\n"
    )
    (shared_dir / ".pre-commit-config.yaml.template").write_text(
        "repos:\n  - repo: https://github.com/pre-commit/pre-commit-hooks\n    rev: v4.4.0\n"
    )

    claude_hooks_dir = shared_dir / ".claude" / "hooks"
    claude_hooks_dir.mkdir(parents=True, exist_ok=True)
    (claude_hooks_dir / "validate-bash-command.sh.template").write_text(
        "#!/bin/bash\necho 'Validating bash commands for {{project_name}}'\n"
    )

    claude_dir = shared_dir / ".claude"
    (claude_dir / "settings.json.template").write_text(
        '{\n  "project_name": "{{project_name}}",\n  "ai_safety": true\n}\n'
    )


def create_python_api_templates(template_dir: Path) -> None:
    """Create Python API templates."""
    # README template
    (template_dir / "README.md.template").write_text(
        "# {{project_name}}\n\n{{project_description}}\n\n## Installation\n\n```bash\npip install {{project_name}}\n```\n"
    )

    # pyproject.toml template
    (template_dir / "pyproject.toml.template").write_text(
        """[tool.poetry]
name = "{{project_name}}"
version = "0.1.0"
description = "{{project_description}}"
authors = ["{{author_name}} <{{author_email}}>"]

[tool.poetry.dependencies]
python = "^{{python_version}}"
fastapi = "^0.104.1"
uvicorn = "^0.24.0"

[tool.poetry.group.dev.dependencies]
pytest = "^7.4.3"
pytest-asyncio = "^0.21.1"
httpx = "^0.25.1"

[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
"""
    )

    # Source structure
    src_dir = template_dir / "src" / "__module_name__"
    src_dir.mkdir(parents=True)

    (src_dir / "__init__.py.template").write_text(
        '"""{{project_name}} API package."""\n\n__version__ = "0.1.0"\n'
    )

    (src_dir / "main.py.template").write_text(
        """from fastapi import FastAPI

app = FastAPI(title="{{project_name}}", version="0.1.0")

@app.get("/")
async def root() -> dict[str, str]:
    return {"message": "Hello from {{project_name}}"}

@app.get("/health")
async def health_check() -> dict[str, str]:
    return {"status": "healthy"}
"""
    )

    # Test structure
    tests_dir = template_dir / "tests"
    tests_dir.mkdir()
    (tests_dir / "__init__.py.template").write_text("")
    (tests_dir / "test_main.py.template").write_text(
        """import pytest
from fastapi.testclient import TestClient
from {{module_name}}.main import app

client = TestClient(app)

def test_read_root() -> None:
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "Hello from {{project_name}}"}

def test_health_check() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy"}
"""
    )


def create_cli_tool_templates(template_dir: Path) -> None:
    """Create CLI tool templates."""
    # README template
    (template_dir / "README.md.template").write_text(
        "# {{project_name}}\n\n{{project_description}}\n\n## Usage\n\n```bash\n{{command_name}} --help\n```\n"
    )

    # pyproject.toml template
    (template_dir / "pyproject.toml.template").write_text(
        """[tool.poetry]
name = "{{project_name}}"
version = "0.1.0"
description = "{{project_description}}"
authors = ["{{author_name}} <{{author_email}}>"]

[tool.poetry.dependencies]
python = "^{{python_version}}"
click = "^8.1.7"

[tool.poetry.group.dev.dependencies]
pytest = "^7.4.3"

[tool.poetry.scripts]
{{command_name}} = "{{module_name}}.cli:main"

[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
"""
    )

    # Source structure
    pkg_dir = template_dir / "__module_name__"
    pkg_dir.mkdir(parents=True)

    (pkg_dir / "__init__.py.template").write_text(
        '"""{{project_name}} CLI package."""\n\n__version__ = "0.1.0"\n'
    )

    (pkg_dir / "cli.py.template").write_text(
        """#!/usr/bin/env python3
import click

@click.command()
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose output')
def main(verbose: bool) -> None:
    \"\"\"{{project_name}} command line interface.\"\"\"
    if verbose:
        click.echo('Verbose mode enabled')
    click.echo('Hello from {{project_name}}!')

if __name__ == '__main__':
    main()
"""
    )

    # Test structure
    tests_dir = template_dir / "tests"
    tests_dir.mkdir()
    (tests_dir / "__init__.py.template").write_text("")
    (tests_dir / "test_cli.py.template").write_text(
        """import pytest
from click.testing import CliRunner
from {{module_name}}.cli import main

def test_cli_help() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ['--help'])
    assert result.exit_code == 0
    assert '{{project_name}}' in result.output

def test_cli_basic() -> None:
    runner = CliRunner()
    result = runner.invoke(main)
    assert result.exit_code == 0
    assert 'Hello from {{project_name}}' in result.output

def test_cli_verbose() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ['--verbose'])
    assert result.exit_code == 0
    assert 'Verbose mode enabled' in result.output
"""
    )


def create_typescript_templates(template_dir: Path) -> None:
    """Create TypeScript service templates."""
    (template_dir / "README.md.template").write_text(
        "# {{project_name}}\n\nTypeScript Service\n\n## Installation\n\n```bash\nnpm install\n```\n"
    )

    (template_dir / "package.json.template").write_text(
        """{
  "name": "{{project_name}}",
  "version": "0.1.0",
  "description": "{{project_description}}",
  "main": "dist/index.js",
  "scripts": {
    "build": "tsc",
    "start": "node dist/index.js",
    "dev": "ts-node src/index.ts",
    "test": "jest"
  },
  "dependencies": {
    "express": "^4.18.2"
  },
  "devDependencies": {
    "@types/node": "^20.8.0",
    "@types/express": "^4.17.18",
    "typescript": "^5.2.2",
    "ts-node": "^10.9.1",
    "jest": "^29.7.0"
  }
}"""
    )

    (template_dir / "tsconfig.json.template").write_text(
        """{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true
  }
}"""
    )

    src_dir = template_dir / "src"
    src_dir.mkdir()
    (src_dir / "index.ts.template").write_text(
        "import express from 'express';\n\nconst app = express();\nconst port = 3000;\n\napp.get('/', (req, res) => {\n  res.json({ message: 'Hello from {{project_name}}' });\n});\n\napp.listen(port, () => {\n  console.log(`{{project_name}} running on port ${port}`);\n});\n"
    )


def create_terraform_templates(template_dir: Path) -> None:
    """Create Terraform templates."""
    (template_dir / "README.md.template").write_text(
        "# {{project_name}}\n\nTerraform Infrastructure\n\n## Usage\n\n```bash\nterraform init\nterraform plan\nterraform apply\n```\n"
    )

    (template_dir / "main.tf.template").write_text(
        """terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

resource "aws_s3_bucket" "{{project_name_underscore}}_bucket" {
  bucket = "{{project_name}}-${random_string.bucket_suffix.result}"
}

resource "random_string" "bucket_suffix" {
  length  = 8
  special = false
  upper   = false
}
"""
    )

    (template_dir / "variables.tf.template").write_text(
        """variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-west-2"
}

variable "environment" {
  description = "Environment name"
  type        = string
  default     = "dev"
}
"""
    )

    (template_dir / "outputs.tf.template").write_text(
        """output "bucket_name" {
  description = "Name of the S3 bucket"
  value       = aws_s3_bucket.{{project_name_underscore}}_bucket.bucket
}
"""
    )
