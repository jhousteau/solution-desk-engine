"""Regression test for sync --force not forcing files with 'never' policy.

Bug Details:
- Problem: `genesis sync --force` does not sync files with policy="never"
- Root cause: Line 454 in sync.py: `if self.force and policy != "never"`
- Expected behavior: --force should override ALL policies, including "never"
- Current behavior: Files with "never" policy are still skipped in force mode

This test demonstrates that --force mode incorrectly respects "never" policy,
when it should override all sync policies.
"""

import tempfile
from collections.abc import Generator
from pathlib import Path
from unittest.mock import MagicMock

import pytest
import yaml

from genesis.commands.sync import SyncManager

try:
    from genesis.core import get_logger

    logger = get_logger(__name__)
except ImportError:
    import logging

    logger = logging.getLogger(__name__)


class TestBugSyncForceNeverPolicy:
    """Test that --force mode overrides 'never' policy."""

    @pytest.fixture
    def temp_project(self) -> Generator[Path]:
        """Create a temporary project directory for testing."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            # Create .genesis directory
            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            # Create sync.yml with a file that has "never" policy
            sync_config = {
                "version": "1.0",
                "template_source": "python-api",
                "project": {
                    "name": "test-project",
                    "type": "python-api",
                    "genesis_version": "1.5.0",
                },
                "sync_policies": [
                    {
                        "source": "CLAUDE.md",
                        "dest": "CLAUDE.md",
                        "policy": "never",
                        "description": "AI assistant instructions (user customizable)",
                    }
                ],
            }

            sync_yml_path = genesis_dir / "sync.yml"
            with open(sync_yml_path, "w") as f:
                yaml.dump(sync_config, f)

            # Create the target file so we can test force overwrite
            claude_md_path = project_path / "CLAUDE.md"
            claude_md_path.write_text(
                "# Existing User Content\n\nThis should be preserved by 'never' policy."
            )

            yield project_path

    @pytest.mark.unit
    def test_force_mode_does_not_override_never_policy_bug(
        self, temp_project: Path
    ) -> None:
        """Test that demonstrates the bug: --force does not override 'never' policy.

        This test FAILS and demonstrates the current buggy behavior.
        After the fix, this test should be updated to verify the correct behavior.
        """
        project_path = temp_project

        # Mock template manager to return content for CLAUDE.md
        mock_template_manager = MagicMock()
        mock_template_manager.get_template.return_value = (
            "# New Template Content\n\nThis is from the template."
        )

        # Create SyncManager with force=True
        sync_manager = SyncManager(
            project_path=project_path,
            force=True,  # This should override ALL policies, including "never"
            dry_run=False,
            template_manager=mock_template_manager,
        )

        # Run sync
        sync_manager.sync()

        # BUG: Currently, force mode does NOT sync files with "never" policy
        # The file should be in skipped_files (demonstrating the bug)
        assert "CLAUDE.md" in sync_manager.skipped_files, (
            "BUG DETECTED: Force mode incorrectly skipped file with 'never' policy. "
            f"Skipped files: {sync_manager.skipped_files}"
        )

        # The file should NOT be in synced_files (current buggy behavior)
        assert "CLAUDE.md" not in sync_manager.synced_files, (
            "BUG DETECTED: File with 'never' policy was synced when it shouldn't be in current buggy behavior. "
            f"Synced files: {sync_manager.synced_files}"
        )

        # Verify the original content is unchanged (bug behavior)
        claude_md_path = project_path / "CLAUDE.md"
        original_content = claude_md_path.read_text()
        assert (
            "Existing User Content" in original_content
        ), "BUG DETECTED: File content changed when force mode should have skipped it due to 'never' policy bug"

    @pytest.mark.unit
    def test_force_mode_should_override_never_policy_expected_behavior(
        self, temp_project: Path
    ) -> None:
        """Test the EXPECTED behavior after fix: --force should override 'never' policy.

        This test currently FAILS because the bug exists.
        After the bug is fixed, this test should PASS.
        """
        project_path = temp_project

        # Mock template manager to return content for CLAUDE.md
        mock_template_manager = MagicMock()
        template_content = "# New Template Content\n\nThis is from the template."
        mock_template_manager.get_template.return_value = template_content

        # Create SyncManager with force=True
        sync_manager = SyncManager(
            project_path=project_path,
            force=True,  # This should override ALL policies, including "never"
            dry_run=False,
            template_manager=mock_template_manager,
        )

        # Run sync
        sync_manager.sync()

        # EXPECTED BEHAVIOR: Force mode should sync files with "never" policy
        # Currently this assertion will FAIL due to the bug
        try:
            assert "CLAUDE.md" in sync_manager.synced_files, (
                "EXPECTED: Force mode should override 'never' policy and sync the file. "
                f"Synced files: {sync_manager.synced_files}, "
                f"Skipped files: {sync_manager.skipped_files}"
            )

            # The file should NOT be in skipped_files
            assert "CLAUDE.md" not in sync_manager.skipped_files, (
                "EXPECTED: Force mode should not skip files with 'never' policy. "
                f"Skipped files: {sync_manager.skipped_files}"
            )

            # Verify the content was updated from template
            claude_md_path = project_path / "CLAUDE.md"
            new_content = claude_md_path.read_text()
            assert (
                "New Template Content" in new_content
            ), "EXPECTED: File content should be updated from template in force mode"
            assert (
                "Existing User Content" not in new_content
            ), "EXPECTED: Original user content should be replaced in force mode"

        except AssertionError as e:
            # This is expected to fail until the bug is fixed
            pytest.skip(
                f"Test skipped - demonstrates expected behavior after bug fix: {e}"
            )

    @pytest.mark.unit
    def test_normal_mode_respects_never_policy(self, temp_project: Path) -> None:
        """Test that normal sync mode (without --force) correctly respects 'never' policy.

        This test should PASS and shows the correct behavior for non-force mode.
        """
        project_path = temp_project

        # Mock template manager
        mock_template_manager = MagicMock()
        mock_template_manager.get_template.return_value = (
            "# New Template Content\n\nThis is from the template."
        )

        # Create SyncManager without force (normal mode)
        sync_manager = SyncManager(
            project_path=project_path,
            force=False,  # Normal mode should respect "never" policy
            dry_run=False,
            template_manager=mock_template_manager,
        )

        # Run sync
        sync_manager.sync()

        # CORRECT BEHAVIOR: Normal mode should respect "never" policy and skip the file
        assert "CLAUDE.md" in sync_manager.skipped_files, (
            "Normal mode should respect 'never' policy and skip the file. "
            f"Skipped files: {sync_manager.skipped_files}"
        )

        # The file should NOT be in synced_files
        assert "CLAUDE.md" not in sync_manager.synced_files, (
            "Normal mode should not sync files with 'never' policy. "
            f"Synced files: {sync_manager.synced_files}"
        )

        # Verify the original content is unchanged
        claude_md_path = project_path / "CLAUDE.md"
        original_content = claude_md_path.read_text()
        assert (
            "Existing User Content" in original_content
        ), "Original file content should be preserved with 'never' policy in normal mode"
        assert (
            "New Template Content" not in original_content
        ), "Template content should not be applied with 'never' policy in normal mode"
