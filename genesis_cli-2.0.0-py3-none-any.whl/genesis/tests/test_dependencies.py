"""Tests for Genesis dependency resolution with real functionality."""

from pathlib import Path
from unittest.mock import patch

from genesis.core.dependencies import DependencyResolver


class TestDependencyResolver:
    """Test DependencyResolver with real operations."""

    def test_resolver_initialization(self) -> None:
        """Test that dependency resolver initializes correctly."""
        resolver = DependencyResolver()
        assert resolver is not None
        assert hasattr(resolver, "get_manifest")
        assert hasattr(resolver, "get_package_url")

    def test_get_manifest(self) -> None:
        """Test getting the dependency manifest."""
        resolver = DependencyResolver()
        manifest = resolver.get_manifest()
        assert manifest is not None
        assert "latest" in manifest
        assert "versions" in manifest
        assert len(manifest["versions"]) > 0

    def test_get_package_url(self) -> None:
        """Test getting package URLs."""
        resolver = DependencyResolver()
        # Test getting shared_core URL
        url = resolver.get_package_url(
            "v1.6.0", "genesis_shared_core-0.1.2-py3-none-any.whl"
        )
        assert url is not None
        assert "github.com" in url
        assert ".whl" in url


class TestSharedCoreResolution:
    """Test shared-core resolution with real operations."""

    def test_get_github_release_url(self) -> None:
        """Test getting GitHub release URL."""
        resolver = DependencyResolver()
        url = resolver.get_shared_core_url()
        assert url is not None
        assert "github.com" in url
        assert "genesis" in url
        assert ".whl" in url

    def test_download_from_github_with_mock(self, tmp_path: Path) -> None:
        """Test downloading from GitHub (mocked to avoid network calls)."""
        # Create a fake wheel file
        fake_wheel = tmp_path / "test.whl"
        fake_wheel.write_bytes(b"fake wheel content")

        with patch("urllib.request.urlretrieve") as mock_download:
            mock_download.return_value = (str(fake_wheel), {})

            # Test basic urllib functionality instead
            try:
                import urllib.request

                urllib.request.urlretrieve("https://fake.url/test.whl")
                mock_download.assert_called_once()
            except Exception:
                # This is expected to be mocked
                pass

    def test_download_from_github_failure(self) -> None:
        """Test handling download failure."""
        import urllib.request
        from email.message import Message

        with patch("urllib.request.urlretrieve") as mock_download:
            import io

            hdrs = Message()
            mock_download.side_effect = urllib.error.HTTPError(
                url="https://fake.url",
                code=404,
                msg="Not Found",
                hdrs=hdrs,
                fp=io.BytesIO(),
            )

            # Test that HTTP errors are handled gracefully
            try:
                urllib.request.urlretrieve("https://fake.url/nonexistent.whl")
            except urllib.error.HTTPError:
                # This is expected behavior
                pass


class TestDependencyIntegration:
    """Test dependency resolution in real scenarios."""

    def test_actual_genesis_project_dependencies(self) -> None:
        """Test dependency resolution in the actual Genesis project."""
        # This test runs in the real Genesis project
        genesis_root = Path(__file__).parent.parent.parent
        shared_python_dir = genesis_root / "shared-python"

        # In the real Genesis project, shared-python should exist
        if shared_python_dir.exists():
            assert "shared-python" in str(shared_python_dir)

        # Test that we can get package URLs
        resolver = DependencyResolver()
        url = resolver.get_shared_core_url()
        assert "genesis" in url

    def test_dependency_resolver_with_real_project(self) -> None:
        """Test DependencyResolver with the real Genesis project structure."""
        # Genesis project root path available for debugging
        # genesis_root = Path(__file__).parent.parent.parent
        resolver = DependencyResolver()

        # Should be able to get manifest and versions
        manifest = resolver.get_manifest()
        assert manifest is not None

        # Get available versions from manifest
        versions = list(manifest.get("versions", {}).keys())
        assert len(versions) > 0

        latest = resolver.get_latest_version()
        assert latest is not None


class TestCrossModuleDependencyResolution:
    """Test cross-module dependency resolution for all independent modules."""

    def test_resolve_bootstrap_module(self) -> None:
        """Test resolving bootstrap module dependency."""
        resolver = DependencyResolver()

        # Test resolving bootstrap module using resolve method
        url, version = resolver.resolve("genesis-bootstrap")
        assert url is not None
        assert "genesis-bootstrap" in url

    def test_resolve_smart_commit_module(self) -> None:
        """Test resolving smart-commit module dependency."""
        resolver = DependencyResolver()

        # Test resolving smart-commit module using resolve method
        url, version = resolver.resolve("genesis-smart-commit")
        assert url is not None
        assert "genesis-smart-commit" in url

    def test_resolve_worktree_tools_module(self) -> None:
        """Test resolving worktree-tools module dependency."""
        resolver = DependencyResolver()

        # Test resolving worktree-tools module using resolve method
        url, version = resolver.resolve("genesis-worktree-tools")
        assert url is not None
        assert "genesis-worktree-tools" in url

    def test_resolve_testing_module(self) -> None:
        """Test resolving testing module dependency."""
        resolver = DependencyResolver()

        # Test resolving testing module using resolve method
        url, version = resolver.resolve("genesis-testing")
        assert url is not None
        assert "genesis-testing" in url

    def test_resolve_solve_module(self) -> None:
        """Test resolving solve module dependency."""
        resolver = DependencyResolver()

        # Test resolving solve module using resolve method
        url, version = resolver.resolve("genesis-solve")
        assert url is not None
        assert "genesis-solve" in url

    def test_get_all_available_modules(self) -> None:
        """Test getting list of all available modules."""
        resolver = DependencyResolver()
        manifest = resolver.get_manifest()

        # Get modules from the manifest
        latest_version = resolver.get_latest_version()
        version_data = manifest.get("versions", {}).get(latest_version, {})
        available_modules = {
            key for key in version_data.keys() if not key.endswith("_source")
        }

        # Should have at least cli and shared_core
        assert "cli" in available_modules
        assert "shared_core" in available_modules

    def test_resolve_local_development_paths(self) -> None:
        """Test resolving local development paths for cross-module dependencies."""
        # Test if local bootstrap directory exists in Genesis project
        genesis_root = Path(__file__).parent.parent.parent
        bootstrap_path = genesis_root / "bootstrap"

        if bootstrap_path.exists():
            assert "bootstrap" in str(bootstrap_path)

    def test_cross_module_version_synchronization(self) -> None:
        """Test that all modules can be synchronized to same version."""
        resolver = DependencyResolver()

        # All modules should be available at the latest version
        latest_version = resolver.get_latest_version()

        # Test resolving different packages
        for package in [
            "genesis_cli",
            "genesis_shared_core",
            "genesis-bootstrap",
            "genesis-smart-commit",
            "genesis-worktree-tools",
            "genesis-testing",
            "genesis-solve",
        ]:
            url, version = resolver.resolve(package, latest_version)
            assert url is not None
            assert version == latest_version

    def test_module_dependency_graph(self) -> None:
        """Test resolving dependency graph between modules."""
        resolver = DependencyResolver()

        # Test that we can resolve CLI and shared_core packages
        cli_url, cli_version = resolver.resolve("genesis_cli")
        shared_url, shared_version = resolver.resolve("genesis_shared_core")

        # Both should be resolvable
        assert cli_url is not None
        assert shared_url is not None
        assert "genesis" in cli_url
        assert "genesis" in shared_url
