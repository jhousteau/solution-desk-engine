"""
TDD RED Phase Test for Feature #475: Consolidate dual-package structure.

This test verifies that shared_core modules are moved to genesis.core
and all imports are updated correctly.
"""


class TestFeature475Consolidation:
    """Test suite for dual-package consolidation."""

    def test_genesis_core_modules_exist(self) -> None:
        """Verify all 8 modules are accessible from genesis.core."""
        # These should all succeed after consolidation
        from genesis.core import (
            ai_safety_constants,
            config,
            env,
            errors,
            health,
            logger,
            retry,
        )

        # Verify modules have expected attributes
        assert hasattr(logger, "get_logger")
        assert hasattr(env, "get_required_env")
        assert hasattr(config, "ConfigLoader")
        assert hasattr(health, "HealthCheck")
        assert hasattr(errors, "handle_error")
        assert hasattr(retry, "retry")
        assert hasattr(ai_safety_constants, "DEFAULT_AI_SAFETY_MODE")

    def test_no_shared_core_imports_remain(self) -> None:
        """Verify no files import from shared_core anymore."""
        import subprocess

        result = subprocess.run(
            [
                "grep",
                "-r",
                "from shared_core",
                "genesis/",
                "--include=*.py",
            ],
            cwd="/Users/source_code/genesis/worktrees/feature-475",
            capture_output=True,
            text=True,
        )

        # Should have no matches (exit code 1 from grep means no matches)
        assert (
            result.returncode == 1
        ), f"Found remaining shared_core imports:\n{result.stdout}"

    def test_genesis_core_init_exports_all_modules(self) -> None:
        """Verify genesis.core.__init__ exports all moved modules."""
        import genesis.core

        # All moved modules should be importable from genesis.core
        expected_modules = [
            "ai_safety_constants",
            "config",
            "env",
            "errors",
            "health",
            "logger",
            "retry",
        ]

        for module_name in expected_modules:
            assert hasattr(
                genesis.core, module_name
            ), f"genesis.core missing {module_name}"

    def test_logger_functionality_preserved(self) -> None:
        """Verify logger works after consolidation."""
        from genesis.core.logger import get_logger

        logger = get_logger(__name__)
        assert logger is not None
        assert hasattr(logger, "info")
        assert hasattr(logger, "error")

    def test_env_functionality_preserved(self) -> None:
        """Verify env utilities work after consolidation."""
        import os

        from genesis.core.env import get_required_env

        # Set a test env var
        os.environ["TEST_VAR_475"] = "test_value"

        result = get_required_env("TEST_VAR_475")
        assert result == "test_value"

        # Clean up
        del os.environ["TEST_VAR_475"]

    def test_errors_functionality_preserved(self) -> None:
        """Verify error handling works after consolidation."""
        from genesis.core.errors import GenesisError, handle_error

        # Should be able to create and handle errors
        error = GenesisError("test error")
        assert str(error) == "test error"
        assert callable(handle_error)

    def test_health_functionality_preserved(self) -> None:
        """Verify health check works after consolidation."""
        from genesis.core.health import HealthCheck, HealthStatus

        assert hasattr(HealthStatus, "HEALTHY")
        assert callable(HealthCheck)

    def test_config_functionality_preserved(self) -> None:
        """Verify config loading works after consolidation."""
        from genesis.core.config import ConfigLoader

        assert callable(ConfigLoader)

    def test_ai_safety_constants_functionality_preserved(self) -> None:
        """Verify AI safety constants work after consolidation."""
        from genesis.core.ai_safety_constants import (
            DEFAULT_AI_SAFETY_CHECK_TYPE,
            DEFAULT_AI_SAFETY_MODE,
        )

        assert DEFAULT_AI_SAFETY_MODE is not None
        assert DEFAULT_AI_SAFETY_CHECK_TYPE is not None


class TestFeature475BackwardCompatibility:
    """Ensure no breaking changes for existing functionality."""

    def test_genesis_imports_still_work(self) -> None:
        """Verify existing genesis imports continue to work."""
        # These are existing imports that should not break
        from genesis.cli import cli
        from genesis.commands.bootstrap import bootstrap_command

        assert cli is not None
        assert bootstrap_command is not None

    def test_no_shared_python_dependency_in_pyproject(self) -> None:
        """Verify pyproject.toml no longer references shared-python."""
        import toml

        pyproject_path = (
            "/Users/source_code/genesis/worktrees/feature-475/pyproject.toml"
        )
        with open(pyproject_path) as f:
            pyproject = toml.load(f)

        # Should not have genesis-shared-core dependency
        dependencies = pyproject["tool"]["poetry"]["dependencies"]
        assert (
            "genesis-shared-core" not in dependencies
        ), "genesis-shared-core should be removed from dependencies"
