"""
Unit tests for build workflow components.

Test Categories:
- Version extraction and validation
- Script existence and permissions
- Configuration file creation
- Build artifact validation
"""

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest


class TestVersionManagement:
    """Unit tests for version management functionality."""

    def test_version_extraction_from_pyproject(self, tmp_path: Path) -> None:
        """Test automatic version reading from pyproject.toml."""
        pyproject_content = """
[tool.poetry]
name = "genesis-cli"
version = "0.13.0"
description = "Genesis Development Toolkit"
"""
        pyproject_file = tmp_path / "pyproject.toml"
        pyproject_file.write_text(pyproject_content)

        with patch("subprocess.check_output") as mock_output:
            mock_output.return_value = b"0.13.0\n"

            result = mock_output.return_value.decode().strip()
            assert result == "0.13.0"
            assert result.startswith("0.")

    def test_version_format_validation(self) -> None:
        """Test version format validation."""
        valid_versions = ["0.13.0", "1.0.0", "2.5.3"]
        invalid_versions = ["v0.13.0", "0.13", "1.0.0-SNAPSHOT"]

        import re

        version_pattern = r"^\d+\.\d+\.\d+$"

        for version in valid_versions:
            assert re.match(version_pattern, version)

        for version in invalid_versions:
            assert not re.match(version_pattern, version)

    def test_pre_release_version_parsing(self) -> None:
        """Test parsing of pre-release versions."""
        pre_release_versions = [
            "v1.0.0-alpha.1",
            "v1.0.0-beta.2",
            "v1.0.0-rc.1",
            "v0.14.0-dev.123",
        ]

        import re

        pattern = r"^v\d+\.\d+\.\d+-(alpha|beta|rc|dev)\.\d+$"

        for version in pre_release_versions:
            assert re.match(pattern, version)
            clean_version = version[1:]  # Remove 'v'
            assert "-" in clean_version


class TestBuildArtifacts:
    """Unit tests for build artifact creation and validation."""

    def test_releases_manifest_structure(self, tmp_path: Path) -> None:
        """Test releases.json manifest structure validation."""
        releases_data = {
            "versions": {
                "v0.13.0": {
                    "cli": "genesis_cli-0.13.0-py3-none-any.whl",
                    "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                }
            }
        }

        releases_file = tmp_path / "releases.json"
        releases_file.write_text(json.dumps(releases_data, indent=2))

        with open(releases_file) as f:
            data = json.load(f)

        assert "versions" in data
        assert "v0.13.0" in data["versions"]
        assert "cli" in data["versions"]["v0.13.0"]
        assert "shared_core" in data["versions"]["v0.13.0"]

    def test_build_script_permissions(self, tmp_path: Path) -> None:
        """Test build script has proper permissions."""
        script_content = "#!/bin/bash\necho 'Mock build script'"
        build_script = tmp_path / "build.sh"
        build_script.write_text(script_content)
        build_script.chmod(0o755)

        assert build_script.exists()
        assert os.access(build_script, os.X_OK)

    def test_pyproject_files_creation(self, tmp_path: Path) -> None:
        """Test pyproject.toml file creation for components."""
        # Main pyproject.toml
        main_content = """
[tool.poetry]
name = "genesis-cli"
version = "0.13.0"
description = "Genesis Development Toolkit"

[tool.poetry.dependencies]
python = "^3.11"
"""
        main_file = tmp_path / "pyproject.toml"
        main_file.write_text(main_content)

        # Shared pyproject.toml
        shared_dir = tmp_path / "shared-python"
        shared_dir.mkdir()
        shared_content = """
[tool.poetry]
name = "genesis-shared-core"
version = "0.1.0"
description = "Genesis Shared Core Utilities"
"""
        shared_file = shared_dir / "pyproject.toml"
        shared_file.write_text(shared_content)

        assert main_file.exists()
        assert shared_file.exists()
        assert "genesis-cli" in main_file.read_text()
        assert "genesis-shared-core" in shared_file.read_text()


class TestClientMakefileTargets:
    """Unit tests for client project Makefile targets."""

    def test_genesis_install_targets_present(self, tmp_path: Path) -> None:
        """Test client Makefile contains Genesis install targets."""
        makefile_content = """
.PHONY: install-genesis install-genesis-version update-genesis

install-genesis: ## Install latest Genesis CLI
\t./scripts/install-genesis.sh

install-genesis-version: ## Install specific version
\t@if [ -z "$(VERSION)" ]; then echo "L Error: VERSION required"; exit 1; fi
\t./scripts/install-genesis.sh $(VERSION)

update-genesis: ## Update Genesis CLI
\t./scripts/install-genesis.sh latest
"""

        makefile = tmp_path / "Makefile"
        makefile.write_text(makefile_content)

        content = makefile.read_text()
        targets = ["install-genesis", "install-genesis-version", "update-genesis"]

        for target in targets:
            assert f"{target}:" in content

    def test_version_parameter_validation(self, tmp_path: Path) -> None:
        """Test VERSION parameter validation in Makefile."""
        makefile_content = """
install-genesis-version:
\t@if [ -z "$(VERSION)" ]; then echo "L Error: VERSION required"; exit 1; fi
\t./scripts/install-genesis.sh $(VERSION)
"""

        makefile = tmp_path / "Makefile"
        makefile.write_text(makefile_content)

        content = makefile.read_text()
        assert "VERSION required" in content
        assert "exit 1" in content


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
