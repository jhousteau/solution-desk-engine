"""Comprehensive integration tests for sync system cleanup - Issue #248.

This test suite ensures that:
1. Legacy migration and backwards compatibility code is properly removed
2. New sync.yml system works correctly
3. Bootstrap creates proper sync.yml configuration
4. Sync command reads sync.yml correctly
5. Error handling for missing sync.yml
6. Template synchronization works end-to-end
7. Clear error messages for legacy setups
"""

import json
import tempfile
from collections.abc import Generator
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml

from genesis.commands.bootstrap import bootstrap_project
from genesis.commands.sync import SyncManager


@pytest.mark.integration
class TestSyncSystemCleanupIntegration:
    """Integration tests for the sync system cleanup."""

    @pytest.fixture
    def mock_template_manager(self) -> MagicMock:
        """Mock template manager for testing."""
        mock_manager = MagicMock()
        mock_manager.get_template.return_value = (
            "# Mock template content\n{{project_name}}\n"
        )
        return mock_manager

    @pytest.fixture
    def temp_genesis_root(self) -> Generator[Path]:
        """Create a temporary Genesis root with templates structure."""
        with tempfile.TemporaryDirectory() as temp_dir:
            genesis_root = Path(temp_dir) / "genesis_root"
            genesis_root.mkdir()

            # Create templates structure
            templates_dir = genesis_root / "templates"
            shared_dir = templates_dir / "shared"
            python_api_dir = templates_dir / "python-api"
            cli_tool_dir = templates_dir / "cli-tool"

            for dir_path in [shared_dir, python_api_dir, cli_tool_dir]:
                dir_path.mkdir(parents=True)

            # Create minimal manifest
            manifest_content = {
                "shared_files": [
                    {
                        "source": "Dockerfile.template",
                        "dest": "Dockerfile",
                        "sync": "always",
                        "description": "Container configuration",
                    },
                    {
                        "source": "CLAUDE.md.template",
                        "dest": "CLAUDE.md",
                        "sync": "never",
                        "description": "AI assistant instructions",
                    },
                ]
            }

            manifest_path = shared_dir / "manifest.yml"
            with open(manifest_path, "w") as f:
                yaml.dump(manifest_content, f)

            # Create template files
            (shared_dir / "Dockerfile.template").write_text(
                "FROM python:3.11\nWORKDIR /app\n"
            )
            (shared_dir / "CLAUDE.md.template").write_text(
                "# {{project_name}}\nAI instructions for {{project_name}}\n"
            )

            yield genesis_root

    def test_bootstrap_creates_sync_yml_not_sync_state(
        self, temp_genesis_root: Path
    ) -> None:
        """Test that bootstrap creates sync.yml and NOT sync-state.json."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir)

            # Mock finding Genesis root
            with patch(
                "genesis.commands.bootstrap.find_genesis_root",
                return_value=temp_genesis_root,
            ):
                with patch(
                    "genesis.commands.bootstrap.get_template_path"
                ) as mock_template_path:
                    mock_template_path.return_value = (
                        temp_genesis_root / "templates" / "python-api"
                    )

                    # Create the template directory and basic files
                    template_dir = temp_genesis_root / "templates" / "python-api"
                    template_dir.mkdir(parents=True, exist_ok=True)

                    # Create a minimal pyproject.toml template
                    pyproject_template = template_dir / "pyproject.toml.template"
                    pyproject_template.write_text(
                        """[tool.poetry]
name = "{{project_name}}"
version = "0.1.0"
description = "{{project_description}}"

[tool.poetry.dependencies]
python = "^3.11"
fastapi = "^0.100.0"
"""
                    )

                    # Mock the constants functions that bootstrap uses
                    with patch(
                        "genesis.core.constants.get_python_version", return_value="3.11"
                    ):
                        with patch(
                            "genesis.core.constants.get_node_version", return_value="20"
                        ):
                            with patch(
                                "genesis.core.constants.get_git_author_info",
                                return_value=("Test User", "test@example.com"),
                            ):
                                # Mock subprocess calls that bootstrap makes
                                with patch("subprocess.run") as mock_run:
                                    mock_run.return_value.returncode = 0

                                    # This should create sync.yml during bootstrap
                                    result_path = bootstrap_project(
                                        name="test-project",
                                        project_type="python-api",
                                        target_path=str(project_path),
                                        skip_git=True,
                                    )

            genesis_dir = result_path / ".genesis"

            # CRITICAL: Bootstrap should create sync.yml, not sync-state.json
            sync_yml_path = genesis_dir / "sync.yml"
            sync_state_path = genesis_dir / "sync-state.json"

            # This is the key assertion for Issue #248
            assert sync_yml_path.exists(), "Bootstrap should create sync.yml"
            assert (
                not sync_state_path.exists()
            ), "Bootstrap should NOT create sync-state.json"

            # Verify sync.yml has correct structure
            with open(sync_yml_path) as f:
                sync_config = yaml.safe_load(f)

            assert "template_source" in sync_config
            assert "sync_policies" in sync_config
            assert sync_config["template_source"] == "python-api"

    def test_sync_command_requires_sync_yml_not_sync_state(self) -> None:
        """Test that sync command requires sync.yml and rejects sync-state.json."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            # Create ONLY sync-state.json (legacy format)
            sync_state_path = genesis_dir / "sync-state.json"
            sync_state_content = {
                "last_sync": "2024-01-01T00:00:00Z",
                "template_version": "0.11.0",
                "files": {},
            }
            with open(sync_state_path, "w") as f:
                json.dump(sync_state_content, f)

            # Ensure sync.yml does NOT exist
            sync_yml_path = genesis_dir / "sync.yml"
            assert not sync_yml_path.exists()

            # Sync manager should fail with clear error
            sync_manager = SyncManager(project_path, dry_run=True)

            with pytest.raises(FileNotFoundError) as exc_info:
                sync_manager.load_config()

            error_message = str(exc_info.value)
            assert "sync.yml" in error_message
            assert "genesis init" in error_message or "genesis migrate" in error_message

    def test_sync_yml_parsing_and_validation(self) -> None:
        """Test sync.yml parsing and validation."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()
            sync_yml_path = genesis_dir / "sync.yml"

            # Test valid sync.yml
            valid_config = {
                "template_source": "python-api",
                "sync_policies": [
                    {
                        "source": "Dockerfile.template",
                        "dest": "Dockerfile",
                        "policy": "always",
                    }
                ],
            }

            with open(sync_yml_path, "w") as f:
                yaml.dump(valid_config, f)

            sync_manager = SyncManager(project_path, dry_run=True)
            config = sync_manager.load_config()

            assert config["template_source"] == "python-api"
            assert len(config["sync_policies"]) == 1

    def test_sync_yml_validation_errors(self) -> None:
        """Test sync.yml validation error handling."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()
            sync_yml_path = genesis_dir / "sync.yml"

            # Test missing required field
            invalid_config = {
                "template_source": "python-api"
                # Missing sync_policies
            }

            with open(sync_yml_path, "w") as f:
                yaml.dump(invalid_config, f)

            sync_manager = SyncManager(project_path, dry_run=True)

            with pytest.raises(yaml.YAMLError) as exc_info:
                sync_manager.load_config()

            assert "missing required field: sync_policies" in str(exc_info.value)

    def test_malformed_sync_yml_handling(self) -> None:
        """Test handling of malformed sync.yml files."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()
            sync_yml_path = genesis_dir / "sync.yml"

            # Create malformed YAML
            sync_yml_path.write_text("invalid: yaml: content: }")

            sync_manager = SyncManager(project_path, dry_run=True)

            with pytest.raises(yaml.YAMLError):
                sync_manager.load_config()

    def test_template_synchronization_end_to_end(
        self, mock_template_manager: MagicMock
    ) -> None:
        """Test end-to-end template synchronization with sync.yml."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            # Create pyproject.toml for variable extraction
            pyproject_content = """[tool.poetry]
name = "test-project"
version = "0.1.0"
description = "Test project"

[tool.poetry.dependencies]
python = "^3.11"
"""
            (project_path / "pyproject.toml").write_text(pyproject_content)

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()
            sync_yml_path = genesis_dir / "sync.yml"

            # Create sync.yml configuration
            sync_config = {
                "template_source": "python-api",
                "sync_policies": [
                    {
                        "source": "Dockerfile.template",
                        "dest": "Dockerfile",
                        "policy": "always",
                    },
                    {
                        "source": "README.md.template",
                        "dest": "README.md",
                        "policy": "never",
                    },
                ],
            }

            with open(sync_yml_path, "w") as f:
                yaml.dump(sync_config, f)

            # Create sync manager with mocked template manager
            sync_manager = SyncManager(project_path, dry_run=False)
            sync_manager.template_manager = mock_template_manager

            # Configure mock responses
            def mock_get_template(path: str) -> str:
                if "Dockerfile" in path:
                    return "FROM python:3.11\nWORKDIR /app\nCOPY . .\nCMD ['python', '{{module_name}}/main.py']"
                elif "README" in path:
                    return "# {{project_name}}\n\nA project generated by Genesis."
                return "# Default template content"

            mock_template_manager.get_template.side_effect = mock_get_template

            # Perform sync
            synced_count = sync_manager.sync()

            # Verify sync completed
            assert synced_count >= 2

            # Verify files were created
            dockerfile = project_path / "Dockerfile"
            readme = project_path / "README.md"

            assert dockerfile.exists()
            assert readme.exists()

            # Verify template variables were substituted
            dockerfile_content = dockerfile.read_text()
            readme_content = readme.read_text()

            assert "test_project/main.py" in dockerfile_content
            assert "# test-project" in readme_content

    def test_no_legacy_code_paths_remain(self) -> None:
        """Test that no legacy code paths can be accessed."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            # Create ONLY legacy files (no sync.yml)
            sync_state_path = genesis_dir / "sync-state.json"
            legacy_content = {
                "last_sync": "2024-01-01T00:00:00Z",
                "template_version": "0.11.0",
                "files": {},
                "auto_detection": True,
            }
            with open(sync_state_path, "w") as f:
                json.dump(legacy_content, f)

            sync_manager = SyncManager(project_path, dry_run=True)

            # Should not auto-migrate or fall back to legacy detection
            with pytest.raises(FileNotFoundError) as exc_info:
                sync_manager.load_config()

            error_message = str(exc_info.value)
            assert "sync.yml" in error_message.lower()
            assert "genesis init" in error_message or "genesis migrate" in error_message

    def test_sync_policies_work_correctly(
        self, mock_template_manager: MagicMock
    ) -> None:
        """Test that sync policies (always, never, if_unchanged) work correctly."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            # Create sync.yml with different policies
            sync_config = {
                "template_source": "python-api",
                "sync_policies": [
                    {
                        "source": "always-file.template",
                        "dest": "always-file.txt",
                        "policy": "always",
                    },
                    {
                        "source": "never-file.template",
                        "dest": "never-file.txt",
                        "policy": "never",
                    },
                    {
                        "source": "if-unchanged-file.template",
                        "dest": "if-unchanged-file.txt",
                        "policy": "if_unchanged",
                    },
                ],
            }

            sync_yml_path = genesis_dir / "sync.yml"
            with open(sync_yml_path, "w") as f:
                yaml.dump(sync_config, f)

            # Create existing files
            always_file = project_path / "always-file.txt"
            never_file = project_path / "never-file.txt"
            if_unchanged_file = project_path / "if-unchanged-file.txt"

            always_file.write_text("existing always content")
            never_file.write_text("existing never content")
            if_unchanged_file.write_text("existing if_unchanged content")

            # Set up sync manager
            sync_manager = SyncManager(project_path, dry_run=False)
            sync_manager.template_manager = mock_template_manager

            mock_template_manager.get_template.return_value = "# New template content"

            # Perform sync
            sync_manager.sync()

            # Check results based on policy
            always_content = always_file.read_text()
            never_content = never_file.read_text()
            if_unchanged_content = if_unchanged_file.read_text()

            # Always policy should overwrite
            assert "New template content" in always_content

            # Never policy should not overwrite existing files
            assert "existing never content" in never_content

            # If_unchanged policy should not overwrite (simplified implementation)
            assert "existing if_unchanged content" in if_unchanged_content

    def test_force_sync_behavior(self, mock_template_manager: MagicMock) -> None:
        """Test force sync behavior with different policies."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            sync_config = {
                "template_source": "python-api",
                "sync_policies": [
                    {
                        "source": "if-unchanged-file.template",
                        "dest": "if-unchanged-file.txt",
                        "policy": "if_unchanged",
                    },
                    {
                        "source": "never-file.template",
                        "dest": "never-file.txt",
                        "policy": "never",
                    },
                ],
            }

            sync_yml_path = genesis_dir / "sync.yml"
            with open(sync_yml_path, "w") as f:
                yaml.dump(sync_config, f)

            # Create existing files
            if_unchanged_file = project_path / "if-unchanged-file.txt"
            never_file = project_path / "never-file.txt"

            if_unchanged_file.write_text("existing content")
            never_file.write_text("existing never content")

            # Force sync
            sync_manager = SyncManager(project_path, force=True, dry_run=False)
            sync_manager.template_manager = mock_template_manager

            mock_template_manager.get_template.return_value = (
                "# Forced template content"
            )

            sync_manager.sync()

            # Force should override if_unchanged but NOT never
            if_unchanged_content = if_unchanged_file.read_text()
            never_content = never_file.read_text()

            assert "Forced template content" in if_unchanged_content
            assert (
                "existing never content" in never_content
            )  # Never policy not overridden

    def test_dry_run_shows_changes_without_applying(
        self, mock_template_manager: MagicMock
    ) -> None:
        """Test dry run mode shows what would change without applying changes."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            sync_config = {
                "template_source": "python-api",
                "sync_policies": [
                    {
                        "source": "test-file.template",
                        "dest": "test-file.txt",
                        "policy": "always",
                    }
                ],
            }

            sync_yml_path = genesis_dir / "sync.yml"
            with open(sync_yml_path, "w") as f:
                yaml.dump(sync_config, f)

            # Dry run sync
            sync_manager = SyncManager(project_path, dry_run=True)
            sync_manager.template_manager = mock_template_manager

            mock_template_manager.get_template.return_value = "# Template content"

            synced_count = sync_manager.sync()

            # Should report what would be synced
            assert synced_count >= 1
            assert "test-file.txt" in sync_manager.synced_files

            # But file should not actually exist
            test_file = project_path / "test-file.txt"
            assert not test_file.exists()

    def test_error_handling_for_missing_templates(self) -> None:
        """Test error handling when template files are missing."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            sync_config = {
                "template_source": "python-api",
                "sync_policies": [
                    {
                        "source": "nonexistent-template.template",
                        "dest": "output.txt",
                        "policy": "always",
                    }
                ],
            }

            sync_yml_path = genesis_dir / "sync.yml"
            with open(sync_yml_path, "w") as f:
                yaml.dump(sync_config, f)

            # Create sync manager with real template manager (will fail)
            sync_manager = SyncManager(project_path, dry_run=False)

            # Should handle missing template gracefully
            sync_manager.sync()

            # Should report errors but not crash
            assert len(sync_manager.errors) > 0
            assert any("not found" in error.lower() for error in sync_manager.errors)

    def test_executable_file_permissions(
        self, mock_template_manager: MagicMock
    ) -> None:
        """Test that executable files get proper permissions."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            sync_config = {
                "template_source": "python-api",
                "sync_policies": [
                    {
                        "source": "script.template",
                        "dest": "script.sh",
                        "policy": "always",
                        "executable": True,
                    }
                ],
            }

            sync_yml_path = genesis_dir / "sync.yml"
            with open(sync_yml_path, "w") as f:
                yaml.dump(sync_config, f)

            sync_manager = SyncManager(project_path, dry_run=False)
            sync_manager.template_manager = mock_template_manager

            mock_template_manager.get_template.return_value = "#!/bin/bash\necho 'test'"

            sync_manager.sync()

            script_file = project_path / "script.sh"
            assert script_file.exists()

            # Check executable permissions
            stat_result = script_file.stat()
            assert stat_result.st_mode & 0o755  # Should have executable bits

    @pytest.mark.ai_safety
    def test_sync_respects_ai_safety_limits(
        self, mock_template_manager: MagicMock
    ) -> None:
        """Test that sync operations respect AI safety file limits."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            # Create sync config with many files (but under AI safety limit)
            sync_policies = []
            for i in range(25):  # Stay well under 45 file limit
                sync_policies.append(
                    {
                        "source": f"file_{i}.template",
                        "dest": f"file_{i}.txt",
                        "policy": "always",
                    }
                )

            sync_config = {
                "template_source": "python-api",
                "sync_policies": sync_policies,
            }

            sync_yml_path = genesis_dir / "sync.yml"
            with open(sync_yml_path, "w") as f:
                yaml.dump(sync_config, f)

            sync_manager = SyncManager(project_path, dry_run=False)
            sync_manager.template_manager = mock_template_manager

            mock_template_manager.get_template.return_value = "# Test file content"

            # Should complete successfully within AI safety limits
            synced_count = sync_manager.sync()

            # Should have synced at least our 25 test files (may be more due to shared template files)
            assert synced_count >= 25

            # Verify files were created
            for i in range(25):
                file_path = project_path / f"file_{i}.txt"
                assert file_path.exists()

    def test_clear_error_messages_for_legacy_projects(self) -> None:
        """Test that clear error messages are shown for legacy projects."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "old_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            # Create old-style sync-state.json without sync.yml
            sync_state_content = {
                "last_sync": "2023-12-01T00:00:00Z",
                "template_version": "0.10.0",
                "migrated_to_genesis_structure": False,
                "files": {},
            }

            sync_state_path = genesis_dir / "sync-state.json"
            with open(sync_state_path, "w") as f:
                json.dump(sync_state_content, f)

            sync_manager = SyncManager(project_path, dry_run=True)

            # Should provide clear migration instructions
            with pytest.raises(FileNotFoundError) as exc_info:
                sync_manager.load_config()

            error_message = str(exc_info.value)
            assert "sync.yml" in error_message
            assert "genesis init" in error_message or "genesis migrate" in error_message

    def test_variable_substitution_in_sync_policies(
        self, mock_template_manager: MagicMock
    ) -> None:
        """Test that template variables are properly substituted."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            # Create pyproject.toml for variable extraction
            pyproject_content = """[tool.poetry]
name = "awesome-project"
version = "1.0.0"
description = "An awesome test project"

[tool.poetry.dependencies]
python = "^3.11"
"""
            (project_path / "pyproject.toml").write_text(pyproject_content)

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            sync_config = {
                "template_source": "python-api",
                "sync_policies": [
                    {
                        "source": "config.template",
                        "dest": "config.yaml",
                        "policy": "always",
                    }
                ],
            }

            sync_yml_path = genesis_dir / "sync.yml"
            with open(sync_yml_path, "w") as f:
                yaml.dump(sync_config, f)

            sync_manager = SyncManager(project_path, dry_run=False)
            sync_manager.template_manager = mock_template_manager

            # Template with variables
            template_content = """project:
  name: {{project_name}}
  module: {{module_name}}
  version: {{project_version}}
  description: {{project_description}}
"""
            mock_template_manager.get_template.return_value = template_content

            sync_manager.sync()

            config_file = project_path / "config.yaml"
            assert config_file.exists()

            config_content = config_file.read_text()

            # Verify variables were substituted
            assert "name: awesome-project" in config_content
            # Note: module_name is derived from directory name, not project name
            assert "module: awesome_project" in config_content
            assert "version: 1.0.0" in config_content
            assert "description: An awesome test project" in config_content


@pytest.mark.integration
class TestSyncSystemNegativeTests:
    """Negative tests to ensure legacy system is properly disabled."""

    def test_no_auto_migration_fallback(self) -> None:
        """Test that there's no automatic migration fallback."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "legacy_project"
            project_path.mkdir()

            # Create old Genesis structure without sync.yml
            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            # Old sync-state.json
            sync_state_content = {
                "last_sync": "2023-01-01T00:00:00Z",
                "auto_detection": True,
                "files": {},
            }

            sync_state_path = genesis_dir / "sync-state.json"
            with open(sync_state_path, "w") as f:
                json.dump(sync_state_content, f)

            # Old manifest.json
            manifest_content = {"version": "1.0", "template": "python-api", "files": []}

            manifest_path = genesis_dir / "manifest.json"
            with open(manifest_path, "w") as f:
                json.dump(manifest_content, f)

            sync_manager = SyncManager(project_path, dry_run=True)

            # Should NOT auto-migrate
            with pytest.raises(FileNotFoundError, match="sync.yml"):
                sync_manager.load_config()

    def test_legacy_detection_methods_removed(self) -> None:
        """Test that legacy auto-detection methods are not accessible."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            sync_manager = SyncManager(project_path, dry_run=True)

            # These legacy methods should not exist or should be compatibility stubs only
            # The actual detection should require sync.yml

            # Create project with typical structure but no sync.yml
            (project_path / "pyproject.toml").write_text(
                """[tool.poetry]
name = "test"
"""
            )

            (project_path / "src").mkdir()
            (project_path / "tests").mkdir()

            # Even with clear project structure, should fail without sync.yml
            with pytest.raises(FileNotFoundError, match="sync.yml"):
                sync_manager.load_config()

    def test_sync_state_json_ignored(self) -> None:
        """Test that sync-state.json is completely ignored."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            # Create both sync-state.json and sync.yml
            sync_state_content = {
                "last_sync": "2023-01-01T00:00:00Z",
                "template_version": "0.10.0",
                "files": {"old_file.txt": {"hash": "oldhash"}},
            }

            sync_state_path = genesis_dir / "sync-state.json"
            with open(sync_state_path, "w") as f:
                json.dump(sync_state_content, f)

            # Valid sync.yml
            sync_config = {
                "template_source": "python-api",
                "sync_policies": [
                    {
                        "source": "new_file.template",
                        "dest": "new_file.txt",
                        "policy": "always",
                    }
                ],
            }

            sync_yml_path = genesis_dir / "sync.yml"
            with open(sync_yml_path, "w") as f:
                yaml.dump(sync_config, f)

            sync_manager = SyncManager(project_path, dry_run=True)

            # Should only read sync.yml, ignore sync-state.json
            config = sync_manager.load_config()

            assert config["template_source"] == "python-api"
            assert len(config["sync_policies"]) == 1
            assert config["sync_policies"][0]["dest"] == "new_file.txt"

    def test_empty_sync_yml_handling(self) -> None:
        """Test handling of empty or minimal sync.yml files."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "test_project"
            project_path.mkdir()

            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()
            sync_yml_path = genesis_dir / "sync.yml"

            # Empty file
            sync_yml_path.write_text("")

            sync_manager = SyncManager(project_path, dry_run=True)

            with pytest.raises(yaml.YAMLError):
                sync_manager.load_config()

    def test_backwards_incompatible_error_messages(self) -> None:
        """Test that error messages clearly indicate backwards incompatibility."""
        with tempfile.TemporaryDirectory() as temp_dir:
            project_path = Path(temp_dir) / "old_project"
            project_path.mkdir()

            # Create old-style project structure
            genesis_dir = project_path / ".genesis"
            genesis_dir.mkdir()

            # Old files that used to be supported
            old_files = {
                "sync-state.json": {"auto_detection": True},
                "manifest.json": {"version": "1.0"},
                "config.json": {"template": "python-api"},
            }

            for filename, content in old_files.items():
                file_path = genesis_dir / filename
                with open(file_path, "w") as f:
                    json.dump(content, f)

            sync_manager = SyncManager(project_path, dry_run=True)

            # Should provide migration guidance
            with pytest.raises(FileNotFoundError) as exc_info:
                sync_manager.load_config()

            error_message = str(exc_info.value)

            # Should mention what's needed
            assert "sync.yml" in error_message

            # Should provide migration path
            migration_mentioned = any(
                cmd in error_message for cmd in ["genesis init", "genesis migrate"]
            )
            assert (
                migration_mentioned
            ), f"Error message should mention migration: {error_message}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
