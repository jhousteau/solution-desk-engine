"""Lightweight structured logging utility."""

import json
import logging
import sys
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class LogConfig:
    """Configuration for logging behavior."""

    level: str
    format_json: bool
    include_timestamp: bool
    include_caller: bool
    extra_fields: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> "LogConfig":
        """Create LogConfig from environment variables with sensible defaults.

        Defaults:
        - LOG_LEVEL: "INFO"
        - LOG_JSON: False
        - LOG_TIMESTAMP: True
        - LOG_CALLER: False

        Invalid or empty values fall back to defaults.
        """
        import os

        level = cls._validate_level(os.environ.get("LOG_LEVEL"))
        format_json = cls._parse_bool(os.environ.get("LOG_JSON"), False)
        include_timestamp = cls._parse_bool(os.environ.get("LOG_TIMESTAMP"), True)
        include_caller = cls._parse_bool(os.environ.get("LOG_CALLER"), False)

        return cls(
            level=level,
            format_json=format_json,
            include_timestamp=include_timestamp,
            include_caller=include_caller,
        )

    @staticmethod
    def _parse_bool(value: str | None, default: bool = False) -> bool:
        """Parse boolean value with fallback to default for invalid/empty values."""
        if not value or not value.strip():
            return default

        normalized = value.lower().strip()
        if normalized in ("true", "1", "yes", "on"):
            return True
        elif normalized in ("false", "0", "no", "off"):
            return False
        else:
            return default

    @staticmethod
    def _validate_level(level: str | None) -> str:
        """Validate log level and return default if invalid."""
        if not level or not level.strip():
            return "INFO"

        normalized = level.upper().strip()
        return (
            normalized
            if normalized in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
            else "INFO"
        )


class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging."""

    def __init__(self, config: LogConfig) -> None:
        super().__init__()
        self.config = config

    def format(self, record: logging.LogRecord) -> str:
        log_data = {
            "message": record.getMessage(),
            "level": record.levelname,
        }

        if self.config.include_timestamp:
            log_data["timestamp"] = datetime.now(UTC).isoformat()

        if self.config.include_caller:
            log_data["caller"] = f"{record.filename}:{record.lineno}"

        if hasattr(record, "extra_data"):
            log_data.update(record.extra_data)

        log_data.update(self.config.extra_fields)

        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_data, default=str)


def get_logger(
    name: str,
    config: LogConfig | None = None,
    handler: logging.Handler | None = None,
) -> logging.Logger:
    """Get configured logger instance.

    Args:
        name: Logger name (typically __name__)
        config: LogConfig instance. Defaults to JSON logging at INFO level.
        handler: Optional custom handler. Defaults to stdout.

    Usage:
        logger = get_logger(__name__)
        logger.info("Simple message")
        logger.info("Message with data", extra={"extra_data": {"key": "value"}})
    """
    if config is None:
        config = LogConfig.from_env()

    logger = logging.getLogger(name)

    # Clear existing handlers to avoid duplicates
    logger.handlers.clear()

    if handler is None:
        handler = logging.StreamHandler(sys.stdout)

    if config.format_json:
        formatter: logging.Formatter = JSONFormatter(config)
    else:
        # Build format string based on config
        format_parts = []
        if config.include_timestamp:
            format_parts.append("%(asctime)s")
        if config.include_caller:
            format_parts.append("%(filename)s:%(lineno)d")
        format_parts.extend(["%(name)s", "%(levelname)s", "%(message)s"])

        formatter = logging.Formatter(" - ".join(format_parts))

    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(getattr(logging, config.level.upper()))
    logger.propagate = False

    return logger
