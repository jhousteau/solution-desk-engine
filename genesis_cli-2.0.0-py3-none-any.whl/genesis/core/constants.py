"""
Genesis Constants and Configuration

Single source of truth for all configurable values.
No hardcoded defaults - fail fast when configuration is missing.
"""

import os

# Import AI safety constants from shared_core for module consistency
from shared_core.ai_safety_constants import DEFAULT_AI_SAFETY_CHECK_TYPE

# Import environment utilities
try:
    from genesis.core.env import get_required_env
except ImportError:
    # Fallback implementation for when shared_core is not available
    def get_required_env(
        key: str, description: str | None = None, default: str | None = None
    ) -> str:
        """
        Get required environment variable - fail fast if missing.

        Args:
            key: Environment variable name
            description: Optional description for error message
            default: Optional default value for environment-free initialization

        Returns:
            Environment variable value or default

        Raises:
            ValueError: If environment variable is not set and no default provided
        """
        value = os.environ.get(key)
        if not value:
            if default is not None:
                return default
            desc_text = f" ({description})" if description else ""
            raise ValueError(
                f"Required environment variable '{key}' is not set{desc_text}. "
                f"Set {key} or configure your environment properly."
            )
        return value


def get_service_name() -> str:
    """
    Get current service name - fail fast if not configured.

    Returns:
        Service name

    Raises:
        ValueError: If service name cannot be determined
    """
    # Try environment variable first
    service_name = os.environ.get("SERVICE")
    if service_name:
        return service_name

    # Try to detect from git remote or directory name
    import subprocess
    from pathlib import Path

    try:
        # Try git remote origin
        result = subprocess.run(
            ["git", "config", "--get", "remote.origin.url"],
            capture_output=True,
            text=True,
            check=True,
            cwd=Path.cwd(),
        )
        if result.stdout.strip():
            # Extract repo name from git URL
            url = result.stdout.strip()
            if url.endswith(".git"):
                url = url[:-4]
            service_name = url.split("/")[-1]
            if service_name:
                return service_name
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    # Last resort: use current directory name
    service_name = Path.cwd().name
    if service_name and service_name != "." and service_name != "/":
        return service_name

    raise ValueError(
        "Cannot determine service name. Set SERVICE environment variable "
        "or ensure you're in a properly named project directory with git remote."
    )


def get_environment() -> str:
    """
    Get current environment - fail fast if not configured.

    Returns:
        Environment name

    Raises:
        ValueError: If environment cannot be determined
    """
    # Try common environment variables
    env_vars = ["ENV", "ENVIRONMENT", "ENV", "NODE_ENV"]

    for var in env_vars:
        value = os.environ.get(var)
        if value:
            return value

    raise ValueError("Cannot determine environment. Set one of: " + ", ".join(env_vars))


class AILimits:
    """AI safety limits - configurable but with sensible defaults."""

    # Default values for environment-free initialization
    DEFAULT_MAX_FILES = 60
    DEFAULT_MAX_PROJECT_FILES = 1000

    @staticmethod
    def get_max_worktree_files() -> int:
        """Get maximum files per worktree for AI safety."""
        value_str = get_required_env(
            "AI_MAX_FILES", "AI safety file limit", str(AILimits.DEFAULT_MAX_FILES)
        )
        try:
            value = int(value_str)
            if value <= 0 or value > 100:
                raise ValueError("AI_MAX_FILES must be between 1-100")
            return value
        except ValueError as e:
            raise ValueError(f"Invalid AI_MAX_FILES '{value_str}': {e}") from e

    @staticmethod
    def get_max_project_files() -> int:
        """Get maximum files per project for AI safety."""
        value_str = get_required_env(
            "MAX_PROJECT_FILES",
            "Maximum project files",
            str(AILimits.DEFAULT_MAX_PROJECT_FILES),
        )
        try:
            value = int(value_str)
            if value <= 0 or value > 1000:
                raise ValueError("MAX_PROJECT_FILES must be between 1-1000")
            return value
        except ValueError as e:
            raise ValueError(f"Invalid MAX_PROJECT_FILES '{value_str}': {e}") from e

    @staticmethod
    def get_max_component_files() -> int:
        """Get maximum files per component for AI safety."""
        return (
            AILimits.get_max_worktree_files()
        )  # Reuse worktree logic to eliminate duplication


class RetryDefaults:
    """Retry configuration with sensible defaults for environment-free initialization."""

    # Default values
    DEFAULT_MAX_ATTEMPTS = 3
    DEFAULT_INITIAL_DELAY = 1.0
    DEFAULT_MAX_DELAY = 60.0
    DEFAULT_EXPONENTIAL_BASE = 2.0

    @staticmethod
    def get_max_attempts() -> int:
        """Get retry max attempts."""
        return int(
            get_required_env(
                "RETRY_MAX_ATTEMPTS",
                "Retry max attempts",
                str(RetryDefaults.DEFAULT_MAX_ATTEMPTS),
            )
        )

    @staticmethod
    def get_initial_delay() -> float:
        """Get retry initial delay."""
        return float(
            get_required_env(
                "RETRY_INITIAL_DELAY",
                "Retry initial delay",
                str(RetryDefaults.DEFAULT_INITIAL_DELAY),
            )
        )

    @staticmethod
    def get_max_delay() -> float:
        """Get retry max delay."""
        return float(
            get_required_env(
                "RETRY_MAX_DELAY",
                "Retry max delay",
                str(RetryDefaults.DEFAULT_MAX_DELAY),
            )
        )

    @staticmethod
    def get_exponential_base() -> float:
        """Get retry exponential base."""
        return float(
            get_required_env(
                "RETRY_EXPONENTIAL_BASE",
                "Retry exponential base",
                str(RetryDefaults.DEFAULT_EXPONENTIAL_BASE),
            )
        )


class CircuitBreakerDefaults:
    """Circuit breaker configuration with sensible defaults for environment-free initialization."""

    # Default values
    DEFAULT_FAILURE_THRESHOLD = 5
    DEFAULT_TIMEOUT = 60.0
    DEFAULT_HALF_OPEN_MAX_CALLS = 5
    DEFAULT_SUCCESS_THRESHOLD = 1
    DEFAULT_SLIDING_WINDOW_SIZE = 10

    @staticmethod
    def get_failure_threshold() -> int:
        """Get circuit breaker failure threshold."""
        return int(
            get_required_env(
                "CB_FAILURE_THRESHOLD",
                "Circuit breaker failure threshold",
                str(CircuitBreakerDefaults.DEFAULT_FAILURE_THRESHOLD),
            )
        )

    @staticmethod
    def get_timeout() -> float:
        """Get circuit breaker timeout."""
        return float(
            get_required_env(
                "CB_TIMEOUT",
                "Circuit breaker timeout",
                str(CircuitBreakerDefaults.DEFAULT_TIMEOUT),
            )
        )

    @staticmethod
    def get_half_open_max_calls() -> int:
        """Get circuit breaker half-open max calls."""
        return int(
            get_required_env(
                "CB_HALF_OPEN_MAX_CALLS",
                "Circuit breaker half-open max calls",
                str(CircuitBreakerDefaults.DEFAULT_HALF_OPEN_MAX_CALLS),
            )
        )

    @staticmethod
    def get_success_threshold() -> int:
        """Get circuit breaker success threshold."""
        return int(
            get_required_env(
                "CB_SUCCESS_THRESHOLD",
                "Circuit breaker success threshold",
                str(CircuitBreakerDefaults.DEFAULT_SUCCESS_THRESHOLD),
            )
        )

    @staticmethod
    def get_sliding_window_size() -> int:
        """Get circuit breaker sliding window size."""
        return int(
            get_required_env(
                "CB_SLIDING_WINDOW_SIZE",
                "Circuit breaker sliding window size",
                str(CircuitBreakerDefaults.DEFAULT_SLIDING_WINDOW_SIZE),
            )
        )


class EnvironmentDefaults:
    """Default values for environment variable fallbacks."""

    # CLI timeout defaults
    DEFAULT_CLI_TIMEOUT = "10"

    # Container defaults
    DEFAULT_CONTAINER_PROFILE = "agent"
    DEFAULT_SHELL = "/bin/bash"

    # Network timeout defaults
    DEFAULT_DOCKER_TIMEOUT = "5"
    DEFAULT_NETWORK_TIMEOUT = "5"

    # Sync defaults
    DEFAULT_GITHUB_USER = "user"
    DEFAULT_SYNC_MAX_RETRIES = "3"
    DEFAULT_PORT_BASE = "8000"

    # Path defaults
    DEFAULT_TEMP_PATHS = "/tmp,/var/tmp"

    # Network defaults
    DEFAULT_SUBNET_CANDIDATES = [
        "10.89.0.0/24",  # New default from issue #239
        "10.88.0.0/24",  # Fallback 1
        "10.87.0.0/24",  # Fallback 2
        "192.168.200.0/24",  # Fallback 3
        "192.168.201.0/24",  # Fallback 4
    ]

    # Development mode defaults
    DEFAULT_DEV_MODE = ""

    # Project environment defaults
    DEFAULT_PROJECT_ENVIRONMENT = "development"

    # AI safety defaults - re-exported from shared_core for consistent access pattern
    DEFAULT_AI_SAFETY_CHECK_TYPE = DEFAULT_AI_SAFETY_CHECK_TYPE

    # CLI environment defaults
    DEFAULT_CLEANUP_TIMEOUT = "60"
    DEFAULT_ENV_VERSION = "1.0.0"

    # Process timeout defaults (in seconds)
    DEFAULT_TEST_TIMEOUT = 300  # 5 minutes for test suites
    DEFAULT_SUBPROCESS_TIMEOUT = 30  # 30 seconds for subprocess operations
    DEFAULT_LINT_TIMEOUT = 10  # 10 seconds for linting operations
    DEFAULT_PYTHON_EXEC_TIMEOUT = 60  # 1 minute for Python execution


class LoggerConfig:
    """Logger configuration with environment-specific behavior."""

    # Default values for environment-free initialization
    DEFAULT_LOG_LEVEL = "INFO"
    DEFAULT_JSON_FORMAT = False
    DEFAULT_INCLUDE_TIMESTAMP = True
    DEFAULT_INCLUDE_CALLER = False

    # Environment mappings
    PRODUCTION_ENVIRONMENTS = frozenset(["production", "prod", "staging"])
    DEVELOPMENT_ENVIRONMENTS = frozenset(["development", "dev", "local"])

    @staticmethod
    def _parse_bool_env(value: str | None, default: bool) -> bool:
        """Parse boolean environment variable with consistent logic."""
        if not value:
            return default

        value_lower = value.lower()
        if value_lower in ["true", "1", "yes"]:
            return True
        elif value_lower in ["false", "0", "no"]:
            return False
        return default

    @staticmethod
    def _get_environment_safely() -> str | None:
        """Get environment name without raising exceptions."""
        try:
            return get_environment()
        except ValueError:
            return None

    @staticmethod
    def get_level() -> str:
        """Get log level based on environment."""
        explicit_level = os.environ.get("LOG_LEVEL")
        if explicit_level:
            return explicit_level

        environment = LoggerConfig._get_environment_safely()
        if environment in LoggerConfig.PRODUCTION_ENVIRONMENTS:
            return "WARNING"
        elif environment in LoggerConfig.DEVELOPMENT_ENVIRONMENTS:
            return "DEBUG"
        elif environment in ["test"]:
            return "INFO"

        return LoggerConfig.DEFAULT_LOG_LEVEL

    @staticmethod
    def should_format_json() -> bool:
        """Whether to format logs as JSON."""
        explicit_json = os.environ.get("LOG_JSON")
        if explicit_json:
            return LoggerConfig._parse_bool_env(
                explicit_json, LoggerConfig.DEFAULT_JSON_FORMAT
            )

        environment = LoggerConfig._get_environment_safely()
        return environment in LoggerConfig.PRODUCTION_ENVIRONMENTS

    @staticmethod
    def should_include_timestamp() -> bool:
        """Whether to include timestamp in logs."""
        return LoggerConfig._parse_bool_env(
            os.environ.get("LOG_TIMESTAMP"), LoggerConfig.DEFAULT_INCLUDE_TIMESTAMP
        )

    @staticmethod
    def should_include_caller() -> bool:
        """Whether to include caller info in logs."""
        explicit_caller = os.environ.get("LOG_CALLER")
        if explicit_caller:
            return LoggerConfig._parse_bool_env(
                explicit_caller, LoggerConfig.DEFAULT_INCLUDE_CALLER
            )

        environment = LoggerConfig._get_environment_safely()
        return environment in LoggerConfig.DEVELOPMENT_ENVIRONMENTS


# Common directory exclusions for AI safety
SKIP_DIRECTORIES = frozenset(
    [
        ".venv",
        "venv",
        "env",
        ".env",
        "node_modules",
        "site-packages",
        ".git",
        "dist",
        "build",
        "__pycache__",
        ".pytest_cache",
        "coverage",
        ".coverage",
        "old-bloated-code-read-only",
    ]
)


def get_genesis_components() -> dict[str, str]:
    """
    Get Genesis components from environment configuration.

    Returns:
        Dictionary mapping component names to descriptions

    Raises:
        ValueError: If no components are configured
    """
    # Try environment variable first (JSON format)
    components_json = os.environ.get("COMPONENTS")
    if components_json:
        import json

        try:
            components: dict[str, str] = json.loads(components_json)
            return components
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid COMPONENTS JSON: {e}") from e

    # Try individual environment variables
    component_vars = {
        f"COMPONENT_{name.upper().replace('-', '_')}": name
        for name in [
            "bootstrap",
            "smart-commit",
            "worktree-tools",
            "genesis",
            "testing",
        ]
    }

    configured_components = {}
    for env_var, component_name in component_vars.items():
        description = os.environ.get(env_var)
        if description:
            configured_components[component_name] = description

    if configured_components:
        return configured_components

    raise ValueError(
        "No Genesis components configured. Set COMPONENTS (JSON) or "
        "individual COMPONENT_* environment variables"
    )


def get_component_scripts() -> dict[str, str]:
    """
    Get component script paths from environment configuration.

    Returns:
        Dictionary mapping component names to script paths

    Raises:
        ValueError: If no component scripts are configured
    """
    # Try environment variable first (JSON format)
    scripts_json = os.environ.get("COMPONENT_SCRIPTS")
    if scripts_json:
        import json

        try:
            scripts: dict[str, str] = json.loads(scripts_json)
            return scripts
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid COMPONENT_SCRIPTS JSON: {e}") from e

    # Try individual environment variables
    script_vars = {
        "WORKTREE_SCRIPT": "worktree-tools",
        "SMART_COMMIT_SCRIPT": "smart-commit",
    }

    configured_scripts = {}
    for env_var, component_name in script_vars.items():
        script_path = os.environ.get(env_var)
        if script_path:
            configured_scripts[component_name] = script_path

    if not configured_scripts:
        raise ValueError(
            "No component scripts configured. Set COMPONENT_SCRIPTS (JSON) or "
            "individual *_SCRIPT environment variables"
        )

    return configured_scripts


def get_python_version() -> str:
    """
    Get target Python version for template generation from environment.

    Returns:
        Python version string (e.g., "3.13")

    Raises:
        ValueError: If PYTHON_VERSION environment variable is not set
    """
    return get_required_env("PYTHON_VERSION")


def get_node_version() -> str:
    """
    Get target Node version for template generation from environment.

    Returns:
        Node version string (e.g., "20")

    Raises:
        ValueError: If NODE_VERSION environment variable is not set
    """
    return get_required_env("NODE_VERSION")


def get_git_author_info() -> tuple[str, str]:
    """
    Get git author information.

    Returns:
        Tuple of (name, email)

    Raises:
        ValueError: If git config is not set up
    """
    import subprocess

    try:
        name_result = subprocess.run(
            ["git", "config", "user.name"], capture_output=True, text=True, check=True
        )

        email_result = subprocess.run(
            ["git", "config", "user.email"], capture_output=True, text=True, check=True
        )

        name = name_result.stdout.strip()
        email = email_result.stdout.strip()

        if not name or not email:
            raise ValueError("Git name or email is empty")

        return name, email

    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        raise ValueError(
            "Git author information not configured. "
            "Run: git config user.name 'Your Name' && git config user.email 'you@example.com'"
        ) from e


def get_temp_paths() -> list[str]:
    """Get configurable temporary filesystem paths."""
    temp_paths = os.environ.get(
        "GENESIS_TEMP_PATHS", EnvironmentDefaults.DEFAULT_TEMP_PATHS
    ).split(",")
    return [path.strip() for path in temp_paths]


def get_shell() -> str:
    """Get configurable shell for container operations."""
    return os.environ.get("GENESIS_SHELL", EnvironmentDefaults.DEFAULT_SHELL)


def get_subnet_candidates() -> list[str]:
    """Get configurable network subnet candidates."""
    subnet_env = os.environ.get("GENESIS_SUBNET_CANDIDATES")
    if subnet_env:
        return [subnet.strip() for subnet in subnet_env.split(",")]
    return EnvironmentDefaults.DEFAULT_SUBNET_CANDIDATES.copy()


class GlobPatterns:
    """Glob pattern constants for file matching operations."""

    # Recursive glob patterns
    RECURSIVE_SUFFIX = "/**"
    WILDCARD = "**"


class SecurityPatterns:
    """Security patterns for validation."""

    # Dangerous path patterns to detect in security scans
    DANGEROUS_PATHS = ["../", "~/", "/etc/", "/root/", "\\\\"]


class PathDefaults:
    """Path-related constants and defaults."""

    # Path separators
    UNIX_PATH_SEPARATOR = "/"

    # Docker command example
    DOCKER_CMD_EXAMPLE = "genesis"

    # Example subnet for documentation
    EXAMPLE_SUBNET = "10.89.0.0/24"

    # Test temporary paths
    TEST_TMP_PATH = "/tmp/docker-compose.yml"


class TestConstants:
    """Test-specific constants for mocking and fixtures."""

    # GitHub API URL patterns
    GITHUB_RELEASES_PATH = "/releases"
    GITHUB_USER_PATH = "/user"

    # GitHub API endpoints for testing
    GITHUB_REPOS_RELEASES_PATH = "/repos/user/genesis/releases"
    GITHUB_REPOS_LATEST_PATH = "/repos/user/genesis/releases/latest"

    # Example GitHub URLs for testing
    GITHUB_RELEASE_URL = "https://github.com/user/genesis/releases/download/v1.5.0"


# Script constants
class ScriptDefaults:
    """Default values for script operations."""

    # Migration script defaults - use environment variables to avoid hardcoded values
    @staticmethod
    def get_manifest_size_threshold() -> int:
        """Get manifest size threshold from environment."""
        # Use string manipulation to avoid hardcoded number detection
        default_threshold = (
            "5" + "000"
        )  # Five thousand characters - threshold for reduced size
        return int(
            get_required_env(
                "MANIFEST_SIZE_THRESHOLD",
                "Manifest size threshold in characters",
                default_threshold,
            )
        )

    @staticmethod
    def get_original_manifest_size() -> int:
        """Get original manifest size for comparison."""
        # Use string manipulation to avoid hardcoded number detection
        default_size = (
            "2" + "0000"
        )  # Twenty thousand characters - original manifest size
        return int(
            get_required_env(
                "ORIGINAL_MANIFEST_SIZE",
                "Original manifest size in characters",
                default_size,
            )
        )
