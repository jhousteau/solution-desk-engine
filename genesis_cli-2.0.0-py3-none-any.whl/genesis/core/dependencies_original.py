"""Dynamic dependency resolution for Genesis packages."""

import json
import os
import urllib.request
from pathlib import Path
from typing import Any

from genesis.core.logger import get_logger

logger = get_logger(__name__)

# GitHub configuration - configurable via environment variables
GITHUB_RELEASES_BASE = os.environ.get(
    "GENESIS_GITHUB_RELEASES_BASE",
    "https://github.com/jhousteau/genesis/releases/download",
)
GITHUB_API_BASE = os.environ.get(
    "GENESIS_GITHUB_API_BASE", "https://api.github.com/repos/jhousteau/genesis"
)


# Module configurations - reduce duplication by defining patterns
def _get_shared_core_version() -> str:
    """Get shared-core version from pyproject.toml or fallback."""
    try:
        shared_pyproject = (
            Path(__file__).parent.parent.parent / "shared-python" / "pyproject.toml"
        )
        if shared_pyproject.exists():
            import toml

            with open(shared_pyproject) as f:
                data = toml.load(f)
            return str(data["tool"]["poetry"]["version"])
    except Exception:
        pass
    return "0.1.2"  # Safe fallback


STABLE_VERSION = _get_shared_core_version()
MODULE_CONFIGS = {
    "cli": "genesis_cli",
    "shared_core": "genesis_shared_core",
    "bootstrap": "genesis-bootstrap",
    "smart_commit": "genesis-smart-commit",
    "worktree_tools": "genesis-worktree-tools",
    "testing": "genesis-testing",
    "solve": "genesis-solve",
}


def _generate_version_manifest(version: str) -> dict[str, str]:
    """Generate manifest for a version, eliminating duplication."""
    manifest: dict[str, str] = {}

    for module, package_name in MODULE_CONFIGS.items():
        # CLI version follows the release version, others use stable version
        if module == "cli":
            module_version = "--help" if version == "--help" else version.lstrip("v")
        else:
            module_version = STABLE_VERSION

        # Generate wheel and source filenames
        manifest[module] = f"{package_name}-{module_version}-py3-none-any.whl"
        manifest[f"{module}_source"] = f"{package_name}-{module_version}.tar.gz"

    return manifest


def get_embedded_manifest() -> dict[str, Any]:
    """Get embedded releases manifest for private repository compatibility.

    This now dynamically loads from releases.json if available,
    falling back to a minimal embedded manifest only when necessary.
    """
    # Try to load from releases.json first
    releases_path = Path(__file__).parent.parent.parent / "config" / "releases.json"
    if releases_path.exists():
        try:
            with open(releases_path) as f:
                data: dict[str, Any] = json.load(f)
                return data
        except (OSError, json.JSONDecodeError):
            pass  # Fall back to embedded

    # Dynamic fallback manifest with current version
    try:
        from genesis.core.version_manager import (
            get_cli_version,
            get_shared_core_version,
        )

        cli_version = get_cli_version()
        get_shared_core_version()  # Validate it works but not used here
    except ImportError:
        # Ultimate fallback if version_manager doesn't exist
        cli_version = "1.6.18"
        # shared_version = "0.1.2"  # Not used in minimal fallback

    # Return minimal dynamic manifest
    return {
        "latest": f"v{cli_version}",
        "versions": {
            "v0.10.0": {
                "cli": "genesis_cli-0.10.0-py3-none-any.whl",
                "cli_source": "genesis_cli-0.10.0.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v0.11.1": {
                "cli": "genesis_cli-0.11.1-py3-none-any.whl",
                "cli_source": "genesis_cli-0.11.1.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v0.12.0": {
                "cli": "genesis_cli-0.12.0-py3-none-any.whl",
                "cli_source": "genesis_cli-0.12.0.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v0.13.0": {
                "cli": "genesis_cli-0.13.0-py3-none-any.whl",
                "cli_source": "genesis_cli-0.13.0.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v0.13.1": {
                "cli": "genesis_cli-0.13.1-py3-none-any.whl",
                "cli_source": "genesis_cli-0.13.1.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v1.6.1": {
                "cli": "genesis_cli-1.6.1-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.1.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v1.6.2": {
                "cli": "genesis_cli-1.6.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.2.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v1.6.3": {
                "cli": "genesis_cli-1.6.3-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.3.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "--help": {
                "cli": "genesis_cli---help-py3-none-any.whl",
                "cli_source": "genesis_cli---help.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v1.6.4": {
                "cli": "genesis_cli-1.6.4-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.4.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.5": {
                "cli": "genesis_cli-1.6.5-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.5.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.6": {
                "cli": "genesis_cli-1.6.6-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.6.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.7": {
                "cli": "genesis_cli-1.6.7-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.7.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.8": {
                "cli": "genesis_cli-1.6.8-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.8.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.9": {
                "cli": "genesis_cli-1.6.9-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.9.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.10": {
                "cli": "genesis_cli-1.6.10-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.10.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.11": {
                "cli": "genesis_cli-1.6.11-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.11.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.12": {
                "cli": "genesis_cli-1.6.12-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.12.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.13": {
                "cli": "genesis_cli-1.6.13-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.13.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.14": {
                "cli": "genesis_cli-1.6.14-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.14.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.15": {
                "cli": "genesis_cli-1.6.15-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.15.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.16": {
                "cli": "genesis_cli-1.6.16-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.16.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.17": {
                "cli": "genesis_cli-1.6.17-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.17.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.18": {
                "cli": "genesis_cli-1.6.18-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.18.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
        },
    }


class DependencyResolver:
    """Hybrid dependency resolver supporting multiple sources."""

    def __init__(self) -> None:
        self._manifest_cache: dict[str, Any] | None = None

    def _try_local_manifest(self) -> dict[str, Any] | None:
        """Try to load manifest from local file (development)."""
        local_path = Path(__file__).parent.parent.parent / "config" / "releases.json"
        if local_path.exists():
            try:
                with open(local_path) as f:
                    manifest = json.load(f)
                logger.info(
                    f"📄 Using local releases.json with {len(manifest['versions'])} versions"
                )
                manifest_data: dict[str, Any] = manifest
                return manifest_data
            except Exception as e:
                logger.warning(f"Failed to load local releases.json: {e}")
        return None

    def _try_authenticated_fetch(self) -> dict[str, Any] | None:
        """Try to fetch manifest with GitHub token authentication."""
        token = os.getenv("GITHUB_TOKEN")
        if not token:
            return None

        try:
            # Try GitHub API for latest release
            url = f"{GITHUB_API_BASE}/releases/latest"
            req = urllib.request.Request(url)
            req.add_header("Authorization", f"token {token}")
            req.add_header("Accept", "application/vnd.github.v3+json")

            with urllib.request.urlopen(req) as response:
                release_info = json.loads(response.read().decode())

            # Look for releases.json in assets
            for asset in release_info.get("assets", []):
                if asset["name"] == "releases.json":
                    asset_req = urllib.request.Request(asset["url"])
                    asset_req.add_header("Authorization", f"token {token}")
                    asset_req.add_header("Accept", "application/octet-stream")

                    with urllib.request.urlopen(asset_req) as asset_response:
                        manifest = json.loads(asset_response.read().decode())

                    logger.info(
                        f"🔐 Using authenticated GitHub manifest with {len(manifest['versions'])} versions"
                    )
                    manifest_data: dict[str, Any] = manifest
                    return manifest_data

        except Exception as e:
            logger.warning(f"Authenticated fetch failed: {e}")

        return None

    def get_manifest(self) -> dict[str, Any]:
        """Get manifest using hybrid approach: local → authenticated → embedded."""
        if self._manifest_cache is None:
            # Strategy 1: Local file (development)
            self._manifest_cache = self._try_local_manifest()

            # Strategy 2: Authenticated GitHub fetch
            if self._manifest_cache is None:
                self._manifest_cache = self._try_authenticated_fetch()

            # Strategy 3: Embedded fallback (always works)
            if self._manifest_cache is None:
                self._manifest_cache = get_embedded_manifest()
                logger.info(
                    f"📦 Using embedded manifest with {len(self._manifest_cache['versions'])} versions"
                )

        return self._manifest_cache

    def get_package_url(self, package_name: str, version: str | None = None) -> str:
        """Get the download URL for a Genesis package.

        Args:
            package_name: Package name ('cli', 'shared_core')
            version: Specific version (e.g. 'v0.11.1') or None for latest

        Returns:
            Full download URL for the package
        """
        manifest = self.get_manifest()

        if version is None:
            version = manifest["latest"]

        if version not in manifest["versions"]:
            raise ValueError(f"Version {version} not found in manifest")

        if package_name not in manifest["versions"][version]:
            raise ValueError(f"Package {package_name} not found in version {version}")

        filename = str(manifest["versions"][version][package_name])
        url = f"{GITHUB_RELEASES_BASE}/{version}/{filename}"

        logger.info(f"Resolved {package_name} {version} -> {url}")
        return url

    def get_latest_version(self) -> str:
        """Get the latest available version."""
        manifest = self.get_manifest()
        latest: str = str(manifest["latest"])
        return latest

    def list_versions(self) -> list[str]:
        """List all available versions."""
        manifest = self.get_manifest()
        return list(manifest["versions"].keys())

    def get_available_modules(self) -> list[str]:
        """Get list of all available modules."""
        return list(MODULE_CONFIGS.keys())

    def get_local_module_path(self, module_name: str) -> Path | None:
        """Get local development path for a module."""
        root_dir = Path(__file__).parent.parent.parent

        # Special cases first
        if module_name == "cli":
            return root_dir if root_dir.exists() else None
        elif module_name == "shared_core":
            path = root_dir / "shared-python"
            return path if path.exists() else None

        # Standard pattern: module name with hyphens
        path = root_dir / module_name.replace("_", "-")
        return path if path.exists() else None

    def get_module_dependencies(self, module_name: str) -> list[str]:
        """Get list of dependencies for a module."""
        # Shared core has no dependencies, everything else depends on shared_core
        return [] if module_name == "shared_core" else ["shared_core"]


# Global resolver instance
_resolver = DependencyResolver()


def get_latest_version() -> str:
    """Get the latest Genesis version."""
    return _resolver.get_latest_version()


# Simplified URL getters - eliminate redundant functions
def get_shared_core_url(version: str | None = None) -> str:
    """Get the download URL for genesis-shared-core package."""
    return _resolver.get_package_url("shared_core", version)


def get_cli_url(version: str | None = None) -> str:
    """Get the download URL for genesis-cli package."""
    return _resolver.get_package_url("cli", version)


# Generate URL getters for additional modules - reduce duplication via lambdas
def get_bootstrap_url(version: str | None = None) -> str:
    return _resolver.get_package_url("bootstrap", version)


def get_smart_commit_url(version: str | None = None) -> str:
    return _resolver.get_package_url("smart_commit", version)


def get_worktree_tools_url(version: str | None = None) -> str:
    return _resolver.get_package_url("worktree_tools", version)


def get_testing_url(version: str | None = None) -> str:
    return _resolver.get_package_url("testing", version)


def get_solve_url(version: str | None = None) -> str:
    return _resolver.get_package_url("solve", version)
