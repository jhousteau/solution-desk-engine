"""Parse and handle Genesis manifest.yml files for template synchronization."""

from pathlib import Path
from typing import Any

import yaml


class ManifestParser:
    """Parse manifest.yml files to extract sync configuration and file mappings."""

    def __init__(self, manifest_path: Path):
        """Initialize manifest parser.

        Args:
            manifest_path: Path to the manifest.yml file
        """
        self.manifest_path = manifest_path
        self.manifest_data = self._load_manifest()

    def _load_manifest(self) -> dict[str, Any]:
        """Load and parse the manifest.yml file.

        Returns:
            Parsed manifest data

        Raises:
            FileNotFoundError: If manifest file doesn't exist
            ValueError: If manifest is invalid YAML
        """
        if not self.manifest_path.exists():
            raise FileNotFoundError(f"Manifest not found: {self.manifest_path}")

        try:
            with open(self.manifest_path, encoding="utf-8") as f:
                data: dict[str, Any] = yaml.safe_load(f) or {}
                return data
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML in manifest: {e}") from e

    def get_files_by_sync_policy(self, policy: str) -> list[dict[str, Any]]:
        """Get all files with a specific sync policy.

        Args:
            policy: Sync policy to filter by ('always', 'if_unchanged', 'never')

        Returns:
            List of file configurations with the specified policy
        """
        files: list[dict[str, Any]] = []

        # Process shared_files section
        for file_config in self.manifest_data.get("shared_files", []):
            if file_config.get("sync") == policy:
                files.append(file_config)

        return files

    def get_claude_hooks(self) -> list[dict[str, Any]]:
        """Get all Claude Code hook configurations.

        Returns:
            List of Claude hook file configurations
        """
        hooks: list[dict[str, Any]] = []

        # Process claude_hooks section
        for hook_config in self.manifest_data.get("claude_hooks", []):
            # Ensure sync policy is set to 'always' for hooks
            hook_config["sync"] = hook_config.get("sync", "always")
            hooks.append(hook_config)

        return hooks

    def get_claude_commands(self) -> list[dict[str, Any]]:
        """Get all Claude Code command configurations.

        Returns:
            List of Claude command file configurations
        """
        commands: list[dict[str, Any]] = []

        # Process claude_commands section
        for cmd_config in self.manifest_data.get("claude_commands", []):
            # Ensure sync policy is set to 'always' for commands
            cmd_config["sync"] = cmd_config.get("sync", "always")
            commands.append(cmd_config)

        return commands

    def get_claude_agents(self) -> list[dict[str, Any]]:
        """Get all Claude Code agent configurations.

        Returns:
            List of Claude agent file configurations
        """
        agents = []

        # Process claude_agents section
        for agent_config in self.manifest_data.get("claude_agents", []):
            # Ensure sync policy is set to 'always' for agents
            agent_config["sync"] = agent_config.get("sync", "always")
            agents.append(agent_config)

        return agents

    def get_all_files(self) -> list[dict[str, Any]]:
        """Get all file configurations from the manifest.

        Returns:
            List of all file configurations
        """
        all_files = []

        # Add shared files
        all_files.extend(self.manifest_data.get("shared_files", []))

        # Add Claude hooks
        all_files.extend(self.get_claude_hooks())

        # Add Claude commands
        all_files.extend(self.get_claude_commands())

        # Add Claude agents
        all_files.extend(self.get_claude_agents())

        return all_files

    def get_template_variables(self) -> list[dict[str, str]]:
        """Get template variable definitions from the manifest.

        Returns:
            List of template variable configurations
        """
        variables: list[dict[str, str]] = self.manifest_data.get(
            "template_variables", []
        )
        return variables

    def get_conditionals(self) -> dict[str, Any]:
        """Get conditional inclusion rules from the manifest.

        Returns:
            Dictionary of conditional configurations
        """
        conditionals: dict[str, Any] = self.manifest_data.get("conditionals", {})
        return conditionals

    def get_sync_config(self) -> dict[str, Any]:
        """Get general sync configuration settings.

        Returns:
            Dictionary of sync configuration settings
        """
        config: dict[str, Any] = self.manifest_data.get(
            "sync_config",
            {
                "backup_changed_files": True,
                "backup_suffix": ".genesis-backup",
                "create_directories": True,
                "preserve_permissions": True,
                "validate_templates": True,
            },
        )
        return config

    def get_resources(self) -> list[dict[str, Any]]:
        """Get parsed resources (alias for get_all_files for compatibility)."""
        return self.get_all_files()

    def parse(self) -> list[dict[str, Any]]:
        """Parse the manifest file and return resources (alias for get_all_files)."""
        return self.get_all_files()

    def get_executable_scripts(self) -> list[str]:
        """Get list of files that should be made executable.

        Returns:
            List of file paths that should have executable permissions
        """
        executable_files = []

        # Check all file configurations for executable flag
        for file_config in self.get_all_files():
            if file_config.get("executable", False):
                executable_files.append(file_config.get("dest", ""))

        return executable_files
