"""Allow running monitoring module as a script."""

from .solve_monitor import main

if __name__ == "__main__":
    main()
