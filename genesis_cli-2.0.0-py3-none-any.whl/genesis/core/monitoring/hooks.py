"""Pre/post hooks for SOLVE interaction monitoring and Task tool monitoring."""

import hashlib
import json
from collections.abc import Callable
from datetime import UTC, datetime
from functools import wraps
from pathlib import Path
from typing import Any

from genesis.core import get_logger


class SOLVEMonitor:
    """Monitor SOLVE interactions using pre/post hooks."""

    def __init__(self, issue_number: int) -> None:
        self.issue = issue_number
        self.logger = get_logger("solve.monitor")
        self.capture_dir = Path(f".genesis/monitoring/solve-{issue_number}")
        self.capture_dir.mkdir(parents=True, exist_ok=True)

        # Interaction storage
        self.interactions_file = self.capture_dir / "interactions.jsonl"
        self.current_phase: str | None = None
        self.interaction_id: str | None = None

    def pre_hook(self, phase: str, operation: str, **kwargs: Any) -> str:
        """Pre-execution hook to capture inputs.

        Args:
            phase: Current SOLVE phase (scaffold, outline, logic, verify, enhance)
            operation: Operation type (agent_dispatch, validation, tool_call, etc.)
            **kwargs: Operation-specific data to capture

        Returns:
            interaction_id: Unique ID for correlating with post-hook
        """
        self.current_phase = phase
        self.interaction_id = hashlib.md5(
            f"{datetime.now(UTC).isoformat()}-{phase}-{operation}".encode()
        ).hexdigest()[:8]

        entry = {
            "timestamp": datetime.now(UTC).isoformat(),
            "interaction_id": self.interaction_id,
            "issue": self.issue,
            "phase": phase,
            "operation": operation,
            "type": "input",
            "data": self._sanitize_data(kwargs),
        }

        self._append_interaction(entry)
        self.logger.debug(
            f"Pre-hook: {phase}/{operation}",
            extra={"extra_data": {"interaction_id": self.interaction_id}},
        )

        return self.interaction_id

    def post_hook(
        self, interaction_id: str, result: Any = None, error: Exception | None = None
    ) -> None:
        """Post-execution hook to capture outputs.

        Args:
            interaction_id: ID from corresponding pre-hook
            result: Operation result (if successful)
            error: Exception (if operation failed)
        """
        entry = {
            "timestamp": datetime.now(UTC).isoformat(),
            "interaction_id": interaction_id,
            "issue": self.issue,
            "phase": self.current_phase,
            "type": "output",
            "success": error is None,
            "data": {
                "result": self._serialize_result(result) if result else None,
                "error": str(error) if error else None,
            },
        }

        self._append_interaction(entry)
        self.logger.debug(
            f"Post-hook: {self.current_phase}",
            extra={
                "extra_data": {
                    "interaction_id": interaction_id,
                    "success": error is None,
                }
            },
        )

    def capture_validation(
        self, phase: str, check_type: str, passed: bool, details: dict | None = None
    ) -> None:
        """Capture validation checks performed by orchestrator.

        Args:
            phase: Phase being validated
            check_type: Type of validation (output_exists, content_valid, etc.)
            passed: Whether validation passed
            details: Additional validation details
        """
        interaction_id = self.pre_hook(
            phase=phase,
            operation="validation",
            check_type=check_type,
            details=details or {},
        )

        self.post_hook(
            interaction_id=interaction_id,
            result={"passed": passed, "check_type": check_type},
        )

    def capture_handoff(
        self, from_phase: str, to_phase: str, artifacts: list[str], success: bool = True
    ) -> None:
        """Capture phase handoffs.

        Args:
            from_phase: Phase completing
            to_phase: Next phase starting
            artifacts: Files/artifacts created
            success: Whether handoff was successful
        """
        interaction_id = self.pre_hook(
            phase=from_phase,
            operation="handoff",
            to_phase=to_phase,
            artifacts=artifacts,
        )

        self.post_hook(
            interaction_id=interaction_id,
            result={"success": success, "next_phase": to_phase},
        )

    def _sanitize_data(self, data: dict[str, Any]) -> dict[str, Any]:
        """Sanitize data for storage.

        Handles special cases:
        - Long prompts: Store full text but mark as long
        - Sensitive data: Redact if needed
        - Large objects: Serialize safely
        """
        sanitized: dict[str, Any] = {}
        for key, value in data.items():
            if key == "prompt" and isinstance(value, str) and len(value) > 1000:
                # Store full prompt but mark as long
                sanitized[key] = {
                    "length": len(value),
                    "preview": value[:500] + "...",
                    "full": value,  # Keep full text for analysis
                }
            elif isinstance(value, (str, int, float, bool, type(None))):
                sanitized[key] = value
            elif isinstance(value, (list, dict)):
                sanitized[key] = value
            else:
                sanitized[key] = str(value)
        return sanitized

    def _serialize_result(self, result: Any) -> Any:
        """Safely serialize results for storage."""
        if isinstance(result, str):
            # For long text responses, store preview + full text
            if len(result) > 1000:
                return {
                    "preview": result[:500] + "...",
                    "full_text": result,
                    "length": len(result),
                }
            return result
        elif isinstance(result, (dict, list)):
            return result
        elif isinstance(result, bool):
            return result
        else:
            return str(result)

    def _append_interaction(self, entry: dict[str, Any]) -> None:
        """Append interaction to JSONL file."""
        with open(self.interactions_file, "a") as f:
            f.write(json.dumps(entry, default=str) + "\n")


def monitored_operation(
    monitor: SOLVEMonitor, phase: str, operation: str
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator to add pre/post hooks to any operation.

    Args:
        monitor: SOLVEMonitor instance
        phase: Current SOLVE phase
        operation: Operation type

    Returns:
        Decorated function with automatic monitoring
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Pre-hook: capture inputs
            interaction_id = monitor.pre_hook(
                phase=phase,
                operation=operation,
                args=str(args) if args else None,
                kwargs=kwargs if kwargs else {},
            )

            # Execute operation
            error: Exception | None = None
            result: Any = None
            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                error = e
                raise
            finally:
                # Post-hook: capture outputs
                monitor.post_hook(interaction_id, result, error)

        return wrapper

    return decorator


class TaskMonitor:
    """Wraps Task tool to capture agent prompts and responses."""

    def __init__(self, monitor: SOLVEMonitor) -> None:
        """Initialize TaskMonitor with a SOLVEMonitor instance.

        Args:
            monitor: SOLVEMonitor instance for capturing interactions
        """
        self.monitor = monitor
        self.logger = get_logger("solve.task_monitor")

    def wrap_task(self, original_task_func: Callable[..., Any]) -> Callable[..., Any]:
        """Wrap the Task tool with monitoring.

        Args:
            original_task_func: The original Task function to wrap

        Returns:
            Wrapped function with monitoring
        """

        def monitored_task(
            subagent_type: str, prompt: str, description: str | None = None
        ) -> Any:
            # Extract phase from agent type (e.g., "scaffold-agent" -> "scaffold")
            phase = subagent_type.replace("-agent", "")

            # Pre-hook: capture the prompt being sent to the agent
            interaction_id = self.monitor.pre_hook(
                phase=phase,
                operation="agent_dispatch",
                agent_type=subagent_type,
                prompt=prompt,
                description=description or f"Execute {phase} phase",
            )

            self.logger.info(
                f"Dispatching {subagent_type} for {phase} phase",
                extra={
                    "extra_data": {
                        "interaction_id": interaction_id,
                        "issue": self.monitor.issue,
                        "phase": phase,
                    }
                },
            )

            try:
                # Execute Task
                result = original_task_func(
                    subagent_type=subagent_type, prompt=prompt, description=description
                )

                # Post-hook: capture agent response
                self.monitor.post_hook(interaction_id, result)

                self.logger.info(
                    f"Agent {subagent_type} completed successfully",
                    extra={
                        "extra_data": {
                            "interaction_id": interaction_id,
                            "issue": self.monitor.issue,
                            "phase": phase,
                        }
                    },
                )

                return result

            except Exception as e:
                # Post-hook: capture failure
                self.monitor.post_hook(interaction_id, None, error=e)

                self.logger.error(
                    f"Agent {subagent_type} failed: {str(e)}",
                    extra={
                        "extra_data": {
                            "interaction_id": interaction_id,
                            "issue": self.monitor.issue,
                            "phase": phase,
                            "error": str(e),
                        }
                    },
                )
                raise

        # Preserve function metadata
        monitored_task.__name__ = getattr(original_task_func, "__name__", "Task")
        monitored_task.__doc__ = getattr(
            original_task_func, "__doc__", "Monitored Task tool"
        )

        return monitored_task

    def capture_tool_call(
        self,
        phase: str,
        agent: str,
        tool: str,
        params: dict[str, Any],
        result: Any = None,
    ) -> None:
        """Capture tool calls made by agents.

        Args:
            phase: Current SOLVE phase
            agent: Agent making the call
            tool: Tool being called (Read, Write, Bash, etc.)
            params: Parameters passed to tool
            result: Tool execution result
        """
        interaction_id = self.monitor.pre_hook(
            phase=phase, operation="tool_call", agent=agent, tool=tool, params=params
        )

        self.monitor.post_hook(interaction_id=interaction_id, result=result)
