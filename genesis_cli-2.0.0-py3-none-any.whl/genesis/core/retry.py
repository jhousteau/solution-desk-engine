"""Lightweight retry decorator with exponential backoff."""

import asyncio
import functools
import random
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, TypeVar, cast

# Type variable for generic decorator typing
F = TypeVar("F", bound=Callable[..., Any])

# Default configuration constants - visible and changeable
DEFAULT_MAX_ATTEMPTS = 3
DEFAULT_INITIAL_DELAY = 1.0
DEFAULT_MAX_DELAY = 60.0
DEFAULT_EXPONENTIAL_BASE = 2.0


@dataclass
class RetryConfig:
    """Configuration for retry behavior."""

    max_attempts: int
    initial_delay: float
    max_delay: float
    exponential_base: float
    jitter: bool = True
    exceptions: tuple[type[Exception], ...] = (Exception,)

    @classmethod
    def create_default(cls) -> "RetryConfig":
        """Create default retry configuration when explicit defaults are needed."""
        return cls(
            max_attempts=DEFAULT_MAX_ATTEMPTS,
            initial_delay=DEFAULT_INITIAL_DELAY,
            max_delay=DEFAULT_MAX_DELAY,
            exponential_base=DEFAULT_EXPONENTIAL_BASE,
            jitter=True,
            exceptions=(Exception,),
        )


def retry(config: RetryConfig) -> Callable[[F], F]:
    """Retry decorator with exponential backoff.

    Args:
        config: RetryConfig instance (required for explicit configuration).

    Usage:
        # Use explicit configuration (values must be explicit)
        @retry(RetryConfig(max_attempts=5, initial_delay=0.5))
        def unreliable_function():
            # May fail, will be retried
            pass

        # Use default configuration when appropriate
        @retry(RetryConfig.create_default())
        async def async_function():
            # Async functions supported
            pass
    """

    def decorator(func: F) -> F:
        if asyncio.iscoroutinefunction(func):
            return cast(F, _async_retry_wrapper(func, config))
        else:
            return cast(F, _sync_retry_wrapper(func, config))

    return decorator


def _sync_retry_wrapper(
    func: Callable[..., Any], config: RetryConfig
) -> Callable[..., Any]:
    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        last_exception: Exception | None = None

        for attempt in range(config.max_attempts):
            try:
                return func(*args, **kwargs)
            except config.exceptions as e:
                last_exception = e
                if attempt == config.max_attempts - 1:
                    break

                delay = min(
                    config.initial_delay * (config.exponential_base**attempt),
                    config.max_delay,
                )
                if config.jitter:
                    delay *= random.uniform(0.5, 1.5)

                time.sleep(delay)

        if last_exception is not None:
            raise last_exception
        raise RuntimeError("All retry attempts failed but no exception was captured")

    return wrapper


def _async_retry_wrapper(
    func: Callable[..., Any], config: RetryConfig
) -> Callable[..., Any]:
    @functools.wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        last_exception: Exception | None = None

        for attempt in range(config.max_attempts):
            try:
                return await func(*args, **kwargs)
            except config.exceptions as e:
                last_exception = e
                if attempt == config.max_attempts - 1:
                    break

                delay = min(
                    config.initial_delay * (config.exponential_base**attempt),
                    config.max_delay,
                )
                if config.jitter:
                    delay *= random.uniform(0.5, 1.5)

                await asyncio.sleep(delay)

        if last_exception is not None:
            raise last_exception
        raise RuntimeError("All retry attempts failed but no exception was captured")

    return wrapper
