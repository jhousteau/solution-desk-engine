"""
Genesis Sparse Worktree Creator - Python wrapper with structured logging

Provides better error messages and integrates with Genesis logging system.
This wraps the bash script but provides structured error handling.
"""

import subprocess
from pathlib import Path

from genesis.core.logger import get_logger

logger = get_logger(__name__)


class WorktreeCreationError(Exception):
    """Raised when worktree creation fails."""

    pass


def validate_inputs(
    name: str, focus_paths: list[str], max_files: int | None = None
) -> int:
    """Validate inputs before creating worktree.

    Args:
        name: Worktree name
        focus_paths: List of focus paths (files or directories)
        max_files: Maximum file count (defaults to 30 if None)

    Returns:
        Validated max_files value

    Raises:
        WorktreeCreationError: If validation fails
    """
    if not name or not name.strip():
        raise WorktreeCreationError("Worktree name cannot be empty")

    if not focus_paths or not any(p.strip() for p in focus_paths):
        raise WorktreeCreationError("At least one focus path must be provided")

    # Check if focus paths exist
    for focus_path in focus_paths:
        if not focus_path.strip():
            continue
        if not Path(focus_path).exists() and not (Path.cwd() / focus_path).exists():
            raise WorktreeCreationError(f"Focus path not found: {focus_path}")

    # Use default if max_files not provided
    if max_files is None:
        max_files = 30  # Safe default for AI tools

    if not isinstance(max_files, int) or max_files <= 0:
        raise WorktreeCreationError(
            f"Max files must be a positive integer, got: {max_files}"
        )

    return max_files


def get_worktree_script_path() -> Path:
    """Get path to the bash worktree script."""
    # Script is now in .genesis/scripts/worktree/
    script_path = (
        Path(__file__).parent.parent.parent.parent
        / ".genesis"
        / "scripts"
        / "worktree"
        / "create-sparse-worktree.sh"
    )

    if not script_path.exists():
        raise WorktreeCreationError(
            f"Worktree creation script not found at {script_path}. "
            "Ensure create-sparse-worktree.sh is in .genesis/scripts/worktree/"
        )

    return script_path


def create_worktree(
    name: str,
    focus_paths: list[str] | str,
    max_files: int | None = None,
    verify: bool = False,
) -> None:
    """Create sparse worktree using bash script.

    Args:
        name: Worktree name
        focus_paths: Single path or list of paths to focus on
        max_files: Maximum file count (defaults to 30)
        verify: Whether to verify safety after creation

    Raises:
        WorktreeCreationError: If creation fails
    """
    # Normalize focus_paths to list
    if isinstance(focus_paths, str):
        focus_paths = [focus_paths]

    # Validate inputs
    max_files = validate_inputs(name, focus_paths, max_files)
    script_path = get_worktree_script_path()

    # Build command
    # Multiple paths are passed as a single space-separated argument
    focus_str = " ".join(focus_paths)
    cmd = ["bash", str(script_path), name, focus_str, "--max-files", str(max_files)]
    if verify:
        cmd.append("--verify")

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        if result.stdout:
            # Print script output directly
            print(result.stdout, end="")

    except subprocess.CalledProcessError as e:
        error_msg = f"Failed to create worktree '{name}'"

        if e.stderr:
            error_msg += f"\n\nError details:\n{e.stderr}"
        elif e.stdout:
            error_msg += f"\n\nOutput:\n{e.stdout}"

        # Common error patterns and suggestions
        output = e.stderr or e.stdout or ""
        if "Focus path not found" in output:
            error_msg += "\n\nSuggestion: Check that focus paths exist in the current repository."
        elif "Branch" in output and "already exists" in output:
            error_msg += f"\n\nSuggestion: A worktree branch may already exist. Try: git branch -D sparse-{name}"
        elif "Worktree path exists" in output:
            error_msg += f"\n\nSuggestion: Worktree directory already exists. Try: rm -rf worktrees/{name}"

        raise WorktreeCreationError(error_msg) from e

    except FileNotFoundError as e:
        raise WorktreeCreationError(
            f"Script not found or not executable: {script_path}"
        ) from e
