"""
Hash utilities for Genesis sync system.

Provides SHA-256 hash calculation and validation for template files,
enabling efficient change detection through hash comparison instead of
full content comparison.
"""

import hashlib
from pathlib import Path

try:
    from genesis.core import get_logger

    logger = get_logger(__name__)
except ImportError:
    import logging

    logger = logging.getLogger(__name__)


def calculate_file_hash(file_path: Path) -> str:
    """
    Calculate SHA-256 hash of a file.

    Args:
        file_path: Path to the file to hash

    Returns:
        Hash string in format "sha256:<64_hex_chars>"

    Raises:
        FileNotFoundError: If the file does not exist
        IOError: If the file cannot be read

    Example:
        >>> calculate_file_hash(Path("template.txt"))
        'sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    """
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    sha256_hash = hashlib.sha256()

    try:
        with open(file_path, "rb") as f:
            # Read in chunks to handle large files efficiently
            for chunk in iter(lambda: f.read(4096), b""):
                sha256_hash.update(chunk)
    except OSError as e:
        logger.error(f"Failed to read file for hashing: {file_path}: {e}")
        raise

    return f"sha256:{sha256_hash.hexdigest()}"


def validate_hash_format(hash_str: str) -> bool:
    """
    Validate that a hash string has the correct format.

    Args:
        hash_str: Hash string to validate

    Returns:
        True if the hash format is valid, False otherwise

    Valid format: "sha256:<64_hex_chars>"

    Example:
        >>> validate_hash_format("sha256:abc123...")
        True
        >>> validate_hash_format("md5:abc123")
        False
    """
    if not hash_str or not isinstance(hash_str, str):
        return False

    if not hash_str.startswith("sha256:"):
        return False

    hash_hex = hash_str[7:]  # Remove "sha256:" prefix

    if len(hash_hex) != 64:
        return False

    # Validate hex format
    try:
        int(hash_hex, 16)
        return True
    except ValueError:
        return False


def hashes_match(file_path: Path, expected_hash: str) -> bool:
    """
    Check if a file's hash matches an expected hash value.

    Args:
        file_path: Path to the file to check
        expected_hash: Expected hash in format "sha256:<64_hex_chars>"

    Returns:
        True if the file exists and its hash matches, False otherwise

    Example:
        >>> hashes_match(Path("file.txt"), "sha256:abc123...")
        True
    """
    if not file_path.exists():
        logger.debug(f"Hash check: file does not exist: {file_path}")
        return False

    if not validate_hash_format(expected_hash):
        logger.warning(f"Invalid hash format for {file_path}: {expected_hash}")
        return False

    try:
        actual_hash = calculate_file_hash(file_path)
        match = actual_hash == expected_hash

        if match:
            logger.debug(f"⚡ Hash match: {file_path.name}")
        else:
            logger.debug(
                f"Hash mismatch: {file_path.name} "
                f"(expected: {expected_hash[:20]}..., actual: {actual_hash[:20]}...)"
            )

        return match
    except (OSError, FileNotFoundError) as e:
        logger.warning(f"Failed to calculate hash for {file_path}: {e}")
        return False


def extract_hash_value(hash_str: str) -> str | None:
    """
    Extract the hex hash value from a prefixed hash string.

    Args:
        hash_str: Hash string in format "sha256:<64_hex_chars>"

    Returns:
        The 64-character hex string, or None if invalid format

    Example:
        >>> extract_hash_value("sha256:abc123...")
        'abc123...'
    """
    if not validate_hash_format(hash_str):
        return None

    return hash_str[7:]  # Remove "sha256:" prefix
