"""Shared path discovery utilities for Genesis templates and resources."""

import os
from pathlib import Path

from genesis.core.constants import EnvironmentDefaults


def discover_genesis_templates_path() -> Path | None:
    """Discover Genesis templates directory using robust path resolution.

    This function provides consistent path discovery across all Genesis commands,
    supporting both development and packaged installations.

    Returns:
        Path to Genesis templates directory, or None if not found
    """
    # Check if we're in development mode
    dev_mode = os.environ.get(
        "GENESIS_DEV_MODE", EnvironmentDefaults.DEFAULT_DEV_MODE
    ).lower() in ("true", "1", "yes")

    if dev_mode:
        # In development mode, templates are in the repository root
        # Navigate up from any genesis/core/* file to the repository root
        genesis_root = Path(__file__).parent.parent.parent
        templates_dir = genesis_root / "templates"

        if templates_dir.exists():
            return templates_dir

    # For installed packages, templates are inside the genesis package
    genesis_package_dir = Path(__file__).parent.parent
    packaged_templates_dir = genesis_package_dir / "templates"
    if packaged_templates_dir.exists():
        return packaged_templates_dir

    # Fallback: try to find templates directory by walking up from current file
    current = Path(__file__).parent
    for parent in [current] + list(current.parents):
        templates_dir = parent / "templates"
        if templates_dir.exists():
            return templates_dir

    return None


def discover_shared_templates_path() -> Path | None:
    """Discover Genesis shared templates directory.

    Returns:
        Path to Genesis shared templates directory, or None if not found
    """
    templates_dir = discover_genesis_templates_path()
    if templates_dir:
        shared_dir = templates_dir / "shared"
        if shared_dir.exists():
            return shared_dir

    return None


def discover_project_template_path(project_type: str) -> Path | None:
    """Discover path to a specific project template.

    Args:
        project_type: Type of project template (python-api, cli-tool, etc.)

    Returns:
        Path to project template directory, or None if not found
    """
    templates_dir = discover_genesis_templates_path()
    if templates_dir:
        project_template_dir = templates_dir / project_type
        if project_template_dir.exists():
            return project_template_dir

    return None
