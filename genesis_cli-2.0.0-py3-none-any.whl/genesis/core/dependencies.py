"""Optimized dependency resolution for Genesis with dynamic version management."""

import json
import os
import subprocess
from pathlib import Path
from typing import Any

from genesis.core.logger import get_logger

logger = get_logger(__name__)

# Timeout constants
DEFAULT_GITHUB_API_TIMEOUT = 5

# GitHub configuration
GITHUB_TOKEN_PATH = Path.home() / ".genesis" / "github_token"
GITHUB_API_BASE = os.environ.get(
    "GITHUB_API_BASE", "https://api.github.com/repos/jhousteau/genesis"
)


def _get_shared_core_version() -> str:
    """Get shared-core version from pyproject.toml or fallback."""
    try:
        shared_pyproject = (
            Path(__file__).parent.parent.parent / "shared-python" / "pyproject.toml"
        )
        if shared_pyproject.exists():
            import toml

            with open(shared_pyproject) as f:
                data = toml.load(f)
            return str(data["tool"]["poetry"]["version"])
    except Exception:
        pass
    return "0.1.2"  # Safe fallback


# Module configurations
STABLE_VERSION = _get_shared_core_version()
MODULE_CONFIGS = {
    "cli": "genesis_cli",
    "shared_core": "genesis_shared_core",
    "bootstrap": "genesis-bootstrap",
    "smart_commit": "genesis-smart-commit",
    "worktree_tools": "genesis-worktree-tools",
    "testing": "genesis-testing",
    "solve": "genesis-solve",
}


def _generate_version_manifest(version: str) -> dict[str, str]:
    """Generate manifest entries for a specific version dynamically."""
    manifest = {}
    version_clean = version.lstrip("v")

    for module, package_name in MODULE_CONFIGS.items():
        # Use stable version for shared_core, current version for others
        module_version = STABLE_VERSION if module == "shared_core" else version_clean

        # Add wheel and source entries
        manifest[module] = f"{package_name}-{module_version}-py3-none-any.whl"
        manifest[f"{module}_source"] = f"{package_name}-{module_version}.tar.gz"

    return manifest


def get_embedded_manifest() -> dict[str, Any]:
    """Get embedded releases manifest for private repository compatibility."""
    return {
        "latest": "v1.8.1",
        "versions": {
            "v0.10.0": {
                "cli": "genesis_cli-0.10.0-py3-none-any.whl",
                "cli_source": "genesis_cli-0.10.0.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v0.11.1": {
                "cli": "genesis_cli-0.11.1-py3-none-any.whl",
                "cli_source": "genesis_cli-0.11.1.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v0.12.0": {
                "cli": "genesis_cli-0.12.0-py3-none-any.whl",
                "cli_source": "genesis_cli-0.12.0.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v0.13.0": {
                "cli": "genesis_cli-0.13.0-py3-none-any.whl",
                "cli_source": "genesis_cli-0.13.0.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v0.13.1": {
                "cli": "genesis_cli-0.13.1-py3-none-any.whl",
                "cli_source": "genesis_cli-0.13.1.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v1.6.1": {
                "cli": "genesis_cli-1.6.1-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.1.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v1.6.2": {
                "cli": "genesis_cli-1.6.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.2.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v1.6.3": {
                "cli": "genesis_cli-1.6.3-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.3.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "--help": {
                "cli": "genesis_cli---help-py3-none-any.whl",
                "cli_source": "genesis_cli---help.tar.gz",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
                "bootstrap": "genesis-bootstrap-0.1.0-py3-none-any.whl",
                "bootstrap_source": "genesis-bootstrap-0.1.0.tar.gz",
                "smart_commit": "genesis-smart-commit-0.1.0-py3-none-any.whl",
                "smart_commit_source": "genesis-smart-commit-0.1.0.tar.gz",
                "worktree_tools": "genesis-worktree-tools-0.1.0-py3-none-any.whl",
                "worktree_tools_source": "genesis-worktree-tools-0.1.0.tar.gz",
                "testing": "genesis-testing-0.1.0-py3-none-any.whl",
                "testing_source": "genesis-testing-0.1.0.tar.gz",
                "solve": "genesis-solve-0.1.0-py3-none-any.whl",
                "solve_source": "genesis-solve-0.1.0.tar.gz",
            },
            "v1.6.4": {
                "cli": "genesis_cli-1.6.4-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.4.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.5": {
                "cli": "genesis_cli-1.6.5-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.5.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.6": {
                "cli": "genesis_cli-1.6.6-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.6.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.7": {
                "cli": "genesis_cli-1.6.7-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.7.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.8": {
                "cli": "genesis_cli-1.6.8-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.8.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.9": {
                "cli": "genesis_cli-1.6.9-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.9.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.10": {
                "cli": "genesis_cli-1.6.10-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.10.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.11": {
                "cli": "genesis_cli-1.6.11-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.11.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.0.tar.gz",
            },
            "v1.6.12": {
                "cli": "genesis_cli-1.6.12-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.12.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.13": {
                "cli": "genesis_cli-1.6.13-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.13.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.14": {
                "cli": "genesis_cli-1.6.14-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.14.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.15": {
                "cli": "genesis_cli-1.6.15-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.15.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.16": {
                "cli": "genesis_cli-1.6.16-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.16.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.17": {
                "cli": "genesis_cli-1.6.17-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.17.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.18": {
                "cli": "genesis_cli-1.6.18-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.18.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.19": {
                "cli": "genesis_cli-1.6.19-py3-none-any.whl",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.19.tar.gz",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.20": {
                "cli": "genesis_cli-1.6.20-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.20.tar.gz",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.21": {
                "cli": "genesis_cli-1.6.21-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.21.tar.gz",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.22": {
                "cli": "genesis_cli-1.6.22-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.22.tar.gz",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.23": {
                "cli": "genesis_cli-1.6.23-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.23.tar.gz",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.6.24": {
                "cli": "genesis_cli-1.6.24-py3-none-any.whl",
                "cli_source": "genesis_cli-1.6.24.tar.gz",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.7.0": {
                "cli": "genesis_cli-1.7.0-py3-none-any.whl",
                "cli_source": "genesis_cli-1.7.0.tar.gz",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.7.1": {
                "cli": "genesis_cli-1.7.1-py3-none-any.whl",
                "cli_source": "genesis_cli-1.7.1.tar.gz",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
            "v1.7.2": {
                "cli": "genesis_cli-1.7.2-py3-none-any.whl",
                "cli_source": "genesis_cli-1.7.2.tar.gz",
                "shared_core": "genesis_shared_core-0.1.2-py3-none-any.whl",
                "shared_core_source": "genesis_shared_core-0.1.2.tar.gz",
            },
        },
    }


class DependencyResolver:
    """Hybrid dependency resolver supporting multiple sources."""

    def __init__(self) -> None:
        """Initialize resolver with manifest loading."""
        self._manifest_cache: dict[str, Any] | None = None
        self._github_token: str | None = None
        self._load_github_token()

    def _load_github_token(self) -> None:
        """Load GitHub token from file if available."""
        if GITHUB_TOKEN_PATH.exists():
            try:
                self._github_token = GITHUB_TOKEN_PATH.read_text().strip()
            except OSError:
                logger.debug("Could not load GitHub token")

    def get_manifest(self) -> dict[str, Any]:
        """Get the releases manifest with caching."""
        if self._manifest_cache is None:
            # Try local manifest first
            manifest = self._try_load_local_manifest()
            if manifest:
                self._manifest_cache = manifest
                return manifest

            # Try GitHub API with auth
            if self._github_token:
                manifest = self._try_fetch_authenticated_manifest()
                if manifest:
                    self._manifest_cache = manifest
                    return manifest

            # Fall back to embedded manifest
            self._manifest_cache = get_embedded_manifest()

        return self._manifest_cache

    def _try_load_local_manifest(self) -> dict[str, Any] | None:
        """Try to load manifest from local config directory."""
        manifest_path = Path("config/releases.json")
        if manifest_path.exists():
            try:
                with open(manifest_path) as f:
                    data: dict[str, Any] = json.load(f)
                    return data
            except (OSError, json.JSONDecodeError):
                pass
        return None

    def _try_fetch_authenticated_manifest(self) -> dict[str, Any] | None:
        """Try to fetch manifest from GitHub with authentication."""
        if not self._github_token:
            return None

        try:
            # Construct the API URL for releases.json
            api_url = f"{GITHUB_API_BASE}/contents/config/releases.json"

            # Use curl for the request (more reliable than urllib)
            result = subprocess.run(
                [
                    "curl",
                    "-s",
                    "-H",
                    f"Authorization: token {self._github_token}",
                    "-H",
                    "Accept: application/vnd.github.v3.raw",
                    api_url,
                ],
                capture_output=True,
                text=True,
                timeout=DEFAULT_GITHUB_API_TIMEOUT,
            )

            if result.returncode == 0:
                data: dict[str, Any] = json.loads(result.stdout)
                return data
        except (subprocess.SubprocessError, json.JSONDecodeError, OSError):
            pass

        return None

    def get_latest_version(self) -> str:
        """Get the latest Genesis version."""
        manifest = self.get_manifest()
        latest = manifest.get("latest")
        if not latest:
            raise ValueError("No 'latest' version found in releases manifest")
        return str(latest)

    def get_package_url(self, version: str, package: str) -> str:
        """Get GitHub release URL for a specific package."""
        base_url = "https://github.com/jhousteau/genesis/releases/download"
        return f"{base_url}/{version}/{package}"

    def get_cli_url(self, version: str | None = None) -> str:
        """Get the CLI package URL for a specific version."""
        if version is None:
            version = self.get_latest_version()

        manifest = self.get_manifest()
        versions = manifest.get("versions", {})
        version_data = versions.get(version, {})

        if "cli" in version_data:
            return self.get_package_url(version, str(version_data["cli"]))

        # Generate dynamically if not in manifest
        version_clean = version.lstrip("v")
        package_name = f"genesis_cli-{version_clean}-py3-none-any.whl"
        return self.get_package_url(version, package_name)

    def get_shared_core_url(self, version: str | None = None) -> str:
        """Get the shared-core package URL for a specific version."""
        if version is None:
            version = self.get_latest_version()

        manifest = self.get_manifest()
        versions = manifest.get("versions", {})
        version_data = versions.get(version, {})

        if "shared_core" in version_data:
            return self.get_package_url(version, str(version_data["shared_core"]))

        # Generate dynamically if not in manifest
        package_name = f"genesis_shared_core-{STABLE_VERSION}-py3-none-any.whl"
        return self.get_package_url(version, package_name)

    def resolve(
        self, package: str = "genesis_cli", version: str | None = None
    ) -> tuple[str, str]:
        """Resolve a package to its download URL and version.

        Args:
            package: Package name to resolve
            version: Specific version (uses latest if None)

        Returns:
            Tuple of (download_url, version)
        """
        if version is None:
            version = self.get_latest_version()

        if package == "genesis_cli":
            url = self.get_cli_url(version)
        elif package == "genesis_shared_core":
            url = self.get_shared_core_url(version)
        else:
            # Generic package resolution
            manifest = self.get_manifest()
            versions = manifest.get("versions", {})
            version_data = versions.get(version, {})

            # Map package names to manifest keys
            package_map = {
                "genesis-bootstrap": "bootstrap",
                "genesis-smart-commit": "smart_commit",
                "genesis-worktree-tools": "worktree_tools",
                "genesis-testing": "testing",
                "genesis-solve": "solve",
            }

            manifest_key = package_map.get(package, package)
            if manifest_key in version_data:
                url = self.get_package_url(version, str(version_data[manifest_key]))
            else:
                # Generate URL dynamically
                version_clean = version.lstrip("v")
                package_file = f"{package}-{version_clean}-py3-none-any.whl"
                url = self.get_package_url(version, package_file)

        return url, version
