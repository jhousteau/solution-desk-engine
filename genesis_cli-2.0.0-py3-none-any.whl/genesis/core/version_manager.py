"""Centralized version management for Genesis.

This module provides dynamic version resolution for all Genesis components,
eliminating the need for hardcoded versions throughout the codebase.
"""

import json
import tomllib
from pathlib import Path
from typing import Any

# Cache for loaded versions
_version_cache: dict[str, str] = {}


def get_cli_version() -> str:
    """Get Genesis CLI version from pyproject.toml."""
    if "cli" not in _version_cache:
        pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"
        try:
            with open(pyproject_path, "rb") as f:
                data = tomllib.load(f)
                _version_cache["cli"] = str(data["tool"]["poetry"]["version"])
        except (FileNotFoundError, KeyError, tomllib.TOMLDecodeError):
            # Fallback to releases.json if available
            latest = _get_latest_from_releases()
            if not latest:
                raise ValueError(
                    "Cannot determine CLI version: pyproject.toml not found "
                    "and no releases.json available"
                ) from None
            _version_cache["cli"] = latest

    return _version_cache["cli"]


def get_shared_core_version() -> str:
    """Get shared-core version from shared-python/pyproject.toml."""
    if "shared_core" not in _version_cache:
        shared_pyproject = (
            Path(__file__).parent.parent.parent / "shared-python" / "pyproject.toml"
        )
        try:
            with open(shared_pyproject, "rb") as f:
                data = tomllib.load(f)
                _version_cache["shared_core"] = str(data["tool"]["poetry"]["version"])
        except (FileNotFoundError, KeyError, tomllib.TOMLDecodeError):
            _version_cache["shared_core"] = "0.1.2"  # Stable fallback

    return _version_cache["shared_core"]


def get_component_version(component: str) -> str:
    """Get version for a specific Genesis component.

    Args:
        component: Component name (bootstrap, smart-commit, worktree-tools, testing)

    Returns:
        Version string for the component
    """
    if component not in _version_cache:
        # All components currently track the CLI version
        _version_cache[component] = get_cli_version()

    return _version_cache[component]


def get_all_versions() -> dict[str, str]:
    """Get all component versions as a dictionary."""
    return {
        "cli": get_cli_version(),
        "shared_core": get_shared_core_version(),
        "bootstrap": get_component_version("bootstrap"),
        "smart_commit": get_component_version("smart_commit"),
        "worktree_tools": get_component_version("worktree_tools"),
        "testing": get_component_version("testing"),
    }


def _get_latest_from_releases() -> str | None:
    """Get latest version from releases.json."""
    releases_path = Path(__file__).parent.parent.parent / "config" / "releases.json"
    try:
        with open(releases_path) as f:
            data = json.load(f)
            latest = str(data.get("latest", ""))
            # Remove 'v' prefix if present
            return latest.lstrip("v") if latest else None
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def update_all_version_references(
    new_cli_version: str | None = None, new_shared_version: str | None = None
) -> dict[str, Any]:
    """Update all hardcoded version references in the codebase.

    Args:
        new_cli_version: New CLI version (if None, reads from pyproject.toml)
        new_shared_version: New shared-core version (if None, reads from pyproject.toml)

    Returns:
        Dictionary with update results
    """
    results: dict[str, Any] = {"updated_files": [], "errors": [], "versions": {}}

    # Get versions
    cli_version = new_cli_version or get_cli_version()
    shared_version = new_shared_version or get_shared_core_version()

    results["versions"] = {"cli": cli_version, "shared_core": shared_version}

    # Files with __version__ that need updating
    version_files: list[Path] = [
        Path(__file__).parent.parent.parent
        / "bootstrap"
        / "src"
        / "bootstrap"
        / "__init__.py",
        Path(__file__).parent.parent.parent
        / "shared-python"
        / "src"
        / "shared_core"
        / "__init__.py",
        Path(__file__).parent.parent.parent
        / "testing"
        / "src"
        / "genesis_testing"
        / "__init__.py",
        Path(__file__).parent.parent.parent
        / "smart-commit"
        / "src"
        / "smart_commit"
        / "__init__.py",
        Path(__file__).parent.parent.parent
        / "worktree-tools"
        / "src"
        / "worktree_tools"
        / "__init__.py",
        Path(__file__).parent.parent.parent / "genesis" / "version.py",
        Path(__file__).parent.parent.parent / "bootstrap" / "__init__.py",
        Path(__file__).parent.parent.parent / "worktree-tools" / "__init__.py",
        Path(__file__).parent.parent.parent / "smart-commit" / "__init__.py",
        Path(__file__).parent.parent.parent / "testing" / "__init__.py",
    ]

    # Update __version__ in Python files
    for file_path in version_files:
        if file_path.exists():
            try:
                content = file_path.read_text()
                # Determine which version to use
                if "shared_core" in str(file_path):
                    version = shared_version
                else:
                    version = cli_version

                # Replace __version__ assignment
                import re

                new_content = re.sub(
                    r'__version__\s*=\s*["\'][^"\']*["\']',
                    f'__version__ = "{version}"',
                    content,
                )

                if new_content != content:
                    file_path.write_text(new_content)
                    results["updated_files"].append(str(file_path))
            except Exception as e:
                results["errors"].append(f"Failed to update {file_path}: {e}")

    # Update releases.json
    releases_path = Path(__file__).parent.parent.parent / "config" / "releases.json"
    if releases_path.exists():
        try:
            with open(releases_path) as f:
                data = json.load(f)

            # Update latest version
            data["latest"] = f"v{cli_version}"

            # Ensure the latest version has an entry
            latest_tag = f"v{cli_version}"
            if latest_tag not in data.get("versions", {}):
                data.setdefault("versions", {})[latest_tag] = {
                    "cli": f"genesis_cli-{cli_version}-py3-none-any.whl",
                    "cli_source": f"genesis_cli-{cli_version}.tar.gz",
                    "shared_core": f"genesis_shared_core-{shared_version}-py3-none-any.whl",
                    "shared_core_source": f"genesis_shared_core-{shared_version}.tar.gz",
                }

            with open(releases_path, "w") as f:
                json.dump(data, f, indent=2)

            results["updated_files"].append(str(releases_path))
        except Exception as e:
            results["errors"].append(f"Failed to update releases.json: {e}")

    return results


def generate_dynamic_manifest(version: str | None = None) -> dict[str, Any]:
    """Generate a dynamic manifest for the given version.

    Args:
        version: Version to generate manifest for (defaults to current CLI version)

    Returns:
        Manifest dictionary with all component packages
    """
    cli_version = version or get_cli_version()
    shared_version = get_shared_core_version()

    manifest = {
        "cli": f"genesis_cli-{cli_version}-py3-none-any.whl",
        "cli_source": f"genesis_cli-{cli_version}.tar.gz",
        "shared_core": f"genesis_shared_core-{shared_version}-py3-none-any.whl",
        "shared_core_source": f"genesis_shared_core-{shared_version}.tar.gz",
    }

    # Add other components (they track CLI version)
    component_mappings: list[tuple[str, str]] = [
        ("bootstrap", "genesis-bootstrap"),
        ("smart_commit", "genesis-smart-commit"),
        ("worktree_tools", "genesis-worktree-tools"),
        ("testing", "genesis-testing"),
    ]
    for component, package_name in component_mappings:
        manifest[component] = f"{package_name}-{cli_version}-py3-none-any.whl"
        manifest[f"{component}_source"] = f"{package_name}-{cli_version}.tar.gz"

    return manifest
