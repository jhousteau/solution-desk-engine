"""Environment variable utilities with fail-fast behavior."""

import os

# Fallback constants if genesis.core is not available
DEFAULT_PROJECT_ENVIRONMENT = "development"


def get_required_env(
    key: str, description: str | None = None, default: str | None = None
) -> str:
    """Get required environment variable with fail-fast behavior.

    Args:
        key: Environment variable name
        description: Optional description for error message
        default: Optional default value for environment-free initialization

    Returns:
        Environment variable value or default

    Raises:
        ValueError: If environment variable is not set and no default provided

    Examples:
        >>> get_required_env("DATABASE_URL", "database connection string")
        ValueError: Required environment variable 'DATABASE_URL' is not set (database connection string). Set DATABASE_URL or configure your environment properly.

        >>> get_required_env("SERVICE_NAME")
        ValueError: Required environment variable 'SERVICE_NAME' is not set. Set SERVICE_NAME or configure your environment properly.

        >>> get_required_env("LOG_LEVEL", "logging level", "INFO")
        "INFO"  # when LOG_LEVEL is not set
    """
    value = os.environ.get(key)
    if not value:
        if default is not None:
            return default
        desc_text = f" ({description})" if description else ""
        raise ValueError(
            f"Required environment variable '{key}' is not set{desc_text}. "
            f"Set {key} or configure your environment properly."
        )
    return value


def check_required_env_vars(*keys: str) -> dict[str, str]:
    """Check multiple required environment variables at once.

    Args:
        *keys: Environment variable names to check

    Returns:
        Dictionary mapping keys to values

    Raises:
        ValueError: If any required environment variable is not set
    """
    missing_keys = []
    result = {}

    for key in keys:
        value = os.environ.get(key)
        if not value:
            missing_keys.append(key)
        else:
            result[key] = value

    if missing_keys:
        keys_text = ", ".join(f"'{key}'" for key in missing_keys)
        raise ValueError(
            f"Required environment variables {keys_text} are not set. "
            f"Set these variables or configure your environment properly."
        )

    return result


def validate_env_setup() -> bool:
    """Validate basic environment setup for Genesis components.

    This checks for commonly required variables across Genesis modules.

    Returns:
        True if environment is properly configured

    Raises:
        ValueError: If required environment variables are missing
    """
    try:
        check_required_env_vars("SERVICE_NAME", "PROJECT_ENVIRONMENT")
        return True
    except ValueError as e:
        raise ValueError(f"Environment validation failed: {e}") from e


def get_current_environment() -> str:
    """Get current environment name.

    Returns:
        Environment name (defaults to "development")
    """
    try:
        from genesis.core.constants import EnvironmentDefaults

        default_env = EnvironmentDefaults.DEFAULT_PROJECT_ENVIRONMENT
    except ImportError:
        default_env = DEFAULT_PROJECT_ENVIRONMENT

    return os.environ.get("PROJECT_ENVIRONMENT", default_env)


def get_supported_environments() -> list[str]:
    """Get list of supported environment names.

    Returns:
        List of supported environment names
    """
    return ["development", "test", "staging", "production"]


def validate_environment(env: str) -> None:
    """Validate that environment is supported.

    Args:
        env: Environment name to validate

    Raises:
        ValueError: If environment is not supported
    """
    supported = get_supported_environments()
    if env not in supported:
        raise ValueError(
            f"Unsupported environment '{env}'. Supported environments: {supported}"
        )


def is_development_environment() -> bool:
    """Check if current environment is development.

    Returns:
        True if current environment is development, False otherwise
    """
    try:
        from genesis.core.constants import EnvironmentDefaults

        default_env = EnvironmentDefaults.DEFAULT_PROJECT_ENVIRONMENT
    except ImportError:
        default_env = DEFAULT_PROJECT_ENVIRONMENT

    return os.environ.get("PROJECT_ENVIRONMENT", default_env) == "development"


def get_env_or_fallback(key: str, fallback: str) -> str:
    """Get environment variable value or return fallback.

    Args:
        key: Environment variable name
        fallback: Fallback value to return if variable is not set

    Returns:
        Environment variable value or fallback
    """
    return os.environ.get(key, fallback)
