"""Template resource manager for package-based and filesystem access.

This module provides a unified interface for accessing Genesis templates
whether running from an installed package or in development mode.
"""

import os

# Check Python version for importlib.resources compatibility
from importlib.resources import files
from pathlib import Path
from typing import Any

from genesis.core.constants import EnvironmentDefaults


class TemplateManager:
    """Manages access to Genesis templates from packages or filesystem.

    This class provides a unified interface for accessing template resources
    whether Genesis is installed as a package or running in development mode.
    It automatically detects the environment and uses the appropriate access method.

    Attributes:
        dev_mode: Whether running in development mode (from source)
        templates_path: Path to templates directory (dev mode) or None (package mode)
    """

    dev_mode: bool
    templates_path: Path | None  # Path in dev mode, None in package mode

    def __init__(self, templates_path: Path | None = None) -> None:
        """Initialize the TemplateManager with environment detection.

        Args:
            templates_path: Optional explicit path to templates directory.
                If provided, forces dev_mode=True and skips auto-detection.

        Detects whether Genesis is running in development mode by checking
        the GENESIS_DEV_MODE environment variable. In development mode,
        templates are accessed directly from the filesystem. In package mode,
        templates are accessed using importlib.resources.
        """
        if templates_path is not None:
            # Explicit templates path provided (e.g., for testing)
            self.dev_mode = True
            self.templates_path = templates_path
            if not self.templates_path.exists():
                raise RuntimeError(
                    f"Explicit templates directory not found at {self.templates_path}."
                )
        else:
            # Auto-detect based on environment
            self.dev_mode = os.environ.get(
                "GENESIS_DEV_MODE", EnvironmentDefaults.DEFAULT_DEV_MODE
            ).lower() in (
                "true",
                "1",
                "yes",
            )

            if self.dev_mode:
                # In development mode, use TEMPLATES_DIR if available
                templates_dir_env = os.environ.get("TEMPLATES_DIR")
                if templates_dir_env:
                    self.templates_path = Path(templates_dir_env)
                else:
                    # Fallback: templates are in the repository
                    # Go up from genesis/core/templates.py to the root, then to templates/
                    # Path(__file__) is genesis/core/templates.py
                    # parent is genesis/core
                    # parent.parent is genesis
                    # parent.parent.parent is the repository root
                    self.templates_path = (
                        Path(__file__).parent.parent.parent / "templates"
                    )

                if not self.templates_path.exists():
                    raise RuntimeError(
                        f"Development mode enabled but templates directory not found at {self.templates_path}. "
                        "Please ensure you're running from the Genesis repository or set TEMPLATES_DIR environment variable."
                    )
            else:
                # In package mode, we'll use importlib.resources
                self.templates_path = None

    def _validate_path(self, template_path: str) -> str:
        """Validate and normalize a template path.

        Args:
            template_path: Path to template relative to templates directory

        Returns:
            Normalized path string

        Raises:
            ValueError: If path contains directory traversal attempts
        """
        # Normalize the path and check for directory traversal
        normalized = Path(template_path).as_posix()

        # Check for directory traversal attempts
        if ".." in Path(normalized).parts:
            raise ValueError(
                f"Invalid template path: {template_path} (directory traversal not allowed)"
            )

        # Remove leading slash if present
        if normalized.startswith("/"):
            normalized = normalized[1:]

        return normalized

    def get_template(self, template_path: str) -> str:
        """Get template content as text.

        Args:
            template_path: Path to template file relative to templates directory

        Returns:
            Template content as string

        Raises:
            FileNotFoundError: If template doesn't exist
            ValueError: If path is invalid or contains directory traversal
        """
        template_path = self._validate_path(template_path)

        if self.dev_mode and self.templates_path is not None:
            # Filesystem access in development mode (templates_path is not None due to guard above)
            assert self.templates_path is not None  # Type assertion for mypy
            full_path = self.templates_path / template_path

            if not full_path.exists():
                raise FileNotFoundError(
                    f"Template not found: {template_path}. " f"Looked in: {full_path}"
                )

            if not full_path.is_file():
                raise FileNotFoundError(f"Template path is not a file: {template_path}")

            try:
                # Use read_bytes and decode to preserve trailing newlines
                content_bytes = full_path.read_bytes()
                return content_bytes.decode("utf-8")
            except UnicodeDecodeError as e:
                raise ValueError(
                    f"Template {template_path} is not a valid text file: {e}. "
                    "Use get_template_bytes() for binary files."
                ) from e
        else:
            # Package resource access
            try:
                # Templates are packaged inside the genesis package
                templates_pkg = files("genesis") / "templates"

                # Check if this is an editable install (source directory)
                # In editable installs, importlib.resources points to source, not installed package
                if not (
                    hasattr(templates_pkg, "exists") and templates_pkg.exists()
                ) or not (hasattr(templates_pkg, "is_dir") and templates_pkg.is_dir()):
                    # Try to find the actual templates directory for editable installs
                    genesis_file = files("genesis")
                    genesis_path = Path(str(genesis_file))
                    # For editable installs, look for templates in the repo root
                    repo_templates = genesis_path.parent / "templates"
                    if repo_templates.exists():
                        templates_pkg = repo_templates
                    else:
                        raise FileNotFoundError(
                            f"Templates directory not found at {templates_pkg} or {repo_templates}"
                        )

                # Navigate to the specific template
                parts = template_path.split("/")
                resource = templates_pkg

                for part in parts:
                    resource = resource / part

                # Read the content using read_bytes to preserve trailing newlines
                content_bytes = resource.read_bytes()
                return content_bytes.decode("utf-8")

            except (FileNotFoundError, AttributeError, UnicodeDecodeError) as e:
                raise FileNotFoundError(
                    f"Template not found in package: {template_path}. " f"Error: {e}"
                ) from e

    def get_template_bytes(self, template_path: str) -> bytes:
        """Get binary template content.

        Args:
            template_path: Path to template file relative to templates directory

        Returns:
            Template content as bytes

        Raises:
            FileNotFoundError: If template doesn't exist
            ValueError: If path is invalid or contains directory traversal
        """
        template_path = self._validate_path(template_path)

        if self.dev_mode and self.templates_path is not None:
            # Filesystem access in development mode (templates_path is not None due to guard above)
            assert self.templates_path is not None  # Type assertion for mypy
            full_path = self.templates_path / template_path

            if not full_path.exists():
                raise FileNotFoundError(
                    f"Template not found: {template_path}. " f"Looked in: {full_path}"
                )

            if not full_path.is_file():
                raise FileNotFoundError(f"Template path is not a file: {template_path}")

            return full_path.read_bytes()
        else:
            # Package resource access
            try:
                # Templates are packaged inside the genesis package
                templates_pkg = files("genesis") / "templates"

                # Check if this is an editable install (source directory)
                if not (
                    hasattr(templates_pkg, "exists") and templates_pkg.exists()
                ) or not (hasattr(templates_pkg, "is_dir") and templates_pkg.is_dir()):
                    # Try to find the actual templates directory for editable installs
                    genesis_file = files("genesis")
                    genesis_path = Path(str(genesis_file))
                    # For editable installs, look for templates in the repo root
                    repo_templates = genesis_path.parent / "templates"
                    if repo_templates.exists():
                        templates_pkg = repo_templates
                    else:
                        raise FileNotFoundError(
                            f"Templates directory not found at {templates_pkg} or {repo_templates}"
                        )

                # Navigate to the specific template
                parts = template_path.split("/")
                resource = templates_pkg

                for part in parts:
                    resource = resource / part

                # Read the content as bytes
                content = resource.read_bytes()
                return bytes(content)

            except (FileNotFoundError, AttributeError) as e:
                raise FileNotFoundError(
                    f"Template not found in package: {template_path}. " f"Error: {e}"
                ) from e

    def list_templates(self, directory: str | None = None) -> list[str]:
        """List templates in a directory.

        Args:
            directory: Directory path relative to templates root (None for root)

        Returns:
            List of template file paths relative to the templates directory

        Raises:
            FileNotFoundError: If directory doesn't exist
            ValueError: If path is invalid or contains directory traversal
        """
        if directory is not None:
            directory = self._validate_path(directory)
        else:
            directory = ""

        templates: list[str] = []

        if self.dev_mode and self.templates_path is not None:
            # Filesystem access in development mode
            # templates_path is not None due to guard above
            assert self.templates_path is not None  # Type assertion for mypy
            if directory:
                search_path = self.templates_path / directory
            else:
                search_path = self.templates_path

            if not search_path.exists():
                raise FileNotFoundError(
                    f"Template directory not found: {directory or 'templates root'}. "
                    f"Looked in: {search_path}"
                )

            if not search_path.is_dir():
                raise FileNotFoundError(
                    f"Template path is not a directory: {directory}"
                )

            # Walk the directory and collect all files
            for item in search_path.rglob("*"):
                if item.is_file():
                    # Get relative path from templates root (templates_path is not None due to guard above)
                    assert self.templates_path is not None  # Type assertion for mypy
                    rel_path = item.relative_to(self.templates_path)
                    templates.append(rel_path.as_posix())

            # Sort for consistent ordering
            templates.sort()

        else:
            # Package resource access
            try:
                templates_pkg = files("genesis") / "templates"

                # Check if this is an editable install (source directory)
                if not (
                    hasattr(templates_pkg, "exists") and templates_pkg.exists()
                ) or not (hasattr(templates_pkg, "is_dir") and templates_pkg.is_dir()):
                    # Try to find the actual templates directory for editable installs
                    genesis_file = files("genesis")
                    genesis_path = Path(str(genesis_file))
                    # For editable installs, look for templates in the repo root
                    repo_templates = genesis_path.parent / "templates"
                    if repo_templates.exists():
                        templates_pkg = repo_templates
                    else:
                        raise FileNotFoundError(
                            f"Templates directory not found at {templates_pkg} or {repo_templates}"
                        )

                # Navigate to the specific directory if provided
                if directory:
                    parts = directory.split("/")
                    resource = templates_pkg
                    for part in parts:
                        resource = resource / part
                else:
                    resource = templates_pkg

                # Recursively collect all files
                def _collect_files(res: Any, prefix: str | None = None) -> list[str]:
                    if prefix is None:
                        prefix = ""
                    result: list[str] = []
                    try:
                        # Try to iterate (it's a directory)
                        for item in res.iterdir():
                            item_name = item.name
                            item_path = f"{prefix}/{item_name}" if prefix else item_name

                            if item.is_file():
                                result.append(item_path)
                            elif item.is_dir():
                                # Recursively collect from subdirectory
                                result.extend(_collect_files(item, item_path))
                    except (AttributeError, NotADirectoryError):
                        # Not a directory, skip
                        pass
                    return result

                templates = _collect_files(resource, directory)
                templates.sort()

            except (FileNotFoundError, AttributeError) as e:
                raise FileNotFoundError(
                    f"Template directory not found in package: {directory or 'templates root'}. "
                    f"Error: {e}"
                ) from e

        return templates

    def template_exists(self, template_path: str) -> bool:
        """Check if a template exists.

        Args:
            template_path: Path to template file relative to templates directory

        Returns:
            True if template exists, False otherwise
        """
        try:
            template_path = self._validate_path(template_path)
        except ValueError:
            # Invalid path means it doesn't exist
            return False

        if self.dev_mode and self.templates_path is not None:
            # Filesystem access in development mode (templates_path is not None due to guard above)
            assert self.templates_path is not None  # Type assertion for mypy
            full_path = self.templates_path / template_path
            return full_path.exists() and full_path.is_file()
        else:
            # Package resource access
            try:
                templates_pkg = files("genesis") / "templates"

                # Check if this is an editable install (source directory)
                if not (
                    hasattr(templates_pkg, "exists") and templates_pkg.exists()
                ) or not (hasattr(templates_pkg, "is_dir") and templates_pkg.is_dir()):
                    # Try to find the actual templates directory for editable installs
                    genesis_file = files("genesis")
                    genesis_path = Path(str(genesis_file))
                    # For editable installs, look for templates in the repo root
                    repo_templates = genesis_path.parent / "templates"
                    if repo_templates.exists():
                        templates_pkg = repo_templates
                    else:
                        return False

                # Navigate to the specific template
                parts = template_path.split("/")
                resource = templates_pkg

                for part in parts:
                    resource = resource / part

                # Check if it's a file (not a directory)
                return bool(resource.is_file())

            except (FileNotFoundError, AttributeError):
                return False


# Convenience functions for module-level access
_manager: TemplateManager | None = None


def get_template_manager() -> TemplateManager:
    """Get or create the global TemplateManager instance.

    Returns:
        The global TemplateManager instance
    """
    global _manager
    if _manager is None:
        _manager = TemplateManager()
    return _manager


def get_template(template_path: str) -> str:
    """Get template content as text using the global manager.

    Args:
        template_path: Path to template file relative to templates directory

    Returns:
        Template content as string
    """
    return get_template_manager().get_template(template_path)


def get_template_bytes(template_path: str) -> bytes:
    """Get binary template content using the global manager.

    Args:
        template_path: Path to template file relative to templates directory

    Returns:
        Template content as bytes
    """
    return get_template_manager().get_template_bytes(template_path)


def list_templates(directory: str | None = None) -> list[str]:
    """List templates in a directory using the global manager.

    Args:
        directory: Directory path relative to templates root (None for root)

    Returns:
        List of template file paths relative to the templates directory
    """
    return get_template_manager().list_templates(directory)


def template_exists(template_path: str) -> bool:
    """Check if a template exists using the global manager.

    Args:
        template_path: Path to template file relative to templates directory

    Returns:
        True if template exists, False otherwise
    """
    return get_template_manager().template_exists(template_path)
