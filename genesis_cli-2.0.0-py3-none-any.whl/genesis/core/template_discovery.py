#!/usr/bin/env python3
"""Template discovery automation script.

This script scans Genesis source files and syncs them to templates/shared/
based on hash changes.

Features:
- Source file discovery from Genesis working directory
- SHA-256 hash calculation for each file
- Automatic sync policy detection
- Manifest update with preservation of custom descriptions
- Dry-run mode for previewing changes
"""

import argparse
import hashlib
import shutil
import sys
from pathlib import Path
from typing import Any

import yaml

from genesis.core.logger import get_logger

logger = get_logger(__name__)

# Source patterns to discover (path, needs_template_suffix)
SOURCE_PATTERNS: list[tuple[str, bool]] = [
    (".genesis/", False),
    (".claude/", False),
    (".envrc", True),
    ("CLAUDE.md", True),
    ("README.md", True),
    ("Dockerfile", True),
    (".gitignore", True),
    ("pyproject.toml", True),
    (".pre-commit-config.yaml", True),
    ("GENESIS_GUIDE.md", True),
]

# Patterns to exclude from discovery
EXCLUDE_PATTERNS: list[str] = [
    "Makefile",
    "docs/",
    "__pycache__/",
    "*.pyc",
    ".git/",
    ".venv/",
    "dist/",
    "build/",
    "*.egg-info/",
    "templates/",
    "scratch/",
    "node_modules/",
    ".DS_Store",
    "**/.DS_Store",
]


def discover_genesis_source_files(genesis_root: Path) -> list[tuple[Path, bool]]:
    """Discover Genesis source files based on SOURCE_PATTERNS.

    Args:
        genesis_root: Path to Genesis repository root

    Returns:
        List of (source_path, needs_template_suffix) tuples
    """
    discovered = []

    for pattern, needs_suffix in SOURCE_PATTERNS:
        pattern_path = genesis_root / pattern

        if pattern_path.is_dir():
            # Discover all files in directory
            for item in pattern_path.rglob("*"):
                if item.is_file() and not _is_excluded(item, genesis_root):
                    discovered.append((item, needs_suffix))
        elif pattern_path.is_file():
            # Single file
            if not _is_excluded(pattern_path, genesis_root):
                discovered.append((pattern_path, needs_suffix))

    logger.info(f"Discovered {len(discovered)} Genesis source files")
    return discovered


def _is_excluded(file_path: Path, genesis_root: Path) -> bool:
    """Check if file should be excluded based on EXCLUDE_PATTERNS.

    Args:
        file_path: Path to check
        genesis_root: Genesis repository root

    Returns:
        True if file should be excluded
    """
    relative = str(file_path.relative_to(genesis_root))

    for pattern in EXCLUDE_PATTERNS:
        if pattern.endswith("/"):
            # Directory pattern
            if pattern[:-1] in relative.split("/"):
                return True
        elif pattern.startswith("*."):
            # Extension pattern
            if file_path.suffix == pattern[1:]:
                return True
        else:
            # Exact match or substring
            if pattern in relative:
                return True

    return False


def calculate_file_hash(file_path: Path) -> str:
    """Calculate SHA-256 hash for a file.

    Args:
        file_path: Path to the file

    Returns:
        Hash string in format 'sha256:hexdigest'
    """
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)

    return f"sha256:{sha256_hash.hexdigest()}"


def detect_sync_policy(file_path: Path, base_dir: Path) -> str:
    """Detect appropriate sync policy based on file type and location.

    Sync policies:
    - 'always': Scripts, hooks, and shared configuration that should always update
    - 'never': User-customizable files (README, CLAUDE.md, pyproject.toml)
    - 'if_unchanged': Environment config and Makefiles that may have local changes

    Args:
        file_path: Path to the file
        base_dir: Base directory (genesis_root or templates_dir)

    Returns:
        Sync policy string: 'always', 'never', or 'if_unchanged'
    """
    try:
        relative_path = file_path.relative_to(base_dir)
    except ValueError:
        # If file is not relative to base_dir, use absolute path
        relative_path = file_path

    path_str = str(relative_path)
    file_name = file_path.name

    # User-customizable files - never overwrite
    never_sync_patterns = [
        "README.md",
        "CLAUDE.md",
        "pyproject.toml",
    ]
    if any(pattern in file_name for pattern in never_sync_patterns):
        return "never"

    # Environment and build files - sync if unchanged
    if_unchanged_patterns = [".envrc", "Makefile", ".gitignore"]
    if any(pattern in file_name for pattern in if_unchanged_patterns):
        return "if_unchanged"

    # Scripts, hooks, agents, commands - always sync
    always_sync_paths = [
        ".genesis/scripts/",
        ".genesis/hooks/",
        ".claude/agents/",
        ".claude/commands/",
        ".pre-commit-config.yaml",
    ]
    if any(pattern in path_str for pattern in always_sync_paths):
        return "always"

    # Default to 'always' for other files
    return "always"


def sync_source_to_templates(
    source_file: Path,
    genesis_root: Path,
    templates_dir: Path,
    needs_template_suffix: bool,
    dry_run: bool = False,
) -> Path:
    """Sync a Genesis source file to templates/shared directory.

    Args:
        source_file: Path to Genesis source file
        genesis_root: Genesis repository root
        templates_dir: Path to templates/shared directory
        needs_template_suffix: Whether to add .template suffix
        dry_run: If True, don't copy files

    Returns:
        Path to template file (where it was/would be copied)
    """
    relative_path = source_file.relative_to(genesis_root)
    template_name = str(relative_path)

    if needs_template_suffix and not template_name.endswith(".template"):
        template_name += ".template"

    template_path = templates_dir / template_name

    if not dry_run:
        template_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_file, template_path)
        logger.debug(f"Copied {source_file} -> {template_path}")

    return template_path


def generate_dest_path(source_path: str) -> str:
    """Generate destination path from source path.

    Removes .template suffix if present.

    Args:
        source_path: Source file path

    Returns:
        Destination path string
    """
    if source_path.endswith(".template"):
        return source_path[:-9]  # Remove '.template'
    return source_path


def generate_description(file_path: Path, base_dir: Path) -> str:
    """Generate a descriptive string for a file based on its path.

    Args:
        file_path: Path to the file
        base_dir: Base directory (genesis_root or templates_dir)

    Returns:
        Description string
    """
    try:
        relative_path = file_path.relative_to(base_dir)
    except ValueError:
        relative_path = file_path

    path_parts = relative_path.parts
    file_name = file_path.name

    # Special cases for known patterns
    if ".genesis/scripts/" in str(relative_path):
        script_type = path_parts[-2] if len(path_parts) > 2 else "utility"
        return f"{script_type.capitalize()} script"

    if ".genesis/hooks/" in str(relative_path):
        hook_name = file_name
        return f"Git {hook_name} hook"

    if ".claude/agents/" in str(relative_path):
        agent_name = file_name.replace(".md", "").replace("-", " ").title()
        return f"{agent_name} agent configuration"

    if ".claude/commands/" in str(relative_path):
        command_name = file_name.replace(".md", "").replace("-", " ").title()
        return f"{command_name} command configuration"

    # Root files
    root_files = {
        ".envrc": "Environment configuration",
        "CLAUDE.md": "AI assistant instructions (user customizable)",
        "README.md": "Project documentation (user customizable)",
        "Dockerfile": "Development container configuration",
        ".gitignore": "Git ignore patterns",
        "pyproject.toml": "Python project configuration (user customizable)",
        ".pre-commit-config.yaml": "Pre-commit hooks configuration",
        "GENESIS_GUIDE.md": "Genesis development guide",
    }

    if file_name in root_files:
        return root_files[file_name]

    # Generic description
    return f"Genesis source file: {file_name}"


def load_manifest(manifest_path: Path) -> dict[str, Any]:
    """Load existing manifest.yml file.

    Args:
        manifest_path: Path to manifest.yml

    Returns:
        Dictionary containing manifest data
    """
    if not manifest_path.exists():
        logger.warning(f"Manifest not found: {manifest_path}, creating new one")
        return {
            "shared_files": [],
            "template_variables": [],
            "sync_config": {
                "backup_changed_files": True,
                "create_directories": True,
                "preserve_permissions": True,
            },
        }

    with open(manifest_path) as f:
        result = yaml.safe_load(f)
        return result if result is not None else {}


def save_manifest(manifest_path: Path, manifest_data: dict) -> None:
    """Save manifest data to file.

    Args:
        manifest_path: Path to manifest.yml
        manifest_data: Dictionary containing manifest data
    """
    with open(manifest_path, "w") as f:
        yaml.dump(manifest_data, f, default_flow_style=False, sort_keys=False)
    logger.info(f"Manifest saved: {manifest_path}")


def update_manifest(
    templates_dir: Path, manifest_path: Path, dry_run: bool = False
) -> dict[str, list[str]]:
    """Update manifest.yml with Genesis source files.

    Discovers Genesis source files, syncs them to templates/shared/,
    and updates manifest.yml with hash tracking.

    Args:
        templates_dir: Path to templates/shared directory
        manifest_path: Path to manifest.yml
        dry_run: If True, don't save changes or copy files

    Returns:
        Dictionary with 'added', 'removed', 'changed' file lists
    """
    # Load existing manifest
    manifest = load_manifest(manifest_path)

    # Find Genesis root (parent of templates_dir/../../)
    genesis_root = templates_dir.parent.parent

    # Discover Genesis source files
    source_files = discover_genesis_source_files(genesis_root)

    # Build lookup of existing entries (key by path, not source hash)
    existing_entries = {
        entry.get("path", entry.get("source")): entry
        for entry in manifest.get("shared_files", [])
    }

    # Track changes
    changes: dict[str, list[str]] = {"added": [], "removed": [], "changed": []}

    # Build new entries list
    new_entries = []
    processed_paths: set[str] = set()

    for source_file, needs_suffix in source_files:
        # Calculate relative path from genesis root
        relative_path = str(source_file.relative_to(genesis_root))
        processed_paths.add(relative_path)

        # Calculate source hash
        source_hash = calculate_file_hash(source_file)

        # Sync to templates directory if hash changed or new
        existing_entry = existing_entries.get(relative_path)

        if existing_entry and existing_entry.get("source_hash") == source_hash:
            # No change - keep existing entry
            new_entries.append(existing_entry)
        else:
            # Changed or new - sync file
            _ = sync_source_to_templates(
                source_file, genesis_root, templates_dir, needs_suffix, dry_run
            )

            # Build manifest entry
            entry = {
                "path": relative_path,
                "source_hash": source_hash,
                "sync": (
                    existing_entry.get("sync")
                    if existing_entry
                    else detect_sync_policy(source_file, genesis_root)
                ),
                "description": (
                    existing_entry.get("description")
                    if existing_entry
                    else generate_description(source_file, genesis_root)
                ),
            }

            if existing_entry:
                changes["changed"].append(relative_path)
            else:
                changes["added"].append(relative_path)

            new_entries.append(entry)

    # Find removed files (in manifest but not in source)
    for path in existing_entries:
        if path not in processed_paths:
            changes["removed"].append(path)

    # Update manifest
    manifest["shared_files"] = new_entries

    # Save if not dry run
    if not dry_run:
        save_manifest(manifest_path, manifest)

    return changes


def report_changes(changes: dict[str, list[str]]) -> None:
    """Print a report of changes to the console.

    Args:
        changes: Dictionary with 'added', 'removed', 'changed' file lists
    """
    if changes["added"]:
        print(f"\n✅ Added {len(changes['added'])} files:")
        for file in sorted(changes["added"]):
            print(f"  + {file}")

    if changes["removed"]:
        print(f"\n❌ Removed {len(changes['removed'])} files:")
        for file in sorted(changes["removed"]):
            print(f"  - {file}")

    if changes["changed"]:
        print(f"\n🔄 Changed {len(changes['changed'])} files:")
        for file in sorted(changes["changed"]):
            print(f"  ~ {file}")

    if not any(changes.values()):
        print("\n✨ No changes detected - manifest is up to date")


def main() -> int:
    """Main entry point for the script."""
    parser = argparse.ArgumentParser(
        description="Discover Genesis source files and sync to templates/shared/"
    )
    parser.add_argument(
        "--templates-dir",
        type=Path,
        default=Path("templates/shared"),
        help="Path to templates/shared directory (default: templates/shared)",
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=None,
        help="Path to manifest.yml (default: templates-dir/manifest.yml)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview changes without copying files or modifying manifest",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable verbose logging"
    )

    args = parser.parse_args()

    # Set up logging
    if args.verbose:
        logger.setLevel("DEBUG")

    # Determine manifest path
    manifest_path = args.manifest or (args.templates_dir / "manifest.yml")

    logger.info(f"Templates directory: {args.templates_dir}")
    logger.info(f"Manifest path: {manifest_path}")

    if args.dry_run:
        logger.info("DRY RUN MODE - no changes will be saved")

    # Update manifest
    try:
        changes = update_manifest(args.templates_dir, manifest_path, args.dry_run)
        report_changes(changes)
        return 0
    except Exception as e:
        logger.error(f"Error updating manifest: {e}", exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
