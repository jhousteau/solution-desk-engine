"""Genesis pull command implementation."""

import subprocess
import sys

import click

from genesis.core.errors import handle_error
from genesis.core.logger import get_logger

# Initialize logger
logger = get_logger(__name__)


@click.command()
@click.argument("remote", default="origin", required=False)
@click.argument("branch", required=False)
@click.option(
    "--rebase",
    "-r",
    is_flag=True,
    help="Use rebase instead of merge (equivalent to git pull --rebase)",
)
@click.option(
    "--force", "-f", is_flag=True, help="Force pull (equivalent to git pull --force)"
)
def pull(remote: str, branch: str, rebase: bool, force: bool) -> None:
    """Pull updates from remote repository.

    Args:
        remote: Remote name (default: origin)
        branch: Branch name (optional)
        rebase: Use rebase instead of merge
        force: Force pull
    """
    # Determine what we're pulling
    if branch:
        logger.info(f"Pulling {remote}/{branch}")
    else:
        logger.info(f"Pulling from {remote}")

    # Build git command
    cmd = ["git", "pull"]
    if rebase:
        cmd.append("--rebase")
    if force:
        cmd.append("--force")

    # Add remote and branch if specified
    if remote != "origin" or branch:
        cmd.append(remote)
        if branch:
            cmd.append(branch)

    try:
        # Execute git pull
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)

        # Handle output
        if result.stdout:
            click.echo(result.stdout.strip())

        if result.returncode != 0:
            if result.stderr:
                logger.error(f"Pull failed: {result.stderr.strip()}")
                click.echo(result.stderr.strip(), err=True)
            sys.exit(result.returncode)

        logger.info("Successfully pulled updates")

    except Exception as e:
        handle_error(RuntimeError(f"Failed to execute pull: {e}"))
        sys.exit(1)
