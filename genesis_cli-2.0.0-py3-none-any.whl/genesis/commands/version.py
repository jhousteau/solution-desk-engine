"""Version command implementation."""

import click

from genesis import __version__


@click.command()
def version() -> None:
    """Show version information."""
    click.echo(f"Genesis v{__version__}")
