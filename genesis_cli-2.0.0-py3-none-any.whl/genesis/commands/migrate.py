"""Genesis migrate command - Migrate existing Genesis projects to new sync.yml format."""

import hashlib
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

import click
import yaml

try:
    from genesis.core import get_logger

    logger = get_logger(__name__)
except ImportError:
    import logging

    logger = logging.getLogger(__name__)


class MigrationDetector:
    """Detects existing Genesis configuration and determines migration strategy."""

    @staticmethod
    def detect_migration_strategy(project_path: Path) -> tuple[str, dict]:
        """Detect project type and return migration strategy.

        Returns:
            Tuple of (strategy_name, metadata)
        """
        genesis_dir = project_path / ".genesis"
        sync_state_file = genesis_dir / "sync-state.json"
        sync_config_file = genesis_dir / "sync.yml"

        # Check if already migrated
        if sync_config_file.exists():
            return "already_migrated", {"config_file": sync_config_file}

        # Check for sync-state.json (most common case)
        if sync_state_file.exists():
            with open(sync_state_file) as f:
                sync_state = json.load(f)
            return "migrate_from_sync_state", {
                "sync_state": sync_state,
                "sync_state_file": sync_state_file,
            }

        # Check for partial Genesis configuration
        if genesis_dir.exists():
            has_scripts = (genesis_dir / "scripts").exists()
            has_manifest = (genesis_dir / "manifest.json").exists()

            if has_scripts or has_manifest:
                return "migrate_from_partial", {
                    "has_scripts": has_scripts,
                    "has_manifest": has_manifest,
                }

        # Check for legacy structure (pre-.genesis)
        legacy_indicators = [
            project_path / "scripts" / "setup.sh",
            project_path / "scripts" / "validate.sh",
            project_path / ".claude" / "commands",
            project_path / "Dockerfile",
        ]

        if any(indicator.exists() for indicator in legacy_indicators):
            return "migrate_from_legacy", {
                "legacy_files": [str(f) for f in legacy_indicators if f.exists()]
            }

        # No Genesis configuration detected
        return "no_genesis_config", {}


class CustomizationAnalyzer:
    """Analyzes user customizations to determine appropriate sync policies."""

    def __init__(self, project_path: Path, genesis_root: Path):
        self.project_path = project_path
        self.genesis_root = genesis_root

    def analyze_customizations(self, files_to_check: list[str]) -> dict[str, str]:
        """Analyze files for user customizations.

        Returns:
            Dictionary mapping file paths to sync policies
        """
        customizations = {}

        for file_path in files_to_check:
            full_path = self.project_path / file_path
            if not full_path.exists():
                continue

            template_source = self._map_to_template_source(file_path)
            if not template_source:
                # File doesn't have a template source, user-owned
                customizations[file_path] = "never"
                continue

            # Compare with template
            if self._file_matches_template(full_path, template_source):
                customizations[file_path] = "always"
            else:
                # File differs from template, user has customized
                customizations[file_path] = "local_override"

        return customizations

    def _map_to_template_source(self, file_path: str) -> Path | None:
        """Map a project file to its template source."""
        template_mappings = {
            "Dockerfile": "shared/Dockerfile.template",
            "docker-compose.yml": "shared/docker-compose.yml.template",
            ".pre-commit-config.yaml": "shared/.pre-commit-config.yaml",
            ".gitignore": "shared/.gitignore.template",
            "Makefile": "shared/Makefile.template",
            ".dockerignore": "shared/.dockerignore",
            "CLAUDE.md": "shared/CLAUDE.md.template",
        }

        # Direct mapping
        if file_path in template_mappings:
            template_file = (
                self.genesis_root / "templates" / template_mappings[file_path]
            )
            if template_file.exists():
                return template_file

        # Check Claude directories
        if file_path.startswith(".claude/"):
            template_file = self.genesis_root / "templates" / "shared" / file_path
            if template_file.exists():
                return template_file

        # Check Genesis scripts
        if file_path.startswith(".genesis/scripts/"):
            template_file = self.genesis_root / "templates" / "shared" / file_path
            if template_file.exists():
                return template_file

        return None

    def _file_matches_template(self, project_file: Path, template_file: Path) -> bool:
        """Check if project file matches its template source."""
        try:
            project_hash = self._calculate_file_hash(project_file)
            template_hash = self._calculate_file_hash(template_file)
            return project_hash == template_hash
        except Exception:
            return False

    def _calculate_file_hash(self, file_path: Path) -> str:
        """Calculate MD5 hash of file content."""
        try:
            with open(file_path, "rb") as f:
                return hashlib.md5(f.read()).hexdigest()
        except Exception:
            return ""


class VariableExtractor:
    """Extracts template variables from existing project files."""

    @staticmethod
    def extract_variables(project_path: Path) -> dict[str, str]:
        """Extract template variables from project files.

        Returns:
            Dictionary of template variables
        """
        variables = {
            "project_name": project_path.name,
            "module_name": project_path.name.replace("-", "_"),
        }

        # Extract from pyproject.toml
        pyproject_path = project_path / "pyproject.toml"
        if pyproject_path.exists():
            pyproject_vars = VariableExtractor._extract_from_pyproject(pyproject_path)
            variables.update(pyproject_vars)

        # Extract from docker-compose.yml
        compose_path = project_path / "docker-compose.yml"
        if compose_path.exists():
            compose_vars = VariableExtractor._extract_from_compose(compose_path)
            variables.update(compose_vars)

        # Extract from package.json
        package_path = project_path / "package.json"
        if package_path.exists():
            package_vars = VariableExtractor._extract_from_package_json(package_path)
            variables.update(package_vars)

        return variables

    @staticmethod
    def _extract_from_pyproject(pyproject_path: Path) -> dict[str, str]:
        """Extract variables from pyproject.toml."""
        variables = {}

        try:
            # Try tomllib first (Python 3.11+)
            try:
                import tomllib

                with open(pyproject_path, "rb") as f:
                    pyproject = tomllib.load(f)
            except ImportError:
                # Try tomli package
                try:
                    import tomli

                    with open(pyproject_path, "rb") as f:
                        pyproject = tomli.load(f)
                except ImportError:
                    # Try toml package as fallback
                    import toml

                    pyproject = toml.load(pyproject_path)

            # Extract author information
            tool_poetry = pyproject.get("tool", {}).get("poetry", {})
            if "authors" in tool_poetry and tool_poetry["authors"]:
                author_str = tool_poetry["authors"][0]
                if "<" in author_str and ">" in author_str:
                    name_part = author_str.split("<")[0].strip()
                    email_part = author_str.split("<")[1].split(">")[0].strip()
                    variables["author_name"] = name_part
                    variables["author_email"] = email_part
                else:
                    variables["author_name"] = author_str

            # Extract description
            if "description" in tool_poetry:
                variables["project_description"] = tool_poetry["description"]

            # Extract Python version requirement
            python_req = tool_poetry.get("dependencies", {}).get("python")
            if python_req:
                variables["python_version"] = python_req

        except Exception as e:
            logger.debug(f"Could not extract from pyproject.toml: {e}")

        return variables

    @staticmethod
    def _extract_from_compose(compose_path: Path) -> dict[str, str]:
        """Extract variables from docker-compose.yml."""
        variables = {}

        try:
            with open(compose_path) as f:
                compose_content = yaml.safe_load(f)

            # Extract subnet configuration
            networks = compose_content.get("networks", {})
            for _network_name, network_config in networks.items():
                if isinstance(network_config, dict):
                    ipam = network_config.get("ipam", {})
                    config_list = ipam.get("config", [])
                    if config_list and isinstance(config_list[0], dict):
                        subnet = config_list[0].get("subnet")
                        if subnet:
                            variables["docker_subnet"] = subnet
                            break

            # Extract service ports
            services = compose_content.get("services", {})
            for service_name, service_config in services.items():
                if isinstance(service_config, dict):
                    ports = service_config.get("ports", [])
                    if ports and isinstance(ports[0], str):
                        port_mapping = ports[0].split(":")
                        if len(port_mapping) >= 2:
                            variables[f"{service_name}_port"] = port_mapping[0]
                            break

        except Exception as e:
            logger.debug(f"Could not extract from docker-compose.yml: {e}")

        return variables

    @staticmethod
    def _extract_from_package_json(package_path: Path) -> dict[str, str]:
        """Extract variables from package.json."""
        variables = {}

        try:
            with open(package_path) as f:
                package_data = json.load(f)

            # Extract basic info
            if "description" in package_data:
                variables["project_description"] = package_data["description"]

            if "author" in package_data:
                author = package_data["author"]
                if isinstance(author, str):
                    variables["author_name"] = author
                elif isinstance(author, dict):
                    if "name" in author:
                        variables["author_name"] = author["name"]
                    if "email" in author:
                        variables["author_email"] = author["email"]

        except Exception as e:
            logger.debug(f"Could not extract from package.json: {e}")

        return variables


class MigrationExecutor:
    """Executes the migration process."""

    def __init__(self, project_path: Path, genesis_root: Path):
        self.project_path = project_path
        self.genesis_root = genesis_root
        self.analyzer = CustomizationAnalyzer(project_path, genesis_root)

    def migrate_from_sync_state(
        self, sync_state: dict, dry_run: bool = False, create_backup: bool = True
    ) -> dict:
        """Migrate from sync-state.json to sync.yml.

        Returns:
            Migration report dictionary
        """
        logger.info("🔄 Migrating from sync-state.json to sync.yml format")

        # Extract project type from sync state or detect it
        project_type = self._detect_project_type_from_sync_state(sync_state)

        # Extract variables from existing files
        variables = VariableExtractor.extract_variables(self.project_path)

        # Analyze existing files for customizations
        files_to_analyze = self._get_files_from_sync_state(sync_state)
        customizations = self.analyzer.analyze_customizations(files_to_analyze)

        # Generate sync.yml configuration
        sync_config = self._generate_sync_config(
            project_type, variables, customizations
        )

        # Create backup if requested
        backup_path = None
        if create_backup and not dry_run:
            backup_path = self._create_backup()

        # Write new configuration
        if not dry_run:
            self._write_sync_config(sync_config)

            # Archive old sync-state.json
            sync_state_file = self.project_path / ".genesis" / "sync-state.json"
            if sync_state_file.exists():
                archived_file = (
                    self.project_path / ".genesis" / "sync-state.json.migrated"
                )
                shutil.move(str(sync_state_file), str(archived_file))
                logger.info(f"📦 Archived old sync-state.json to {archived_file}")

        return {
            "strategy": "migrate_from_sync_state",
            "project_type": project_type,
            "variables_extracted": len(variables),
            "files_analyzed": len(customizations),
            "customizations_found": len(
                [f for f, p in customizations.items() if p == "local_override"]
            ),
            "backup_created": backup_path,
            "dry_run": dry_run,
        }

    def migrate_from_partial(
        self, metadata: dict, dry_run: bool = False, create_backup: bool = True
    ) -> dict:
        """Migrate from partial Genesis configuration.

        Returns:
            Migration report dictionary
        """
        logger.info("🔄 Migrating from partial Genesis configuration")

        # Detect project type
        project_type = self._detect_project_type()

        # Extract variables
        variables = VariableExtractor.extract_variables(self.project_path)

        # Analyze existing Genesis files
        genesis_files = self._scan_genesis_files()
        customizations = self.analyzer.analyze_customizations(genesis_files)

        # Generate sync.yml configuration
        sync_config = self._generate_sync_config(
            project_type, variables, customizations
        )

        # Create backup if requested
        backup_path = None
        if create_backup and not dry_run:
            backup_path = self._create_backup()

        # Write new configuration
        if not dry_run:
            self._write_sync_config(sync_config)

        return {
            "strategy": "migrate_from_partial",
            "project_type": project_type,
            "variables_extracted": len(variables),
            "files_analyzed": len(customizations),
            "backup_created": backup_path,
            "dry_run": dry_run,
        }

    def migrate_from_legacy(
        self, metadata: dict, dry_run: bool = False, create_backup: bool = True
    ) -> dict:
        """Migrate from legacy project structure.

        Returns:
            Migration report dictionary
        """
        logger.info("🔄 Migrating from legacy project structure")

        # Detect project type
        project_type = self._detect_project_type()

        # Extract variables
        variables = VariableExtractor.extract_variables(self.project_path)

        # Analyze legacy files
        legacy_files = metadata.get("legacy_files", [])
        relative_files = [
            str(Path(f).relative_to(self.project_path)) for f in legacy_files
        ]
        customizations = self.analyzer.analyze_customizations(relative_files)

        # Generate sync.yml configuration
        sync_config = self._generate_sync_config(
            project_type, variables, customizations
        )

        # Create backup if requested
        backup_path = None
        if create_backup and not dry_run:
            backup_path = self._create_backup()

        # Create .genesis directory and write configuration
        if not dry_run:
            (self.project_path / ".genesis").mkdir(exist_ok=True)
            self._write_sync_config(sync_config)

        return {
            "strategy": "migrate_from_legacy",
            "project_type": project_type,
            "variables_extracted": len(variables),
            "files_analyzed": len(customizations),
            "backup_created": backup_path,
            "dry_run": dry_run,
        }

    def _detect_project_type_from_sync_state(self, sync_state: dict) -> str:
        """Detect project type from sync state or project structure."""
        # Check if stored in sync state
        if "project_type" in sync_state:
            project_type = sync_state["project_type"]
            return str(project_type) if project_type else "python-api"

        return self._detect_project_type()

    def _detect_project_type(self) -> str:
        """Auto-detect project type from project structure."""
        # Import the detector from init command
        from genesis.commands.init import ProjectDetector

        project_type, _ = ProjectDetector.detect_project_type(self.project_path)
        return project_type if project_type != "unknown" else "python-api"

    def _get_files_from_sync_state(self, sync_state: dict) -> list[str]:
        """Extract file list from sync state."""
        files = []

        # Get files from sync state
        sync_files = sync_state.get("files", {})
        files.extend(sync_files.keys())

        # Add common Genesis files
        common_files = [
            "Dockerfile",
            "docker-compose.yml",
            ".pre-commit-config.yaml",
            ".gitignore",
            "Makefile",
            ".dockerignore",
            "CLAUDE.md",
        ]

        for file_path in common_files:
            if (self.project_path / file_path).exists() and file_path not in files:
                files.append(file_path)

        return files

    def _scan_genesis_files(self) -> list[str]:
        """Scan for existing Genesis-managed files."""
        files = []
        genesis_dir = self.project_path / ".genesis"

        if genesis_dir.exists():
            for file_path in genesis_dir.rglob("*"):
                if file_path.is_file():
                    relative_path = str(file_path.relative_to(self.project_path))
                    files.append(relative_path)

        # Add Claude directory if it exists
        claude_dir = self.project_path / ".claude"
        if claude_dir.exists():
            for file_path in claude_dir.rglob("*"):
                if file_path.is_file():
                    relative_path = str(file_path.relative_to(self.project_path))
                    files.append(relative_path)

        return files

    def _generate_sync_config(
        self,
        project_type: str,
        variables: dict[str, str],
        customizations: dict[str, str],
    ) -> dict[str, Any]:
        """Generate sync.yml configuration."""
        from genesis.commands.init import SyncConfigGenerator

        # Generate base configuration
        config = SyncConfigGenerator.generate_sync_config(
            project_type, variables, self.project_path
        )

        # Override sync policies based on customizations
        for file_config in config["files"]:
            pattern = file_config["pattern"]
            if pattern in customizations:
                file_config["sync"] = customizations[pattern]
                if customizations[pattern] == "local_override":
                    file_config["description"] += " (user customized)"

        # Convert files array to sync_policies array format
        sync_policies = []
        for file_config in config["files"]:
            sync_policies.append(
                {
                    "source": file_config["pattern"],
                    "dest": file_config["pattern"],
                    "policy": file_config["sync"],
                    "description": file_config["description"],
                }
            )

        config["sync_policies"] = sync_policies
        del config["files"]

        return config

    def _write_sync_config(self, config: dict) -> None:
        """Write sync.yml configuration to disk."""
        from genesis.commands.init import SyncConfigGenerator

        sync_config_path = self.project_path / ".genesis" / "sync.yml"
        yaml_content = SyncConfigGenerator.add_helpful_comments(config)

        sync_config_path.parent.mkdir(exist_ok=True)
        sync_config_path.write_text(yaml_content)

        logger.info(f"✅ Created Genesis sync configuration at {sync_config_path}")

    def _create_backup(self) -> Path | None:
        """Create backup of existing configuration."""
        genesis_dir = self.project_path / ".genesis"
        if not genesis_dir.exists():
            return None

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = self.project_path / f".genesis.backup.{timestamp}"

        try:
            shutil.copytree(genesis_dir, backup_dir)
            logger.info(f"📦 Created backup at {backup_dir}")
            return backup_dir
        except Exception as e:
            logger.warning(f"⚠️  Could not create backup: {e}")
            return None


def generate_migration_report(report_data: dict) -> str:
    """Generate human-readable migration report."""
    lines = [
        "🔄 Genesis Migration Report",
        "=" * 50,
        "",
        f"Strategy: {report_data['strategy']}",
        f"Project Type: {report_data['project_type']}",
        f"Variables Extracted: {report_data['variables_extracted']}",
        f"Files Analyzed: {report_data['files_analyzed']}",
    ]

    if "customizations_found" in report_data:
        lines.append(f"User Customizations: {report_data['customizations_found']}")

    if report_data.get("backup_created"):
        lines.append(f"Backup Created: {report_data['backup_created']}")

    if report_data.get("dry_run"):
        lines.extend(
            [
                "",
                "⚠️  This was a dry run - no changes were made",
                "Run without --dry-run to perform the migration",
            ]
        )
    else:
        lines.extend(
            [
                "",
                "✅ Migration completed successfully!",
                "",
                "Next steps:",
                "1. Review the generated .genesis/sync.yml configuration",
                "2. Customize sync policies as needed",
                "3. Run 'genesis sync' to synchronize files from templates",
            ]
        )

    return "\n".join(lines)


@click.command()
@click.option(
    "--dry-run", is_flag=True, help="Show what would be migrated without making changes"
)
@click.option(
    "--backup/--no-backup",
    default=True,
    help="Create backup of existing configuration before migration",
)
@click.option(
    "--force", is_flag=True, help="Force migration even if sync.yml already exists"
)
def migrate(dry_run: bool, backup: bool, force: bool) -> None:
    """Migrate existing Genesis project to new sync.yml configuration format.

    This command converts old sync-state.json configurations to the new
    explicit sync.yml format introduced in Genesis 0.12.0. It preserves
    user customizations and automatically detects the appropriate migration
    strategy based on the current project state.

    Migration strategies:
    - sync-state.json → sync.yml (most common)
    - Partial Genesis config → sync.yml
    - Legacy structure → sync.yml
    """
    project_path = Path.cwd()

    # Find Genesis root
    try:
        # Look for Genesis in several locations
        possible_paths = [
            Path(__file__).parent.parent.parent,  # From this file
            Path.cwd().parent.parent,  # From worktree
            Path.home() / "projects" / "genesis",  # Common location
        ]

        genesis_root = None
        for path in possible_paths:
            if (path / "templates").exists() and (path / "genesis").exists():
                genesis_root = path
                break

        if not genesis_root:
            raise FileNotFoundError("Could not find Genesis root directory")

    except Exception as e:
        logger.error(f"❌ Could not locate Genesis installation: {e}")
        raise click.ClickException("Genesis installation not found") from e

    # Detect migration strategy
    strategy, metadata = MigrationDetector.detect_migration_strategy(project_path)

    if strategy == "already_migrated" and not force:
        logger.error(
            f"❌ Project already has sync.yml configuration at {metadata['config_file']}\n"
            f"   Use --force to overwrite existing configuration"
        )
        raise click.ClickException(
            "Project already migrated. Use --force to overwrite."
        )

    if strategy == "no_genesis_config":
        logger.error(
            "❌ No Genesis configuration detected in this project\n"
            "   Run 'genesis init' to initialize a new Genesis project"
        )
        raise click.ClickException("No Genesis configuration found")

    # Initialize executor
    executor = MigrationExecutor(project_path, genesis_root)

    # Execute migration based on strategy
    if dry_run:
        logger.info("🔍 Performing dry run - no changes will be made")

    try:
        if strategy == "migrate_from_sync_state":
            report_data = executor.migrate_from_sync_state(
                metadata["sync_state"], dry_run=dry_run, create_backup=backup
            )
        elif strategy == "migrate_from_partial":
            report_data = executor.migrate_from_partial(
                metadata, dry_run=dry_run, create_backup=backup
            )
        elif strategy == "migrate_from_legacy":
            report_data = executor.migrate_from_legacy(
                metadata, dry_run=dry_run, create_backup=backup
            )
        elif strategy == "already_migrated" and force:
            # Force re-migration by treating as partial config
            report_data = executor.migrate_from_partial(
                {}, dry_run=dry_run, create_backup=backup
            )
        else:
            raise click.ClickException(f"Unknown migration strategy: {strategy}")

        # Generate and display report
        report = generate_migration_report(report_data)
        click.echo(report)

    except Exception as e:
        logger.error(f"❌ Migration failed: {e}")
        raise click.ClickException(f"Migration failed: {e}") from e


# Export for CLI registration
migrate_command = migrate
