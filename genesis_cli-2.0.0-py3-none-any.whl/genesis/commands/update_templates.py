"""Update templates command - orchestrates template discovery and manifest updates."""

from pathlib import Path

import click

from genesis.core import get_logger
from genesis.core.path_discovery import discover_genesis_templates_path
from genesis.core.template_discovery import (
    report_changes,
)
from genesis.core.template_discovery import (
    update_manifest as discover_update_manifest,
)

logger = get_logger(__name__)


@click.command("update-templates")
@click.option(
    "--dry-run",
    is_flag=True,
    help="Preview changes without modifying manifest.yml",
)
@click.option(
    "--templates-dir",
    type=click.Path(exists=True, file_okay=False),
    default=None,
    help="Path to templates/shared directory (auto-detected if not specified)",
)
@click.option(
    "--manifest",
    type=click.Path(),
    default=None,
    help="Path to manifest.yml (default: templates-dir/manifest.yml)",
)
def update_templates(
    dry_run: bool, templates_dir: str | None, manifest: str | None
) -> None:
    """Update templates/shared/manifest.yml with discovered template files.

    This command scans templates/shared/ directory, discovers all template files,
    calculates their SHA-256 hashes, detects appropriate sync policies, and updates
    manifest.yml accordingly.

    Features:
    - Automatic file discovery
    - SHA-256 hash calculation
    - Sync policy detection (always/never/if_unchanged)
    - Preserves custom descriptions
    - Reports added/removed/changed files

    Examples:
        genesis update-templates
        genesis update-templates --dry-run
        genesis update-templates --templates-dir /path/to/templates/shared
    """
    try:
        # Convert string paths to Path objects
        templates_dir_path: Path | None = Path(templates_dir) if templates_dir else None
        manifest_path_arg: Path | None = Path(manifest) if manifest else None

        # Auto-discover templates directory if not specified
        if not templates_dir_path:
            genesis_templates = discover_genesis_templates_path()
            if not genesis_templates:
                logger.error("Could not discover Genesis templates directory")
                click.echo(
                    "❌ Could not find templates directory. "
                    "Use --templates-dir to specify manually.",
                    err=True,
                )
                raise click.Abort()

            templates_dir_path = genesis_templates / "shared"
            if not templates_dir_path.exists():
                logger.error(
                    f"Shared templates directory not found: {templates_dir_path}"
                )
                click.echo(
                    f"❌ Shared templates directory not found: {templates_dir_path}",
                    err=True,
                )
                raise click.Abort()

        # Determine manifest path
        manifest_path = manifest_path_arg or (templates_dir_path / "manifest.yml")

        logger.info(f"Templates directory: {templates_dir_path}")
        logger.info(f"Manifest path: {manifest_path}")

        if dry_run:
            logger.info("DRY RUN MODE - no changes will be saved")
            click.echo("🔍 DRY RUN MODE - previewing changes without modifying files\n")

        # Run manifest update
        changes = discover_update_manifest(templates_dir_path, manifest_path, dry_run)

        # Report changes
        report_changes(changes)

        # Summary
        total_changes = sum(len(v) for v in changes.values())
        if total_changes > 0:
            if dry_run:
                click.echo(
                    f"\n📋 Preview complete: {total_changes} changes detected "
                    "(run without --dry-run to apply)"
                )
            else:
                click.echo(
                    f"\n✅ Manifest updated successfully with {total_changes} changes"
                )
        else:
            click.echo("\n✨ No changes needed - manifest is up to date")

    except Exception as e:
        logger.error(f"Failed to update templates: {e}", exc_info=True)
        click.echo(f"❌ Failed to update templates: {e}", err=True)
        raise click.Abort() from e
