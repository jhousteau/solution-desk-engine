"""Genesis sync command - Simple template-driven file synchronization.

This command reads configuration from .genesis/sync.yml and uses TemplateManager
to synchronize files according to user-defined policies.
"""

import difflib
import hashlib
import json
import os
import threading
import time
from pathlib import Path
from typing import Any

import click
import yaml
from jinja2 import Template

try:
    from genesis.core import get_logger

    logger = get_logger(__name__)
except ImportError:
    import logging

    logger = logging.getLogger(__name__)

from genesis.core.constants import EnvironmentDefaults
from genesis.core.hash_utils import hashes_match
from genesis.core.path_discovery import discover_shared_templates_path
from genesis.core.templates import get_template_manager


class SyncManager:
    """Simple template-driven sync manager that reads configuration from .genesis/sync.yml."""

    def __init__(
        self,
        project_path: Path,
        force: bool = False,
        dry_run: bool = False,
        preview: bool = False,
        files: list[str] | None = None,
        exclude: list[str] | None = None,
        reset: bool = False,
        verbose: bool = False,
        template_manager: Any = None,
    ):
        """Initialize the sync manager.

        Args:
            project_path: Path to the project directory
            force: Force sync all files regardless of policy
            dry_run: Show what would be synced without making changes
            preview: Show detailed diff of changes without applying them
            files: Sync only specific files (multiple values allowed)
            exclude: Exclude files from sync (multiple values allowed)
            reset: Reset files to template defaults (ignore policies)
            verbose: Show detailed processing information
            template_manager: Optional custom TemplateManager instance
        """
        self.project_path = Path(project_path)
        self.force = force
        self.dry_run = dry_run
        self.preview = preview
        self.files = files or []
        self.exclude = exclude or []
        self.reset = reset
        self.verbose = verbose
        self.config_path = self.project_path / ".genesis" / "sync.yml"
        self.template_manager = template_manager or get_template_manager()

        # Track sync results
        self.synced_files: list[str] = []
        self.skipped_files: list[str] = []
        self.errors: list[str] = []
        self.diffs: list[tuple[str, str]] = []  # Store diffs for preview mode
        self.config: dict[str, Any] | None = None  # Store loaded configuration

        # Thread safety for concurrent operations
        self._lock = threading.RLock()
        self._file_locks: dict[str, threading.RLock] = {}  # Per-file locks

        # Checksum cache for tracking file modifications
        self.checksum_cache_path = (
            self.project_path / ".genesis" / ".sync_checksums.json"
        )
        self.checksum_cache = self._load_checksum_cache()

        # Source hash cache from manifest.yml (Phase 2 optimization)
        self.source_hashes: dict[str, str] = {}  # Maps source -> hash

    @property
    def should_modify_files(self) -> bool:
        """Check if we should actually modify files (not in dry-run or preview mode)."""
        return not self.dry_run and not self.preview

    def _log_verbose(self, message: str) -> None:
        """Log message only in verbose mode."""
        if self.verbose:
            logger.info(message)

    def _echo_verbose(self, message: str) -> None:
        """Echo message only in verbose mode."""
        if self.verbose:
            click.echo(message)

    def _get_file_lock(self, dest_path: str) -> threading.RLock:
        """Get or create a lock for a specific file."""
        with self._lock:
            if dest_path not in self._file_locks:
                self._file_locks[dest_path] = threading.RLock()
            return self._file_locks[dest_path]

    def _safe_path_resolve(self, dest_path: Path) -> Path:
        """Safely resolve path, preventing directory traversal attacks."""
        try:
            resolved = dest_path.resolve()
            # Ensure the resolved path is within the project directory
            project_resolved = self.project_path.resolve()
            try:
                resolved.relative_to(project_resolved)
                return resolved
            except ValueError:
                # Path is outside project directory - sanitize it
                logger.warning(f"Path {dest_path} outside project, using safe fallback")
                return project_resolved / dest_path.name
        except Exception as e:
            logger.error(f"Path resolution failed for {dest_path}: {e}")
            # Fallback to a safe path within project
            return self.project_path / "safe_fallback.txt"

    def load_config(self) -> dict[str, Any]:
        """Load sync configuration from .genesis/manifest.yml or .genesis/sync.yml.

        Tries to load from manifest.yml first (new format with hashes).
        Falls back to sync.yml if manifest.yml doesn't exist (backward compatibility).

        Returns:
            Configuration dictionary

        Raises:
            FileNotFoundError: If neither config file exists
            yaml.YAMLError: If config file is invalid
        """
        # Try loading from manifest.yml first (Phase 2 optimization)
        manifest_config = self._load_from_manifest()
        if manifest_config is not None:
            self.config = manifest_config
            # Populate source_hashes from manifest for performance optimization
            self._populate_source_hashes_from_config(manifest_config)
            return manifest_config

        # Fall back to sync.yml (backward compatibility)
        self._verify_config_exists()
        config = self._parse_config_file()
        self._validate_config(config)
        self.config = config  # Store for later access
        return config

    def _verify_config_exists(self) -> None:
        """Check that sync configuration file exists."""
        if not self.config_path.exists():
            raise FileNotFoundError(
                f"Sync configuration not found: {self.config_path}\n"
                f"Run 'genesis init' or 'genesis migrate' to create configuration."
            )

        # Show deprecation warning if using sync.yml
        self._show_deprecation_warning_if_needed()

    def _show_deprecation_warning_if_needed(self) -> None:
        """Show deprecation warning if using sync.yml instead of manifest.yml."""
        manifest_path = self.project_path / ".genesis" / "manifest.yml"

        # Only show warning if sync.yml exists but manifest.yml doesn't
        if self.config_path.exists() and not manifest_path.exists():
            logger.warning(
                "⚠️  DEPRECATION: sync.yml is deprecated and will be removed in a future version."
            )
            logger.warning(
                "    Please migrate to manifest.yml using: genesis migrate-sync"
            )
            logger.warning(
                "    The new manifest.yml format provides hash-based sync optimization."
            )

    def _parse_config_file(self) -> dict[str, Any]:
        """Parse the YAML configuration file."""
        try:
            with open(self.config_path) as f:
                config = yaml.safe_load(f)
            result: dict[str, Any] = config
            return result
        except yaml.YAMLError as e:
            # Re-raise the original error to preserve "while parsing" message for tests
            raise e

    def _validate_config(self, config: dict[str, Any]) -> None:
        """Validate configuration structure and required fields."""
        if not isinstance(config, dict):
            raise yaml.YAMLError("Configuration must be a dictionary")

        if "template_source" not in config:
            raise yaml.YAMLError(
                "Configuration missing required field: template_source"
            )

        # Support both old and new formats
        if "sync_policies" not in config and "files" not in config:
            raise yaml.YAMLError(
                "Configuration missing required field: sync_policies or files"
            )

    def _load_from_manifest(self) -> dict[str, Any] | None:
        """Load sync configuration from .genesis/manifest.yml.

        This method implements hash-based sync optimization by loading source file hashes
        from manifest.yml. The manifest format is converted to sync.yml format for
        backward compatibility with existing code.

        Performance Benefits:
            - Hash-based change detection avoids expensive template fetches
            - Files with matching hashes are skipped immediately
            - Reduces I/O operations significantly for unchanged files

        Format Conversion:
            Manifest format (input):
                shared_files:
                  - source: file.template
                    dest: file
                    sync: always
                    source_hash: sha256:abc123...

            Sync format (output):
                template_source: shared
                files:
                  - source: file.template
                    dest: file
                    policy: always
                    source_hash: sha256:abc123...

        Returns:
            Configuration dictionary in sync.yml format, or None if manifest doesn't exist

        Note:
            This method is called before falling back to sync.yml, enabling seamless
            migration from sync.yml to manifest.yml without breaking existing projects.
        """
        manifest_path = self.project_path / ".genesis" / "manifest.yml"

        if not manifest_path.exists():
            self._log_verbose("📄 No manifest.yml found, falling back to sync.yml")
            return None

        try:
            with open(manifest_path) as f:
                manifest_data = yaml.safe_load(f)

            if not isinstance(manifest_data, dict):
                logger.warning("manifest.yml is not a valid dictionary")
                return None

            # Convert manifest format to sync format
            config: dict[str, Any] = {
                "template_source": "shared",  # Manifest files are from shared templates
                "files": [],  # Use 'files' list (new format)
            }

            # Convert shared_files to files list
            shared_files = manifest_data.get("shared_files", [])
            for file_entry in shared_files:
                converted_entry = self._convert_manifest_entry(file_entry)
                config["files"].append(converted_entry)

            logger.info(f"📋 Loaded {len(config['files'])} files from manifest.yml")
            return config

        except yaml.YAMLError as e:
            logger.warning(f"Failed to parse manifest.yml: {e}")
            return None
        except Exception as e:
            logger.warning(f"Unexpected error loading manifest.yml: {e}")
            return None

    def _convert_manifest_entry(self, file_entry: dict[str, Any]) -> dict[str, Any]:
        """Convert a single manifest file entry to sync format.

        Args:
            file_entry: File entry from manifest.yml

        Returns:
            Converted entry in sync.yml format
        """
        # Handle both manifest formats:
        # 1. New format with 'source' and 'dest' fields
        # 2. Legacy format with 'path' field (used as both source and dest)
        source = file_entry.get("source")
        dest = file_entry.get("dest")

        # If source/dest not present, check for 'path' field
        if not source and not dest:
            path = file_entry.get("path")
            if path:
                source = path
                dest = path

        converted_entry = {
            "source": source,
            "dest": dest,
            "policy": file_entry.get(
                "sync", "if_unchanged"
            ),  # Convert 'sync' to 'policy'
        }

        # Preserve source_hash if present (for performance optimization)
        if "source_hash" in file_entry:
            converted_entry["source_hash"] = file_entry["source_hash"]

        # Preserve description if present
        if "description" in file_entry:
            converted_entry["description"] = file_entry["description"]

        # Preserve executable flag if present
        if "executable" in file_entry:
            converted_entry["executable"] = file_entry["executable"]

        return converted_entry

    def _populate_source_hashes_from_config(self, config: dict[str, Any]) -> None:
        """Populate source_hashes dictionary from configuration.

        This enables hash-based optimization for detecting unchanged files.

        Args:
            config: Configuration dictionary with file entries
        """
        # Support both 'files' (new format) and 'sync_policies' (old format)
        file_entries = config.get("files", config.get("sync_policies", []))

        for entry in file_entries:
            source = entry.get("source")
            source_hash = entry.get("source_hash")

            if source and source_hash:
                self.source_hashes[source] = source_hash
                self._log_verbose(f"📌 Loaded hash for {source}: {source_hash[:20]}...")

        if self.source_hashes:
            logger.debug(
                f"Loaded {len(self.source_hashes)} source hashes from configuration"
            )

    def _should_sync_file_hash(self, source: str, dest_path: Path, policy: str) -> bool:
        """Determine if a file should be synced using hash-based optimization.

        This method provides significant performance improvements by checking
        file hashes before fetching templates from storage.

        Args:
            source: Source template path
            dest_path: Destination file path
            policy: Sync policy

        Returns:
            True if file should be synced, False if can be skipped
        """
        # If file doesn't exist, always sync
        if not dest_path.exists():
            return True

        # If no hash available for this source, fall back to regular policy check
        if source not in self.source_hashes:
            return self._should_sync_file_policy(dest_path, policy)

        # Hash-based optimization: check if destination matches source hash
        expected_hash = self.source_hashes[source]
        if hashes_match(dest_path, expected_hash):
            # File matches source hash - can skip sync
            self._log_verbose(f"⚡ Hash match, skipping: {dest_path.name}")
            return False

        # Hash mismatch - need to sync
        self._log_verbose(f"🔄 Hash mismatch, syncing: {dest_path.name}")
        return True

    def validate_file_filters(self, config: dict[str, Any]) -> None:
        """Validate that specified files exist in the sync policies.

        Args:
            config: Sync configuration

        Raises:
            click.ClickException: If specified files are not found in sync policies
        """
        if not self.files:
            return

        # Support both old and new formats
        # Old format: sync_policies is a list of file configs
        # New format: files is a list, sync_policies is settings dict
        if "files" in config and isinstance(config["files"], list):
            sync_policies = config["files"]
        else:
            sync_policies = config.get("sync_policies", [])
        available_files = {policy["dest"] for policy in sync_policies}

        invalid_files = [f for f in self.files if f not in available_files]
        if invalid_files:
            available_list = "\n".join(f"  • {f}" for f in sorted(available_files))
            invalid_list = "\n".join(f"  • {f}" for f in invalid_files)
            raise click.ClickException(
                f"Invalid file names specified:\n{invalid_list}\n\n"
                f"Available files:\n{available_list}"
            )

    def should_sync_file(
        self, dest_file: str | Path, policy: str | None = None
    ) -> bool:
        """Determine if a file should be synced based on filters and policy.

        Args:
            dest_file: Destination file path (string or Path object)
            policy: Optional sync policy to check

        Returns:
            True if file should be synced, False otherwise
        """
        # Handle Path objects by converting to string
        if isinstance(dest_file, Path):
            dest_file_str = (
                str(dest_file.relative_to(self.project_path))
                if dest_file.is_absolute()
                else str(dest_file)
            )
            dest_path = (
                dest_file if dest_file.is_absolute() else self.project_path / dest_file
            )
        else:
            dest_file_str = dest_file
            dest_path = self.project_path / dest_file

        # If specific files are requested, only sync those
        if self.files:
            return dest_file_str in self.files

        # If file is in exclude list, skip it
        if dest_file_str in self.exclude:
            self._log_verbose(f"🚫 Excluding file: {dest_file_str}")
            return False

        # If policy is specified, also check the sync policy
        if policy is not None:
            return self._should_sync_file_policy(dest_path, policy)

        return True

    def generate_diff(self, dest_path: Path, new_content: str) -> str | None:
        """Generate a colored diff between current and new content.

        Args:
            dest_path: Path to destination file
            new_content: New content from template

        Returns:
            Colored diff string, or None if files are identical
        """
        if not dest_path.exists():
            # New file - show all lines as additions
            lines = new_content.splitlines(keepends=True)
            diff_lines = [f"\033[32m+{line}\033[0m" for line in lines]
            return "".join(diff_lines)

        current_content = dest_path.read_text()
        if current_content == new_content:
            return None  # No changes

        current_lines = current_content.splitlines(keepends=True)
        new_lines = new_content.splitlines(keepends=True)

        # Generate unified diff
        diff = difflib.unified_diff(
            current_lines,
            new_lines,
            fromfile=f"a/{dest_path.name}",
            tofile=f"b/{dest_path.name}",
            lineterm="",
        )

        # Color the diff output
        colored_lines = []
        for line in diff:
            if line.startswith("+++") or line.startswith("---"):
                colored_lines.append(f"\033[1m{line}\033[0m")  # Bold
            elif line.startswith("@@"):
                colored_lines.append(f"\033[36m{line}\033[0m")  # Cyan
            elif line.startswith("+"):
                colored_lines.append(f"\033[32m{line}\033[0m")  # Green
            elif line.startswith("-"):
                colored_lines.append(f"\033[31m{line}\033[0m")  # Red
            else:
                colored_lines.append(line)

        return "\n".join(colored_lines)

    def get_template_variables(self) -> dict[str, str]:
        """Extract template variables from project files.

        Returns:
            Dictionary of template variables
        """
        variables = self._get_basic_variables()
        variables.update(self._get_project_file_variables())
        variables.update(self._get_environment_variables())

        # Recalculate module_name based on the final project_name
        # (which might have been updated from pyproject.toml)
        if "project_name" in variables:
            variables["module_name"] = variables["project_name"].replace("-", "_")

        return variables

    def _get_basic_variables(self) -> dict[str, str]:
        """Get basic project variables from directory name."""
        project_name = self.project_path.name
        return {
            "project_name": project_name,
            "module_name": project_name.replace("-", "_"),
            "app_port": str(self._generate_port(project_name)),
            "subnet_octet": str(self._generate_octet(project_name)),
        }

    def _get_project_file_variables(self) -> dict[str, str]:
        """Extract variables from project files (pyproject.toml, package.json)."""
        variables = {}

        # Try pyproject.toml first
        pyproject_vars = self._extract_pyproject_variables()
        if pyproject_vars:
            variables.update(pyproject_vars)
            return variables

        # Fall back to package.json
        package_vars = self._extract_package_json_variables()
        if package_vars:
            variables.update(package_vars)

        return variables

    def _extract_pyproject_variables(self) -> dict[str, str]:
        """Extract variables from pyproject.toml."""
        pyproject_path = self.project_path / "pyproject.toml"
        if not pyproject_path.exists():
            return {}

        try:
            import tomllib

            with open(pyproject_path, "rb") as f:
                pyproject = tomllib.load(f)

            if "tool" not in pyproject or "poetry" not in pyproject["tool"]:
                return {}

            poetry = pyproject["tool"]["poetry"]
            variables = {
                "project_name": poetry.get("name", self.project_path.name),
                "project_description": poetry.get("description", ""),
                "project_version": poetry.get("version", "0.1.0"),
            }

            # Extract Python version
            deps = poetry.get("dependencies", {})
            python_req = deps.get("python", "^3.11")
            import re

            match = re.search(r"(\d+\.\d+)", python_req)
            variables["python_version"] = match.group(1) if match else "3.11"

            return variables

        except Exception as e:
            logger.debug(f"Could not parse pyproject.toml: {e}")
            return {}

    def _extract_package_json_variables(self) -> dict[str, str]:
        """Extract variables from package.json."""
        package_path = self.project_path / "package.json"
        if not package_path.exists():
            return {}

        try:
            import json

            with open(package_path) as f:
                package = json.load(f)

            return {
                "project_name": package.get("name", self.project_path.name),
                "project_description": package.get("description", ""),
                "project_version": package.get("version", "0.1.0"),
            }

        except Exception as e:
            logger.debug(f"Could not parse package.json: {e}")
            return {}

    def _get_environment_variables(self) -> dict[str, str]:
        """Get variables from environment."""
        # Import version dynamically to avoid circular imports
        try:
            from genesis.version import get_version

            default_version = get_version()
        except ImportError:
            default_version = "1.5.0"

        return {
            "github_user": os.environ.get(
                "GITHUB_USER", EnvironmentDefaults.DEFAULT_GITHUB_USER
            ),
            "genesis_version": os.environ.get("GENESIS_VERSION", default_version),
        }

    def _generate_port(self, project_name: str, base: int | None = None) -> int:
        """Generate a deterministic port number from project name."""
        if base is None:
            base = int(
                os.environ.get(
                    "GENESIS_DEFAULT_PORT_BASE", EnvironmentDefaults.DEFAULT_PORT_BASE
                )
            )
        # Simple hash to generate port offset
        hash_val = abs(hash(project_name)) % 1000
        return base + hash_val

    def _generate_octet(self, project_name: str) -> int:
        """Generate a deterministic subnet octet from project name."""
        # Generate octet between 1-254
        hash_val = abs(hash(project_name)) % 254
        return hash_val + 1

    def _should_sync_file_policy(self, dest_path: Path, policy: str) -> bool:
        """Determine if a file should be synced based on policy.

        Args:
            dest_path: Destination file path
            policy: Sync policy ('always', 'if_unchanged', 'never')

        Returns:
            True if file should be synced
        """
        # Reset mode overrides all policies
        if self.reset:
            self._echo_verbose(
                f"🔄 Reset mode: overriding policy '{policy}' for {dest_path.name}"
            )
            return True

        if self.force:
            self._echo_verbose(
                f"💪 Force mode: overriding policy '{policy}' for {dest_path.name}"
            )
            return True

        return self._check_sync_policy(dest_path, policy)

    def _check_sync_policy(self, dest_path: Path, policy: str) -> bool:
        """Check if file should be synced based on specific policy."""
        if policy == "always":
            return True
        elif policy == "never":
            return not dest_path.exists()  # Only create if doesn't exist
        elif policy == "if_unchanged":
            return self._should_sync_if_unchanged(dest_path)
        elif policy == "local_override":
            # Local version always wins - never sync
            return False
        else:
            logger.warning(f"Unknown sync policy: {policy}")
            return False

    def _should_sync_if_unchanged(self, dest_path: Path) -> bool:
        """Check if file should be synced under 'if_unchanged' policy.

        Returns True if:
        - File doesn't exist (new files are always synced)
        - File exists and hasn't been modified by client since last sync

        Returns False if:
        - File exists and no sync record exists (assume client created/modified it)
        - File exists and has been modified by client since last sync
        """
        if not dest_path.exists():
            return True

        # Get relative path for cache lookup
        try:
            rel_path = str(dest_path.relative_to(self.project_path))
        except ValueError:
            # Path not relative to project
            return False

        # Check if we have a stored checksum for this file
        if rel_path not in self.checksum_cache:
            # No previous sync record - existing file should not be synced
            # This assumes the file was created/modified by the client
            self._log_verbose(f"🔒 No sync record for existing file: {rel_path}")
            return False

        # Calculate current checksum and compare
        current_checksum = self._calculate_file_checksum(dest_path)
        stored_checksum = self.checksum_cache[rel_path]

        # If checksums differ, the client has modified the file
        if current_checksum != stored_checksum:
            self._log_verbose(f"🔒 File modified by client: {rel_path}")
            return False

        # File exists, has sync record, and hasn't been modified - allow sync
        return True

    def process_template(self, content: str, variables: dict[str, str]) -> str:
        """Process template content with variables.

        Args:
            content: Template content
            variables: Template variables

        Returns:
            Processed content
        """
        try:
            # Create template with keep_trailing_newline to preserve file endings
            template = Template(content, keep_trailing_newline=True)
            rendered: str = template.render(variables)
            return rendered
        except Exception as e:
            logger.error(f"Template processing failed: {e}")
            raise

    def sync_file(
        self, source: str, dest: str, policy: str, variables: dict[str, str]
    ) -> bool:
        """Sync a single file from template to destination.

        Args:
            source: Source template path
            dest: Destination path relative to project root
            policy: Sync policy
            variables: Template variables

        Returns:
            True if file was synced, False if skipped
        """
        # Normalize path to handle cross-platform separators
        dest = dest.replace("\\", "/")
        dest_path = self.project_path / dest

        # Safely resolve path to prevent directory traversal
        safe_dest_path = self._safe_path_resolve(dest_path)

        # Use file-specific locking for concurrent operations
        file_lock = self._get_file_lock(dest)

        with file_lock:
            # Check file filtering first (include/exclude)
            if not self.should_sync_file(dest):
                with self._lock:
                    self.skipped_files.append(dest)
                self._log_verbose(f"🚫 Skipping filtered file: {dest}")
                return False

            # Check sync policy
            if not self._should_sync_file_policy(safe_dest_path, policy):
                with self._lock:
                    self.skipped_files.append(dest)
                self._log_verbose(f"🚫 Skipping {dest} (policy: {policy})")
                return False

            try:
                return self._perform_file_sync(source, dest, safe_dest_path, variables)
            except Exception as e:
                return self._handle_sync_error(e, dest, safe_dest_path)

    def _perform_file_sync(
        self, source: str, dest: str, dest_path: Path, variables: dict[str, str]
    ) -> bool:
        """Perform the actual file synchronization."""
        try:
            # Phase 2 Optimization: Use hash-based change detection if available
            # This allows us to skip I/O-heavy operations for unchanged files
            if source in self.source_hashes and dest_path.exists():
                expected_hash = self.source_hashes[source]
                if hashes_match(dest_path, expected_hash):
                    self._log_verbose(f"⚡ Hash match, skipping: {dest}")
                    with self._lock:
                        self.skipped_files.append(dest)
                    # Update checksum cache for skipped files
                    self._update_checksum_cache(dest, dest_path)
                    return False

            # Get template content with retry logic
            template_content = self._get_template_with_retry(source)

            # Process template variables with error handling
            # Skip template processing for files without .template suffix
            # (files under .genesis/ and .claude/ directories)
            if source.endswith(".template") or dest.endswith(".template"):
                processed_content = self._process_template_safe(
                    template_content, variables, dest
                )
            else:
                # Files without .template suffix are copied as-is (no Jinja2 processing)
                processed_content = template_content

            # Check if file already has the same content
            if dest_path.exists() and not self.preview:
                existing_content = dest_path.read_text(encoding="utf-8")
                if existing_content == processed_content:
                    self._log_verbose(f"✓ Already up-to-date: {dest}")
                    with self._lock:
                        self.skipped_files.append(dest)
                    # Update checksum cache even for skipped files
                    self._update_checksum_cache(dest, dest_path)
                    return False

            # Handle preview mode
            if self.preview:
                return self._handle_preview_mode(dest, dest_path, processed_content)

            # Handle dry run mode
            if self.dry_run:
                logger.info(
                    f"📝 Would sync: {dest}" if self.verbose else f"Would sync: {dest}"
                )
                with self._lock:
                    self.synced_files.append(dest)
                return True

            # Create destination directory if needed with error handling
            self._ensure_directory_exists(dest_path.parent)

            # Write processed content with atomic operation
            self._write_file_atomic(dest_path, processed_content)

            # Update checksum cache after successful write
            self._update_checksum_cache(dest, dest_path)

            logger.info(f"✅ Synced: {dest}" if self.verbose else f"Synced: {dest}")
            with self._lock:
                self.synced_files.append(dest)
            return True

        except FileNotFoundError as e:
            # Template not found - this is expected in some environments
            logger.warning(f"⚠️ Template not found for {dest}: {e}")
            with self._lock:
                self.errors.append(f"Template not found for {dest}: {e}")
            return False
        except Exception as e:
            logger.error(f"Failed to sync {dest}: {e}")
            with self._lock:
                self.errors.append(f"Failed to sync {dest}: {e}")
            return False

    def _handle_preview_mode(
        self, dest: str, dest_path: Path, processed_content: str
    ) -> bool:
        """Handle preview mode - show diff without applying changes."""
        diff = self.generate_diff(dest_path, processed_content)

        if diff:
            logger.info(f"📄 Changes for {dest}:")
            print(diff)  # Use print for colored output
            print()  # Add blank line between files
            with self._lock:
                self.diffs.append((dest, diff))
                self.synced_files.append(dest)
            return True
        else:
            self._log_verbose(f"✅ No changes for {dest}")
            with self._lock:
                self.skipped_files.append(dest)
            return False

    def _handle_sync_error(self, error: Exception, dest: str, dest_path: Path) -> bool:
        """Handle errors during file sync."""
        error_msg = f"Failed to sync {dest}: {error}"
        logger.error(error_msg)
        with self._lock:
            self.errors.append(error_msg)
        return False

    def _get_template_with_retry(
        self, source: str, max_retries: int | None = None
    ) -> str:
        """Get template content with retry logic for reliability."""
        if max_retries is None:
            max_retries = int(
                os.environ.get(
                    "GENESIS_SYNC_MAX_RETRIES",
                    EnvironmentDefaults.DEFAULT_SYNC_MAX_RETRIES,
                )
            )
        for attempt in range(max_retries):
            try:
                return self.template_manager.get_template(source)
            except Exception as e:
                if attempt == max_retries - 1:
                    raise
                logger.warning(
                    f"Template fetch attempt {attempt + 1} failed for {source}: {e}"
                )
                time.sleep(0.1 * (attempt + 1))  # Progressive backoff
        # Should never reach here, but satisfies type checker
        raise RuntimeError(
            f"Failed to get template {source} after {max_retries} attempts"
        )

    def _should_skip_template_processing(self, dest: str) -> bool:
        """Check if file should skip template processing (pure shell/config files)."""
        # Files with complex bash/shell syntax that shouldn't be templated
        skip_files = [
            ".envrc",
            ".bashrc",
            ".zshrc",
            ".profile",
        ]

        dest_name = Path(dest).name
        return dest_name in skip_files

    def _process_template_safe(
        self, content: str, variables: dict[str, str], dest: str = ""
    ) -> str:
        """Process template with enhanced error handling and security."""
        # Skip template processing for pure shell/config files
        if dest and self._should_skip_template_processing(dest):
            return content

        # Filter sensitive variables from logging
        safe_variables = self._filter_sensitive_variables(variables)

        try:
            return self.process_template(content, variables)
        except Exception as e:
            logger.error(f"Template processing failed: {e}")
            # Add template processing error to errors list
            with self._lock:
                self.errors.append(f"Template processing failed: {e}")
            # Log safe variables for debugging
            if self.verbose:
                logger.debug(f"Template variables (filtered): {safe_variables}")
            # Return content as-is if template processing fails
            # This handles files with complex syntax that shouldn't be templated
            logger.warning("Returning content without template processing due to error")
            return content

    def _filter_sensitive_variables(self, variables: dict[str, str]) -> dict[str, str]:
        """Filter out sensitive information from variables for logging."""
        filtered = {}
        sensitive_patterns = ["key", "password", "secret", "token", "credential"]

        for key, value in variables.items():
            key_lower = key.lower()
            if any(pattern in key_lower for pattern in sensitive_patterns):
                filtered[key] = "***FILTERED***"
            else:
                filtered[key] = value
        return filtered

    def _ensure_directory_exists(self, directory: Path) -> None:
        """Ensure directory exists with proper error handling."""
        try:
            directory.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            if e.errno == 28:  # No space left on device
                raise OSError("No space left on device") from e
            elif e.errno == 13:  # Permission denied
                raise PermissionError(
                    f"Permission denied creating directory: {directory}"
                ) from e
            else:
                raise

    def _write_file_atomic(self, dest_path: Path, content: str) -> None:
        """Write file atomically to prevent corruption during concurrent operations."""
        # Write to temporary file first
        temp_path = dest_path.parent / f".{dest_path.name}.tmp"
        try:
            # Write in binary mode to preserve exact content including trailing newlines
            with open(temp_path, "wb") as f:
                f.write(content.encode("utf-8"))
                f.flush()
                os.fsync(f.fileno())  # Force write to disk

            # Atomic move
            temp_path.replace(dest_path)

            # Make shell scripts executable
            if str(dest_path).endswith(".sh"):
                dest_path.chmod(dest_path.stat().st_mode | 0o755)
        except Exception:
            # Clean up temp file on error
            if temp_path.exists():
                try:
                    temp_path.unlink()
                except Exception:
                    pass
            raise

    def sync_executable_file(
        self,
        source: str,
        dest: str,
        policy: str,
        variables: dict[str, str],
        executable: bool = False,
    ) -> bool:
        """Sync a file and optionally set executable permissions.

        Args:
            source: Source template path
            dest: Destination path relative to project root
            policy: Sync policy
            variables: Template variables
            executable: Whether to set executable permissions

        Returns:
            True if file was synced, False if skipped
        """
        synced = self.sync_file(source, dest, policy, variables)

        if synced and self.should_modify_files:
            dest_path = self.project_path / dest
            # Always make shell scripts executable, regardless of executable flag
            if dest.endswith(".sh") or executable:
                # Set executable permissions for user, group, and other
                dest_path.chmod(dest_path.stat().st_mode | 0o755)
                logger.debug(f"Set executable: {dest}")

        return synced

    def sync(self) -> int:
        """Perform the sync operation.

        Returns:
            Number of files synced
        """
        try:
            config = self.load_config()
            self.validate_file_filters(config)
            self._log_sync_start(config["template_source"])

            variables = self.get_template_variables()
            self._log_verbose(f"📊 Template variables: {variables}")

            self._process_sync_policies(config, variables)
            sync_count = self._report_sync_results()

            return sync_count

        except FileNotFoundError as e:
            # Handle template not found gracefully - this should not stop sync
            error_str = str(e).lower()
            if "template" in error_str and (
                "not found" in error_str or "no such file" in error_str
            ):
                logger.warning(f"⚠️ Template not found: {e}")
                self.errors.append(f"Template not found: {e}")
                # Return 0 files synced, but still report results gracefully
                self._report_sync_results()
                return 0
            else:
                logger.error(f"❌ Configuration error: {e}")
                raise
        except Exception as e:
            error_str = str(e).lower()
            # Check if this is a template-related error that should be treated as warning
            if "template" in error_str and (
                "not found" in error_str or "no such file" in error_str
            ):
                logger.warning(f"⚠️ Template error: {e}")
                self.errors.append(f"Template error: {e}")
                self._report_sync_results()
                return 0
            else:
                logger.error(f"❌ Sync failed: {e}")
                raise

    def _log_sync_start(self, template_source: str) -> None:
        """Log sync operation start."""
        logger.info(f"🔄 Syncing from template: {template_source}")

        if self.preview:
            logger.info("👀 Preview mode - showing detailed diff of changes")
        elif self.dry_run:
            logger.info("🔍 Dry run mode - showing what would be synced")

        if self.reset:
            logger.info("🔄 Reset mode - ignoring sync policies")
        elif self.force:
            logger.info("💪 Force mode - updating all files regardless of policy")

        if self.files:
            logger.info(f"📁 Syncing specific files: {', '.join(self.files)}")

        if self.exclude:
            logger.info(f"🚫 Excluding files: {', '.join(self.exclude)}")

        self._log_verbose("📢 Verbose mode enabled")

    def _process_sync_policies(
        self, config: dict[str, Any], variables: dict[str, str]
    ) -> None:
        """Process all sync policies from configuration."""
        template_source = config["template_source"]

        # Process files from sync configuration first
        # Support both old and new formats
        # Old format: sync_policies is a list of file configs
        # New format: files is a list, sync_policies is settings dict
        if "files" in config and isinstance(config["files"], list):
            sync_policies = config["files"]
        else:
            sync_policies = config.get("sync_policies", [])

        for policy_config in sync_policies:
            source = policy_config["source"]
            # Support both "dest" and "pattern" for backward compatibility
            dest = policy_config.get("dest") or policy_config.get("pattern")
            if not dest:
                logger.error(
                    f"Missing 'dest' field in sync policy for source: {source}"
                )
                raise KeyError(
                    f"Missing 'dest' field in sync policy for source: {source}"
                )
            # Process template variables in destination path
            original_dest = dest
            dest = self.process_template(dest, variables)
            if original_dest != dest:
                logger.info(f"🔧 Template substitution: {original_dest} → {dest}")
            else:
                logger.debug(f"🔧 No substitution needed for: {dest}")
            # Support both "sync" and "policy" field names (new format uses "policy")
            policy = policy_config.get("policy") or policy_config.get(
                "sync", "if_unchanged"
            )
            executable = policy_config.get("executable", False)

            # Phase 2: Load source hash if present (optional for backward compatibility)
            source_hash = policy_config.get("source_hash")
            if source_hash:
                self.source_hashes[source] = source_hash
                self._log_verbose(f"📌 Loaded hash for {source}: {source_hash[:20]}...")

            template_source_path = self._resolve_template_path(source, template_source)

            # Handle wildcards in source path
            if "**" in template_source_path or "*" in template_source_path:
                self._sync_wildcard_files(
                    template_source_path, dest, policy, variables, executable
                )
            else:
                self.sync_executable_file(
                    template_source_path, dest, policy, variables, executable
                )

        # Also discover and sync all files from shared templates directory like bootstrap does
        self._sync_all_shared_files(variables)

    def _sync_all_shared_files(self, variables: dict[str, str]) -> None:
        """Discover and sync all files from shared templates directory like bootstrap does."""
        try:
            # Use shared path discovery function for consistency
            shared_templates_dir = discover_shared_templates_path()

            if not shared_templates_dir:
                logger.error(
                    "❌ Genesis templates not found. This usually means Genesis is installed "
                    "as a package but templates are not bundled with the installation. "
                    "For full sync functionality, use a local Genesis development setup."
                )
                self.errors.append(
                    "Templates directory not found - some files may not be synced"
                )
                return

            logger.debug("Discovering all shared template files...")

            # Discover all template files recursively
            for template_file in shared_templates_dir.rglob("*"):
                # Skip __pycache__ directories, .pyc files, and backup files
                if (
                    "__pycache__" in str(template_file)
                    or template_file.suffix in [".pyc", ".pyo", ".pyd"]
                    or template_file.name.endswith(".backup")
                ):
                    continue

                if template_file.is_file() and template_file.name != "manifest.yml":
                    # Calculate relative path from shared directory
                    relative_path = template_file.relative_to(shared_templates_dir)
                    source_name = str(relative_path)

                    # Calculate destination path by removing .template extension if present
                    dest_name = source_name
                    if dest_name.endswith(".template"):
                        dest_name = dest_name[:-9]

                    # Check if this file was already processed by sync policies
                    already_processed = False
                    # Check both synced and skipped files
                    all_processed_files = list(self.synced_files) + list(
                        self.skipped_files
                    )
                    for processed_file in all_processed_files:
                        if processed_file == dest_name:
                            already_processed = True
                            break

                    if already_processed:
                        self._log_verbose(
                            f"🔄 Skipping already processed file: {dest_name}"
                        )
                        continue

                    # Determine sync policy based on file characteristics
                    policy = self._determine_file_sync_policy(dest_name)
                    executable = self._is_file_executable(dest_name)

                    # Sync the file using existing logic
                    self.sync_executable_file(
                        f"shared/{source_name}",
                        dest_name,
                        policy,
                        variables,
                        executable,
                    )

        except Exception as e:
            logger.warning(f"Failed to discover shared templates: {e}")

    def _determine_file_sync_policy(self, dest_name: str) -> str:
        """Determine appropriate sync policy for a file based on its characteristics."""
        # Files that should never be overwritten after creation
        never_sync = ["CLAUDE.md", "README.md", "pyproject.toml"]

        # Files that should only sync if unchanged
        if_unchanged = ["Makefile", ".envrc", ".gitignore"]

        if dest_name in never_sync:
            return "never"
        elif dest_name in if_unchanged:
            return "if_unchanged"
        else:
            return "always"

    def _is_file_executable(self, dest_name: str) -> bool:
        """Determine if a file should be executable based on its path."""
        executable_patterns = ["scripts/", ".genesis/scripts/", ".genesis/hooks/"]

        # Check if file is in an executable directory
        is_executable_dir = any(
            dest_name.startswith(pattern) for pattern in executable_patterns
        )

        # Also check if it's a shell script
        is_shell_script = dest_name.endswith(".sh")

        return is_executable_dir or is_shell_script

    def _sync_wildcard_files(
        self,
        source_pattern: str,
        dest_pattern: str,
        policy: str,
        variables: dict[str, str],
        executable: bool = False,
    ) -> None:
        """Sync files matching a wildcard pattern.

        Args:
            source_pattern: Source template pattern with wildcards (e.g., 'shared/.claude/agents/**')
            dest_pattern: Destination pattern (e.g., '.claude/agents/**')
            policy: Sync policy
            variables: Template variables
            executable: Whether to set executable permissions
        """
        try:
            # Extract base directory from pattern using pathlib
            from pathlib import Path

            from genesis.core.constants import GlobPatterns

            if GlobPatterns.WILDCARD in source_pattern:
                # Pattern like 'shared/.claude/agents/**' -> 'shared/.claude/agents'
                base_dir = source_pattern.replace(
                    GlobPatterns.RECURSIVE_SUFFIX, ""
                ).replace(GlobPatterns.WILDCARD, "")
            elif "*" in source_pattern:
                # Pattern like 'shared/*.txt' -> 'shared'
                split_parts = source_pattern.split("*")
                if split_parts:
                    first_part = split_parts[0]
                    base_dir = str(
                        Path(first_part).parent
                        if first_part.endswith("/")
                        else Path(first_part)
                    )
                else:
                    base_dir = source_pattern
            else:
                base_dir = source_pattern

            # List all templates in the directory
            try:
                templates = self.template_manager.list_templates(base_dir)
            except FileNotFoundError as e:
                # Directory doesn't exist, fail fast
                logger.error(f"❌ Template directory not found: {base_dir}")
                raise FileNotFoundError(
                    f"Template directory not found: {base_dir}"
                ) from e

            # Process each template file
            for template_path in templates:
                # Skip if not matching the pattern
                if not self._matches_pattern(template_path, source_pattern):
                    continue

                # Calculate destination path
                # Remove base directory from template path to get relative path
                if base_dir and template_path.startswith(base_dir + "/"):
                    relative_path = template_path[len(base_dir) + 1 :]
                else:
                    relative_path = template_path

                # Build destination path
                if "**" in dest_pattern:
                    # Replace ** in destination with the relative path
                    dest_file = dest_pattern.replace("**", relative_path)
                else:
                    # Use relative path as-is
                    dest_file = relative_path

                # Remove .template extension if present
                if dest_file.endswith(".template"):
                    dest_file = dest_file[:-9]

                # Sync the individual file
                self.sync_executable_file(
                    template_path, dest_file, policy, variables, executable
                )

        except Exception as e:
            logger.error(f"Failed to sync wildcard pattern {source_pattern}: {e}")
            self.errors.append(f"Failed to sync wildcard pattern {source_pattern}: {e}")

    def _matches_pattern(self, path: str, pattern: str) -> bool:
        """Check if a path matches a wildcard pattern.

        Args:
            path: Path to check
            pattern: Pattern with wildcards

        Returns:
            True if path matches pattern
        """
        import fnmatch

        # Convert ** to * for fnmatch using pathlib
        from pathlib import Path

        from genesis.core.constants import GlobPatterns

        if GlobPatterns.WILDCARD in pattern:
            # Pattern like 'shared/.claude/agents/**' matches any file under that directory
            base = pattern.replace(GlobPatterns.RECURSIVE_SUFFIX, "").replace(
                GlobPatterns.WILDCARD, ""
            )
            base_path = Path(base)
            path_obj = Path(path)
            return str(path_obj).startswith(str(base_path / "")) or str(
                path_obj
            ) == str(base_path)

        # Use fnmatch for other patterns
        return fnmatch.fnmatch(path, pattern)

    def _resolve_template_path(self, source: str, template_source: str) -> str:
        """Resolve template source path.

        First checks if the template exists in the project-specific folder,
        then falls back to the shared folder for common templates.
        """
        if source.startswith(template_source) or source.startswith("shared/"):
            return source

        # Common shared templates that should always come from shared folder
        shared_patterns = [
            ".claude/",
            ".genesis/",
            "Dockerfile",
            ".dockerignore",
            ".gitignore",
            ".pre-commit-config.yaml",
            ".envrc",
            ".gitattributes",
            ".gitleaks.toml",
            ".markdownlint.json",
            ".mcp.json",
            "Makefile",
            "CLAUDE.md",
            "docker-compose.yml",
            ".genesis/scripts/setup/setup.sh",
            ".genesis/scripts/docker/container-rebuild.sh",
            ".genesis/scripts/docker/docker-cleanup.sh",
            ".genesis/scripts/setup/install-genesis.sh",
            ".genesis/scripts/utils/common-setup-functions.sh",
            ".genesis/scripts/utils/common-check-functions.sh",
            ".genesis/scripts/validation/check-genesis-components.sh",
            ".genesis/scripts/validation/check-variable-defaults.sh",
            ".genesis/scripts/validation/check-file-organization.sh",
            ".genesis/scripts/validation/check-ai-signatures.sh",
            ".genesis/scripts/validation/find-hardcoded-values.sh",
            ".genesis/scripts/validation/validate-components.sh",
            ".genesis/scripts/validation/validate-bootstrap.sh",
            "docs/",
            "config/",
        ]

        # Check if this should come from shared folder
        for pattern in shared_patterns:
            if source.startswith(pattern):
                # This is a shared template
                from pathlib import Path

                base_name = Path(source).name

                # Handle config files with .template extension in source
                if source.startswith("config/"):
                    if source.endswith(".template"):
                        return f"shared/{source}"
                    # Special case: config/.gitignore doesn't have .template
                    if source == "config/.gitignore":
                        return f"shared/{source}"
                    # Other config files need .template extension
                    return f"shared/{source}.template"

                # Handle other patterns
                # New convention: files under .claude/ or .genesis/ have NO .template suffix
                # Only root-level files have .template suffix
                if source.startswith((".claude/", ".genesis/")):
                    # Files in these directories don't have .template suffix
                    return f"shared/{source}"
                elif base_name in [
                    "Dockerfile",
                    "Makefile",
                    ".gitignore",
                    ".pre-commit-config.yaml",
                    ".dockerignore",
                    ".envrc",
                    "CLAUDE.md",
                    ".gitattributes",
                    ".gitleaks.toml",
                    ".markdownlint.json",
                    "README.md",
                    "GENESIS_GUIDE.md",
                    "pyproject.toml",
                ]:
                    # Root-level files have .template suffix
                    return f"shared/{source}.template"
                # For paths with wildcards or subdirectories, use as-is
                elif "**" in source:
                    return f"shared/{source}"
                # For docs files, check if they need .template extension
                elif source.startswith("docs/"):
                    # Documentation in guides/genesis-how-to has .template suffix
                    if "guides/genesis-how-to/" in source and base_name.endswith(".md"):
                        return f"shared/{source}.template"
                    # Architecture docs have .template suffix
                    elif "architecture/" in source and base_name.endswith(".md"):
                        return f"shared/{source}.template"
                    # Reference docs don't have .template suffix
                    return f"shared/{source}"
                # Default: return as-is
                return f"shared/{source}"

        # Default to project-specific template path
        # Most project-specific templates have .template extension
        if not source.endswith(".template"):
            # Check if file exists with .template extension first
            return f"{template_source}/{source}.template"
        return f"{template_source}/{source}"

    def _load_checksum_cache(self) -> dict[str, str]:
        """Load the checksum cache from disk.

        Returns:
            Dictionary mapping file paths to their checksums
        """
        if not self.checksum_cache_path.exists():
            return {}

        try:
            with open(self.checksum_cache_path) as f:
                data = json.load(f)
                # Ensure we return a dict even if file is corrupted
                if isinstance(data, dict):
                    return data
                return {}
        except (OSError, json.JSONDecodeError) as e:
            logger.warning(f"Could not load checksum cache: {e}")
            return {}

    def _save_checksum_cache(self) -> None:
        """Save the checksum cache to disk."""
        if self.dry_run or self.preview:
            # Don't save cache in dry-run or preview mode
            return

        try:
            # Ensure .genesis directory exists
            self.checksum_cache_path.parent.mkdir(parents=True, exist_ok=True)

            # Write cache atomically
            temp_path = (
                self.checksum_cache_path.parent
                / f".{self.checksum_cache_path.name}.tmp"
            )
            with open(temp_path, "w") as f:
                json.dump(self.checksum_cache, f, indent=2, sort_keys=True)
                f.flush()
                os.fsync(f.fileno())

            # Atomic replace
            temp_path.replace(self.checksum_cache_path)
        except OSError as e:
            logger.warning(f"Could not save checksum cache: {e}")

    def _calculate_file_checksum(self, file_path: Path) -> str:
        """Calculate SHA-256 checksum of a file.

        Args:
            file_path: Path to the file

        Returns:
            Hex string of the checksum
        """
        if not file_path.exists():
            return ""

        try:
            sha256 = hashlib.sha256()
            with open(file_path, "rb") as f:
                # Read in chunks for large files
                for chunk in iter(lambda: f.read(65536), b""):
                    sha256.update(chunk)
            return sha256.hexdigest()
        except OSError as e:
            logger.warning(f"Could not calculate checksum for {file_path}: {e}")
            return ""

    def _update_checksum_cache(self, dest: str, dest_path: Path) -> None:
        """Update the checksum cache for a file.

        Args:
            dest: Destination path relative to project
            dest_path: Absolute path to the file
        """
        if self.dry_run or self.preview:
            # Don't update cache in dry-run or preview mode
            return

        checksum = self._calculate_file_checksum(dest_path)
        if checksum:
            # Normalize path for consistent cache keys
            cache_key = dest.replace("\\", "/")
            self.checksum_cache[cache_key] = checksum

    def _report_sync_results(self) -> int:
        """Report sync operation results."""
        # Save checksum cache before reporting
        if self.should_modify_files:
            self._save_checksum_cache()

        synced_count = len(self.synced_files)
        skipped_count = len(self.skipped_files)
        error_count = len(self.errors)

        if self.preview:
            diff_count = len(self.diffs)
            if error_count > 0:
                logger.info(
                    f"📊 Preview complete: {diff_count} files with changes, {skipped_count} unchanged, {error_count} errors"
                )
            else:
                logger.info(
                    f"📊 Preview complete: {diff_count} files with changes, {skipped_count} unchanged"
                )
            if diff_count > 0:
                logger.info("💡 Run without --preview to apply changes")
        elif self.dry_run:
            logger.info(f"📊 Would sync {synced_count} files, skip {skipped_count}")
        else:
            logger.info(f"📊 Synced {synced_count} files, skipped {skipped_count}")

        self._report_errors(error_count)
        self._report_next_steps(synced_count)

        return synced_count

    def _report_errors(self, error_count: int) -> None:
        """Report any errors that occurred during sync."""
        if error_count > 0:
            logger.error(f"❌ {error_count} errors occurred during sync")
            for error in self.errors:
                logger.error(f"  • {error}")

    def _report_next_steps(self, synced_count: int) -> None:
        """Report suggested next steps after sync."""
        if synced_count > 0 and self.should_modify_files:
            logger.info("💡 Review changes with: git diff")
            logger.info(
                "💡 Commit when ready: genesis commit -m 'chore: sync Genesis updates'"
            )


@click.command()
@click.option(
    "--preview",
    is_flag=True,
    help="Show detailed diff of changes without applying them",
)
@click.option(
    "--dry-run", is_flag=True, help="Show what would be updated without making changes"
)
@click.option(
    "--files",
    multiple=True,
    help="Sync only specific files (can be used multiple times)",
)
@click.option(
    "--exclude",
    multiple=True,
    help="Exclude files from sync (can be used multiple times)",
)
@click.option(
    "--reset", is_flag=True, help="Reset files to template defaults (ignore policies)"
)
@click.option(
    "--force", is_flag=True, help="Force update all files regardless of policy"
)
@click.option(
    "--refresh", is_flag=True, help="Refresh sync.yml with all files from manifest"
)
@click.option(
    "--verbose", "-v", is_flag=True, help="Show detailed processing information"
)
@click.option(
    "--path",
    type=click.Path(exists=True),
    help="Path to project (default: current directory)",
)
def sync(
    preview: bool,
    dry_run: bool,
    files: tuple[str, ...],
    exclude: tuple[str, ...],
    reset: bool,
    force: bool,
    refresh: bool,
    verbose: bool,
    path: str | None,
) -> None:
    """Update project support files from Genesis templates.

    This command reads sync configuration from .genesis/sync.yml and updates
    files according to the defined policies.

    Examples:
        genesis sync --preview                   # Show detailed diff of changes
        genesis sync --dry-run                   # Check what would be updated
        genesis sync --files docker-compose.yml # Sync only specific file
        genesis sync --exclude .envrc           # Exclude files from sync
        genesis sync --reset                     # Reset all to template defaults
        genesis sync --force                     # Force update all files
        genesis sync --verbose                   # Show detailed processing info
        genesis sync --preview --files file.yml # Preview specific file changes
    """
    try:
        # Validate option combinations
        _validate_option_combinations(preview, dry_run, reset, force)

        project_path = _get_project_path(path)
        _verify_genesis_project(project_path)

        # Handle --refresh flag to update sync.yml
        if refresh:
            _refresh_sync_config(project_path)
            logger.info("✅ Refreshed sync.yml with all files from manifest")
            logger.info("💡 Run 'genesis sync' to apply the updated configuration")
            return

        manager = SyncManager(
            project_path,
            force=force,
            dry_run=dry_run,
            preview=preview,
            files=list(files) if files else None,
            exclude=list(exclude) if exclude else None,
            reset=reset,
            verbose=verbose,
        )
        updated = manager.sync()

        _report_cli_completion(updated, dry_run, preview)

    except click.ClickException:
        # Re-raise ClickExceptions (validation errors)
        raise
    except FileNotFoundError as e:
        # Fail fast on missing templates - no fallbacks
        error_msg = str(e)
        if "genesis init" in error_msg or "genesis migrate" in error_msg:
            # Preserve init/migrate suggestion for tests
            click.echo(error_msg, err=True)
        else:
            logger.error(f"❌ Configuration error: {error_msg}")
        raise click.ClickException(error_msg) from e
    except Exception as e:
        logger.error(f"❌ Sync failed: {str(e)}")
        raise click.ClickException(str(e)) from e


def _validate_option_combinations(
    preview: bool, dry_run: bool, reset: bool, force: bool
) -> None:
    """Validate that option combinations make sense."""
    if preview and dry_run:
        raise click.ClickException(
            "Cannot use --preview and --dry-run together. Use --preview for detailed diff."
        )

    if reset and force:
        logger.warning(
            "⚠️  Both --reset and --force specified. --reset takes precedence."
        )


def _get_project_path(path: str | None) -> Path:
    """Get the project path, defaulting to current directory."""
    return Path(path) if path else Path.cwd()


def _verify_genesis_project(project_path: Path) -> None:
    """Verify that the directory is a Genesis project."""
    genesis_dir = project_path / ".genesis"
    if not genesis_dir.exists():
        error_msg = (
            "❌ Not a Genesis project. Run 'genesis init' or 'genesis migrate' first."
        )
        logger.error(error_msg)
        raise click.ClickException("Genesis configuration not found")


def _refresh_sync_config(project_path: Path) -> None:
    """Refresh sync.yml with all files from manifest and update manifest.yml.

    This regenerates the sync.yml to include all files from the manifest,
    preserving any user customizations to sync policies. Also updates
    the local manifest.yml from the packaged Genesis templates.
    """
    from genesis.commands.init import SyncConfigGenerator

    sync_yml_path = project_path / ".genesis" / "sync.yml"

    # Load existing config to preserve user customizations
    existing_config = {}
    if sync_yml_path.exists():
        try:
            with open(sync_yml_path) as f:
                existing_config = yaml.safe_load(f)
        except Exception as e:
            logger.warning(f"Could not load existing sync.yml: {e}")

    # Extract project info and variables from existing config
    project_info = existing_config.get("project", {})
    project_type = project_info.get("type", "python-api")
    variables = existing_config.get("variables", {})

    # Add default variables if missing
    if "project_name" not in variables:
        variables["project_name"] = project_path.name
    if "module_name" not in variables:
        variables["module_name"] = variables["project_name"].replace("-", "_")

    # Generate fresh config with all files from manifest
    new_config = SyncConfigGenerator.generate_sync_config(
        project_type, variables, project_path
    )

    # Preserve user policy customizations
    if "sync_policies" in existing_config or "files" in existing_config:
        existing_policies = existing_config.get(
            "sync_policies", existing_config.get("files", [])
        )
        # Create a map of existing user customizations
        user_overrides = {}
        # Handle list format (new format or old format)
        if isinstance(existing_policies, list):
            for policy in existing_policies:
                dest = policy.get("dest", policy.get("pattern", ""))
                if dest:
                    # Check if user changed the policy from default
                    user_overrides[dest] = policy.get("policy", policy.get("sync"))
        # Handle dict format (grouped by policy type)
        elif isinstance(existing_policies, dict):
            for policy_type, files in existing_policies.items():
                if isinstance(files, list):
                    for file_path in files:
                        user_overrides[file_path] = policy_type

        # Apply user overrides to new config
        for policy in new_config.get("sync_policies", []):
            dest = policy.get("dest", "")
            if dest in user_overrides:
                policy["policy"] = user_overrides[dest]
                policy["user_override"] = True  # Mark as user customized

    # Add helpful comment about refresh
    from datetime import datetime

    new_config["_comment"] = f"Refreshed from manifest on {datetime.now().isoformat()}"

    # Write updated config
    with open(sync_yml_path, "w") as f:
        yaml.dump(new_config, f, default_flow_style=False, sort_keys=False)

    # Update manifest.yml from packaged Genesis templates
    manifest_yml_path = project_path / ".genesis" / "manifest.yml"
    from genesis.core.path_discovery import discover_genesis_templates_path

    template_base = discover_genesis_templates_path()

    if template_base:
        shared_manifest = template_base / "shared" / "manifest.yml"
        if shared_manifest.exists():
            import shutil

            shutil.copy2(shared_manifest, manifest_yml_path)
            logger.info(f"📝 Updated {manifest_yml_path} from packaged templates")
        else:
            logger.error(f"❌ Could not find manifest at {shared_manifest}")
            raise FileNotFoundError(f"Genesis manifest not found at {shared_manifest}")
    else:
        logger.error("❌ Could not locate Genesis templates directory")
        raise FileNotFoundError(
            "Genesis templates directory not found. Ensure Genesis is properly installed or set GENESIS_DEV_MODE=true for development."
        )

    # Log statistics
    file_count = len(new_config.get("sync_policies", []))
    logger.info(f"📝 Updated {sync_yml_path}")
    logger.info(f"📊 Now includes {file_count} files from manifest")


def _report_cli_completion(updated: int, dry_run: bool, preview: bool = False) -> None:
    """Report sync completion status."""
    if preview:
        if updated > 0:
            logger.info("✅ Preview completed - changes shown above")
        else:
            logger.info("✅ Preview completed - no changes needed")
    elif updated > 0 and not dry_run:
        logger.info("✅ Sync completed successfully")
    elif dry_run and updated > 0:
        logger.info("✅ Dry run completed - use 'genesis sync' to apply changes")
    else:
        logger.info("✅ All files are up to date")
