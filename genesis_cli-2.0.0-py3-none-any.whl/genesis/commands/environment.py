"""Environment management commands for Genesis."""

import os
from pathlib import Path

import click
import yaml

from genesis.core.config import load_environment_config
from genesis.core.constants import EnvironmentDefaults
from genesis.core.env import get_current_environment, validate_environment
from genesis.core.errors import handle_error
from genesis.core.logger import get_logger

logger = get_logger(__name__)


@click.group()
def environment() -> None:
    """Manage multi-environment configuration."""
    pass


@environment.command("current")
def current() -> None:
    """Show current environment."""
    try:
        env = get_current_environment()
        click.echo(f"Current environment: {env}")

        # Check if PROJECT_ENVIRONMENT is explicitly set
        if "PROJECT_ENVIRONMENT" not in os.environ:
            click.echo(
                click.style(
                    "Note: PROJECT_ENVIRONMENT not set, defaulting to 'development'",
                    fg="yellow",
                )
            )
    except Exception as e:
        handle_error(e)
        logger.error("Failed to get current environment")
        raise click.ClickException(str(e)) from e


@environment.command("switch")
@click.argument(
    "env_name", type=click.Choice(["development", "test", "staging", "production"])
)
def switch(env_name: str) -> None:
    """Switch to a different environment.

    Updates .env.local with PROJECT_ENVIRONMENT setting.
    """
    try:
        validate_environment(env_name)

        # Find .env.local or create it
        env_local_path = Path(".env.local")

        # Read existing content if file exists
        existing_lines = []
        if env_local_path.exists():
            with open(env_local_path) as f:
                existing_lines = f.readlines()

        # Update or add PROJECT_ENVIRONMENT
        updated = False
        new_lines = []
        for line in existing_lines:
            if line.startswith("PROJECT_ENVIRONMENT=") or line.startswith(
                "export PROJECT_ENVIRONMENT="
            ):
                new_lines.append(f"export PROJECT_ENVIRONMENT={env_name}\n")
                updated = True
            else:
                new_lines.append(line)

        # Add if not found
        if not updated:
            # Add newline if file doesn't end with one
            if new_lines and not new_lines[-1].endswith("\n"):
                new_lines.append("\n")
            new_lines.append(f"export PROJECT_ENVIRONMENT={env_name}\n")

        # Write back to file
        with open(env_local_path, "w") as f:
            f.writelines(new_lines)

        click.echo(f"Switched to environment: {env_name}")
        click.echo(
            click.style(
                "Note: Run 'source .envrc' to apply the change in your current shell",
                fg="yellow",
            )
        )

    except Exception as e:
        handle_error(e)
        logger.error(f"Failed to switch to environment: {env_name}")
        raise click.ClickException(str(e)) from e


@environment.command("init")
@click.option(
    "--config-dir",
    default="config",
    help="Directory for config files (default: config)",
)
def init(config_dir: str) -> None:
    """Initialize environment configuration files."""
    try:
        config_path = Path(config_dir)

        # Create config directory
        config_path.mkdir(parents=True, exist_ok=True)

        # Define default content for each file
        defaults_content = {
            "app_name": "{{project_name}}",
            "version": os.environ.get(
                "GENESIS_ENV_VERSION", EnvironmentDefaults.DEFAULT_ENV_VERSION
            ),
            "log_level": "INFO",
            "debug": False,
        }

        env_contents = {
            "development": {
                "debug": True,
                "log_level": "DEBUG",
                "hot_reload": True,
            },
            "test": {
                "log_level": "WARNING",
                "mock_external_services": True,
                "test_database": True,
            },
            "staging": {
                "log_level": "INFO",
                "enable_profiling": True,
            },
            "production": {
                "log_level": "WARNING",
                "enable_monitoring": True,
                "enable_alerting": True,
            },
        }

        # Create defaults.yaml
        defaults_file = config_path / "defaults.yaml"
        if not defaults_file.exists():
            with open(defaults_file, "w") as f:
                yaml.dump(
                    defaults_content, f, default_flow_style=False, sort_keys=False
                )
            click.echo(f"Created: {defaults_file}")
        else:
            click.echo(f"Skipped (exists): {defaults_file}")

        # Create environment-specific files
        for env_name, env_config in env_contents.items():
            env_file = config_path / f"{env_name}.yaml"
            if not env_file.exists():
                with open(env_file, "w") as f:
                    yaml.dump(env_config, f, default_flow_style=False, sort_keys=False)
                click.echo(f"Created: {env_file}")
            else:
                click.echo(f"Skipped (exists): {env_file}")

        # Create .gitignore for local.yaml
        gitignore_file = config_path / ".gitignore"
        if not gitignore_file.exists():
            with open(gitignore_file, "w") as f:
                f.write("# Local overrides (not committed)\n")
                f.write("local.yaml\n")
            click.echo(f"Created: {gitignore_file}")

        click.echo(
            click.style(
                "\nEnvironment configuration initialized successfully!", fg="green"
            )
        )
        click.echo("\nYou can now:")
        click.echo(f"  - Edit config files in the '{config_dir}' directory")
        click.echo("  - Use 'genesis environment config <key>' to view config values")
        click.echo("  - Create 'config/local.yaml' for local overrides (gitignored)")

    except Exception as e:
        handle_error(e)
        logger.error("Failed to initialize environment configuration")
        raise click.ClickException(str(e)) from e


@environment.command("config")
@click.argument("key", required=False)
@click.option(
    "--env",
    type=click.Choice(["development", "test", "staging", "production"]),
    help="Environment to use (default: current)",
)
@click.option(
    "--config-dir",
    default="config",
    help="Directory containing config files (default: config)",
)
def config(key: str | None, env: str | None, config_dir: str) -> None:
    """Show configuration value for environment.

    If KEY is not provided, shows all configuration values.
    """
    try:
        # Use specified environment or current
        environment_name = env or get_current_environment()

        # Check if config directory exists
        config_path = Path(config_dir)
        if not config_path.exists():
            click.echo(
                click.style(
                    f"Config directory '{config_dir}' not found. Run 'genesis environment init' first.",
                    fg="red",
                )
            )
            raise click.ClickException("Configuration not initialized")

        # Load configuration
        config_data = load_environment_config(
            env_prefix="APP_",
            config_dir=config_path,
            environment=environment_name,
        )

        if key:
            # Show specific key
            if key in config_data:
                value = config_data[key]
                click.echo(f"{key}: {value}")
            else:
                click.echo(
                    click.style(f"Key '{key}' not found in configuration", fg="red")
                )
                raise click.ClickException(f"Configuration key not found: {key}")
        else:
            # Show all configuration
            click.echo(f"Configuration for environment: {environment_name}")
            click.echo("-" * 40)

            if config_data:
                # Pretty print the config
                for k, v in sorted(config_data.items()):
                    click.echo(f"{k}: {v}")
            else:
                click.echo("No configuration found")

    except Exception as e:
        if "Configuration key not found" not in str(
            e
        ) and "Configuration not initialized" not in str(e):
            handle_error(e)
            logger.error("Failed to get configuration")
        raise click.ClickException(str(e)) from e


# Export the command group
__all__ = ["environment"]
