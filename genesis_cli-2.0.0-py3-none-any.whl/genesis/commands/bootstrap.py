"""
Genesis Bootstrap Command

Project initialization functionality extracted from bootstrap shell script.
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import click

from genesis.core import get_logger

# Import from genesis.core for consolidated package
from genesis.core.errors import (
    InfrastructureError,
    ResourceError,
    ValidationError,
    handle_error,
)
from genesis.core.manifest_parser import ManifestParser
from genesis.core.path_discovery import (
    discover_project_template_path,
    discover_shared_templates_path,
)

# Initialize logger
logger = get_logger(__name__)

# Module-level shell path constants - configurable via environment variables
# These follow Genesis fail-fast principle: explicit configuration over hardcoded values


def _get_unix_shell_paths() -> list[str]:
    """Get Unix shell paths from environment or use platform defaults."""
    env_paths = os.environ.get("GENESIS_UNIX_SHELLS")
    if env_paths:
        return [path.strip() for path in env_paths.split(":") if path.strip()]
    return ["/bin/bash", "/usr/bin/bash", "/bin/zsh", "/usr/bin/zsh"]


def _get_windows_powershell_paths() -> list[str]:
    """Get Windows PowerShell paths from environment or use platform defaults."""
    env_paths = os.environ.get("GENESIS_WINDOWS_SHELLS")
    if env_paths:
        return [path.strip() for path in env_paths.split(";") if path.strip()]
    return [
        "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
        "C:\\Program Files\\PowerShell\\7\\pwsh.exe",
    ]


def find_genesis_root() -> Path | None:
    """Find Genesis project root by looking for CLAUDE.md."""
    current = Path.cwd()
    for parent in [current] + list(current.parents):
        if (parent / "CLAUDE.md").exists():
            return parent
    return None


def get_user_shell() -> str:
    """
    Get the user's shell with proper detection across platforms.

    Follows Genesis fail-fast principle - fails with clear error if shell cannot be detected.

    Returns:
        str: Path to the user's shell

    Raises:
        ValidationError: If shell cannot be detected
    """
    import os
    import platform

    # Try SHELL environment variable first (Unix/Linux/macOS)
    shell = os.environ.get("SHELL")
    if shell:
        return shell

    # Windows-specific detection
    if platform.system() == "Windows":
        # Check for common Windows shells
        comspec = os.environ.get("COMSPEC")
        if comspec:
            return comspec

        # PowerShell is common on Windows
        powershell_paths = _get_windows_powershell_paths()
        for ps_path in powershell_paths:
            if Path(ps_path).exists():
                return ps_path

    # Try to detect shell from system defaults
    system = platform.system()
    if system in ("Linux", "Darwin"):  # Darwin is macOS
        # Check common shell locations
        common_shells = _get_unix_shell_paths()
        for shell_path in common_shells:
            if Path(shell_path).exists():
                return shell_path

    # If we get here, we couldn't detect the shell
    system = platform.system()
    if system == "Windows":
        env_var = "GENESIS_WINDOWS_SHELLS"
        separator = ";"
        current_paths = _get_windows_powershell_paths()
    else:
        env_var = "GENESIS_UNIX_SHELLS"
        separator = ":"
        current_paths = _get_unix_shell_paths()

    raise ValidationError(
        f"Could not detect user shell. "
        f"Set SHELL environment variable or ensure a supported shell is installed. "
        f"Current search paths: {separator.join(current_paths)}. "
        f"Override with {env_var}={separator}join(['path1','path2']).",
        field="shell",
    )


def get_template_path(project_type: str) -> Path | None:
    """Get path to project template using shared path discovery."""
    # Use shared function for consistency across all commands
    template_path = discover_project_template_path(project_type)
    if template_path:
        return template_path

    # Final fallback: try to find Genesis root using legacy method
    genesis_root = find_genesis_root()
    if genesis_root:
        template_path = genesis_root / "templates" / project_type
        if template_path.exists():
            return template_path

    return None


def validate_project_name(name: str) -> None:
    """Validate project name meets requirements."""
    if not name:
        raise ValidationError("Project name cannot be empty", field="name")

    # Allow letters, numbers, hyphens, and underscores
    if not name.replace("-", "").replace("_", "").isalnum():
        raise ValidationError(
            "Project name must contain only letters, numbers, hyphens, and underscores",
            field="name",
        )

    if name.startswith("-") or name.endswith("-"):
        raise ValidationError(
            "Project name cannot start or end with hyphen", field="name"
        )


def create_project_directory(project_path: Path) -> None:
    """Create project directory structure."""
    if project_path.exists():
        raise ResourceError(
            f"Directory {project_path} already exists", resource_type="directory"
        )

    try:
        project_path.mkdir(parents=True, exist_ok=False)
        get_logger(__name__).info(f"Created project directory: {project_path}")
    except OSError as e:
        raise InfrastructureError(
            f"Failed to create directory {project_path}: {e}"
        ) from e


def process_template_file(
    template_file: Path, target_file: Path, substitutions: dict[str, str]
) -> None:
    """Process a template file with substitutions."""
    try:
        # Read template content
        content = template_file.read_text()

        # Apply substitutions
        for placeholder, value in substitutions.items():
            content = content.replace(placeholder, value)

        # Ensure target directory exists
        target_file.parent.mkdir(parents=True, exist_ok=True)

        # Write processed content
        target_file.write_text(content)

        # Make shell scripts executable
        if str(target_file).endswith(".sh"):
            target_file.chmod(target_file.stat().st_mode | 0o755)
            get_logger(__name__).debug(f"Set executable: {target_file}")

        get_logger(__name__).debug(
            f"Processed template: {template_file} -> {target_file}"
        )

    except Exception as e:
        raise InfrastructureError(
            f"Failed to process template {template_file}: {e}"
        ) from e


def copy_essential_shared_file(
    project_path: Path,
    shared_template_path: str,
    target_path: str,
    substitutions: dict[str, str],
) -> None:
    """Copy a single essential file from shared templates."""
    from genesis.core.path_discovery import discover_shared_templates_path

    logger = get_logger(__name__)
    shared_templates_dir = discover_shared_templates_path()

    if not shared_templates_dir:
        logger.debug(f"Shared templates not found - skipping {shared_template_path}")
        return

    shared_file = shared_templates_dir / shared_template_path
    if not shared_file.exists():
        logger.debug(f"Essential shared file not found: {shared_template_path}")
        return

    target_file = project_path / target_path
    target_file.parent.mkdir(parents=True, exist_ok=True)

    # Process template file (but don't apply substitutions for shell scripts)
    if shared_template_path.endswith(".sh.template"):
        # For shell scripts, just copy without variable substitution
        target_file.write_text(shared_file.read_text())
        # Make executable
        target_file.chmod(target_file.stat().st_mode | 0o755)
    else:
        process_template_file(shared_file, target_file, substitutions)

    # Set executable permissions for any shell script or script in executable directories
    if target_path.endswith(".sh") or any(
        target_path.startswith(pattern)
        for pattern in [".genesis/scripts/", ".genesis/hooks/", "scripts/"]
    ):
        target_file.chmod(target_file.stat().st_mode | 0o755)

    logger.info(f"✅ Copied essential shared file: {target_path}")


def copy_essential_files(
    template_path: Path, project_path: Path, project_name: str, project_type: str
) -> None:
    """Copy only essential files during bootstrap, letting sync handle the rest.

    Essential files are those needed to immediately start working:
    - README.md (project documentation)
    - pyproject.toml or package.json (dependency management)
    - .gitignore (version control setup)
    - Main source file (entry point)
    """
    import datetime

    from genesis.core.constants import (
        get_git_author_info,
        get_node_version,
        get_python_version,
    )

    logger = get_logger(__name__)
    logger.info(f"Copying essential files from {template_path}")

    # Get dynamic values - fail fast if not available
    try:
        python_version = get_python_version()
        author_name, author_email = get_git_author_info()
    except ValueError as e:
        logger.error(f"Configuration error: {e}")
        raise click.ClickException(f"Bootstrap failed: {e}") from e

    # Create substitution map
    module_name = project_name.replace("-", "_")
    current_date = datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%d")

    substitutions = {
        # Double underscore format (for filenames/directories)
        "__project_name__": project_name,
        "__PROJECT_NAME__": project_name.upper().replace("-", "_"),
        "__project-name__": project_name,
        "__module_name__": module_name,
        # Mustache format (for content) - with and without spaces
        "{{project_name}}": project_name,
        "{{ project_name }}": project_name,
        "{{PROJECT_NAME}}": project_name.upper().replace("-", "_"),
        "{{ PROJECT_NAME }}": project_name.upper().replace("-", "_"),
        "{{project-name}}": project_name,
        "{{ project-name }}": project_name,
        "{{module_name}}": module_name,
        "{{ module_name }}": module_name,
        "{{command_name}}": project_name,
        "{{project_description}}": f"A {project_name} project created with Genesis",
        "{{project_type}}": project_type,
        "{{current_date}}": current_date,
        "{{python_version}}": python_version,
        "{{node_version}}": get_node_version(),
        "{{author_name}}": author_name,
        "{{author_email}}": author_email,
        "{{genesis_version}}": "0.12.0",
    }

    # Define essential files per project type
    essential_files = {
        "python-api": [
            "README.md.template",
            "pyproject.toml.template",
            ".gitignore.template",
            "main.py.template",
        ],
        "cli-tool": [
            "README.md.template",
            "pyproject.toml.template",
            ".gitignore.template",
            "Makefile.template",
            ".genesis/scripts/setup/setup.sh.template",
            "src/__module_name__/__init__.py.template",
            "src/__module_name__/cli.py.template",
            "src/__module_name__/main.py.template",
            "tests/test_cli.py.template",
        ],
        "typescript-service": [
            "README.md.template",
            "package.json.template",
            ".gitignore.template",
            "src/index.ts.template",
        ],
        "terraform-project": [
            "README.md.template",
            ".gitignore.template",
            "main.tf.template",
        ],
    }

    # Get essential files for this project type
    files_to_copy = essential_files.get(
        project_type, ["README.md.template", ".gitignore.template"]
    )

    # Copy essential template files
    for filename in files_to_copy:
        template_file = template_path / filename
        if not template_file.exists():
            logger.debug(f"Essential template file not found: {filename}")
            continue

        # Calculate target path (remove .template extension and apply substitutions)
        target_filename = filename[:-9] if filename.endswith(".template") else filename
        for placeholder, value in substitutions.items():
            target_filename = target_filename.replace(placeholder, value)

        target_file = project_path / target_filename
        target_file.parent.mkdir(parents=True, exist_ok=True)

        # Process template file with substitutions
        process_template_file(template_file, target_file, substitutions)
        logger.info(f"✅ Copied essential file: {target_filename}")

    # Copy essential shared files needed for basic functionality
    copy_essential_shared_file(
        project_path,
        ".genesis/scripts/validation/check-file-organization.sh.template",
        ".genesis/scripts/validation/check-file-organization.sh",
        substitutions,
    )

    copy_essential_shared_file(project_path, ".envrc.template", ".envrc", substitutions)

    logger.info(
        "Essential files copied. Run 'genesis sync' to get the complete project structure."
    )


def copy_template_structure(
    template_path: Path, project_path: Path, project_name: str
) -> None:
    """Copy and process template structure.

    Deprecated: Use copy_essential_files instead for bootstrap.
    This function copies all template files which is now handled by sync.
    """
    import datetime

    from genesis.core.constants import (
        get_git_author_info,
        get_node_version,
        get_python_version,
    )

    get_logger(__name__).info(f"Processing template from {template_path}")

    # Get dynamic values - fail fast if not available
    try:
        get_python_version()
        author_name, author_email = get_git_author_info()
    except ValueError as e:
        get_logger(__name__).error(f"Configuration error: {e}")
        raise click.ClickException(f"Bootstrap failed: {e}") from e

    # Create substitution map supporting multiple template formats
    # Create Python-safe module name (replace hyphens with underscores)
    module_name = project_name.replace("-", "_")
    current_date = datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%d")

    # Detect project type from template path
    template_type = template_path.name  # e.g., 'python-api', 'cli-tool', etc.

    substitutions = {
        # Double underscore format (for filenames/directories)
        "__project_name__": project_name,
        "__PROJECT_NAME__": project_name.upper().replace("-", "_"),
        "__project-name__": project_name,
        "__module_name__": module_name,
        # Mustache format (for content) - with and without spaces
        "{{project_name}}": project_name,
        "{{ project_name }}": project_name,  # With spaces
        "{{PROJECT_NAME}}": project_name.upper().replace("-", "_"),
        "{{ PROJECT_NAME }}": project_name.upper().replace("-", "_"),  # With spaces
        "{{project-name}}": project_name,
        "{{ project-name }}": project_name,  # With spaces
        "{{module_name}}": module_name,
        "{{ module_name }}": module_name,  # With spaces
        "{{command_name}}": project_name,  # CLI command name (same as project name)
        "{{project_description}}": f"A {project_name} project created with Genesis",
        "{{project_type}}": template_type,
        "{{current_date}}": current_date,
        "{{python_version}}": get_python_version(),
        "{{node_version}}": get_node_version(),
        "{{author_name}}": author_name,
        "{{author_email}}": author_email,
        "{{genesis_version}}": "0.1.0-alpha",
    }

    # Process all template files
    for template_file in template_path.rglob("*.template"):
        # Calculate relative path from template root
        relative_path = template_file.relative_to(template_path)

        # Remove .template extension and apply name substitutions to path
        target_relative_path_str = str(relative_path)[:-9]  # Remove .template
        for placeholder, value in substitutions.items():
            target_relative_path_str = target_relative_path_str.replace(
                placeholder, value
            )

        target_file = project_path / target_relative_path_str
        process_template_file(template_file, target_file, substitutions)

    # Copy non-template files (like README.md in templates)
    # Files that should have substitutions applied even without .template extension
    files_to_process = {
        ".envrc",
        "pyproject.toml",
        "package.json",
        "Makefile",
        "Dockerfile",
        "docker-compose.yml",
    }

    for non_template_file in template_path.rglob("*"):
        if (
            non_template_file.is_file()
            and not non_template_file.name.endswith(".template")
            and non_template_file.name != "template.json"
        ):
            relative_path = non_template_file.relative_to(template_path)
            target_file = project_path / relative_path
            target_file.parent.mkdir(parents=True, exist_ok=True)

            # Check if this file should have substitutions applied
            # Include .envrc specifically and other text-based config files
            if (
                non_template_file.name in files_to_process
                or non_template_file.suffix
                in {
                    ".py",
                    ".sh",
                    ".md",
                    ".yml",
                    ".yaml",
                    ".toml",
                    ".json",
                    ".txt",
                    ".cfg",
                    ".ini",
                    ".env",
                }
                or non_template_file.name == ".envrc"
            ):
                # Process with substitutions
                process_template_file(non_template_file, target_file, substitutions)
                get_logger(__name__).debug(
                    f"Processed file with substitutions: {non_template_file} -> {target_file}"
                )
            else:
                # Copy as-is
                shutil.copy2(non_template_file, target_file)
                get_logger(__name__).debug(
                    f"Copied file: {non_template_file} -> {target_file}"
                )

    # Process shared templates from manifest
    copy_shared_templates(project_path, substitutions)


def copy_shared_templates(project_path: Path, substitutions: dict[str, str]) -> None:
    """Copy shared templates from manifest configuration to project.

    Args:
        project_path: Path to the project directory
        substitutions: Template variable substitutions
    """
    logger = get_logger(__name__)

    # Use shared path discovery function for consistency
    shared_templates_dir = discover_shared_templates_path()

    if not shared_templates_dir:
        logger.debug("Shared templates directory not found - skipping shared templates")
        return
    manifest_path = shared_templates_dir / "manifest.yml"

    if not manifest_path.exists():
        logger.debug("No shared manifest.yml found - skipping shared templates")
        return

    try:
        parser = ManifestParser(manifest_path)
    except (FileNotFoundError, ValueError) as e:
        logger.warning(f"Failed to load shared manifest: {e}")
        return

    logger.debug("Processing shared templates from manifest...")

    # Process all file types from manifest
    all_files = parser.get_all_files()

    for file_config in all_files:
        # Handle both manifest formats:
        # 1. New format with 'source' and 'dest' fields
        # 2. Legacy format with 'path' field (used as both source and dest)
        source_name = file_config.get("source")
        dest_name = file_config.get("dest")

        # If source/dest not present, check for 'path' field
        if not source_name and not dest_name:
            path = file_config.get("path")
            if path:
                source_name = path
                dest_name = path

        if not source_name or not dest_name:
            logger.debug(
                f"Skipping manifest entry with missing source/dest: {file_config}"
            )
            continue

        template_file = shared_templates_dir / source_name
        target_file = project_path / dest_name

        if not template_file.exists():
            logger.debug(f"Shared template not found: {source_name}")
            continue

        # Create target directory if needed
        target_file.parent.mkdir(parents=True, exist_ok=True)

        # Process template file with substitutions
        process_template_file(template_file, target_file, substitutions)
        logger.debug(f"Processed shared template: {source_name} -> {dest_name}")

        # Make executable if specified
        if file_config.get("executable", False):
            import stat

            current_permissions = target_file.stat().st_mode
            new_permissions = (
                current_permissions | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
            )
            target_file.chmod(new_permissions)
            logger.debug(f"Made executable: {dest_name}")


def setup_claude_hooks(project_path: Path) -> None:
    """Set up Claude Code hooks and script permissions using manifest configuration."""
    import stat

    logger = get_logger(__name__)

    # Use shared path discovery function for consistency
    shared_templates_dir = discover_shared_templates_path()

    executable_scripts = []

    if shared_templates_dir:
        manifest_path = shared_templates_dir / "manifest.yml"

        if manifest_path.exists():
            try:
                parser = ManifestParser(manifest_path)
                executable_scripts.extend(parser.get_executable_scripts())
                logger.debug(
                    f"Found {len(executable_scripts)} executable scripts from manifest"
                )
            except (FileNotFoundError, ValueError) as e:
                logger.warning(f"Failed to load shared manifest: {e}")

    # Fallback to hardcoded list if no manifest found
    if not executable_scripts:
        logger.debug("Using fallback hardcoded executable scripts list")
        executable_scripts = [
            ".claude/hooks/validate-bash-command.sh",
            ".claude/hooks/update-docs.py",
            ".genesis/scripts/setup/setup.sh",
        ]

    # Make scripts executable
    for script_rel_path in executable_scripts:
        script_path = project_path / script_rel_path
        if script_path.exists():
            # Add execute permission for user, group, and others
            current_permissions = script_path.stat().st_mode
            new_permissions = (
                current_permissions | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
            )
            script_path.chmod(new_permissions)
            logger.debug(f"Made executable: {script_path}")
        else:
            logger.debug(f"Script not found (optional): {script_path}")

    # Also make all shell scripts in scripts/ directory executable (safety net)
    scripts_dir = project_path / "scripts"
    if scripts_dir.exists():
        for script_file in scripts_dir.glob("*.sh"):
            if script_file.is_file():
                current_permissions = script_file.stat().st_mode
                new_permissions = (
                    current_permissions | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
                )
                script_file.chmod(new_permissions)
                logger.debug(f"Made executable: {script_file}")

    # Verify .claude/settings.json exists
    settings_file = project_path / ".claude" / "settings.json"
    if settings_file.exists():
        logger.info("✅ Claude Code hooks configured and ready")
    else:
        logger.warning("⚠️  Claude Code settings.json not found")

    logger.info("🎯 Genesis development patterns will be enforced by Claude Code hooks")


def create_initial_sync_config(project_path: Path, project_type: str) -> None:
    """Create initial sync.yml configuration file for the bootstrapped project.

    Args:
        project_path: Path to the project directory
        project_type: Type of project (python-api, cli-tool, etc.)
    """
    logger = get_logger(__name__)

    genesis_dir = project_path / ".genesis"

    # Handle corrupted .genesis (exists as file instead of directory)
    if genesis_dir.exists() and not genesis_dir.is_dir():
        logger.warning(f"Found corrupted .genesis file, removing: {genesis_dir}")
        genesis_dir.unlink()

    genesis_dir.mkdir(exist_ok=True)

    sync_yml_path = genesis_dir / "sync.yml"

    # Generate sync configuration based on project type and shared manifest
    sync_config = generate_sync_config(project_path, project_type)

    # Write sync.yml
    try:
        import yaml

        with open(sync_yml_path, "w") as f:
            yaml.dump(sync_config, f, default_flow_style=False, sort_keys=False)

        logger.info(f"✅ Created sync configuration: {sync_yml_path}")

    except Exception as e:
        logger.warning(f"⚠️  Failed to create sync.yml: {e}")
        # Don't fail bootstrap for this - sync.yml can be created later with genesis init


def create_sync_yml_config(project_path: Path, project_type: str) -> None:
    """Create sync.yml configuration file for the bootstrapped project.

    Deprecated: Use create_initial_sync_config instead.
    This function is kept for backward compatibility.

    Args:
        project_path: Path to the project directory
        project_type: Type of project (python-api, cli-tool, etc.)
    """
    create_initial_sync_config(project_path, project_type)


def generate_sync_config(project_path: Path, project_type: str) -> dict[str, Any]:
    """Generate sync.yml configuration dictionary.

    Args:
        project_path: Path to the project directory
        project_type: Type of project (python-api, cli-tool, etc.)

    Returns:
        Dictionary representing sync.yml content
    """
    logger = get_logger(__name__)

    project_name = project_path.name
    # Replace hyphens and dots with underscores and lowercase for valid Python module names
    module_name = project_name.replace("-", "_").replace(".", "_").lower()

    # Generate separate file lists for nested structure
    shared_files = generate_file_list_for_type("shared")
    project_files = generate_file_list_for_type(project_type, project_name)

    # Combine for backward compatibility with sync_policies
    all_files = shared_files + project_files

    sync_config: dict[str, Any] = {
        "version": "1.0",  # v1.0 format specification
        "template_source": project_type,  # For backward compatibility
        "project": {
            "name": project_name,
            "type": project_type,
            "module_name": module_name,
            "created_at": None,  # Will be set below
            "created_with_genesis": "0.12.0",
        },
        "variables": {
            "project_name": project_name,
            "module_name": module_name,
            "project_type": project_type,
            "python_version": "3.11",
            "genesis_version": "0.12.0",
            "github_user": "",
            "app_port": "8000",
            "subnet_octet": "172",
        },
        "files": all_files,  # Flat list of all file synchronization rules
        "sync_policies": {  # Configuration settings for sync behavior
            "backup_changed_files": True,
            "backup_suffix": ".genesis-backup",
            "create_directories": True,
            "preserve_permissions": True,
            "validate_templates": True,
        },
    }

    # Set creation timestamp
    import datetime

    project_section = sync_config["project"]
    assert isinstance(project_section, dict)
    project_section["created_at"] = datetime.datetime.now(datetime.UTC).isoformat()

    logger.debug(f"Generated sync config for {project_type} project: {project_name}")
    return sync_config


def generate_file_list_for_type(
    file_type: str, project_name: str | None = None
) -> list[dict[str, Any]]:
    """Generate file list for specific project type or shared files.

    Args:
        file_type: Type identifier ('shared', 'python-api', 'cli-tool', etc.)

    Returns:
        List of file configuration dictionaries
    """
    logger = get_logger(__name__)

    if file_type == "shared":
        # Load shared files from manifest
        shared_policies = load_shared_template_policies()
        return shared_policies

    elif file_type in ["python-api", "cli-tool"]:
        # Python project specific files
        files = []

        # Calculate module_name from project_name
        module_name = (
            project_name.replace("-", "_") if project_name else "{{module_name}}"
        )

        # Common Python files
        files.append(
            {
                "source": f"{file_type}/pyproject.toml.template",
                "dest": "pyproject.toml",
                "policy": "if_unchanged",
                "description": "Python project configuration",
            }
        )

        files.append(
            {
                "source": f"{file_type}/README.md.template",
                "dest": "README.md",
                "policy": "never",
                "description": "Project documentation",
            }
        )

        # Project type specific files
        if file_type == "python-api":
            files.extend(
                [
                    {
                        "source": f"{file_type}/main.py.template",
                        "dest": "main.py",
                        "policy": "never",
                        "description": "Main application file",
                    },
                    {
                        "source": f"{file_type}/api/__init__.py.template",
                        "dest": f"{module_name}/__init__.py",
                        "policy": "never",
                        "description": "API package initialization",
                    },
                ]
            )

        elif file_type == "cli-tool":
            files.extend(
                [
                    {
                        "source": f"{file_type}/src/__module_name__/cli.py.template",
                        "dest": f"src/{module_name}/cli.py",
                        "policy": "never",
                        "description": "CLI entry point",
                    },
                    {
                        "source": f"{file_type}/src/__module_name__/__init__.py.template",
                        "dest": f"src/{module_name}/__init__.py",
                        "policy": "never",
                        "description": "CLI package initialization",
                    },
                    {
                        "source": f"{file_type}/src/__module_name__/main.py.template",
                        "dest": f"src/{module_name}/main.py",
                        "policy": "never",
                        "description": "Main entry point",
                    },
                    {
                        "source": f"{file_type}/tests/test_cli.py.template",
                        "dest": "tests/test_cli.py",
                        "policy": "never",
                        "description": "CLI tests",
                    },
                ]
            )

        return files

    elif file_type in ["typescript-service", "react-app"]:
        # TypeScript project specific files
        return [
            {
                "source": f"{file_type}/package.json.template",
                "dest": "package.json",
                "policy": "if_unchanged",
                "description": "Node.js project configuration",
            },
            {
                "source": f"{file_type}/tsconfig.json.template",
                "dest": "tsconfig.json",
                "policy": "if_unchanged",
                "description": "TypeScript configuration",
            },
            {
                "source": f"{file_type}/src/index.ts.template",
                "dest": "src/index.ts",
                "policy": "never",
                "description": "Main TypeScript entry point",
            },
        ]

    elif file_type == "terraform-project":
        # Terraform project specific files
        return [
            {
                "source": f"{file_type}/main.tf.template",
                "dest": "main.tf",
                "policy": "never",
                "description": "Main Terraform configuration",
            },
            {
                "source": f"{file_type}/variables.tf.template",
                "dest": "variables.tf",
                "policy": "if_unchanged",
                "description": "Terraform variables",
            },
            {
                "source": f"{file_type}/outputs.tf.template",
                "dest": "outputs.tf",
                "policy": "if_unchanged",
                "description": "Terraform outputs",
            },
        ]

    else:
        logger.warning(f"Unknown file type: {file_type}")
        return []


def load_shared_template_policies() -> list[dict[str, str]]:
    """Load sync policies from shared templates manifest.

    Returns:
        List of sync policy dictionaries
    """
    logger = get_logger(__name__)

    # Use shared path discovery function for consistency
    shared_templates_dir = discover_shared_templates_path()

    if not shared_templates_dir:
        logger.debug("Shared templates directory not found - no shared policies loaded")
        return []

    manifest_path = shared_templates_dir / "manifest.yml"
    if not manifest_path.exists():
        logger.debug("Shared manifest not found - no shared policies loaded")
        return []

    try:
        import yaml

        with open(manifest_path) as f:
            manifest = yaml.safe_load(f)

        policies = []

        # Process shared_files
        for file_config in manifest.get("shared_files", []):
            policy = {
                "source": f"shared/{file_config['source']}",
                "dest": file_config["dest"],
                "policy": file_config["sync"],
                "description": file_config.get("description", ""),
            }

            if file_config.get("executable"):
                policy["executable"] = True

            policies.append(policy)

        # Process claude_hooks
        for hook_config in manifest.get("claude_hooks", []):
            policy = {
                "source": f"shared/{hook_config['source']}",
                "dest": hook_config["dest"],
                "policy": hook_config["sync"],
                "executable": hook_config.get("executable", False),
                "description": hook_config.get("description", "Claude Code hook"),
            }
            policies.append(policy)

        # Process claude_commands
        for cmd_config in manifest.get("claude_commands", []):
            policy = {
                "source": f"shared/{cmd_config['source']}",
                "dest": cmd_config["dest"],
                "policy": cmd_config["sync"],
                "description": cmd_config.get(
                    "description", "Claude Code configuration"
                ),
            }
            policies.append(policy)

        # Process claude_agents
        for agent_config in manifest.get("claude_agents", []):
            policy = {
                "source": f"shared/{agent_config['source']}",
                "dest": agent_config["dest"],
                "policy": agent_config["sync"],
                "description": agent_config.get("description", "Claude Code agent"),
            }
            policies.append(policy)

        logger.debug(f"Loaded {len(policies)} policies from shared manifest")
        return policies

    except Exception as e:
        logger.warning(f"Failed to load shared manifest: {e}")
        return []


def get_project_specific_policies(project_type: str) -> list[dict[str, str]]:
    """Get project-specific sync policies.

    Args:
        project_type: Type of project (python-api, cli-tool, etc.)

    Returns:
        List of project-specific sync policy dictionaries
    """
    # Base policies that most projects have
    policies = []

    # Python projects typically have these files
    if project_type in ["python-api", "cli-tool"]:
        policies.extend(
            [
                {
                    "source": f"{project_type}/pyproject.toml.template",
                    "dest": "pyproject.toml",
                    "policy": "if_unchanged",
                    "description": "Python project configuration",
                }
            ]
        )

        if project_type == "python-api":
            policies.append(
                {
                    "source": f"{project_type}/main.py.template",
                    "dest": "main.py",
                    "policy": "never",
                    "description": "Main application file",
                }
            )

        elif project_type == "cli-tool":
            # CLI tools use src/ layout - these are handled by generate_file_list_for_type
            # This function is deprecated for CLI tools, but keeping for compatibility
            pass

    # TypeScript projects
    elif project_type in ["typescript-service", "react-app"]:
        policies.extend(
            [
                {
                    "source": f"{project_type}/package.json.template",
                    "dest": "package.json",
                    "policy": "if_unchanged",
                    "description": "Node.js project configuration",
                },
                {
                    "source": f"{project_type}/tsconfig.json.template",
                    "dest": "tsconfig.json",
                    "policy": "if_unchanged",
                    "description": "TypeScript configuration",
                },
            ]
        )

    return policies


def initialize_git_repo(project_path: Path, skip_git: bool) -> None:
    """Initialize Git repository in project."""
    if skip_git:
        get_logger(__name__).info("Skipping Git initialization (--skip-git)")
        return

    try:
        # Check if git is available
        subprocess.run(["git", "--version"], check=True, capture_output=True)

        # Initialize repository
        subprocess.run(
            ["git", "init"], cwd=project_path, check=True, capture_output=True
        )

        # Create initial commit
        subprocess.run(
            ["git", "add", "."], cwd=project_path, check=True, capture_output=True
        )

        subprocess.run(
            ["git", "commit", "-m", "Initial commit from Genesis bootstrap"],
            cwd=project_path,
            check=True,
            capture_output=True,
        )

        get_logger(__name__).info("Initialized Git repository with initial commit")

    except subprocess.CalledProcessError as e:
        get_logger(__name__).warning(f"Git initialization failed: {e}")
    except FileNotFoundError:
        get_logger(__name__).warning(
            "Git not found - skipping repository initialization"
        )


def setup_project_environment(project_path: Path) -> None:
    """Set up project development environment (Poetry, pre-commit, etc.)."""
    logger = get_logger(__name__)

    # Check if this is a Python project with Poetry
    if not (project_path / "pyproject.toml").exists():
        logger.debug("No pyproject.toml found - skipping Python setup")
        return

    try:
        # Install Poetry dependencies
        logger.info("Installing project dependencies with Poetry...")
        subprocess.run(
            ["poetry", "install"],
            cwd=project_path,
            check=True,
            capture_output=True,
            text=True,
        )
        logger.info("✅ Poetry dependencies installed successfully")

        # Install Genesis CLI for development workflow
        logger.info("Installing Genesis CLI for development workflow...")
        genesis_root = find_genesis_root()
        if genesis_root:
            # Install Genesis from local development version
            subprocess.run(
                ["poetry", "run", "pip", "install", "-e", str(genesis_root)],
                cwd=project_path,
                check=True,
                capture_output=True,
            )
            logger.info("✅ Genesis CLI installed from local development version")
        else:
            # Try to install from PyPI (future when published)
            try:
                subprocess.run(
                    ["poetry", "run", "pip", "install", "genesis-cli"],
                    cwd=project_path,
                    check=True,
                    capture_output=True,
                )
                logger.info("✅ Genesis CLI installed from PyPI")
            except subprocess.CalledProcessError:
                logger.warning(
                    "⚠️  Genesis CLI not available - install manually: pip install genesis-cli"
                )

        # Install pre-commit hooks
        if (project_path / ".pre-commit-config.yaml").exists():
            logger.info("Installing pre-commit hooks...")
            subprocess.run(
                ["poetry", "run", "pre-commit", "install", "--install-hooks"],
                cwd=project_path,
                check=True,
                capture_output=True,
            )
            logger.info("✅ Pre-commit hooks installed successfully")

        # Handle direnv if available and .envrc exists
        if (project_path / ".envrc").exists():
            try:
                subprocess.run(
                    ["direnv", "allow", str(project_path)],
                    check=True,
                    capture_output=True,
                )
                logger.info("✅ Direnv environment configured")
            except FileNotFoundError:
                # Direnv not found - try to install it
                logger.info("📦 Installing direnv for automatic environment loading...")
                try:
                    # Try to install direnv via Homebrew (macOS/Linux)
                    subprocess.run(
                        ["brew", "install", "direnv"],
                        check=True,
                        capture_output=True,
                    )
                    # Configure direnv for the shell automatically
                    logger.info("🔧 Configuring direnv for shell integration...")
                    try:
                        # Add direnv hook to shell config files

                        shell = get_user_shell()

                        if "zsh" in shell:
                            zshrc_path = Path.home() / ".zshrc"
                            hook_line = 'eval "$(direnv hook zsh)"\n'
                        elif "bash" in shell:
                            bashrc_path = Path.home() / ".bashrc"
                            hook_line = 'eval "$(direnv hook bash)"\n'
                        else:
                            # Default to zsh
                            zshrc_path = Path.home() / ".zshrc"
                            hook_line = 'eval "$(direnv hook zsh)"\n'

                        # Add hook if not already present
                        if "zsh" in shell:
                            config_file = zshrc_path
                        else:
                            config_file = bashrc_path if "bash" in shell else zshrc_path

                        if config_file.exists():
                            existing_content = config_file.read_text()
                            if "direnv hook" not in existing_content:
                                with config_file.open("a") as f:
                                    f.write(
                                        f"\n# Added by Genesis bootstrap\n{hook_line}"
                                    )
                                logger.info(
                                    "✅ Added direnv hook to shell configuration"
                                )
                        else:
                            # Create shell config file with direnv hook
                            with config_file.open("w") as f:
                                f.write(f"# Genesis shell configuration\n{hook_line}")
                            logger.info(
                                "✅ Created shell configuration with direnv hook"
                            )

                        # Allow the .envrc file after installation
                        subprocess.run(
                            ["direnv", "allow", str(project_path)],
                            check=True,
                            capture_output=True,
                        )
                        logger.info("✅ Direnv installed and configured automatically")

                    except subprocess.CalledProcessError:
                        logger.warning("⚠️  Direnv installed but configuration failed")
                        logger.info(
                            "💡 Run 'direnv allow' in the project directory to enable environment loading"
                        )
                except subprocess.CalledProcessError:
                    logger.warning("⚠️  Could not install direnv automatically")
                    logger.info("💡 Install manually: brew install direnv")
                    logger.info("💡 Then run 'direnv allow' in the project directory")
                except FileNotFoundError:
                    logger.warning(
                        "⚠️  Homebrew not found - cannot install direnv automatically"
                    )
                    logger.info(
                        "💡 Install direnv manually for automatic environment loading"
                    )
            except subprocess.CalledProcessError:
                logger.warning("⚠️  Failed to configure direnv for this project")
                logger.info(
                    "💡 Run 'direnv allow' in the project directory to enable environment loading"
                )

    except subprocess.CalledProcessError as e:
        if e.stderr:
            error_output = (
                e.stderr.decode() if isinstance(e.stderr, bytes) else e.stderr
            )
        else:
            error_output = str(e)
        logger.warning(f"Project setup encountered issues: {error_output}")
        logger.info(
            "You can run the setup manually later with the provided setup.sh script"
        )
    except FileNotFoundError:
        logger.warning("Poetry not found - skipping dependency installation")
        logger.info(
            "Please install Poetry and run 'poetry install' in the project directory"
        )


def bootstrap_project(
    name: str,
    project_type: str,
    target_path: str | None = None,
    skip_git: bool = False,
) -> Path:
    """Bootstrap a new project with Genesis patterns."""

    # Extract project name from path if needed
    project_name = Path(name).name

    # Validate inputs
    validate_project_name(project_name)

    # Determine project path
    if target_path:
        project_path = Path(target_path) / name
    else:
        project_path = Path.cwd() / name

    project_path = project_path.resolve()

    # Get template path
    template_path = get_template_path(project_type)
    if not template_path:
        raise ResourceError(
            f"Template '{project_type}' not found or Genesis not detected",
            resource_type="template",
        )

    get_logger(__name__).info(
        f"Bootstrapping {project_type} project '{name}' at {project_path}"
    )

    try:
        # Create project directory
        create_project_directory(project_path)

        # Copy only essential files - let sync handle the rest
        copy_essential_files(template_path, project_path, project_name, project_type)

        # Create initial sync.yml configuration
        create_initial_sync_config(project_path, project_type)

        # Set up Claude Code hooks
        setup_claude_hooks(project_path)

        # Initialize Git repository
        initialize_git_repo(project_path, skip_git)

        # Set up project environment (Poetry, pre-commit, direnv)
        setup_project_environment(project_path)

        get_logger(__name__).info(
            f"✅ Project '{name}' created successfully at {project_path}"
        )
        return project_path

    except Exception as e:
        # Clean up on failure
        if project_path.exists():
            try:
                shutil.rmtree(project_path)
                get_logger(__name__).debug(
                    f"Cleaned up failed project directory: {project_path}"
                )
            except Exception:
                pass  # Best effort cleanup
        handled_error = handle_error(e)
        raise InfrastructureError(f"Bootstrap failed: {handled_error.message}") from e


# CLI command integration
def bootstrap_command(
    name: str, project_type: str, target_path: str | None, skip_git: bool
) -> None:
    """Bootstrap command implementation for CLI integration."""
    try:
        project_path = bootstrap_project(name, project_type, target_path, skip_git)
        logger.info(f"✅ Project '{name}' created at {project_path}")
        logger.info(f"📁 Type: {project_type}")
        logger.info("🚀 Essential files created, ready to start development!")
        logger.info("")
        logger.info("📋 IMPORTANT: Complete project setup by running:")
        logger.info(f"  cd {name}")
        logger.info(
            "  genesis sync       # Get complete project structure and configuration"
        )
        logger.info("")
        logger.info("Next steps after sync:")
        logger.info("  make setup         # Install dependencies and dev tools")
        logger.info("  make test          # Run tests")
        logger.info("  make run           # Start development server")
        logger.info("")
        logger.info("Development workflow:")
        logger.info("  genesis sync       # Update project files from templates")
        logger.info("  genesis commit     # Smart commit with quality gates")
        logger.info("  make help          # See all available commands")
        logger.info("")
        logger.info("📁 Current structure:")
        logger.info("  README.md          # Project documentation")
        logger.info("  .genesis/sync.yml  # Sync configuration (customize as needed)")
        logger.info("  Core project files # Main entry point and dependencies")
        logger.info("")
        logger.info("🔄 Sync will add:")
        logger.info("  Development tools  # Docker, scripts, CI/CD configuration")
        logger.info("  Genesis tooling    # Claude hooks, quality gates")
        logger.info("  Documentation      # Guides and troubleshooting")

    except Exception as e:
        handled_error = handle_error(e)
        logger.error(f"❌ Bootstrap failed: {handled_error.message}")
        get_logger(__name__).error("Bootstrap error", extra=handled_error.to_dict())
        sys.exit(1)
