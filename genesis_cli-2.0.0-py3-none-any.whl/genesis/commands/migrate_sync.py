"""Genesis migrate-sync command - Migrate sync.yml to manifest.yml format.

This module provides migration tooling for transitioning from the deprecated sync.yml
format to the new manifest.yml format (issue #458.5).

The migration preserves all project configuration and file metadata while converting
to the new format that supports hash-based sync optimization.
"""

import shutil
from pathlib import Path
from typing import Any

import click
import yaml

try:
    from genesis.core import get_logger

    logger = get_logger(__name__)
except ImportError:
    import logging

    logger = logging.getLogger(__name__)


def convert_sync_to_manifest(sync_config: dict[str, Any]) -> dict[str, Any]:
    """Convert sync.yml format to manifest.yml format.

    Args:
        sync_config: Configuration dictionary in sync.yml format

    Returns:
        Configuration dictionary in manifest.yml format

    Format conversion:
        sync.yml:
            template_source: shared
            files:
              - source: file.template
                dest: file
                policy: always

        manifest.yml:
            shared_files:
              - source: file.template
                dest: file
                sync: always
    """
    manifest_config: dict[str, Any] = {"shared_files": []}

    # Get file list from either 'files' or 'sync_policies' (old format)
    files = sync_config.get("files", sync_config.get("sync_policies", []))

    for file_entry in files:
        manifest_entry: dict[str, Any] = {}

        # Convert source
        manifest_entry["source"] = file_entry.get("source", "")

        # Convert dest (handle both 'dest' and 'pattern' field names)
        manifest_entry["dest"] = file_entry.get("dest", file_entry.get("pattern", ""))

        # Convert policy -> sync
        policy = file_entry.get("policy", file_entry.get("sync", "if_unchanged"))
        manifest_entry["sync"] = policy

        # Preserve optional fields
        if "description" in file_entry:
            manifest_entry["description"] = file_entry["description"]

        if "source_hash" in file_entry:
            manifest_entry["source_hash"] = file_entry["source_hash"]

        if "executable" in file_entry:
            manifest_entry["executable"] = file_entry["executable"]

        manifest_config["shared_files"].append(manifest_entry)

    return manifest_config


def migrate_sync_yml_to_manifest(
    project_path: Path, dry_run: bool = False, force: bool = False
) -> dict[str, Any]:
    """Migrate sync.yml to manifest.yml format.

    Args:
        project_path: Path to the project directory
        dry_run: If True, show what would be done without making changes
        force: If True, overwrite existing manifest.yml

    Returns:
        Dictionary with migration results

    Raises:
        FileNotFoundError: If sync.yml doesn't exist
    """
    genesis_dir = project_path / ".genesis"
    sync_yml_path = genesis_dir / "sync.yml"
    manifest_yml_path = genesis_dir / "manifest.yml"

    # Check if sync.yml exists
    if not sync_yml_path.exists():
        raise FileNotFoundError(
            f"sync.yml not found at {sync_yml_path}. Nothing to migrate."
        )

    # Check if manifest.yml already exists
    if manifest_yml_path.exists() and not force:
        logger.warning(
            f"⚠️  manifest.yml already exists at {manifest_yml_path}. "
            "Use --force to overwrite."
        )
        return {
            "success": False,
            "skipped": True,
            "message": "manifest.yml already exists",
        }

    # Load sync.yml
    logger.info(f"📄 Loading sync.yml from {sync_yml_path}")
    with open(sync_yml_path) as f:
        sync_config = yaml.safe_load(f)

    # Convert to manifest format
    logger.info("🔄 Converting sync.yml format to manifest.yml format")
    manifest_config = convert_sync_to_manifest(sync_config)

    # Extract project metadata for result
    project_metadata = {
        "name": sync_config.get("project", {}).get("name", project_path.name),
        "type": sync_config.get("project", {}).get("type", "unknown"),
        "variables": sync_config.get("variables", {}),
    }

    result: dict[str, Any] = {
        "success": True,
        "dry_run": dry_run,
        "files_migrated": len(manifest_config["shared_files"]),
        "project_metadata": project_metadata,
        "backup_created": False,
        "skipped": False,
    }

    if dry_run:
        logger.info("🔍 DRY RUN - No files will be modified")
        logger.info(f"Would create manifest.yml with {result['files_migrated']} files")
        result["would_create_manifest"] = True
        return result

    # Create backup of sync.yml
    backup_path = genesis_dir / "sync.yml.backup"
    logger.info(f"📦 Creating backup at {backup_path}")
    shutil.copy2(sync_yml_path, backup_path)
    result["backup_created"] = True

    # Write manifest.yml
    logger.info(f"✅ Writing manifest.yml to {manifest_yml_path}")
    with open(manifest_yml_path, "w") as f:
        yaml.dump(manifest_config, f, default_flow_style=False, sort_keys=False)

    logger.info(
        f"✅ Migration complete! Migrated {result['files_migrated']} file entries"
    )
    logger.info(f"📝 Original sync.yml backed up to {backup_path}")
    logger.info(
        "💡 You can now use 'genesis sync' which will automatically use manifest.yml"
    )

    return result


@click.command("migrate-sync")
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be migrated without making changes",
)
@click.option(
    "--force",
    is_flag=True,
    help="Overwrite existing manifest.yml if it exists",
)
@click.option(
    "--path",
    type=click.Path(exists=True),
    help="Path to project (default: current directory)",
)
def migrate_sync(dry_run: bool, force: bool, path: str | None) -> None:
    """Migrate sync.yml to manifest.yml format.

    This command converts the deprecated sync.yml configuration format to the new
    manifest.yml format introduced in Genesis 1.5.0. The new format supports
    hash-based sync optimization for better performance.

    The migration:
    - Converts 'policy' field to 'sync' field
    - Preserves all file metadata (description, executable, source_hash)
    - Creates backup of original sync.yml
    - Maintains project configuration

    Examples:
        genesis migrate-sync                # Migrate current project
        genesis migrate-sync --dry-run      # Preview migration
        genesis migrate-sync --force        # Overwrite existing manifest.yml
    """
    try:
        project_path = Path(path) if path else Path.cwd()

        # Verify Genesis project
        genesis_dir = project_path / ".genesis"
        if not genesis_dir.exists():
            raise click.ClickException(
                "Not a Genesis project. Run 'genesis init' first."
            )

        # Run migration
        result = migrate_sync_yml_to_manifest(
            project_path, dry_run=dry_run, force=force
        )

        # Display results
        if result.get("skipped"):
            click.echo(f"⚠️  {result['message']}")
            click.echo("Use --force to overwrite existing manifest.yml")
        elif result["dry_run"]:
            click.echo(f"🔍 DRY RUN: Would migrate {result['files_migrated']} files")
            click.echo("Run without --dry-run to perform the migration")
        else:
            click.echo(f"✅ Successfully migrated {result['files_migrated']} files")
            click.echo("📦 Backup created: .genesis/sync.yml.backup")
            click.echo("💡 Run 'genesis sync' to use the new manifest.yml")

    except FileNotFoundError as e:
        logger.error(f"❌ {e}")
        raise click.ClickException(str(e)) from e
    except Exception as e:
        logger.error(f"❌ Migration failed: {e}")
        raise click.ClickException(f"Migration failed: {e}") from e


# Export for CLI registration
migrate_sync_command = migrate_sync
