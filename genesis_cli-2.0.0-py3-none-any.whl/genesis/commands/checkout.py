"""Genesis checkout command implementation."""

import subprocess
import sys

import click

from genesis.core.errors import handle_error
from genesis.core.logger import get_logger

# Initialize logger
logger = get_logger(__name__)


@click.command()
@click.argument("target", required=True)
@click.option(
    "--force", "-f", is_flag=True, help="Force checkout (equivalent to git checkout -f)"
)
def checkout(target: str, force: bool) -> None:
    """Switch to a different branch or restore files.

    Args:
        target: Branch name or file path to checkout
        force: Force checkout, discarding local changes
    """
    logger.info(f"Switching to {target}")

    # Build git command
    cmd = ["git", "checkout"]
    if force:
        cmd.append("-f")
    cmd.append(target)

    try:
        # Execute git checkout
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)

        # Handle output
        if result.stdout:
            click.echo(result.stdout.strip())

        if result.returncode != 0:
            if result.stderr:
                logger.error(f"Checkout failed: {result.stderr.strip()}")
                click.echo(result.stderr.strip(), err=True)
            sys.exit(result.returncode)

        logger.info(f"Successfully switched to {target}")

    except Exception as e:
        handled_error = handle_error(e)
        logger.error(f"Failed to execute checkout: {handled_error.message}")
        sys.exit(1)
