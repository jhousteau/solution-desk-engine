"""Genesis branch command implementation."""

import subprocess
import sys

import click

from genesis.core.errors import handle_error
from genesis.core.logger import get_logger

# Initialize logger
logger = get_logger(__name__)


@click.group()
def branch() -> None:
    """Manage Git branches."""


@branch.command("list")
@click.option("--all", "-a", is_flag=True, help="Show all branches (local and remote)")
@click.option("--remote", "-r", is_flag=True, help="Show only remote branches")
def list_branches(all: bool, remote: bool) -> None:
    """List branches."""
    logger.info("Listing branches")

    # Build git command
    cmd = ["git", "branch"]
    if all:
        cmd.append("-a")
    elif remote:
        cmd.append("-r")

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)

        if result.stdout:
            click.echo(result.stdout.strip())

        if result.returncode != 0:
            if result.stderr:
                logger.error(f"Branch list failed: {result.stderr.strip()}")
                click.echo(result.stderr.strip(), err=True)
            sys.exit(result.returncode)

    except Exception as e:
        handled_error = handle_error(e)
        logger.error(f"Failed to list branches: {handled_error.message}")
        sys.exit(1)


@branch.command("delete")
@click.argument("branch_name", required=True)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Force delete branch (equivalent to git branch -D)",
)
def delete_branch(branch_name: str, force: bool) -> None:
    """Delete a branch.

    Args:
        branch_name: Name of the branch to delete
        force: Force delete (use -D instead of -d)
    """
    logger.info(f"Deleting branch {branch_name}")

    # Build git command
    cmd = ["git", "branch"]
    if force:
        cmd.append("-D")
    else:
        cmd.append("-d")
    cmd.append(branch_name)

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)

        if result.stdout:
            click.echo(result.stdout.strip())

        if result.returncode != 0:
            if result.stderr:
                logger.error(f"Branch delete failed: {result.stderr.strip()}")
                click.echo(result.stderr.strip(), err=True)
            sys.exit(result.returncode)

        logger.info(f"Successfully deleted branch {branch_name}")

    except Exception as e:
        handled_error = handle_error(e)
        logger.error(f"Failed to delete branch: {handled_error.message}")
        sys.exit(1)


@branch.command("create")
@click.argument("branch_name", required=True)
@click.option(
    "--switch", "-s", is_flag=True, help="Switch to the new branch after creating it"
)
def create_branch(branch_name: str, switch: bool) -> None:
    """Create a new branch.

    Args:
        branch_name: Name of the new branch
        switch: Switch to the new branch after creating
    """
    logger.info(f"Creating branch {branch_name}")

    # Build git command
    if switch:
        cmd = ["git", "checkout", "-b", branch_name]
    else:
        cmd = ["git", "branch", branch_name]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)

        if result.stdout:
            click.echo(result.stdout.strip())

        if result.returncode != 0:
            if result.stderr:
                logger.error(f"Branch create failed: {result.stderr.strip()}")
                click.echo(result.stderr.strip(), err=True)
            sys.exit(result.returncode)

        action = "created and switched to" if switch else "created"
        logger.info(f"Successfully {action} branch {branch_name}")

    except Exception as e:
        handled_error = handle_error(e)
        logger.error(f"Failed to create branch: {handled_error.message}")
        sys.exit(1)
