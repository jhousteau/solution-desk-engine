"""Docker network conflict detection and resolution utilities.

This module provides utilities to detect and resolve Docker network conflicts
for Genesis container management. It automatically selects available subnets
when conflicts are detected and provides clear error messages.

Environment Variables:
    GENESIS_DOCKER_SUBNET: Override the default subnet selection
"""

import json
import os
import subprocess
from pathlib import Path

import yaml

try:
    from genesis.core import get_logger

    logger = get_logger(__name__)
except ImportError:
    import logging

    logger = logging.getLogger(__name__)


# Use constants for subnet candidates and environment defaults
from genesis.core.constants import EnvironmentDefaults, get_subnet_candidates


def is_docker_running() -> bool:
    """Check if Docker daemon is running and accessible.

    Returns:
        bool: True if Docker is running and accessible, False otherwise
    """
    try:
        docker_timeout = int(
            os.environ.get(
                "GENESIS_DOCKER_TIMEOUT", EnvironmentDefaults.DEFAULT_DOCKER_TIMEOUT
            )
        )
        result = subprocess.run(
            ["docker", "version", "--format", "{{.Server.Version}}"],
            capture_output=True,
            text=True,
            timeout=docker_timeout,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def get_existing_docker_networks() -> dict[str, list[str]]:
    """Get all existing Docker networks and their subnets.

    Returns:
        Dict mapping network names to list of subnets
        Returns empty dict if Docker is not running or on error
    """
    if not is_docker_running():
        logger.debug("Docker is not running, skipping network check")
        return {}

    try:
        # Get all networks in JSON format
        docker_timeout = int(
            os.environ.get(
                "GENESIS_DOCKER_TIMEOUT", EnvironmentDefaults.DEFAULT_DOCKER_TIMEOUT
            )
        )
        result = subprocess.run(
            ["docker", "network", "ls", "--format", "{{json .}}"],
            capture_output=True,
            text=True,
            timeout=docker_timeout,
            check=True,
        )

        networks = {}
        for line in result.stdout.strip().split("\n"):
            if not line:
                continue
            try:
                network_info = json.loads(line)
                network_name = network_info.get("Name", "")

                # Get detailed network info including subnets
                # Network timeout for Docker network inspection operations
                network_timeout = int(
                    os.environ.get(
                        "GENESIS_NETWORK_TIMEOUT",
                        EnvironmentDefaults.DEFAULT_NETWORK_TIMEOUT,
                    )
                )
                inspect_result = subprocess.run(
                    ["docker", "network", "inspect", network_name],
                    capture_output=True,
                    text=True,
                    timeout=network_timeout,
                    check=True,
                )

                network_details = json.loads(inspect_result.stdout)
                if network_details and len(network_details) > 0:
                    ipam = network_details[0].get("IPAM", {})
                    # Handle case where Config exists but is None (null in JSON)
                    configs = ipam.get("Config") or []

                    subnets = []
                    for config in configs:
                        subnet = config.get("Subnet")
                        if subnet:
                            subnets.append(subnet)

                    if subnets:
                        networks[network_name] = subnets

            except (json.JSONDecodeError, subprocess.CalledProcessError) as e:
                logger.debug(f"Failed to inspect network {network_name}: {e}")
                continue

        return networks

    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
        logger.warning(f"Failed to get Docker networks: {e}")
        return {}


def parse_subnet_from_compose(compose_file: Path) -> str | None:
    """Extract subnet configuration from docker-compose.yml file.

    Args:
        compose_file: Path to docker-compose.yml file

    Returns:
        Subnet string if found, None otherwise
    """
    if not compose_file.exists():
        logger.debug(f"Compose file does not exist: {compose_file}")
        return None

    try:
        with open(compose_file) as f:
            config = yaml.safe_load(f)

        # Check for network configuration in standard location
        networks = config.get("networks", {})

        # Check each network for subnet configuration
        for network_name, network_config in networks.items():
            if not isinstance(network_config, dict):
                continue

            ipam = network_config.get("ipam", {})
            # Handle case where config exists but is None (null in JSON)
            configs = ipam.get("config") or []

            for ipam_config in configs:
                if isinstance(ipam_config, dict):
                    subnet = ipam_config.get("subnet")
                    if subnet:
                        logger.debug(f"Found subnet {subnet} in network {network_name}")
                        return str(subnet)

        return None

    except (yaml.YAMLError, KeyError) as e:
        logger.debug(f"Failed to parse compose file {compose_file}: {e}")
        return None


def check_network_conflicts(
    subnet: str, existing_networks: dict[str, list[str]] | None = None
) -> bool:
    """Check if a subnet conflicts with existing Docker networks.

    Args:
        subnet: Subnet to check (e.g., PathDefaults.EXAMPLE_SUBNET)
        existing_networks: Optional dict of existing networks, will be fetched if not provided

    Returns:
        True if there's a conflict, False otherwise
    """
    if not is_docker_running():
        logger.debug("Docker not running, no conflicts possible")
        return False

    if existing_networks is None:
        existing_networks = get_existing_docker_networks()

    # Use ipaddress module for proper subnet comparison
    try:
        import ipaddress

        target_network = ipaddress.IPv4Network(subnet)

        for network_name, subnets in existing_networks.items():
            for existing_subnet in subnets:
                try:
                    existing_network = ipaddress.IPv4Network(existing_subnet)
                    if target_network.overlaps(existing_network):
                        logger.debug(
                            f"Subnet {subnet} conflicts with network '{network_name}' "
                            f"using {existing_subnet}"
                        )
                        return True
                except (ipaddress.AddressValueError, ValueError) as e:
                    logger.debug(f"Invalid subnet {existing_subnet}: {e}")
                    continue

    except (ipaddress.AddressValueError, ValueError) as e:
        logger.error(f"Invalid subnet {subnet}: {e}")
        return True  # Treat invalid subnet as conflict to be safe

    return False


def get_available_subnet(candidates: list[str] | None = None) -> str | None:
    """Find an available subnet from candidates that doesn't conflict.

    Args:
        candidates: List of subnet candidates to try (uses defaults if not provided)

    Returns:
        First available subnet, or None if all conflict
    """
    if not is_docker_running():
        # If Docker is not running, return the first candidate as default
        if candidates:
            return str(candidates[0])
        return str(get_subnet_candidates()[0])

    if candidates is None:
        candidates = get_subnet_candidates()

    existing_networks = get_existing_docker_networks()

    for subnet in candidates:
        if not check_network_conflicts(subnet, existing_networks):
            logger.info(f"Selected available subnet: {subnet}")
            return str(subnet)

    return None


def resolve_network_conflicts(
    compose_file: Path,
) -> tuple[bool, str | None, str | None]:
    """Resolve network conflicts for a docker-compose file.

    This is the main entry point for conflict resolution. It:
    1. Checks if GENESIS_DOCKER_SUBNET is set (user override)
    2. Parses the compose file for current subnet
    3. Checks for conflicts
    4. Finds an available subnet if needed

    Args:
        compose_file: Path to docker-compose.yml file

    Returns:
        Tuple of (has_conflict, current_subnet, suggested_subnet)
    """
    # Check for user override first
    override_subnet = os.environ.get("GENESIS_DOCKER_SUBNET")
    if override_subnet:
        logger.info(f"Using subnet from GENESIS_DOCKER_SUBNET: {override_subnet}")
        # Still check for conflicts but respect user choice
        if check_network_conflicts(override_subnet):
            logger.warning(
                f"User-specified subnet {override_subnet} may conflict with existing networks"
            )
        return (False, override_subnet, None)

    # Parse current subnet from compose file
    current_subnet = parse_subnet_from_compose(compose_file)

    if not current_subnet:
        # No subnet configured, suggest a default
        suggested = get_available_subnet()
        logger.info(f"No subnet configured, suggesting: {suggested}")
        return (False, None, suggested)

    # Check for conflicts
    if check_network_conflicts(current_subnet):
        # Find an alternative
        suggested = get_available_subnet()

        if suggested and suggested != current_subnet:
            logger.warning(
                f"Network conflict detected! Current subnet {current_subnet} "
                f"conflicts with existing Docker networks"
            )
            return (True, current_subnet, suggested)
        elif not suggested:
            logger.error(
                f"Network conflict detected with {current_subnet} "
                "but no alternative subnets available"
            )
            return (True, current_subnet, None)

    # No conflicts
    logger.debug(f"No conflicts detected for subnet {current_subnet}")
    return (False, current_subnet, None)


def update_compose_subnet(compose_file: Path, new_subnet: str) -> bool:
    """Update the subnet in a docker-compose.yml file.

    Args:
        compose_file: Path to docker-compose.yml file
        new_subnet: New subnet to use

    Returns:
        True if successfully updated, False otherwise
    """
    if not compose_file.exists():
        logger.error(f"Compose file does not exist: {compose_file}")
        return False

    try:
        with open(compose_file) as f:
            config = yaml.safe_load(f)

        # Update subnet in network configuration
        networks = config.get("networks", {})
        updated = False

        for network_name, network_config in networks.items():
            if not isinstance(network_config, dict):
                continue

            ipam = network_config.setdefault("ipam", {})
            configs = ipam.setdefault("config", [])

            # Update existing subnet or add new one
            if configs:
                for ipam_config in configs:
                    if isinstance(ipam_config, dict) and "subnet" in ipam_config:
                        ipam_config["subnet"] = new_subnet
                        updated = True
                        logger.info(
                            f"Updated subnet in network '{network_name}' to {new_subnet}"
                        )
            else:
                # Add new subnet configuration
                configs.append({"subnet": new_subnet})
                updated = True
                logger.info(f"Added subnet {new_subnet} to network '{network_name}'")

        if updated:
            # Write back the updated configuration
            with open(compose_file, "w") as f:
                yaml.dump(config, f, default_flow_style=False, sort_keys=False)

            logger.info(f"Successfully updated {compose_file} with new subnet")
            return True
        else:
            logger.warning(
                f"No network configuration found to update in {compose_file}"
            )
            return False

    except (OSError, yaml.YAMLError) as e:
        logger.error(f"Failed to update compose file: {e}")
        return False


def format_conflict_message(
    current_subnet: str,
    suggested_subnet: str | None,
    existing_networks: dict[str, list[str]] | None = None,
) -> str:
    """Format a user-friendly error message about network conflicts.

    Args:
        current_subnet: The conflicting subnet
        suggested_subnet: Suggested alternative subnet
        existing_networks: Optional dict of existing networks for details

    Returns:
        Formatted error message
    """
    if existing_networks is None:
        existing_networks = get_existing_docker_networks()

    # Find which network is conflicting
    conflicting_networks = []
    for network_name, subnets in existing_networks.items():
        if current_subnet in subnets:
            conflicting_networks.append(network_name)

    message_lines = [
        "❌ Docker network conflict detected!",
        f"   Current subnet {current_subnet} conflicts with existing Docker networks.",
        "",
    ]

    if conflicting_networks:
        message_lines.append("   Conflicting networks:")
        for network in conflicting_networks[:3]:  # Show max 3 conflicts
            message_lines.append(f"   • {network}")
        if len(conflicting_networks) > 3:
            message_lines.append(f"   • ... and {len(conflicting_networks) - 3} more")
        message_lines.append("")

    message_lines.append("   💡 Solutions:")

    if suggested_subnet:
        message_lines.extend(
            [
                f"   1. Update docker-compose.yml to use subnet: {suggested_subnet}",
                f"   2. Set environment variable: export GENESIS_DOCKER_SUBNET={suggested_subnet}",
                "   3. Remove conflicting Docker networks if not in use",
            ]
        )
    else:
        message_lines.extend(
            [
                "   1. Set a custom subnet: export GENESIS_DOCKER_SUBNET=<your-subnet>",
                "   2. Remove conflicting Docker networks if not in use",
                "   3. Stop other Docker services that may be using the same subnet",
            ]
        )

    return "\n".join(message_lines)
