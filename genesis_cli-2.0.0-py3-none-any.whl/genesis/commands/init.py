"""Genesis init command - Initialize project with explicit sync configuration."""

import json
import re
import subprocess
from pathlib import Path
from typing import Any

import click

from genesis.commands.bootstrap import load_shared_template_policies

try:
    from genesis.core import get_logger

    logger = get_logger(__name__)
except ImportError:
    import logging

    logger = logging.getLogger(__name__)


class ProjectDetector:
    """Detects project type and extracts relevant metadata."""

    @staticmethod
    def _load_toml_file(toml_path: Path) -> dict[str, Any]:
        """Load TOML file with fallback parsers."""
        # Try standard library first (Python 3.11+)
        try:
            import tomllib

            with open(toml_path, "rb") as f:
                return tomllib.load(f)
        except ImportError:
            pass

        # Try tomli package (commonly available)
        try:
            import tomli

            with open(toml_path, "rb") as f:
                result = tomli.load(f)
                return dict(result) if result else {}
        except ImportError:
            pass

        # Try toml package as last resort
        try:
            import toml

            return toml.load(toml_path)
        except ImportError:
            pass

        # Fallback to regex parsing if no toml library available
        content = toml_path.read_text()
        pyproject: dict[str, Any] = {"tool": {"poetry": {"dependencies": {}}}}

        # Extract project name
        name_match = re.search(r'^name\s*=\s*"([^"]+)"', content, re.MULTILINE)
        if name_match:
            pyproject["tool"]["poetry"]["name"] = name_match.group(1)

        # Extract dependencies (basic parsing)
        if "[tool.poetry.dependencies]" in content:
            deps_section = content.split("[tool.poetry.dependencies]")[1]
            # Split at next section or end
            if "[" in deps_section:
                deps_section = deps_section.split("[")[0]

            # Parse dependency lines
            for line in deps_section.split("\n"):
                line = line.strip()
                if line and "=" in line and not line.startswith("#"):
                    dep_name = line.split("=")[0].strip()
                    pyproject["tool"]["poetry"]["dependencies"][dep_name] = "parsed"

        return pyproject

    @staticmethod
    def _create_base_variables(project_name: str, project_path: Path) -> dict[str, str]:
        """Create base template variables from project name."""
        # Use project_name if provided, otherwise use directory name
        name = project_name or project_path.name
        return {
            "project_name": name,
            "module_name": name.replace("-", "_"),  # Convert kebab-case to snake_case
        }

    @staticmethod
    def detect_python_project(
        project_path: Path,
    ) -> tuple[str | None, dict[str, str]]:
        """Detect Python project type from pyproject.toml.

        Returns:
            Tuple of (project_type, variables)
        """
        pyproject_path = project_path / "pyproject.toml"
        if not pyproject_path.exists():
            return None, {}

        pyproject = ProjectDetector._load_toml_file(pyproject_path)

        # Extract project metadata
        tool_section = pyproject.get("tool")
        if not isinstance(tool_section, dict):
            tool_section = {}
        poetry_config = tool_section.get("poetry")
        if not isinstance(poetry_config, dict):
            poetry_config = {}
        project_name = poetry_config.get("name", project_path.name)
        dependencies = poetry_config.get("dependencies")
        if not isinstance(dependencies, dict):
            dependencies = {}

        variables = ProjectDetector._create_base_variables(project_name, project_path)

        # Detect project type based on dependencies
        if "fastapi" in dependencies or "uvicorn" in dependencies:
            return "python-api", variables
        elif "click" in dependencies or "typer" in dependencies:
            variables["command_name"] = project_name
            return "cli-tool", variables
        elif "django" in dependencies:
            return "python-django", variables
        elif "flask" in dependencies:
            return "python-flask", variables
        else:
            # Generic Python project
            return "python", variables

    @staticmethod
    def detect_typescript_project(
        project_path: Path,
    ) -> tuple[str | None, dict[str, str]]:
        """Detect TypeScript/JavaScript project from package.json.

        Returns:
            Tuple of (project_type, variables)
        """
        package_json_path = project_path / "package.json"
        if not package_json_path.exists():
            return None, {}

        try:
            package = json.loads(package_json_path.read_text())

            project_name = package.get("name", project_path.name)
            pkg_deps = package.get("dependencies")
            dev_deps = package.get("devDependencies")
            dependencies = {}
            if isinstance(pkg_deps, dict):
                dependencies.update(pkg_deps)
            if isinstance(dev_deps, dict):
                dependencies.update(dev_deps)

            variables = ProjectDetector._create_base_variables(
                project_name, project_path
            )
            variables["language_extension"] = (
                "ts" if "typescript" in dependencies else "js"
            )

            # Detect specific frameworks
            if "next" in dependencies:
                return "typescript-nextjs", variables
            elif "express" in dependencies:
                return "typescript-service", variables
            elif "react" in dependencies:
                return "typescript-react", variables
            elif "@angular/core" in dependencies:
                return "typescript-angular", variables
            elif "vue" in dependencies:
                return "typescript-vue", variables
            else:
                return "typescript", variables

        except (json.JSONDecodeError, KeyError):
            return None, {}

    @staticmethod
    def detect_terraform_project(
        project_path: Path,
    ) -> tuple[str | None, dict[str, str]]:
        """Detect Terraform project from main.tf or *.tf files.

        Returns:
            Tuple of (project_type, variables)
        """
        tf_files = list(project_path.glob("*.tf"))
        if not tf_files:
            return None, {}

        variables = ProjectDetector._create_base_variables(
            project_path.name, project_path
        )

        variables["terraform_version"] = (
            "latest"  # Could be extracted from .terraform-version if exists
        )

        # Check for specific cloud providers
        for tf_file in tf_files:
            content = tf_file.read_text()
            if "aws" in content.lower():
                variables["cloud_provider"] = "aws"
                break
            elif "azurerm" in content.lower():
                variables["cloud_provider"] = "azure"
                break
            elif "google" in content.lower():
                variables["cloud_provider"] = "gcp"
                break

        return "terraform-project", variables

    @classmethod
    def detect_project_type(cls, project_path: Path) -> tuple[str, dict[str, str]]:
        """Auto-detect project type and extract variables.

        Returns:
            Tuple of (project_type, variables)
        """
        # Try Python detection first
        project_type, variables = cls.detect_python_project(project_path)
        if project_type:
            return project_type, variables

        # Try TypeScript/JavaScript detection
        project_type, variables = cls.detect_typescript_project(project_path)
        if project_type:
            return project_type, variables

        # Try Terraform detection
        project_type, variables = cls.detect_terraform_project(project_path)
        if project_type:
            return project_type, variables

        # Default to unknown with basic variables
        return "unknown", ProjectDetector._create_base_variables(
            project_path.name, project_path
        )


class SyncConfigGenerator:
    """Generates Genesis sync configuration files."""

    # Additional policies not covered by manifest
    ADDITIONAL_POLICIES = {
        "if_unchanged": [
            ".pre-commit-config.yaml",
            ".gitignore",
            "Makefile",
        ],
        "never": [
            "pyproject.toml",
            ".envrc",
            "README.md",
            "CLAUDE.md",
        ],
        "local_override": [
            "docker-compose.yml",
        ],
    }

    @classmethod
    def _load_manifest_policies(cls) -> dict[str, list[dict[str, str]]]:
        """Load sync policies from shared manifest and transform to grouped format."""
        manifest_policies = load_shared_template_policies()

        # Group policies by sync type, preserving full policy objects
        grouped_policies: dict[str, list[dict[str, str]]] = {
            "always": [],
            "if_unchanged": [],
            "never": [],
            "local_override": [],
        }

        for policy in manifest_policies:
            sync_type = policy["policy"]
            if sync_type in grouped_policies:
                grouped_policies[sync_type].append(policy)

        # Add additional hardcoded policies not covered by manifest
        for sync_type, patterns in cls.ADDITIONAL_POLICIES.items():
            for pattern in patterns:
                # For hardcoded policies, assume source equals dest
                policy_obj = {
                    "source": pattern,
                    "dest": pattern,
                    "policy": sync_type,
                    "description": cls._get_file_description(pattern),
                }
                grouped_policies[sync_type].append(policy_obj)

        return grouped_policies

    # Project-specific file additions
    PROJECT_FILES = {
        "python-api": {
            # Python API doesn't have additional specific files currently
        },
        "cli-tool": {
            # CLI tool doesn't have additional specific files currently
        },
        "typescript-service": {
            "always": ["scripts/build-ts.sh"],
            "if_unchanged": ["tsconfig.json", "jest.config.js"],
        },
        "terraform-project": {
            "always": ["scripts/terraform-*.sh"],
            "if_unchanged": ["terraform.tfvars.example"],
        },
    }

    @classmethod
    def generate_sync_config(
        cls, project_type: str, variables: dict[str, str], project_path: Path
    ) -> dict[str, Any]:
        """Generate sync.yml configuration based on project type.

        Args:
            project_type: Detected or specified project type
            variables: Template variables
            project_path: Path to project

        Returns:
            Dictionary representing sync.yml content
        """
        # Start with base configuration
        config: dict[str, Any] = {
            "version": "1.0",
            "template_source": project_type,
            "project": {
                "name": variables.get("project_name", project_path.name),
                "type": project_type,
                "genesis_version": cls._get_genesis_version(),
            },
            "variables": variables,
            "sync_policies": [],
            "exclude": [
                "*.pyc",
                "__pycache__",
                ".git",
                ".venv",
                "node_modules",
                "dist",
                "build",
                ".terraform",
                "*.log",
                "*.tmp",
                ".DS_Store",
            ],
            "sync_options": {
                "create_backups": True,
                "show_diff": True,
                "auto_format": True,
                "preserve_executable": True,
            },
        }

        # Build sync policies list
        sync_policies: list[dict[str, Any]] = []

        # Add default files for all projects
        default_policies = cls._load_manifest_policies()
        for policy_type, policy_objects in default_policies.items():
            for policy_obj in policy_objects:
                policy_dict: dict[str, Any] = {
                    "source": policy_obj["source"],
                    "dest": policy_obj["dest"],
                    "sync": policy_type,
                    "description": policy_obj.get(
                        "description", cls._get_file_description(policy_obj["dest"])
                    ),
                    "executable": policy_obj.get(
                        "executable", cls._should_be_executable(policy_obj["dest"])
                    ),
                }
                sync_policies.append(policy_dict)

        # Add project-specific files
        if project_type in cls.PROJECT_FILES:
            project_file_config = cls.PROJECT_FILES[project_type]
            if isinstance(project_file_config, dict):
                for policy, patterns in project_file_config.items():
                    if isinstance(patterns, list):
                        for pattern in patterns:
                            project_policy_dict: dict[str, Any] = {
                                "source": pattern,
                                "dest": pattern,
                                "sync": policy,
                                "description": cls._get_file_description(pattern),
                                "executable": cls._should_be_executable(pattern),
                            }
                            sync_policies.append(project_policy_dict)

        config["sync_policies"] = sync_policies

        return config

    @staticmethod
    def _get_genesis_version() -> str:
        """Get current Genesis version."""
        try:
            from genesis import __version__

            return __version__
        except ImportError:
            return "unknown"

    @staticmethod
    def _should_be_executable(pattern: str) -> bool:
        """Determine if a file pattern should be executable."""
        executable_directories = ["scripts/", ".genesis/scripts/", ".claude/hooks/"]
        executable_extensions = [".sh", ".py"]

        # Check if pattern is in executable directory
        if any(pattern.startswith(directory) for directory in executable_directories):
            return True

        # Check for executable extensions in script/hook contexts
        pattern_lower = pattern.lower()
        has_executable_ext = any(pattern.endswith(ext) for ext in executable_extensions)
        is_script_context = "script" in pattern_lower or "hook" in pattern_lower

        return has_executable_ext and is_script_context

    @staticmethod
    def _get_file_description(pattern: str) -> str:
        """Get human-readable description for file pattern."""
        descriptions = {
            ".claude/settings.json": "Claude Code settings",
            ".claude/agents/**": "Claude AI agent configurations",
            ".claude/commands/**": "Claude slash commands",
            ".claude/hooks/**": "Claude validation hooks",
            ".claude/LEAN-TDD-WORKFLOW.md": "LEAN TDD workflow documentation",
            ".genesis/scripts/**": "Genesis utility scripts",
            "Dockerfile": "Development container configuration",
            ".pre-commit-config.yaml": "Pre-commit hooks configuration",
            ".gitignore": "Git ignore patterns",
            "Makefile": "Build and development tasks",
            ".env.example": "Environment variables template",
            "docker-compose.yml": "Docker Compose configuration",
            "scripts/build-cli.sh": "CLI build script",
            "scripts/build-ts.sh": "TypeScript build script",
            "scripts/terraform-*.sh": "Terraform helper scripts",
            "setup.cfg": "Python package configuration",
            "tsconfig.json": "TypeScript configuration",
            "jest.config.js": "Jest testing configuration",
            "terraform.tfvars.example": "Terraform variables template",
        }

        # Try exact match first
        if pattern in descriptions:
            return descriptions[pattern]

        # Try base pattern for wildcard matches
        if "**" in pattern:
            base_pattern = pattern.split("**")[0].rstrip("/")
            if base_pattern in descriptions:
                return descriptions[base_pattern]

        # Generate generic descriptions
        from genesis.core.constants import GlobPatterns

        if pattern.endswith(GlobPatterns.RECURSIVE_SUFFIX):
            return f"All files in {pattern[:-len(GlobPatterns.RECURSIVE_SUFFIX)]}"
        elif "*" in pattern:
            return f"Files matching {pattern}"
        else:
            return f"File: {pattern}"

    @staticmethod
    def add_helpful_comments(config_dict: dict[str, Any]) -> str:
        """Convert config dict to YAML with helpful comments.

        Args:
            config_dict: Configuration dictionary

        Returns:
            YAML string with comments
        """
        yaml_lines = []

        # Header comment
        yaml_lines.extend(
            [
                "# Genesis Sync Configuration",
                "# This file controls how Genesis syncs template files to your project",
                "# Generated by: genesis init",
                "",
            ]
        )

        # Version
        yaml_lines.append(f"version: {config_dict['version']}")
        yaml_lines.append("")

        # Template source
        yaml_lines.append(
            f"template_source: {config_dict['template_source']}  # Template type for sync operations"
        )
        yaml_lines.append("")

        # Project section
        yaml_lines.extend(
            [
                "# Project metadata",
                "project:",
                f"  name: {config_dict['project']['name']}",
                f"  type: {config_dict['project']['type']}  # Detected project type",
                f"  genesis_version: {config_dict['project']['genesis_version']}",
                "",
            ]
        )

        # Variables section
        yaml_lines.extend(
            [
                "# Template variables used for file generation",
                "# You can modify these values to customize generated files",
                "variables:",
            ]
        )
        for key, value in config_dict["variables"].items():
            yaml_lines.append(f"  {key}: {value}")
        yaml_lines.append("")

        # Sync policies section
        yaml_lines.extend(
            [
                "# File synchronization rules",
                "# Sync policies:",
                "#   - always: Always update from template (Genesis-managed)",
                "#   - if_unchanged: Only update if user hasn't modified",
                "#   - never: Only sync on initial creation",
                "#   - local_override: User's version takes precedence",
                "sync_policies:",
            ]
        )

        for file_config in config_dict["sync_policies"]:
            source = file_config["source"]
            dest = file_config["dest"]
            # Quote patterns if they contain special characters
            if source.startswith(("*", ".", "!", "@", "#", "&")) or "*" in source:
                yaml_lines.append(f'  - source: "{source}"')
                yaml_lines.append(f'    dest: "{dest}"')
            else:
                yaml_lines.append(f"  - source: {source}")
                yaml_lines.append(f"    dest: {dest}")
            yaml_lines.append(f"    sync: {file_config['sync']}")
            if file_config.get("executable", False):
                yaml_lines.append("    executable: true")
            yaml_lines.append(f"    description: \"{file_config['description']}\"")

        yaml_lines.append("")

        # Exclude patterns
        yaml_lines.extend(
            [
                "# Patterns to exclude from sync operations",
                "exclude:",
            ]
        )
        for pattern in config_dict["exclude"]:
            # Quote patterns that start with special characters
            if pattern.startswith(("*", ".", "!", "@", "#", "&")):
                yaml_lines.append(f'  - "{pattern}"')
            else:
                yaml_lines.append(f"  - {pattern}")
        yaml_lines.append("")

        # Sync options
        yaml_lines.extend(
            [
                "# Sync behavior options",
                "sync_options:",
                f"  create_backups: {str(config_dict['sync_options']['create_backups']).lower()}  # Create .bak files before overwriting",
                f"  show_diff: {str(config_dict['sync_options']['show_diff']).lower()}  # Show diffs for changed files",
                f"  auto_format: {str(config_dict['sync_options']['auto_format']).lower()}  # Run formatters after sync",
                f"  preserve_executable: {str(config_dict['sync_options']['preserve_executable']).lower()}  # Preserve file permissions",
            ]
        )

        return "\n".join(yaml_lines)


@click.command()
@click.option(
    "--force",
    is_flag=True,
    help="Skip confirmation prompt when overwriting existing configuration",
)
@click.option(
    "--type",
    "project_type",
    help="Explicitly set project type (python-api, cli-tool, typescript, terraform)",
)
@click.option("--name", "project_name", help="Override project name")
def init(force: bool, project_type: str | None, project_name: str | None) -> None:
    """Initialize Genesis sync configuration for current project.

    Creates .genesis/sync.yml with project-specific sync rules and variables.
    Automatically detects project type and extracts relevant metadata.

    If configuration already exists, you'll be prompted to confirm overwriting
    (unless --force is used to skip confirmation).
    """
    project_path = Path.cwd()
    genesis_dir = project_path / ".genesis"
    sync_config_path = genesis_dir / "sync.yml"

    # Check if configuration already exists
    if sync_config_path.exists():
        if not force:
            # Prompt for confirmation to overwrite
            logger.warning(
                f"⚠️  Genesis configuration already exists at {sync_config_path}"
            )
            if not click.confirm("   Overwrite existing configuration?", default=False):
                logger.info("❌ Init cancelled - existing configuration preserved")
                return
            logger.info("✅ Proceeding with initialization...")
        else:
            logger.info(f"🔄 Overwriting existing configuration at {sync_config_path}")

    # Create .genesis directory if it doesn't exist
    genesis_dir.mkdir(exist_ok=True)
    logger.info(f"📁 Created .genesis directory at {genesis_dir}")

    # Detect or use specified project type
    if project_type:
        detected_type = project_type
        logger.info(f"📋 Using specified project type: {detected_type}")
        # Still try to detect variables even with explicit type
        _, detected_variables = ProjectDetector.detect_project_type(project_path)
    else:
        detected_type, detected_variables = ProjectDetector.detect_project_type(
            project_path
        )
        if detected_type == "unknown":
            logger.warning(
                "⚠️  Could not auto-detect project type\n"
                "   Using 'unknown' type - you may want to specify --type"
            )
        else:
            logger.info(f"🔍 Detected project type: {detected_type}")

    # Override project name if specified
    if project_name:
        detected_variables["project_name"] = project_name
        # Update module_name for Python projects
        if detected_type.startswith("python") or detected_type == "cli-tool":
            detected_variables["module_name"] = project_name.replace("-", "_")

    # Get GitHub username if available
    try:
        result = subprocess.run(
            ["git", "config", "user.name"],
            capture_output=True,
            text=True,
            cwd=project_path,
        )
        if result.returncode == 0 and result.stdout and result.stdout.strip():
            detected_variables["github_user"] = result.stdout.strip()
    except Exception:
        pass

    # Generate sync configuration
    logger.info("⚙️  Generating sync configuration...")
    config = SyncConfigGenerator.generate_sync_config(
        detected_type, detected_variables, project_path
    )

    # Write configuration with comments
    yaml_content = SyncConfigGenerator.add_helpful_comments(config)
    sync_config_path.write_text(yaml_content)

    logger.info(f"✅ Created Genesis configuration at {sync_config_path}")
    logger.info("")
    logger.info("📚 Next steps:")
    logger.info("   1. Review the generated configuration in .genesis/sync.yml")
    logger.info("   2. Customize variables and sync policies as needed")
    logger.info("   3. Run 'genesis sync' to synchronize files from templates")
    logger.info("")
    logger.info(
        "💡 Tip: Edit sync policies in .genesis/sync.yml to control how files are updated:"
    )
    logger.info("   - always: Genesis manages these files")
    logger.info("   - if_unchanged: Only update if you haven't modified them")
    logger.info("   - never: Only created once, you own them")
    logger.info("   - local_override: Your version always wins")


# Export for CLI registration
init_command = init
