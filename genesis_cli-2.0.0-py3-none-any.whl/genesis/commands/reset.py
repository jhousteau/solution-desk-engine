"""Genesis reset command implementation."""

import subprocess
import sys

import click

from genesis.core.errors import handle_error
from genesis.core.logger import get_logger

# Initialize logger
logger = get_logger(__name__)


@click.command()
@click.argument("target", default="HEAD", required=False)
@click.option(
    "--soft",
    is_flag=True,
    help="Soft reset - keep changes in working directory and index",
)
@click.option(
    "--mixed",
    is_flag=True,
    help="Mixed reset - keep changes in working directory only (default)",
)
@click.option(
    "--hard", is_flag=True, help="Hard reset - discard all changes (DANGEROUS)"
)
@click.option(
    "--confirm-hard",
    is_flag=True,
    help="Required confirmation for hard reset operations",
)
def reset(target: str, soft: bool, mixed: bool, hard: bool, confirm_hard: bool) -> None:
    """Reset current branch to a specific commit.

    Args:
        target: Target commit/branch (default: HEAD)
        soft: Soft reset (keep staged and working changes)
        mixed: Mixed reset (keep working changes only)
        hard: Hard reset (discard all changes) - DANGEROUS!
        confirm_hard: Required confirmation for hard reset
    """
    # Safety check for hard reset
    if hard and not confirm_hard:
        logger.error("Hard reset requires explicit confirmation with --confirm-hard")
        click.echo(
            "❌ DANGER: Hard reset will permanently lose uncommitted changes!", err=True
        )
        click.echo("Use --confirm-hard if you really want to proceed", err=True)
        sys.exit(1)

    # Determine reset type
    if hard:
        reset_type = "hard"
        logger.warning(f"Performing HARD reset to {target} - this will lose changes!")
    elif soft:
        reset_type = "soft"
        logger.info(f"Performing soft reset to {target}")
    else:
        reset_type = "mixed"
        logger.info(f"Performing mixed reset to {target}")

    # Build git command
    cmd = ["git", "reset"]
    if hard:
        cmd.append("--hard")
    elif soft:
        cmd.append("--soft")
    else:
        cmd.append("--mixed")
    cmd.append(target)

    try:
        # Execute git reset
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)

        # Handle output
        if result.stdout:
            click.echo(result.stdout.strip())

        if result.returncode != 0:
            if result.stderr:
                logger.error(f"Reset failed: {result.stderr.strip()}")
                click.echo(result.stderr.strip(), err=True)
            sys.exit(result.returncode)

        logger.info(f"Successfully performed {reset_type} reset to {target}")

    except Exception as e:
        handle_error(RuntimeError(f"Failed to execute reset: {e}"))
        sys.exit(1)
