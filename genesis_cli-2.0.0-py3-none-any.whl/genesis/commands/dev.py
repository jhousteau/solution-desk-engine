"""Genesis development commands - wrappers for common development tasks."""

import os
import subprocess
import sys
from pathlib import Path

import click

from genesis.core import get_logger

logger = get_logger(__name__)


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
def setup() -> None:
    """Run initial project setup (install dependencies and configure environment)."""
    setup_script = Path(".genesis/scripts/setup/setup.sh")

    if not setup_script.exists():
        logger.error("❌ Setup script not found")
        click.echo(
            "❌ Setup script not found at .genesis/scripts/setup/setup.sh", err=True
        )
        sys.exit(1)

    try:
        logger.info("🚀 Running project setup...")
        subprocess.run([str(setup_script)], check=True)
        logger.info("✅ Setup completed successfully")
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ Setup failed with exit code {e.returncode}")
        sys.exit(e.returncode)


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.argument("args", nargs=-1)
def test(args: tuple[str, ...]) -> None:
    """Run tests with pytest (automatically sets PYTHONPATH for Genesis development)."""
    project_root = Path.cwd()
    shared_core_path = project_root / "shared-python" / "src"

    # Set PYTHONPATH for Genesis development
    env = os.environ.copy()
    current_pythonpath = env.get("PYTHONPATH", "")
    if current_pythonpath:
        env["PYTHONPATH"] = f"{shared_core_path}:{current_pythonpath}"
    else:
        env["PYTHONPATH"] = str(shared_core_path)

    # Determine test path
    if (project_root / "testing/tests").exists():
        test_path = "testing/tests"
    elif (project_root / "genesis/tests").exists():
        test_path = "genesis/tests"
    elif (project_root / "tests").exists():
        test_path = "tests"
    else:
        test_path = "tests"

    try:
        cmd = ["poetry", "run", "python", "-m", "pytest", test_path, "-v", "--tb=short"]
        if args:
            cmd.extend(args)

        logger.info(f"🧪 Running tests: {' '.join(cmd)}")
        subprocess.run(cmd, check=True, env=env)
        logger.info("✅ Tests passed")
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ Tests failed with exit code {e.returncode}")
        sys.exit(e.returncode)


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
def format() -> None:
    """Format code with black and ruff (respects .gitignore)."""
    try:
        logger.info("🎨 Formatting code with black...")
        subprocess.run(["poetry", "run", "black", "."], check=True)

        logger.info("🔧 Fixing issues with ruff...")
        subprocess.run(["poetry", "run", "ruff", "check", "--fix", "."], check=True)

        logger.info("✅ Code formatting completed")
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ Formatting failed with exit code {e.returncode}")
        sys.exit(e.returncode)


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
def lint() -> None:
    """Lint code with ruff (respects .gitignore)."""
    try:
        logger.info("🔍 Linting code with ruff...")
        subprocess.run(["poetry", "run", "ruff", "check", "."], check=True)
        logger.info("✅ Linting passed")
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ Linting failed with exit code {e.returncode}")
        sys.exit(e.returncode)


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
def typecheck() -> None:
    """Type check with mypy (checks source dirs, ignores build/test artifacts)."""
    # Paths to check (matches Makefile)
    paths = [
        "genesis/",
        "bootstrap/",
        "shared-python/src/",
        "smart-commit/src/",
        "testing/src/",
    ]

    # Filter to only existing paths
    existing_paths = [p for p in paths if Path(p).exists()]

    if not existing_paths:
        logger.warning("⚠️  No source directories found to type check")
        return

    try:
        logger.info("🔍 Type checking with mypy...")
        cmd = ["poetry", "run", "mypy"] + existing_paths + ["--ignore-missing-imports"]
        subprocess.run(cmd, check=True)
        logger.info("✅ Type checking passed")
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ Type checking failed with exit code {e.returncode}")
        sys.exit(e.returncode)


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.pass_context
def quality(ctx: click.Context) -> None:
    """Run all quality checks (format + lint + typecheck)."""
    logger.info("🎯 Running quality checks...")

    # Run format
    try:
        ctx.invoke(format)
    except SystemExit:
        pass

    # Run lint
    try:
        ctx.invoke(lint)
    except SystemExit:
        pass

    # Run typecheck
    try:
        ctx.invoke(typecheck)
    except SystemExit:
        pass

    # Run validation checks
    logger.info("🔍 Running validation checks...")
    script_path = Path(".genesis/scripts/validation/find-hardcoded-values.sh")
    if script_path.exists():
        try:
            validation_timeout = int(os.environ.get("GENESIS_VALIDATION_TIMEOUT", "30"))
            result = subprocess.run(
                [str(script_path)],
                capture_output=True,
                text=True,
                timeout=validation_timeout,
            )
            if result.returncode != 0:
                logger.warning("⚠️  Validation checks found issues:")
                logger.warning(result.stdout)
            else:
                logger.info("✅ Validation checks passed")
        except subprocess.TimeoutExpired:
            logger.warning("⚠️  Validation checks timed out")
        except Exception as e:
            logger.warning(f"⚠️  Validation checks failed: {e}")
    else:
        logger.info("ℹ️  Validation script not found, skipping")

    logger.info("✅ Quality checks completed")


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
def precommit() -> None:
    """Run pre-commit hooks on all files."""
    logger.info("🔍 Running pre-commit hooks...")

    try:
        precommit_timeout = int(os.environ.get("GENESIS_PRECOMMIT_TIMEOUT", "300"))
        result = subprocess.run(
            ["pre-commit", "run", "--all-files"],
            capture_output=False,
            timeout=precommit_timeout,
        )
        if result.returncode != 0:
            logger.error("❌ Pre-commit hooks found issues")
            sys.exit(1)
        else:
            logger.info("✅ Pre-commit hooks passed")
    except FileNotFoundError:
        logger.error("❌ pre-commit not found. Install with: pip install pre-commit")
        sys.exit(1)
    except subprocess.TimeoutExpired:
        logger.error("❌ Pre-commit hooks timed out")
        sys.exit(1)
    except Exception as e:
        logger.error(f"❌ Failed to run pre-commit hooks: {e}")
        sys.exit(1)
