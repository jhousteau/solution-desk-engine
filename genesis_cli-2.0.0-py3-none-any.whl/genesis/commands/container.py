"""Docker Compose container management for Genesis.

This module wraps docker-compose commands to manage development containers
using the docker-compose.yml file specified in GENESIS_CONTAINER_CONFIG.

Environment Variables:
    GENESIS_CONTAINER_CONFIG: Path to docker-compose.yml file (optional)
    GENESIS_CONTAINER_PROFILE: Profile to use for docker-compose operations (optional)
                              Defaults to auto-detection or 'agent'

Profile Detection:
    1. GENESIS_CONTAINER_PROFILE environment variable
    2. Auto-detection from docker-compose.yml services/profiles
    3. Default fallback to 'agent'
"""

import os
import subprocess
import sys
from pathlib import Path

import click

from genesis.commands.network_utils import (
    format_conflict_message,
    is_docker_running,
    resolve_network_conflicts,
)
from genesis.core.constants import EnvironmentDefaults

try:
    from genesis.core import get_logger

    logger = get_logger(__name__)
except ImportError:
    import logging

    logger = logging.getLogger(__name__)


def check_docker_running() -> bool:
    """Check if Docker daemon is running."""
    try:
        result = subprocess.run(
            ["docker", "version"], capture_output=True, text=True, check=False
        )
        return result.returncode == 0
    except FileNotFoundError:
        return False


def get_project_name() -> str:
    """Get the current project name from environment or directory."""
    # Try CLIENT_PROJECT_NAME first (for client projects using Genesis)
    client_project_name = os.environ.get("CLIENT_PROJECT_NAME")
    if client_project_name:
        return client_project_name

    # Use directory name as primary fallback (works for client projects)
    directory_name = Path.cwd().name

    # Only use PROJECT_NAME if we're actually in the Genesis project directory
    project_name = os.environ.get("PROJECT_NAME")
    if project_name and directory_name == "genesis":
        return project_name

    # Default to directory name for all client projects
    return directory_name


def get_container_profile() -> str:
    """Get container profile with simple environment-based configuration.

    Returns profile from GENESIS_CONTAINER_PROFILE or 'agent' as default.
    Simplified per issue #232 to remove complex YAML parsing.
    """
    return os.environ.get(
        "GENESIS_CONTAINER_PROFILE", EnvironmentDefaults.DEFAULT_CONTAINER_PROFILE
    )


def get_compose_file(silent: bool = False) -> str:
    """Get the docker-compose file path, auto-detecting project-specific config.

    Args:
        silent: If True, raise FileNotFoundError instead of printing errors and exiting.
                Used for optional checks like status command.
    """
    project_root = Path.cwd()

    # First, check standard locations in current directory (client projects)
    # Also check Genesis structure (.genesis/docker/) for Genesis-based client projects
    compose_files = [
        project_root / "docker-compose.yml",
        project_root / "docker-compose.yaml",
        project_root / "compose.yml",
        project_root / "compose.yaml",
        project_root / ".genesis" / "docker" / "docker-compose.yml",
        project_root / ".genesis" / "docker" / "docker-compose.yaml",
    ]

    for compose_file in compose_files:
        if compose_file.exists():
            logger.debug(f"Using auto-detected compose file: {compose_file}")
            return str(compose_file)

    # If no local compose file found, try the explicit environment variable (backward compatibility)
    config_file = os.environ.get("GENESIS_CONTAINER_CONFIG")
    if config_file:
        # Convert to absolute path if relative
        config_path = Path(config_file)
        if not config_path.is_absolute():
            config_path = project_root / config_path

        if config_path.exists():
            logger.debug(f"Using configured compose file: {config_path}")
            return str(config_path)
        else:
            logger.debug(f"Configured compose file not found: {config_path}")

    # If no local compose file, check Genesis toolkit development locations
    try:
        genesis_root = find_genesis_root()
        if genesis_root:
            # Check new Genesis structure first
            new_compose = genesis_root / ".genesis" / "docker" / "docker-compose.yml"
            if new_compose.exists():
                logger.debug(
                    f"Using Genesis compose file (new structure): {new_compose}"
                )
                return str(new_compose)

            # Fall back to old location for backward compatibility
            old_compose = genesis_root / "docker-compose.yml"
            if old_compose.exists():
                logger.debug(
                    f"Using Genesis compose file (old location): {old_compose}"
                )
                return str(old_compose)
    except Exception as e:
        logger.debug(f"Error finding Genesis root: {e}")

    # File not found - handle based on silent flag
    if silent:
        raise FileNotFoundError("No docker-compose.yml file found")

    error_msg = "No docker-compose.yml file found!"
    logger.error(error_msg)
    click.echo(error_msg, err=True)

    options = [
        "Options:",
        "  1. Create docker-compose.yml in current directory",
        "  2. Set GENESIS_CONTAINER_CONFIG environment variable",
        "  3. Run from Genesis root directory",
        f"Current directory: {Path.cwd()}",
    ]

    for option in options:
        logger.error(option)
        click.echo(option, err=True)

    sys.exit(1)


def find_genesis_root() -> Path | None:
    """Find Genesis project root by looking for CLAUDE.md."""
    current = Path.cwd()
    for parent in [current] + list(current.parents):
        claude_md = parent / "CLAUDE.md"
        if claude_md.exists():
            try:
                content = claude_md.read_text()
                if "Genesis" in content:
                    return Path(parent)
            except Exception:
                # Skip if we can't read the file
                continue
    return None


def _check_and_handle_network_conflicts(compose_file: Path) -> None:
    """Check for Docker network conflicts and provide clear guidance.

    Args:
        compose_file: Path to docker-compose.yml file
    """
    # Only check if Docker is running
    if not is_docker_running():
        logger.debug("Docker not running, skipping network conflict check")
        return

    has_conflict, current_subnet, suggested_subnet = resolve_network_conflicts(
        compose_file
    )

    if has_conflict:
        # Format and display error message
        if current_subnet is not None:
            error_msg = format_conflict_message(current_subnet, suggested_subnet)
            logger.error(error_msg)

        # If we have a suggestion and running in non-interactive mode, just warn
        if suggested_subnet and os.environ.get("CI"):
            logger.warning("Continuing with potential conflict (CI mode)")
        elif not suggested_subnet:
            # No alternative available, must fail
            logger.error("Cannot continue: No alternative subnet available")
            sys.exit(1)
        else:
            # Interactive mode with suggestion - fail with guidance
            logger.error("\n💡 Quick fix: Run the following command:")
            logger.error(f"   export GENESIS_DOCKER_SUBNET={suggested_subnet}")
            sys.exit(1)
    elif suggested_subnet and not current_subnet:
        # No subnet configured, suggest adding one
        logger.info(
            f"💡 Tip: Consider adding subnet {suggested_subnet} to docker-compose.yml"
        )
        logger.info("   This helps avoid potential network conflicts")


def _validate_build_requirements() -> None:
    """Validate all required environment variables and files for container build."""
    errors = []
    warnings = []

    # Check required files
    compose_file = None
    try:
        compose_file = get_compose_file()
    except SystemExit:
        errors.append("docker-compose.yml file not found in current directory")

    dockerfile_path = Path.cwd() / "Dockerfile"
    if not dockerfile_path.exists():
        errors.append("Dockerfile not found in current directory")

    # Check critical environment variables
    github_token = os.environ.get("GITHUB_TOKEN")
    if not github_token:
        errors.append("GITHUB_TOKEN environment variable not set")

    # Check project identification
    project_name = get_project_name()
    client_project_name = os.environ.get("CLIENT_PROJECT_NAME")
    project_name_env = os.environ.get("PROJECT_NAME")

    if not client_project_name and not project_name_env:
        warnings.append(
            f"No CLIENT_PROJECT_NAME or PROJECT_NAME set, using directory name: {project_name}"
        )

    # Check Docker availability
    try:
        subprocess.run(["docker", "--version"], capture_output=True, check=True)
    except (FileNotFoundError, subprocess.CalledProcessError):
        errors.append("Docker not available - please install Docker")

    # Check for docker-compose or docker compose
    docker_compose_available = False
    try:
        subprocess.run(
            ["docker", "compose", "version"], capture_output=True, check=True
        )
        docker_compose_available = True
    except (FileNotFoundError, subprocess.CalledProcessError):
        try:
            subprocess.run(
                ["docker-compose", "--version"], capture_output=True, check=True
            )
            docker_compose_available = True
        except (FileNotFoundError, subprocess.CalledProcessError):
            pass

    if not docker_compose_available:
        errors.append("docker-compose or 'docker compose' not available")

    # Report findings
    if warnings:
        for warning in warnings:
            logger.warning(f"⚠️  {warning}")

    if errors:
        logger.error("❌ Container build requirements not met:")
        for error in errors:
            logger.error(f"   • {error}")
        logger.error("")
        logger.error("💡 Suggestions:")
        logger.error("   • Run 'genesis sync' to ensure project files are up to date")
        logger.error(
            "   • Check that .envrc exists and run 'direnv allow' to load environment"
        )
        logger.error("   • Ensure GITHUB_TOKEN is set in your environment")
        sys.exit(1)

    # Success - log what we found
    logger.info("✅ Build requirements validated:")
    logger.info(f"   • Project: {project_name}")
    logger.info(
        f"   • Docker compose file: {Path(compose_file).name if compose_file else 'Unknown'}"
    )
    logger.info(f"   • GitHub token: {'Present' if github_token else 'Missing'}")


def run_docker_compose(
    args: list[str], check: bool = True, capture_output: bool = False
) -> str | bool:
    """Run a docker-compose command with project name."""
    # Check if Docker is running first
    if not check_docker_running():
        logger.error(
            "Docker daemon is not running. Please start Docker Desktop or run 'sudo systemctl start docker'"
        )
        if check:
            sys.exit(1)
        return False

    compose_file = get_compose_file()
    project_name = get_project_name()

    # Check for network conflicts before running commands that create networks
    if args and len(args) > 0 and args[0] in ["up", "create", "build"]:
        _check_and_handle_network_conflicts(Path(compose_file))

    # Try docker compose (v2) first, fall back to docker-compose (v1)
    try:
        cmd = ["docker", "compose", "-f", compose_file, "-p", project_name] + args
        logger.debug(f"Running: {' '.join(cmd)}")
        if capture_output:
            result = subprocess.run(cmd, check=check, capture_output=True, text=True)
            return str(result.stdout) if result.stdout else ""
        else:
            # Ensure we see all output from docker-compose
            logger.debug(f"Executing command with full output: {' '.join(cmd)}")
            result = subprocess.run(
                cmd, check=check, stdout=None, stderr=None, text=True
            )
            return result.returncode == 0
    except subprocess.CalledProcessError as e:
        if check:
            logger.error(f"Command failed: {e}")
            sys.exit(1)
        return False
    except FileNotFoundError:
        # Fall back to docker-compose v1
        cmd = ["docker-compose", "-f", compose_file, "-p", project_name] + args
        logger.debug(f"Falling back to: {' '.join(cmd)}")

    try:
        if capture_output:
            result = subprocess.run(cmd, check=check, capture_output=True, text=True)
            return str(result.stdout) if result.stdout else ""
        else:
            # Ensure we see all output from docker-compose fallback
            logger.debug(
                f"Executing fallback command with full output: {' '.join(cmd)}"
            )
            result = subprocess.run(
                cmd, check=check, stdout=None, stderr=None, text=True
            )
            return result.returncode == 0
    except subprocess.CalledProcessError as e:
        if check:
            logger.error(f"Command failed: {e}")
            sys.exit(1)
        return False
    except FileNotFoundError:
        logger.error(
            "docker-compose not found. Please install Docker and docker-compose"
        )
        sys.exit(1)


@click.group()
def container() -> None:
    """Manage Docker containers using docker-compose."""


@container.command()
def build() -> None:
    """Build the container image with GitHub token for package access."""
    logger.info("Building container image...")

    # Validate required environment and files
    _validate_build_requirements()

    # Check for network conflicts early
    compose_file = get_compose_file()
    _check_and_handle_network_conflicts(Path(compose_file))

    # Enable BuildKit for secret support
    os.environ["DOCKER_BUILDKIT"] = "1"
    os.environ["COMPOSE_DOCKER_CLI_BUILD"] = "1"

    # Check if GITHUB_TOKEN is available for Genesis package installation
    github_token = os.environ.get("GITHUB_TOKEN")
    if not github_token:
        logger.error("❌ GITHUB_TOKEN not found in environment")
        logger.error("   Please source .envrc or set GITHUB_TOKEN environment variable")
        logger.error("   Genesis CLI packages require GitHub token for download")
        sys.exit(1)

    if github_token:
        logger.info("🔑 GitHub token detected - Genesis packages will be installed")
        # Use BuildKit secret instead of build arg to avoid token leakage
        # Create secrets directory if it doesn't exist
        secrets_dir = Path(".secrets")
        secrets_dir.mkdir(exist_ok=True)

        # Write token to secrets file (temporary, for build only)
        token_file = secrets_dir / "github_token"
        token_file.write_text(github_token)
        token_file.chmod(0o600)  # Secure permissions

        # First, remove any existing images and cache to force rebuild
        project_name = get_project_name()
        logger.info("🗑️  Removing existing images and cache to force rebuild...")
        # Remove project images
        subprocess.run(
            ["docker", "rmi", f"{project_name}/dev:latest"], capture_output=True
        )
        subprocess.run(["docker", "rmi", f"{project_name}-dev"], capture_output=True)
        # Clear build cache for this project
        subprocess.run(["docker", "builder", "prune", "-f"], capture_output=True)

        # All projects now use profiles (Genesis synced to template structure)
        profile = get_container_profile()
        build_args = ["--profile", profile, "build", "--no-cache"]

        logger.info(f"Running: docker-compose {' '.join(build_args)}")
        logger.info(f"Environment: DOCKER_BUILDKIT={os.environ.get('DOCKER_BUILDKIT')}")

        try:
            # Don't capture output so we can see the build logs
            logger.info("🏗️  Starting Docker build - this may take several minutes...")
            result = run_docker_compose(build_args, capture_output=False)
            if result:
                logger.info("✅ Container built successfully with Genesis packages")
            else:
                logger.error("❌ Container build failed")
        finally:
            # Keep token file for runtime - don't delete it
            # Use 'genesis container clean' to manually remove if needed
            if token_file.exists():
                logger.info("✅ GitHub token file preserved for container runtime")
    else:
        logger.warning(
            "⚠️  No GITHUB_TOKEN found - Genesis CLI won't be available in container"
        )
        logger.info(
            "   Set GITHUB_TOKEN environment variable to install genesis-cli and genesis-shared-core"
        )
        logger.info(
            "   Or create .secrets/github_token file manually for persistent setup"
        )
        build_args = ["build", "--no-cache"]

        if run_docker_compose(build_args):
            logger.info("✅ Container image built successfully")


@container.command()
def run() -> None:
    """Start the container in detached mode."""
    logger.info("Starting container...")

    # Check for network conflicts before starting
    compose_file = get_compose_file()
    _check_and_handle_network_conflicts(Path(compose_file))

    # Create GitHub token file if environment variable exists
    github_token = os.environ.get("GITHUB_TOKEN")
    if github_token:
        secrets_dir = Path(".secrets")
        secrets_dir.mkdir(exist_ok=True)
        token_file = secrets_dir / "github_token"
        if not token_file.exists():
            token_file.write_text(github_token)
            token_file.chmod(0o600)
            logger.info("🔑 Created GitHub token file for Docker Compose")
        else:
            logger.debug("🔑 GitHub token file already exists")

    # Use the configured container profile
    compose_file = get_compose_file()  # Still needed for validation
    profile = get_container_profile()
    logger.info(f"🔒 Using '{profile}' profile for development")

    run_args = ["--profile", profile, "up", "-d"]

    if run_docker_compose(run_args):
        logger.info("✅ Container started")
        logger.info("Use 'genesis container shell' to enter the container")


@container.command()
def shell() -> None:
    """Open an interactive shell in the container."""
    compose_file = get_compose_file()
    project_name = get_project_name()

    # Try to detect the service name from compose file
    service_name = detect_service_name(compose_file)

    # Check if container is running first
    output = run_docker_compose(["ps", "-q", service_name], capture_output=True)
    output_str = str(output) if isinstance(output, str) else ""
    if not output_str.strip():
        message = "Container not running. Run 'genesis container run' first"
        logger.error(message)
        click.echo(message, err=True)
        sys.exit(1)

    logger.info(f"Opening shell in {project_name} container...")
    # Use subprocess with proper TTY handling
    from genesis.core.constants import get_shell

    shell = get_shell()
    cmd = [
        "docker-compose",
        "-f",
        compose_file,
        "-p",
        project_name,
        "exec",
        service_name,
        shell,
    ]
    logger.debug(f"Running command: {' '.join(cmd)}")
    subprocess.run(cmd)


@container.command()
def clean() -> None:
    """Clean up secrets and temporary files."""
    secrets_dir = Path(".secrets")
    token_file = secrets_dir / "github_token"

    if token_file.exists():
        token_file.unlink()
        logger.info("🧹 Cleaned up GitHub token file")
    else:
        logger.info("No GitHub token file found to clean")

    # Also clean up any empty .secrets directory
    if secrets_dir.exists() and not any(secrets_dir.iterdir()):
        secrets_dir.rmdir()
        logger.info("🧹 Removed empty .secrets directory")


def detect_service_name(compose_file: str) -> str:
    """Detect the main service name from docker-compose file."""
    try:
        import yaml

        with open(compose_file) as f:
            compose_config = yaml.safe_load(f)

        services = compose_config.get("services", {})
        if len(services) == 1:
            # Single service - use it
            return str(next(iter(services.keys())))
        elif "app" in services:
            return "app"
        elif "web" in services:
            return "web"
        elif "main" in services:
            return "main"
        elif "agent" in services:
            return "agent"
        else:
            # Use first service
            return str(next(iter(services.keys())))
    except Exception:
        # Fallback to common names
        return "app"


@container.command()
def stop() -> None:
    """Stop the container."""
    logger.info("Stopping container...")

    project_name = get_project_name()
    profile = get_container_profile()

    # First, handle any standalone Docker containers with the project name
    try:
        # Look for any running containers with the project name
        list_result = subprocess.run(
            ["docker", "ps", "--format", "{{.Names}}", "-f", f"name={project_name}"],
            capture_output=True,
            text=True,
            check=False,
        )
        stdout_str = str(list_result.stdout) if list_result.stdout else ""
        standalone_containers = [c for c in stdout_str.strip().split("\n") if c]

        for container in standalone_containers:
            logger.info(f"Stopping standalone container: {container}")
            subprocess.run(
                ["docker", "stop", container], capture_output=True, check=False
            )
    except Exception as e:
        logger.debug(f"Error checking for standalone containers: {e}")

    # Stop docker-compose managed containers
    if run_docker_compose(["--profile", profile, "stop"]):
        logger.info("✅ Container stopped")


@container.command()
def remove() -> None:
    """Remove the container (stop and remove)."""
    logger.info("Removing container...")

    project_name = get_project_name()
    profile = get_container_profile()

    # First, handle any standalone Docker containers with the project name
    # This catches containers that were started with 'docker run' instead of compose
    try:
        # Look for any containers with the project name (running or stopped)
        list_result = subprocess.run(
            [
                "docker",
                "ps",
                "-a",
                "--format",
                "{{.Names}}",
                "-f",
                f"name={project_name}",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        stdout_str = str(list_result.stdout) if list_result.stdout else ""
        standalone_containers = [c for c in stdout_str.strip().split("\n") if c]

        for container in standalone_containers:
            logger.info(f"Found standalone container: {container}")
            # Stop the container if running
            subprocess.run(
                ["docker", "stop", container], capture_output=True, check=False
            )
            # Remove the container
            subprocess.run(
                ["docker", "rm", container], capture_output=True, check=False
            )
            logger.info(f"Removed standalone container: {container}")
    except Exception as e:
        logger.debug(f"Error checking for standalone containers: {e}")

    # Check if there are containers or images to remove
    try:
        # Check for containers managed by docker-compose
        containers_output = run_docker_compose(["ps", "-q"], capture_output=True)
        containers_output_str = (
            str(containers_output) if isinstance(containers_output, str) else ""
        )
        has_containers: bool = bool(
            containers_output_str and containers_output_str.strip()
        )

        # Check for images
        subprocess.run(
            ["docker", "images", "-q", f"{project_name}/dev"],
            capture_output=True,
            text=True,
        )

    except (subprocess.CalledProcessError, Exception):
        has_containers = False

    # All projects now use profiles (Genesis synced to template structure)
    down_args = ["--profile", profile, "down", "--remove-orphans", "--volumes"]

    # First stop any running containers explicitly
    if has_containers:
        stop_args = ["--profile", profile, "stop"]
        run_docker_compose(stop_args)

    if run_docker_compose(down_args):
        # Also remove the project images explicitly
        try:
            # Remove specific project images
            subprocess.run(
                ["docker", "rmi", f"{project_name}/dev:latest"], capture_output=True
            )
            subprocess.run(
                ["docker", "rmi", f"{project_name}-dev"], capture_output=True
            )
        except subprocess.CalledProcessError:
            pass

        # Remove any conflicting networks
        try:
            # Remove networks that might cause conflicts
            network_patterns = [
                f"{project_name}_default",
                f"{project_name}-dev_default",
                f"{project_name}-default",
            ]
            for pattern in network_patterns:
                subprocess.run(
                    ["docker", "network", "rm", pattern],
                    capture_output=True,
                    check=False,
                )
            logger.info("✅ Container, volumes, images, and networks removed")
        except subprocess.CalledProcessError:
            logger.info("✅ Container, volumes, and images removed")
    else:
        logger.info("ℹ️  No docker-compose managed containers found")


@container.command()
def logs() -> None:
    """Show container logs."""
    run_docker_compose(["logs", "--tail=50"])


@container.command()
def status() -> None:
    """Show container status."""
    run_docker_compose(["ps"])


@container.command()
def restart() -> None:
    """Restart the container."""
    logger.info("Restarting container...")
    if run_docker_compose(["restart"]):
        logger.info("✅ Container restarted")


@container.command()
def cleanup() -> None:
    """Clean up stopped containers and unused resources."""
    logger.info("Cleaning up Docker resources...")

    project_name = get_project_name()
    profile = get_container_profile()

    # First, clean up any standalone containers with the project name
    try:
        # Look for any stopped containers with the project name
        list_result = subprocess.run(
            [
                "docker",
                "ps",
                "-a",
                "--format",
                "{{.Names}}",
                "-f",
                f"name={project_name}",
                "-f",
                "status=exited",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        stdout_str = str(list_result.stdout) if list_result.stdout else ""
        stopped_containers = [c for c in stdout_str.strip().split("\n") if c]

        for container in stopped_containers:
            logger.info(f"Removing stopped container: {container}")
            subprocess.run(
                ["docker", "rm", container], capture_output=True, check=False
            )
    except Exception as e:
        logger.debug(f"Error cleaning up standalone containers: {e}")

    # Clean up docker-compose managed resources
    if run_docker_compose(
        ["--profile", profile, "down", "--volumes", "--remove-orphans"]
    ):
        logger.info("✅ Cleanup complete")

    # Also run docker system prune for good measure
    logger.info("Pruning unused Docker objects...")
    subprocess.run(["docker", "system", "prune", "-f"], check=False)


@container.command()
def config() -> None:
    """Show the docker-compose configuration."""
    compose_file = get_compose_file()
    logger.info(f"Using docker-compose file: {compose_file}")
    run_docker_compose(["config"])


@container.command(name="list")
def list_containers() -> None:
    """List containers managed by this compose file."""
    run_docker_compose(["ps", "-a"])


@container.command()
def health() -> None:
    """Check container health status."""
    output = run_docker_compose(["ps"], capture_output=True)
    output_str = str(output) if isinstance(output, str) else ""
    if "Up" in output_str:
        logger.info("✅ Container is healthy")
    else:
        logger.warning("⚠️ Container is not running or unhealthy")
        logger.info("Run 'genesis container logs' for more details")


@container.command()
def kill() -> None:
    """Force kill the container."""
    logger.warning("Force killing container...")
    profile = get_container_profile()
    if run_docker_compose(["--profile", profile, "kill"]):
        logger.info("Container killed")


@container.command()
@click.option(
    "--max-age", "-a", default=6, help="Maximum age of files to preserve in hours"
)
@click.option(
    "--dry-run", "-n", is_flag=True, help="Show what would be cleaned without doing it"
)
@click.option("--force", "-f", is_flag=True, help="Force cleanup without confirmation")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
def tmpfs_cleanup(max_age: int, dry_run: bool, force: bool, verbose: bool) -> None:
    """Clean up temporary filesystem to prevent 'No space left on device' errors.

    This command runs the tmpfs cleanup script inside the container to prevent
    GitHub issue #268: Container tmpfs fills up causing errors.

    The cleanup targets:
    - Pytest cache files older than specified age
    - Pip uninstall remnants
    - Temporary build artifacts
    - Old log files in /tmp and /var/tmp
    - Preserves active session files
    """
    logger.info("Running tmpfs cleanup in container...")

    # First check if compose file exists
    try:
        compose_file = get_compose_file()
        get_container_profile()
        service_name = detect_service_name(compose_file)
    except SystemExit:
        # get_compose_file already printed the error message
        sys.exit(1)

    # Check if container is running
    try:
        output = run_docker_compose(["ps", "-q", service_name], capture_output=True)
        output_str = str(output) if isinstance(output, str) else ""
        if not output_str.strip():
            message = "Container not running. Run 'genesis container run' first"
            logger.error(message)
            click.echo(message, err=True)
            sys.exit(1)
    except Exception as e:
        message = f"Error checking container status: {e}"
        logger.error(message)
        click.echo(message, err=True)
        sys.exit(1)

    # Build cleanup command arguments
    cleanup_args = []
    if verbose:
        cleanup_args.append("-v")
    if dry_run:
        cleanup_args.append("-n")
    if force:
        cleanup_args.append("-f")
    cleanup_args.extend(["-a", str(max_age)])

    # Run cleanup script in container
    try:
        project_name = get_project_name()

        cmd = [
            "docker-compose",
            "-f",
            compose_file,
            "-p",
            project_name,
            "exec",
            service_name,
            "/workspace/scripts/cleanup-temp.sh",
        ] + cleanup_args

        logger.debug(f"Running cleanup command: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)

        # Display cleanup script output if verbose or dry-run
        if verbose or dry_run:
            if result.stdout:
                click.echo(result.stdout)
            if result.stderr:
                click.echo(result.stderr, err=True)

        if result.returncode == 0:
            message = "✅ Tmpfs cleanup completed successfully"
            logger.info(message)
            click.echo(message)
        else:
            message = "❌ Tmpfs cleanup failed"
            logger.error(message)
            click.echo(message, err=True)
            sys.exit(1)

    except subprocess.CalledProcessError as e:
        message = f"❌ Cleanup command failed: {e}"
        logger.error(message)
        click.echo(message, err=True)
        sys.exit(1)
    except FileNotFoundError:
        # Try with docker compose (v2)
        try:
            cmd = [
                "docker",
                "compose",
                "-f",
                compose_file,
                "-p",
                project_name,
                "exec",
                service_name,
                "/workspace/scripts/cleanup-temp.sh",
            ] + cleanup_args

            logger.debug(f"Trying v2 command: {' '.join(cmd)}")
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)

            # Display cleanup script output if verbose or dry-run
            if verbose or dry_run:
                if result.stdout:
                    click.echo(result.stdout)
                if result.stderr:
                    click.echo(result.stderr, err=True)

            if result.returncode == 0:
                message = "✅ Tmpfs cleanup completed successfully"
                logger.info(message)
                click.echo(message)
            else:
                message = "❌ Tmpfs cleanup failed"
                logger.error(message)
                click.echo(message, err=True)
                sys.exit(1)

        except Exception as e:
            message = f"❌ Both docker-compose and docker compose failed: {e}"
            logger.error(message)
            click.echo(message, err=True)
            sys.exit(1)
