"""Genesis worktree command implementation."""

import os
import subprocess
import sys
from pathlib import Path

import click
import yaml

from genesis.core.errors import handle_error
from genesis.core.logger import get_logger
from genesis.core.worktree import WorktreeCreationError, create_worktree

# Initialize logger
logger = get_logger(__name__)


def load_genesis_config() -> dict | None:
    """Load Genesis configuration from .genesis/config.yml if it exists."""
    config_path = Path.cwd() / ".genesis" / "config.yml"
    if not config_path.exists():
        return None

    try:
        with open(config_path) as f:
            data = yaml.safe_load(f)
            return dict(data) if data else None
    except Exception:
        # If config file is malformed, fall back to defaults
        return None


def get_max_files_from_config(config: dict | None, cli_max_files: int | None) -> int:
    """Get max files setting from config, CLI args, or environment in that order."""
    # CLI argument takes highest priority
    if cli_max_files is not None:
        return cli_max_files

    # Then check Genesis config
    if config and config.get("worktree", {}).get("max_files"):
        return int(config["worktree"]["max_files"])

    # Then check environment variable
    if "AI_MAX_FILES" in os.environ:
        try:
            return int(os.environ["AI_MAX_FILES"])
        except ValueError:
            pass

    # Default fallback
    return 30


@click.group()
def worktree() -> None:
    """Manage AI-safe sparse worktrees for focused development."""


@worktree.command()
@click.argument("name")
@click.argument("focus_path", required=False)
@click.option(
    "--focus", multiple=True, help="Focus path (can be specified multiple times)"
)
@click.option(
    "--exclude", multiple=True, help="Exclude pattern (can be specified multiple times)"
)
@click.option(
    "--max-files",
    type=int,
    help="Maximum number of files (defaults to .genesis/config.yml, AI_MAX_FILES env var, or 30)",
)
@click.option("--verify", is_flag=True, help="Verify safety after creation")
def create(
    name: str,
    focus_path: str | None,
    focus: tuple[str, ...],
    exclude: tuple[str, ...],
    max_files: int | None,
    verify: bool,
) -> None:
    """Create a new sparse worktree focused on specific paths.

    NAME: Worktree name (e.g., fix-auth, update-tests)
    FOCUS_PATH: Path to focus on (legacy single path support)

    Examples:
        # Single path (backward compatible)
        genesis worktree create my-feature src/feature.py

        # Multiple paths (new)
        genesis worktree create my-feature --focus src/ --focus tests/
    """
    # Handle backward compatibility: convert single focus_path to --focus format
    if focus_path and not focus:
        # Legacy single path usage
        focus = (focus_path,)
    elif not focus_path and not focus:
        logger.error("❌ Must provide either FOCUS_PATH or --focus flags")
        sys.exit(1)

    # Load Genesis configuration
    config: dict | None = load_genesis_config()

    # Determine max files setting
    effective_max_files = get_max_files_from_config(config, max_files)

    # Show configuration source for debugging
    if max_files is not None:
        logger.debug(f"Using max_files from CLI: {effective_max_files}")
    elif config and config.get("worktree", {}).get("max_files"):
        logger.debug(f"Using max_files from .genesis/config.yml: {effective_max_files}")
    elif "AI_MAX_FILES" in os.environ:
        logger.debug(
            f"Using max_files from AI_MAX_FILES env var: {effective_max_files}"
        )
    else:
        logger.debug(f"Using default max_files: {effective_max_files}")

    # Check if we're in a git repository
    try:
        subprocess.run(
            ["git", "rev-parse", "--show-toplevel"], capture_output=True, check=True
        )
    except subprocess.CalledProcessError:
        logger.error("❌ Not in a git repository")
        sys.exit(1)

    # Use the integrated worktree creator
    try:
        create_worktree(
            name=name,
            focus_paths=list(focus),
            max_files=effective_max_files,
            verify=verify,
        )
        logger.info(f"✅ Sparse worktree '{name}' created successfully!")
    except WorktreeCreationError as e:
        logger.error(f"❌ {e}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"❌ Unexpected error: {e}")
        sys.exit(1)


@worktree.command(name="list")
@click.option("--all", is_flag=True, help="List all worktrees (not just Genesis ones)")
def list_worktrees(all: bool) -> None:
    """List existing worktrees."""
    try:
        # Get worktree list
        result = subprocess.run(
            ["git", "worktree", "list"], capture_output=True, text=True, check=True
        )

        if not result.stdout.strip():
            logger.info("No worktrees found")
            return

        logger.info("Existing worktrees:")
        lines = result.stdout.strip().split("\n")

        for line in lines:
            parts = line.split()
            if len(parts) >= 2:
                path = parts[0]
                branch = (
                    " ".join(parts[2:])
                    if len(parts) > 2
                    else (parts[1] if len(parts) > 1 else "unknown")
                )

                # Skip main repo entry unless --all specified
                if not all and "worktrees" not in Path(path).parts:
                    continue

                # Check if it's a Genesis sparse worktree
                manifest_path = Path(path) / ".ai-safety-manifest"
                if manifest_path.exists():
                    logger.info(f"  🛡️  {Path(path).name} -> {branch} (AI-safe)")
                elif all:
                    logger.info(f"  📁 {Path(path).name} -> {branch}")

    except subprocess.CalledProcessError as e:
        handled_error = handle_error(e)
        logger.error(f"❌ Failed to list worktrees: {handled_error}")
        sys.exit(1)


@worktree.command()
@click.argument("name")
@click.option(
    "--force", is_flag=True, help="Force removal even with uncommitted changes"
)
def remove(name: str, force: bool) -> None:
    """Remove a worktree by name."""
    # Find worktree path
    worktree_path = Path(f"worktrees/{name}")

    if not worktree_path.exists():
        logger.error(f"❌ Worktree '{name}' not found at {worktree_path}")
        sys.exit(1)

    try:
        cmd = ["git", "worktree", "remove", str(worktree_path)]
        if force:
            cmd.append("--force")

        subprocess.run(cmd, check=True)
        logger.info(f"✅ Removed worktree '{name}'")

    except subprocess.CalledProcessError as e:
        handled_error = handle_error(e)
        logger.error(f"❌ Failed to remove worktree: {handled_error}")
        sys.exit(1)


@worktree.command()
@click.argument("name")
def info(name: str) -> None:
    """Show information about a specific worktree."""
    worktree_path = Path(f"worktrees/{name}")

    if not worktree_path.exists():
        logger.error(f"❌ Worktree '{name}' not found")
        sys.exit(1)

    # Read AI safety manifest if it exists
    manifest_path = worktree_path / ".ai-safety-manifest"
    if manifest_path.exists():
        logger.info(f"🛡️  AI-Safe Worktree: {name}")
        logger.info("─" * 40)

        try:
            with open(manifest_path) as f:
                content = f.read()
                # Extract key info from manifest
                lines = content.split("\n")
                for line in lines:
                    if (
                        line.startswith("Focus:")
                        or line.startswith("Files:")
                        or line.startswith("Branch:")
                        or line.startswith("Created:")
                    ):
                        logger.info(f"  {line}")
        except Exception:
            logger.warning("  Error reading manifest")
    else:
        logger.info(f"📁 Standard Worktree: {name}")

    # Show git status
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True,
            text=True,
            cwd=worktree_path,
        )

        if result.stdout.strip():
            logger.info("\n  Modified files:")
            for line in result.stdout.strip().split("\n"):
                logger.info(f"    {line}")
        else:
            logger.info("\n  ✅ No uncommitted changes")

    except subprocess.CalledProcessError:
        logger.warning("\n  ⚠️  Could not check git status")
