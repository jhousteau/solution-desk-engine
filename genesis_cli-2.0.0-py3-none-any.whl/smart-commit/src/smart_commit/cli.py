#!/usr/bin/env python3
"""CLI entry point for smart-commit command."""

import os
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING

# Import utilities from shared_core - fallback if not available
try:
    from shared_core.env import get_env_or_fallback
except ImportError:

    def get_env_or_fallback(key: str, fallback: str) -> str:
        return os.environ.get(key, fallback)


# Import constants from genesis - fallback if not available
# Define a fallback for DEFAULT_SHELL
import platform
import shutil

_detected_shell = shutil.which("bash") or shutil.which("sh") or "bash"
DEFAULT_SHELL = (
    get_env_or_fallback("SHELL", _detected_shell)
    if platform.system() != "Windows"
    else "cmd.exe"
)

if TYPE_CHECKING:
    from genesis.core.constants import EnvironmentDefaults
else:
    try:
        from genesis.core.constants import EnvironmentDefaults

        DEFAULT_SHELL = EnvironmentDefaults.DEFAULT_SHELL
    except ImportError:
        # Use the fallback already defined above
        pass


def main() -> None:
    """Main entry point for smart-commit CLI."""
    try:
        # Script is always packaged alongside this module
        script_path = Path(__file__).parent / "smart-commit.sh"

        if not script_path.exists():
            raise FileNotFoundError(f"smart-commit.sh not found at {script_path}")

        # Execute script with current environment
        shell = get_env_or_fallback("GENESIS_SHELL", DEFAULT_SHELL)

        result = subprocess.run(
            [shell, str(script_path)] + sys.argv[1:], env=os.environ
        )
        sys.exit(result.returncode)

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nOperation cancelled.", file=sys.stderr)
        sys.exit(130)


if __name__ == "__main__":
    main()
