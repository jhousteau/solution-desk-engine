#!/usr/bin/env bash
# Smart Commit System - Quality gates before commits
# Extracted and simplified from old Genesis (225→95 lines)

set -euo pipefail

# Parse command line arguments
NO_APPROVE=false
SHOW_DETAILS=false
while [[ $# -gt 0 ]]; do
    case $1 in
        --no-approve)
            NO_APPROVE=true
            shift
            ;;
        --details|-d)
            SHOW_DETAILS=true
            shift
            ;;
        --help|-h)
            # Handle help below
            break
            ;;
        *)
            # Save positional arguments
            break
            ;;
    esac
done

# Load environment configuration if available (fail gracefully)
if [[ -f ".envrc" ]]; then
    source .envrc 2>/dev/null || true
elif [[ -f "../.envrc" ]]; then
    source ../.envrc 2>/dev/null || true
fi

# Colors and configuration (respect LOG_TIMESTAMP setting)
RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'
MIN_MSG_LENGTH=10; MAX_MSG_LENGTH=72

# Simplified logging that respects LOG_TIMESTAMP
log() {
    local msg="$1"
    local color="${2:-$NC}"
    # Simple output without color codes if LOG_JSON is true or we want plain output
    if [[ "${LOG_JSON:-false}" == "true" ]] || [[ "${LOG_TIMESTAMP:-true}" == "false" ]]; then
        echo "$msg"
    else
        echo -e "${color}${msg}${NC}"
    fi
}
error_exit() { log "❌ $1" "$RED" >&2; exit 1; }

# Parse commit message from arguments/environment/stdin
parse_commit_message() {
    if [[ -n "${COMMIT_MESSAGE:-}" ]]; then
        commit_msg="$COMMIT_MESSAGE"
    elif [[ $# -ge 2 ]]; then
        local type="$1" desc="$2"
        if [[ ! "$type" =~ ^(feat|fix|docs|refactor|test|chore)$ ]]; then
            error_exit "Invalid commit type: $type. Must be one of: feat, fix, docs, refactor, test, chore"
        fi
        commit_msg="$type: $desc"
    elif [[ $# -eq 0 ]] && [[ ! -t 0 ]]; then
        commit_msg=$(cat)
        [[ -z "$commit_msg" ]] && error_exit "Empty commit message provided via stdin"
    else
        return 1  # No commit message available
    fi
}

# Extract commit type from commit message
get_commit_type() { echo "$1" | head -n1 | cut -d':' -f1; }

# Extract commit description (without type prefix)
get_commit_desc() { echo "$1" | head -n1 | sed -E 's/^[^:]+: //'; }

# Handle help flag
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    cat << 'EOF'
Smart Commit - Intelligent commit system with quality gates

USAGE:
    smart-commit [OPTIONS] [TYPE] [DESCRIPTION]

EXAMPLES:
    smart-commit                        # Interactive mode
    smart-commit feat "add login"       # Direct commit
    smart-commit --no-approve fix "bug" # Non-interactive mode
    echo "fix: bug fix" | smart-commit  # From stdin

COMMIT TYPES:
    feat        New feature
    fix         Bug fix
    docs        Documentation changes
    refactor    Code refactoring
    test        Test changes
    chore       Maintenance tasks

OPTIONS:
    -h, --help      Show this help message
    --no-approve    Skip interactive approval (for agents/CI)
    -d, --details   Show detailed information about findings

QUALITY GATES:
    - Code formatting (black)
    - Linting (ruff)
    - Type checking (mypy)
    - Commit message validation
    - Git status verification
    - Secret detection
    - Test execution
EOF
    exit 0
fi

log "🎯 Smart Commit" "$BLUE"
log "======================" "$BLUE"

# Initialize summary tracking arrays
declare -a SUMMARY_ITEMS=()
declare -a WARNINGS=()
declare -a ERRORS=()
declare -a DETAILED_WARNINGS=()
FILE_COUNT=0
FORMATTING_CHANGES=0
LINTING_ISSUES=0
TEST_STATUS="not_run"
SECRET_STATUS="clean"

# 1. Check for uncommitted changes
if [[ -z $(git status --porcelain) ]]; then
    error_exit "No changes to commit"
fi
FILE_COUNT=$(git status --porcelain | wc -l)
SUMMARY_ITEMS+=("📁 Files to commit: $FILE_COUNT")

# 2. Run autofix system (standalone version)
log "ℹ️ Running code quality checks..."

# Simple autofix using available tools
if command -v ruff &>/dev/null; then
    log "🔍 Running ruff checks..."
    # Capture ruff output and parse for issues
    if ruff_output=$(ruff check --fix . 2>&1); then
        log "✅ Ruff checks completed"
        # Parse output for number of issues found/fixed
        if echo "$ruff_output" | grep -q "All checks passed!"; then
            SUMMARY_ITEMS+=("✅ Ruff: No issues found")
        elif echo "$ruff_output" | grep -q "Found"; then
            issues_count=$(echo "$ruff_output" | grep -oE "Found [0-9]+" | grep -oE "[0-9]+" | head -1 || echo "0")
            SUMMARY_ITEMS+=("🔧 Ruff fixed $issues_count issues")
        else
            SUMMARY_ITEMS+=("✅ Ruff: No issues found")
        fi
    else
        ERRORS+=("❌ Ruff linting failed")
        error_exit "Ruff linting failed"
    fi
else
    log "⚠️ Ruff not available, skipping advanced linting..." "$YELLOW"
    WARNINGS+=("⚠️ Ruff not available")
fi

if command -v black &>/dev/null; then
    log "🎨 Running black formatting..."
    # Check if black will make changes
    if ! black --check . &>/dev/null; then
        FORMATTING_CHANGES=1
        black . &>/dev/null || true
        SUMMARY_ITEMS+=("🎨 Black reformatted files")
    else
        SUMMARY_ITEMS+=("✅ Black: Already formatted")
    fi
    log "✅ Black formatting completed"
else
    log "⚠️ Black not available, skipping formatting..." "$YELLOW"
    WARNINGS+=("⚠️ Black not available")
fi

# Run mypy type checking
if command -v mypy &>/dev/null; then
    log "🔍 Running mypy type checking..."
    # Check if we have a pyproject.toml or Makefile with mypy configuration
    if [[ -f Makefile ]] && make -n typecheck &>/dev/null; then
        # Use Makefile typecheck target if available (respects project config)
        if mypy_output=$(make typecheck 2>&1); then
            log "✅ Type checking passed" "$GREEN"
            SUMMARY_ITEMS+=("✅ MyPy: Type checks passed")
        else
            # Count errors from mypy output
            if echo "$mypy_output" | grep -q "error:"; then
                error_count=$(echo "$mypy_output" | grep -c "error:" || echo "?")
                ERRORS+=("❌ MyPy: $error_count type errors found")
                if [[ "$SHOW_DETAILS" == true ]]; then
                    DETAILED_WARNINGS+=("Type errors:" "$mypy_output")
                fi
                error_exit "Type checking failed with $error_count errors. Run 'make typecheck' for details."
            else
                ERRORS+=("❌ Type checking failed")
                error_exit "Type checking failed. Run 'make typecheck' for details."
            fi
        fi
    elif [[ -f pyproject.toml ]] && command -v poetry &>/dev/null; then
        # Poetry project - run mypy through poetry
        if mypy_output=$(poetry run mypy . --ignore-missing-imports 2>&1); then
            log "✅ Type checking passed" "$GREEN"
            SUMMARY_ITEMS+=("✅ MyPy: Type checks passed")
        else
            if echo "$mypy_output" | grep -q "error:"; then
                error_count=$(echo "$mypy_output" | grep -c "error:" || echo "?")
                ERRORS+=("❌ MyPy: $error_count type errors found")
                error_exit "Type checking failed with $error_count errors."
            else
                ERRORS+=("❌ Type checking failed")
                error_exit "Type checking failed."
            fi
        fi
    else
        # Direct mypy on Python files
        if mypy_output=$(mypy . --ignore-missing-imports 2>&1); then
            log "✅ Type checking passed" "$GREEN"
            SUMMARY_ITEMS+=("✅ MyPy: Type checks passed")
        else
            if echo "$mypy_output" | grep -q "error:"; then
                error_count=$(echo "$mypy_output" | grep -c "error:" || echo "?")
                ERRORS+=("❌ MyPy: $error_count type errors found")
                error_exit "Type checking failed with $error_count errors."
            fi
        fi
    fi
    log "✅ Type checking completed"
else
    log "⚠️ MyPy not available, skipping type checking..." "$YELLOW"
    WARNINGS+=("⚠️ MyPy not available")
fi

# Basic flake8 linting if available (only on modified Python files)
if command -v flake8 &>/dev/null; then
    log "📊 Running flake8 checks..."
    # Only run on modified Python files to avoid hanging on large repos
    modified_py_files=$(git diff --cached --name-only --diff-filter=ACM | grep '\.py$' || true)
    if [[ -n "$modified_py_files" ]]; then
        flake8_output=$(echo "$modified_py_files" | xargs flake8 --count --select=E9,F63,F7,F82 --show-source --statistics 2>&1 || true)
        # Count actual error lines (not empty lines or headers)
        if [[ -n "$flake8_output" ]] && echo "$flake8_output" | grep -q "\.py:"; then
            flake8_count=$(echo "$flake8_output" | grep "\.py:" | wc -l | tr -d ' ')
            WARNINGS+=("⚠️ Flake8: $flake8_count critical issues")
        else
            SUMMARY_ITEMS+=("✅ Flake8: No critical issues")
        fi
    else
        SUMMARY_ITEMS+=("ℹ️ Flake8: No Python files to check")
    fi
    log "✅ Flake8 checks completed"
fi
log "✅ AutoFixer completed" "$GREEN"

# 3. Handle branch management before pre-commit checks
log "ℹ️ Checking branch status..."
current_branch=$(git branch --show-current)
main_branch=$(git symbolic-ref refs/remotes/origin/HEAD 2>/dev/null | sed 's@^refs/remotes/origin/@@' || echo "main")

# Check if we're on the main branch and need to create a feature branch
if [[ "$current_branch" == "$main_branch" ]]; then
    # Try to parse commit message for branch name
    if parse_commit_message "$@"; then
        # Message parsed successfully, will create descriptive branch below
        :
    else
        # Create a generic branch name with timestamp
        timestamp=$(date +"%Y%m%d-%H%M%S")
        branch_name="feature/auto-branch-$timestamp"
        log "🌿 Creating auto-branch: $branch_name" "$YELLOW"
        git checkout -b "$branch_name"
    fi

    # If we have a commit message, create a descriptive branch name
    if [[ -n "${commit_msg:-}" ]]; then
        commit_type=$(get_commit_type "$commit_msg")

        # Generate branch suffix (extract description and clean it)
        branch_suffix=$(get_commit_desc "$commit_msg" | sed -E 's/[^a-zA-Z0-9]+/-/g' | tr '[:upper:]' '[:lower:]' | sed -E 's/-+$//g')
        # Truncate at word boundary if too long
        if [[ ${#branch_suffix} -gt 50 ]]; then
            branch_suffix=$(echo "$branch_suffix" | cut -c1-50 | sed -E 's/-[^-]*$//')
        fi

        # Set branch prefix based on commit type
        case "$commit_type" in
            "feat") branch_name="feature/$branch_suffix" ;;
            "fix")  branch_name="fix/$branch_suffix" ;;
            *)      branch_name="chore/$branch_suffix" ;;
        esac

        log "🌿 Creating branch: $branch_name" "$GREEN"
        git checkout -b "$branch_name"
    fi
fi

# 4. Pre-commit validation handled by AutoFixer ValidationStage
# (removed duplicate pre-commit execution that caused convergence issues)

# 4. Run tests with continue option
log "ℹ️ Running tests..."
test_cmd=""
if command -v genesis &>/dev/null && [[ -d .genesis/ ]]; then
    # Genesis project - use genesis test
    test_cmd="genesis test"
elif [[ -f Makefile ]] && make -n test &>/dev/null; then
    # Prefer Makefile test target (official project test command)
    test_cmd="make test"
elif [[ -f pyproject.toml ]] && command -v poetry &>/dev/null && [[ -d tests/ ]]; then
    # Poetry project - use poetry run pytest on tests directory only
    test_cmd="poetry run pytest tests/"
elif [[ -d tests/ ]] && command -v pytest &>/dev/null; then
    # Fallback to direct pytest
    test_cmd="pytest tests/ -q"
fi

if [[ -n $test_cmd ]]; then
    echo "Running: $test_cmd"
    # Capture test output to parse results
    if test_output=$(eval "$test_cmd" 2>&1); then
        log "✅ Tests passed" "$GREEN"
        TEST_STATUS="passed"
        # Parse test results for counts
        if echo "$test_output" | grep -q "passed"; then
            passed_count=$(echo "$test_output" | grep -oE "[0-9]+ passed" | grep -oE "[0-9]+" | head -1 || echo "?")
            skipped_count=$(echo "$test_output" | grep -oE "[0-9]+ skipped" | grep -oE "[0-9]+" | head -1 || echo "0")
            if [[ "$skipped_count" != "0" ]]; then
                SUMMARY_ITEMS+=("✅ Tests: $passed_count passed, $skipped_count skipped")
            else
                SUMMARY_ITEMS+=("✅ Tests: $passed_count passed")
            fi
        else
            SUMMARY_ITEMS+=("✅ Tests: All passed")
        fi
    else
        log "⚠️ Tests failed" "$YELLOW"
        TEST_STATUS="failed"
        # Try to parse failure counts
        if echo "$test_output" | grep -q "failed"; then
            failed_count=$(echo "$test_output" | grep -oE "[0-9]+ failed" | grep -oE "[0-9]+" | head -1 || echo "?")
            WARNINGS+=("⚠️ Tests: $failed_count failed")
        else
            WARNINGS+=("⚠️ Tests failed")
        fi
        if [[ "$NO_APPROVE" == "false" ]]; then
            echo ""
            echo "Test command that failed: $test_cmd"
            echo "Run the command above to see detailed error output."
            echo ""
            read -p "Continue anyway? (y/N): " -n 1 -r
            echo; [[ ! $REPLY =~ ^[Yy]$ ]] && exit 1
        fi
    fi
else
    TEST_STATUS="skipped"
    SUMMARY_ITEMS+=("ℹ️ Tests: No test command found")
fi

# 5. Genesis Quality Gates (similar to pre-commit hooks)
log "ℹ️ Running Genesis quality gates..."

# Check for hardcoded values
if [[ -f ".genesis/scripts/validation/find-hardcoded-values.sh" ]]; then
    if hardcoded_output=$(.genesis/scripts/validation/find-hardcoded-values.sh 2>&1); then
        SUMMARY_ITEMS+=("✅ Hardcoded values: None found")
    else
        # Count categories with issues
        categories_count=$(echo "$hardcoded_output" | grep -c "❌ Found issues:" || echo "0")
        categories_count=$(echo "$categories_count" | tr -d '\n' | grep -o '[0-9]*' | head -1)
        categories_count=${categories_count:-0}
        if [[ $categories_count -gt 0 ]]; then
            WARNINGS+=("⚠️ Hardcoded values: $categories_count categories with issues")
            # Store details for --details flag
            if [[ "$SHOW_DETAILS" == "true" ]]; then
                # Extract first few specific issues
                specific_issues=$(echo "$hardcoded_output" | grep "\.py:" | head -3 | sed 's/^/      • /')
                if [[ -n "$specific_issues" ]]; then
                    DETAILED_WARNINGS+=("⚠️ Hardcoded values: $categories_count categories")
                    DETAILED_WARNINGS+=("$specific_issues")
                    DETAILED_WARNINGS+=("      • (run: genesis fix --hardcoded for all)")
                fi
            fi
        else
            SUMMARY_ITEMS+=("✅ Hardcoded values: None found")
        fi
    fi
else
    SUMMARY_ITEMS+=("ℹ️ Hardcoded values: Check not available")
fi

# Check for dangerous defaults (temporarily disabled - most violations are in test fixtures)
# if [[ -f ".genesis/scripts/validation/check-variable-defaults.sh" ]]; then
#     if defaults_output=$(.genesis/scripts/validation/check-variable-defaults.sh 2>&1); then
#         SUMMARY_ITEMS+=("✅ Variable defaults: Safe")
#     else
#         # Count dangerous defaults found
#         defaults_count=$(echo "$defaults_output" | grep -c "dangerous default" || echo "0")
#         if [[ $defaults_count -gt 0 ]]; then
#             WARNINGS+=("⚠️ Variable defaults: $defaults_count dangerous")
#         else
#             SUMMARY_ITEMS+=("✅ Variable defaults: Safe")
#         fi
#     fi
# else
#     SUMMARY_ITEMS+=("ℹ️ Variable defaults: Check not available")
# fi
SUMMARY_ITEMS+=("ℹ️ Variable defaults: Check temporarily disabled")

# Check for AI signatures
if [[ -f ".genesis/scripts/validation/check-ai-signatures.sh" ]]; then
    if ai_output=$(.genesis/scripts/validation/check-ai-signatures.sh 2>&1); then
        SUMMARY_ITEMS+=("✅ AI signatures: None found")
    else
        ai_count=$(echo "$ai_output" | grep -c "AI signature" || echo "0")
        ai_count=$(echo "$ai_count" | tr -d '\n' | grep -o '[0-9]*' | head -1)
        ai_count=${ai_count:-0}
        if [[ $ai_count -gt 0 ]]; then
            WARNINGS+=("⚠️ AI signatures: $ai_count found")
        else
            SUMMARY_ITEMS+=("✅ AI signatures: None found")
        fi
    fi
else
    SUMMARY_ITEMS+=("ℹ️ AI signatures: Check not available")
fi

# Check file organization
if [[ -f ".genesis/scripts/validation/check-file-organization.sh" ]]; then
    if org_output=$(.genesis/scripts/validation/check-file-organization.sh 2>&1); then
        SUMMARY_ITEMS+=("✅ File organization: Clean")
    else
        # Count suggestions for improvement
        suggestions_count=$(echo "$org_output" | grep -c "suggestions for improvement" || echo "0")
        suggestions_count=$(echo "$suggestions_count" | tr -d '\n' | grep -o '[0-9]*' | head -1)
        suggestions_count=${suggestions_count:-0}
        misplaced_count=$(echo "$org_output" | grep -c "wrong location" || echo "0")
        misplaced_count=$(echo "$misplaced_count" | tr -d '\n' | grep -o '[0-9]*' | head -1)
        misplaced_count=${misplaced_count:-0}
        if [[ $suggestions_count -gt 0 ]] || [[ $misplaced_count -gt 0 ]]; then
            WARNINGS+=("⚠️ File organization: $misplaced_count misplaced files")
            # Store details for --details flag
            if [[ "$SHOW_DETAILS" == "true" ]]; then
                # Extract specific file issues
                specific_files=$(echo "$org_output" | grep "should not be in root\|wrong location\|Should be in" | head -3 | sed 's/^/      • /')
                if [[ -n "$specific_files" ]]; then
                    DETAILED_WARNINGS+=("⚠️ File organization: $misplaced_count misplaced files")
                    DETAILED_WARNINGS+=("$specific_files")
                    DETAILED_WARNINGS+=("      • (run: genesis organize --files for all)")
                fi
            fi
        else
            SUMMARY_ITEMS+=("✅ File organization: Clean")
        fi
    fi
else
    SUMMARY_ITEMS+=("ℹ️ File organization: Check not available")
fi

# Check Genesis component usage
if [[ -f ".genesis/scripts/validation/check-genesis-components.sh" ]]; then
    if comp_output=$(.genesis/scripts/validation/check-genesis-components.sh 2>&1); then
        SUMMARY_ITEMS+=("✅ Genesis components: Properly used")
    else
        comp_issues=$(echo "$comp_output" | grep -c "should use Genesis" || echo "0")
        comp_issues=$(echo "$comp_issues" | tr -d '\n' | grep -o '[0-9]*' | head -1)
        comp_issues=${comp_issues:-0}
        if [[ $comp_issues -gt 0 ]]; then
            WARNINGS+=("⚠️ Genesis components: $comp_issues usage issues")
        else
            SUMMARY_ITEMS+=("✅ Genesis components: Properly used")
        fi
    fi
else
    SUMMARY_ITEMS+=("ℹ️ Genesis components: Check not available")
fi

# Basic secret detection (keep existing)
log "ℹ️ Scanning for secrets..."
if grep -rE "(sk-[a-zA-Z0-9]{48}|ghp_[a-zA-Z0-9]{36})" --include="*.py" --include="*.js" --include="*.ts" . 2>/dev/null | grep -v test; then
    SECRET_STATUS="found"
    ERRORS+=("❌ Potential secrets detected")
    error_exit "Potential secrets detected! Remove before committing"
else
    SECRET_STATUS="clean"
    SUMMARY_ITEMS+=("🔒 Secrets: None detected")
fi

# 6. Quality Check Summary and Approval
echo ""
log "📋 Quality Check Summary" "$BLUE"
log "========================" "$BLUE"

# Display summary items
for item in "${SUMMARY_ITEMS[@]}"; do
    echo "  $item"
done

# Display warnings if any
if [[ -n "${WARNINGS[*]:-}" ]]; then
    warnings_count=${#WARNINGS[@]}
    echo ""
    if [[ "$SHOW_DETAILS" == "true" ]] && [[ -n "${DETAILED_WARNINGS[*]:-}" ]]; then
        log "⚠️ Warnings ($warnings_count) - Details:" "$YELLOW"
        for detail in "${DETAILED_WARNINGS[@]}"; do
            echo "$detail"
        done
    else
        log "⚠️ Warnings ($warnings_count):" "$YELLOW"
        for warning in "${WARNINGS[@]}"; do
            echo "  $warning"
        done
        if [[ $warnings_count -gt 0 ]]; then
            echo ""
            echo "💡 For details: genesis commit --details (or -d)"
            echo "💡 To fix issues: genesis autofix --quality-gates"
        fi
    fi
else
    warnings_count=0
fi

# Display errors if any (should not reach here with errors, but for completeness)
if [[ -n "${ERRORS[*]:-}" ]]; then
    errors_count=${#ERRORS[@]}
    echo ""
    log "❌ Errors ($errors_count):" "$RED"
    for error in "${ERRORS[@]}"; do
        echo "  $error"
    done
else
    errors_count=0
fi

# Show overall status
echo ""
if [[ $errors_count -gt 0 ]]; then
    log "Status: ❌ Critical issues found" "$RED"
elif [[ $warnings_count -gt 0 ]]; then
    log "Status: ⚠️ Warnings found but can proceed" "$YELLOW"
else
    log "Status: ✅ All checks passed" "$GREEN"
fi

# Ask for approval unless --no-approve is set
if [[ "$NO_APPROVE" == "false" ]]; then
    echo ""
    read -p "Continue with commit? (y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log "❌ Commit cancelled by user" "$YELLOW"
        exit 0
    fi
else
    log "ℹ️ Running in non-interactive mode (--no-approve)" "$BLUE"
fi

# 7. Interactive commit message
echo ""

# Parse commit message if not already done
if [[ -z "${commit_msg:-}" ]]; then
    if parse_commit_message "$@"; then
        [[ -n "${COMMIT_MESSAGE:-}" ]] && log "Using provided commit message: $commit_msg" || log "Using provided commit: $commit_msg"
    else
        error_exit "Commit message required.

Usage options:
1. Single line: smart-commit feat 'add new feature'
2. Multi-line: echo -e 'feat: summary\\n\\nDetails' | smart-commit
3. With env var: COMMIT_MESSAGE='feat: add feature' smart-commit

Git convention: First line ≤72 chars, blank line, then detailed description."
    fi
fi

# Validate message length (only check first line for max length)
commit_first_line=$(echo "$commit_msg" | head -n1)
[[ ${#commit_first_line} -lt $MIN_MSG_LENGTH ]] && error_exit "Message too short (min $MIN_MSG_LENGTH chars)"
[[ ${#commit_first_line} -gt $MAX_MSG_LENGTH ]] && error_exit "First line too long (max $MAX_MSG_LENGTH chars).

Git commit convention:
- Line 1: Brief summary (max 72 chars)
- Line 2: Blank line
- Line 3+: Detailed description (no length limit)

Example:
  smart-commit feat 'add user authentication'
  echo -e 'feat: add auth\\n\\nDetailed description' | smart-commit"

# 7. Show preview and confirm
echo ""
log "📝 Changes to commit:"
git status --short
echo ""
log "💬 Message: $commit_msg"
echo ""

# Skip confirmation if message provided via environment variable or --no-approve flag
if [[ -z "${COMMIT_MESSAGE:-}" ]] && [[ "$NO_APPROVE" == "false" ]]; then
    read -p "Proceed with commit? (Y/n): " -n 1 -r
    echo
    [[ $REPLY =~ ^[Nn]$ ]] && { log "Cancelled" "$YELLOW"; exit 0; }
fi

# 8. Update documentation before commit
log "ℹ️ Updating documentation..."

# Extract commit type from message for documentation updates
commit_type=$(get_commit_type "$commit_msg")

# Update CHANGELOG.md if it exists and this is a meaningful change
if [[ -f "CHANGELOG.md" ]] && [[ "$commit_type" =~ ^(feat|fix|chore)$ ]]; then
    # Check if we already have an entry for this exact commit message (retry detection)
    if ! grep -q "$(get_commit_desc "$commit_msg")" CHANGELOG.md 2>/dev/null; then
        log "📝 Adding entry to CHANGELOG.md"

        # Create a temporary changelog entry
        description=$(get_commit_desc "$commit_msg")

        # Map commit types to changelog sections
        case "$commit_type" in
            "feat")
                section="### Added"
                ;;
            "fix")
                section="### Fixed"
                ;;
            "chore")
                section="### Changed"
                ;;
        esac

        # Create a temporary file with the changelog update
        temp_changelog=$(mktemp)

        # Process the changelog
        awk -v section="$section" -v entry="- $description" '
        /^## \[Unreleased\]/ {
            print $0
            unreleased_found = 1
            next
        }
        unreleased_found && /^### / {
            if ($0 == section) {
                print $0
                getline
                print entry
                print $0
                section_found = 1
            } else {
                print $0
            }
            next
        }
        unreleased_found && /^## \[/ && !section_found {
            print section
            print entry
            print ""
            print $0
            unreleased_found = 0
            next
        }
        { print $0 }
        END {
            if (unreleased_found && !section_found) {
                print section
                print entry
                print ""
            }
        }' CHANGELOG.md > "$temp_changelog"

        # Replace the original changelog
        mv "$temp_changelog" CHANGELOG.md

        log "✅ Updated CHANGELOG.md"
    else
        log "ℹ️ CHANGELOG.md already contains this entry (retry detected)"
    fi
else
    log "ℹ️ Skipping CHANGELOG.md update (no changelog or non-notable change)"
fi

# 9. Detect version bump needs
should_bump_version=false
if [[ -f "pyproject.toml" ]] && [[ "$commit_type" =~ ^(feat|fix)$ ]]; then
    [[ "$commit_type" == "feat" ]] && log "ℹ️ Feature detected - checking version bump..." || log "ℹ️ Fix detected - checking version bump..."

    current_version=$(grep -E '^version\s*=' pyproject.toml 2>/dev/null | head -1 | cut -d'"' -f2)

    if [[ -n "$current_version" ]]; then
        # Parse semantic version (major.minor.patch)
        IFS='.' read -r major minor patch <<< "$current_version"

        # Calculate new version based on commit type
        if [[ "$commit_type" == "feat" ]] && [[ "$minor" =~ ^[0-9]+$ ]]; then
            new_version="$major.$((minor + 1)).0"
            log_msg="📈 Bumping version: $current_version → $new_version"
        elif [[ "$commit_type" == "fix" ]] && [[ "$patch" =~ ^[0-9]+$ ]]; then
            new_version="$major.$minor.$((patch + 1))"
            log_msg="🔧 Bumping patch version: $current_version → $new_version"
        else
            log "⚠️ Warning: Invalid version format '$current_version', skipping version bump"
            new_version="$current_version"
        fi

        # Update version if changed
        if [[ "$current_version" != "$new_version" ]]; then
            log "$log_msg"
            sed -i.bak -E "s/version\s*=\s*\"[^\"]+\"/version = \"$new_version\"/" pyproject.toml
            rm pyproject.toml.bak 2>/dev/null || true
            should_bump_version=true
            log "✅ Version bumped in pyproject.toml"
        else
            log "ℹ️ Version already at expected level (retry detected)"
        fi
    fi
fi

# 10. Create atomic commit with all changes (with pre-commit hook handling)
git add -A

# Try commit and handle pre-commit hook modifications
max_attempts=3
attempt=1

while [ $attempt -le $max_attempts ]; do
    log "🔄 Commit attempt $attempt/$max_attempts..."

    if git commit -m "$commit_msg"; then
        log "✅ Commit successful!" "$GREEN"
        break
    else
        # Pre-commit hooks may have modified files - check and restage
        if [[ -n $(git status --porcelain) ]]; then
            log "ℹ️ Pre-commit hooks modified files, restaging..." "$YELLOW"
            git add -A
            attempt=$((attempt + 1))

            if [ $attempt -gt $max_attempts ]; then
                error_exit "Failed to commit after $max_attempts attempts. Pre-commit hooks keep modifying files."
            fi
        else
            error_exit "Commit failed for unknown reason"
        fi
    fi
done

log "✅ Commit created: $commit_msg" "$GREEN"

# 11. Push changes and create PR if needed
current_branch=$(git branch --show-current)

if [[ "$current_branch" != "$main_branch" ]]; then
    log "📤 Pushing branch to origin..."
    git push -u origin "$current_branch"

    # Create PR if gh CLI is available
    if command -v gh &> /dev/null; then
        log "🔗 Creating pull request..."

        # Generate PR description based on commit type
        commit_desc=$(get_commit_desc "$commit_msg")
        case "$commit_type" in
            "feat") pr_body="## Summary\n- New feature: $commit_desc\n\n## Test plan\n- [ ] Manual testing completed\n- [ ] All existing tests pass" ;;
            "fix")  pr_body="## Summary\n- Bug fix: $commit_desc\n\n## Test plan\n- [ ] Fix verified manually\n- [ ] All existing tests pass" ;;
            *)      pr_body="## Summary\n- $commit_desc\n\n## Test plan\n- [ ] Changes reviewed and tested" ;;
        esac

        gh pr create --title "$commit_msg" --body "$pr_body" --base "$main_branch" || {
            log "⚠️ Could not create PR automatically - create manually if needed"
        }
    else
        log "ℹ️ Install gh CLI for automatic PR creation"
    fi
else
    log "ℹ️ On main branch - changes committed locally"
fi
