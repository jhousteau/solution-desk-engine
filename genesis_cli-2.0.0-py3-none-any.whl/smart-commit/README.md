# Smart Commit System

Automated quality gates system providing validation before commits with essential quality gates.

## Features

**Core Quality Gates:**
- ✅ Pre-commit hook validation (if .pre-commit-config.yaml exists)
- ✅ Test execution with continue option (pytest or make test)
- ✅ Linting with auto-fix (ruff, black)
- ✅ Basic secret detection (API keys, tokens)
- ✅ Commit message validation (first line max 72 chars)
- ✅ Multi-line commit message support
- ✅ Interactive commit type selection

**Simplifications from Original (225→93 lines):**
- Removed over-complex user interaction
- Streamlined error handling
- Simplified command detection
- Focused on core functionality
- Maintained all essential quality gates

## Usage

```bash
# Run smart commit (interactive)
./src/smart-commit.sh

# With single-line message
genesis commit -m "feat: add new feature"

# With multi-line message
genesis commit -m "feat: add user authentication\n\nImplemented JWT-based authentication with refresh tokens.\nAdded user registration and login endpoints."

# The script will guide you through:
# 1. Pre-commit checks (if configured)
# 2. Running tests (with continue option)
# 3. Code linting and auto-formatting
# 4. Secret scanning
# 5. Commit type selection
# 6. Message validation (first line ≤72 chars)
# 7. Final confirmation and commit
```

## Multi-line Commit Messages

Smart commit now supports multi-line commit messages following Git conventions:
- **Line 1**: Brief summary (max 72 characters)
- **Line 2**: Blank line (separator)
- **Line 3+**: Detailed description (no length limit)

### Usage Examples

```bash
# Via Genesis CLI with \n
genesis commit -m "feat: add user auth\n\nImplemented JWT authentication with refresh tokens"

# Via environment variable
export COMMIT_MESSAGE="feat: add feature

Detailed description with multiple lines.
Can include implementation details."
./smart-commit.sh

# Via stdin (pipe)
echo -e "feat: add auth\n\nDetailed description" | ./smart-commit.sh
```

### Validation

- Only the first line is validated for the 72-character limit
- If validation fails, helpful usage instructions are provided
- Shows examples of proper formatting

## Integration with Genesis Workflow

Works seamlessly with Genesis development patterns:
- Integrates with `.pre-commit-config.yaml` (branch protection)
- Respects Makefile test targets
- Compatible with sparse worktree usage (<30 files)
- Follows conventional commit format

## Development (AI-Safe Sparse Worktree)

```bash
# Work on smart-commit in isolation
git worktree add ../smart-commit-work feature/smart-commit-fixes
cd ../smart-commit-work
git sparse-checkout set smart-commit/

# Component has <10 files for AI safety:
# smart-commit/
# ├── README.md
# ├── src/smart-commit.sh      # 93 lines
# └── tests/test_smart_commit.py
```

## Testing

```bash
# Run component tests
pytest smart-commit/tests/ -v

# Test smart-commit functionality
cd smart-commit/
./src/smart-commit.sh  # Interactive test
```

## Configuration

The script automatically detects and uses:
- `.pre-commit-config.yaml` - Pre-commit hooks
- `pytest` or `make test` - Test runners
- `ruff`, `black` - Code linters/formatters
- Git configuration - For commit creation

No additional configuration required - works out of the box with Genesis patterns.
