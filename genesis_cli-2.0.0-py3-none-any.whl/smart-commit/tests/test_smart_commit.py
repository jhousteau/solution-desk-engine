"""Consolidated tests for smart-commit system functionality and independence."""

import os
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest


# Shared fixtures for Git mock setup
@pytest.fixture
def git_repo():
    """Create a temporary git repository for testing."""
    original_cwd = os.getcwd()
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            repo_path = Path(tmpdir)
            os.chdir(repo_path)

            # Initialize git repo with minimal setup
            subprocess.run(["git", "init"], check=True, capture_output=True)
            subprocess.run(["git", "config", "user.name", "Test User"], check=True)
            subprocess.run(
                ["git", "config", "user.email", "test@example.com"], check=True
            )

            # Add remote and create initial commit
            subprocess.run(
                ["git", "remote", "add", "origin", f"file://{repo_path}/dummy-origin"],
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["git", "commit", "--allow-empty", "-m", "Initial commit"],
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["git", "branch", "-M", "main"], check=True, capture_output=True
            )

            # Set up remote refs to avoid SSH queries
            subprocess.run(
                [
                    "git",
                    "symbolic-ref",
                    "refs/remotes/origin/HEAD",
                    "refs/remotes/origin/main",
                ],
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["git", "update-ref", "refs/remotes/origin/main", "HEAD"],
                check=True,
                capture_output=True,
            )

            yield repo_path
    finally:
        os.chdir(original_cwd)


@pytest.fixture
def smart_commit_script():
    """Get path to smart-commit script."""
    return Path(__file__).parent.parent / "src" / "smart-commit.sh"


@pytest.fixture
def test_env():
    """Clean test environment."""
    env = os.environ.copy()
    env["GIT_SSH_COMMAND"] = "echo 'SSH disabled for testing'; false"
    env["GIT_TERMINAL_PROMPT"] = "0"
    env.pop("COMMIT_MESSAGE", None)
    return env


@pytest.fixture
def isolated_venv():
    """Create isolated virtual environment for independence tests."""
    with tempfile.TemporaryDirectory() as tmpdir:
        venv_path = Path(tmpdir) / "test_venv"
        subprocess.run(
            [sys.executable, "-m", "venv", str(venv_path)],
            check=True,
            capture_output=True,
        )

        python_path = venv_path / (
            "Scripts/python.exe" if sys.platform == "win32" else "bin/python"
        )
        yield venv_path, python_path


class TestSmartCommitFunctionality:
    """Test smart-commit system behavior."""

    def test_no_changes_to_commit(self, git_repo, smart_commit_script):
        """Test that script exits when no changes exist."""
        result = subprocess.run(
            ["bash", str(smart_commit_script)],
            capture_output=True,
            text=True,
            cwd=git_repo,
        )
        assert result.returncode == 1
        assert "No changes to commit" in result.stderr

    def test_with_changes_but_no_precommit(self, git_repo, smart_commit_script):
        """Test smart-commit with changes but no pre-commit config."""
        test_file = git_repo / "test.py"
        test_file.write_text("print('hello world')")
        subprocess.run(["git", "add", "test.py"], cwd=git_repo, check=True)

        result = subprocess.run(
            ["bash", str(smart_commit_script), "feat", "add test file"],
            capture_output=True,
            text=True,
            cwd=git_repo,
        )

        if result.returncode == 0:
            log_result = subprocess.run(
                ["git", "log", "--oneline"],
                capture_output=True,
                text=True,
                cwd=git_repo,
            )
            assert log_result.returncode == 0

    def test_secret_detection(self, git_repo, smart_commit_script):
        """Test that script detects potential secrets."""
        secret_file = git_repo / "config.py"
        secret_file.write_text(
            "API_KEY = 'sk-abcdef123456789012345678901234567890123456789012'"
        )
        subprocess.run(["git", "add", "config.py"], cwd=git_repo, check=True)

        result = subprocess.run(
            ["bash", str(smart_commit_script), "feat", "test secret detection"],
            capture_output=True,
            text=True,
            cwd=git_repo,
        )

        assert result.returncode == 1
        assert "secrets detected" in result.stderr

    def test_commit_message_validation(self, git_repo, smart_commit_script, test_env):
        """Test commit message length validation."""
        test_file = git_repo / "test.py"
        test_file.write_text("print('hello')")
        subprocess.run(["git", "add", "test.py"], cwd=git_repo, check=True)

        result = subprocess.run(
            ["bash", str(smart_commit_script), "feat", "hi"],  # Very short description
            capture_output=True,
            text=True,
            cwd=git_repo,
            env=test_env,
        )

        assert (
            result.returncode == 1
        ), f"Expected exit code 1, got {result.returncode}. stderr: {result.stderr}"
        assert "too short" in result.stderr or "Message too short" in result.stderr

    def test_script_permissions(self, smart_commit_script):
        """Test that smart-commit script has execute permissions."""
        assert smart_commit_script.exists()
        file_stat = smart_commit_script.stat()
        assert (
            file_stat.st_mode & 0o100
        ), "smart-commit.sh should have execute permissions"

    @pytest.mark.skipif(
        subprocess.run(["which", "ruff"], capture_output=True).returncode != 0
        and subprocess.run(["which", "black"], capture_output=True).returncode != 0,
        reason="Neither ruff nor black available for testing",
    )
    def test_linting_tools_detection(self, git_repo, smart_commit_script):
        """Test detection of linting tools."""
        test_file = git_repo / "test.py"
        test_file.write_text("import os\nprint( 'hello' )  # Spacing issues")

        result = subprocess.run(
            ["bash", str(smart_commit_script)],
            capture_output=True,
            text=True,
            cwd=git_repo,
        )
        assert "lint" in result.stdout.lower() or "lint" in result.stderr.lower()


class TestSmartCommitIndependence:
    """Test that smart-commit module is truly independent."""

    @pytest.fixture
    def smart_commit_root(self):
        """Get smart-commit module root path."""
        return Path(__file__).parent.parent

    def test_has_own_pyproject_toml(self, smart_commit_root):
        """FAIL: Smart-commit module must have its own pyproject.toml."""
        pyproject_path = smart_commit_root / "pyproject.toml"
        assert pyproject_path.exists(), (
            "Smart-commit module must have its own pyproject.toml for independence. "
            "This test will fail until pyproject.toml is created."
        )

    def test_pyproject_has_correct_package_name(self, smart_commit_root):
        """FAIL: pyproject.toml must define genesis-smart-commit as package name."""
        pyproject_path = smart_commit_root / "pyproject.toml"
        assert pyproject_path.exists(), "pyproject.toml must exist first"

        content = pyproject_path.read_text()
        assert (
            'name = "genesis-smart-commit"' in content
        ), "Package name must be 'genesis-smart-commit' for module independence"

    def test_can_install_independently(self, smart_commit_root, isolated_venv):
        """FAIL: Smart-commit module must be pip installable independently."""
        venv_path, python_path = isolated_venv
        pyproject_path = smart_commit_root / "pyproject.toml"
        assert pyproject_path.exists(), "pyproject.toml must exist for installation"

        result = subprocess.run(
            [str(python_path), "-m", "pip", "install", "-e", str(smart_commit_root)],
            capture_output=True,
            text=True,
        )

        assert (
            result.returncode == 0
        ), f"Smart-commit module must be pip installable independently. Install failed: {result.stderr}"

    def test_no_genesis_imports_in_shell_script(self, smart_commit_root):
        """FAIL: smart-commit.sh must not import from Genesis modules."""
        shell_script = smart_commit_root / "src" / "smart_commit" / "smart-commit.sh"
        assert shell_script.exists(), "smart-commit.sh must exist"

        with open(shell_script) as f:
            content = f.read()

        # Check for Genesis imports
        genesis_autofix_import = "from genesis.core.autofix import AutoFixer"
        assert (
            genesis_autofix_import not in content
        ), f"smart-commit.sh must not import from Genesis modules. Found forbidden import: {genesis_autofix_import} (lines 29-47)"

        lines = content.split("\n")
        genesis_imports = [
            f"Line {i}: {line.strip()}"
            for i, line in enumerate(lines, 1)
            if "from genesis" in line or "import genesis" in line
        ]
        assert (
            len(genesis_imports) == 0
        ), f"smart-commit.sh must not import from Genesis modules. Found forbidden imports: {genesis_imports}"

    def test_has_independent_cli_entry_point(self, smart_commit_root):
        """FAIL: Smart-commit must work as standalone CLI command."""
        pyproject_path = smart_commit_root / "pyproject.toml"
        assert pyproject_path.exists(), "pyproject.toml must exist for CLI entry point"

        content = pyproject_path.read_text()
        assert (
            "[project.scripts]" in content or "[tool.poetry.scripts]" in content
        ), "Must define CLI entry points in pyproject.toml"
        assert (
            "smart-commit" in content
        ), "Must define 'smart-commit' CLI command in entry points"

    def test_cli_works_without_genesis_installed(
        self, smart_commit_root, isolated_venv
    ):
        """FAIL: smart-commit CLI must work without Genesis CLI installed."""
        venv_path, python_path = isolated_venv
        pyproject_path = smart_commit_root / "pyproject.toml"
        assert pyproject_path.exists(), "pyproject.toml must exist for CLI testing"

        # Install smart-commit module
        install_result = subprocess.run(
            [str(python_path), "-m", "pip", "install", "-e", str(smart_commit_root)],
            capture_output=True,
            text=True,
        )
        assert (
            install_result.returncode == 0
        ), f"Failed to install: {install_result.stderr}"

        # Try to run smart-commit command
        smart_commit_path = venv_path / (
            "Scripts/smart-commit" if sys.platform == "win32" else "bin/smart-commit"
        )
        minimal_env = {
            "PATH": f"{venv_path / 'bin'}:/usr/bin:/bin:/usr/local/bin",
            "HOME": os.environ.get("HOME", "/tmp"),
        }
        result = subprocess.run(
            [str(smart_commit_path), "--help"],
            capture_output=True,
            text=True,
            env=minimal_env,
        )

        assert (
            result.returncode == 0
        ), f"smart-commit CLI must work without Genesis CLI installed. Error: {result.stderr}"
        assert (
            "genesis" not in result.stdout.lower()
        ), "smart-commit CLI should not reference genesis commands in help output"

    def test_has_proper_package_structure(self, smart_commit_root):
        """FAIL: Must have standard Python package structure."""
        # Check for one of these structures:
        src_layout = (
            smart_commit_root / "src" / "smart_commit" / "__init__.py"
        ).exists()
        flat_layout = (smart_commit_root / "smart_commit" / "__init__.py").exists()
        minimal_layout = (smart_commit_root / "__init__.py").exists()

        assert src_layout or flat_layout or minimal_layout, (
            "Smart-commit must have proper Python package structure. "
            "Create one of: src/smart_commit/__init__.py, smart_commit/__init__.py, or __init__.py"
        )

    def test_version_is_independent(self, smart_commit_root):
        """FAIL: Smart-commit module must have its own version."""
        pyproject_path = smart_commit_root / "pyproject.toml"
        assert pyproject_path.exists(), "pyproject.toml must exist"

        content = pyproject_path.read_text()
        assert "version = " in content, "Must define independent version"
        assert (
            'version = "0.0.0"' not in content
        ), "Must have real version number, not placeholder"

    def test_minimal_dependencies(self, smart_commit_root):
        """FAIL: Smart-commit should have minimal external dependencies."""
        pyproject_path = smart_commit_root / "pyproject.toml"
        assert pyproject_path.exists(), "pyproject.toml must exist"

        content = pyproject_path.read_text()

        # Should not depend on heavy frameworks or Genesis packages
        forbidden_deps = [
            "fastapi",
            "django",
            "flask",
            "requests",
            "genesis-cli",
            "genesis-shared-core",
        ]
        for dep in forbidden_deps:
            assert (
                dep.lower() not in content.lower()
            ), f"Smart-commit should not depend on: {dep}"

    def test_no_shared_core_imports(self, smart_commit_root):
        """FAIL: Smart-commit must not import from shared_core until it's independent."""
        py_files = list(smart_commit_root.glob("**/*.py"))
        shared_core_imports = []

        for py_file in py_files:
            if "test_" in py_file.name:  # Skip test files for now
                continue

            try:
                with open(py_file) as f:
                    content = f.read()

                if "from shared_core" in content or "import shared_core" in content:
                    shared_core_imports.append(str(py_file))
            except Exception:
                continue

        assert len(shared_core_imports) == 0, (
            f"Smart-commit module must not import from shared_core until independence. "
            f"Found shared_core imports in: {shared_core_imports}"
        )
