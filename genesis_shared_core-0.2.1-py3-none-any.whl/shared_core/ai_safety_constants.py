"""
AI Safety Constants for Genesis

Shared constants for AI safety checks across all Genesis components.
This module provides centralized configuration for AI safety settings
to ensure consistency across genesis-cli and genesis-testing packages.
"""

from typing import Final

# AI Safety Check Types
# Valid values: "auto", "strict", "manual"
# "auto" enables automatic safety checks with smart defaults
DEFAULT_AI_SAFETY_CHECK_TYPE: Final[str] = "auto"

# AI Safety Mode
# Valid values: "enforced", "warning", "disabled"
# "enforced" blocks operations that exceed safety limits
DEFAULT_AI_SAFETY_MODE: Final[str] = "enforced"

__all__ = ["DEFAULT_AI_SAFETY_CHECK_TYPE", "DEFAULT_AI_SAFETY_MODE"]
