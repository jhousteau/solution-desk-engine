"""Lightweight configuration management with YAML and environment variables."""

import os
from pathlib import Path
from typing import Any

import yaml

from .env import get_current_environment


class ConfigLoader:
    """Simple configuration loader supporting YAML files and env var overrides."""

    def __init__(self, env_prefix: str) -> None:
        """Initialize config loader.

        Args:
            env_prefix: Prefix for environment variables (e.g., "APP_")
        """
        self.env_prefix = env_prefix.upper()
        self._config: dict[str, Any] = {}

    def load_file(self, file_path: str | Path) -> dict[str, Any]:
        """Load configuration from YAML file."""
        path = Path(file_path)
        if not path.exists():
            return {}

        with open(path) as f:
            return yaml.safe_load(f) or {}

    def load_env(self, config: dict[str, Any]) -> dict[str, Any]:
        """Apply environment variable overrides to config."""
        result = config.copy()

        for key, value in os.environ.items():
            if key.startswith(self.env_prefix):
                # Remove prefix and convert to lowercase
                config_key = key[len(self.env_prefix) :].lower()

                # Convert common string values to appropriate types
                if value.lower() in ("true", "false"):
                    result[config_key] = value.lower() == "true"
                elif value.isdigit():
                    result[config_key] = int(value)
                else:
                    try:
                        # Try float conversion
                        result[config_key] = float(value)
                    except ValueError:
                        result[config_key] = value

        return result

    def load(
        self,
        file_path: str | Path | None = None,
        defaults: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Load configuration with precedence: defaults < file < environment.

        Args:
            file_path: Path to YAML config file
            defaults: Default configuration values

        Returns:
            Merged configuration dictionary
        """
        config = defaults or {}

        # Load from file if provided
        if file_path:
            file_config = self.load_file(file_path)
            config.update(file_config)

        # Apply environment overrides
        config = self.load_env(config)

        self._config = config
        return config

    def load_with_environment(
        self,
        config_dir: str | Path,
        environment: str | None = None,
        defaults: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Load configuration with environment-specific hierarchy.

        Precedence: defaults.yaml < {environment}.yaml < local.yaml < env vars

        Args:
            config_dir: Directory containing config files
            environment: Environment name (uses PROJECT_ENVIRONMENT if not specified)
            defaults: Additional default configuration values

        Returns:
            Merged configuration dictionary
        """
        config = defaults or {}
        config_path = Path(config_dir)

        # Use current environment if not specified
        if environment is None:
            environment = get_current_environment()

        # Load defaults.yaml
        defaults_file = config_path / "defaults.yaml"
        if defaults_file.exists():
            defaults_config = self.load_file(defaults_file)
            config.update(defaults_config)

        # Load environment-specific file
        env_file = config_path / f"{environment}.yaml"
        if env_file.exists():
            env_config = self.load_file(env_file)
            config.update(env_config)

        # Load local.yaml (for local overrides, not committed)
        local_file = config_path / "local.yaml"
        if local_file.exists():
            local_config = self.load_file(local_file)
            config.update(local_config)

        # Apply environment variable overrides (highest precedence)
        config = self.load_env(config)

        self._config = config
        return config

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value by key."""
        return self._config.get(key, default)

    def __getitem__(self, key: str) -> Any:
        """Dictionary-style access to config values."""
        return self._config[key]


def load_config(
    env_prefix: str,
    file_path: str | Path | None = None,
    defaults: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Simple function interface for loading configuration.

    Args:
        env_prefix: Prefix for environment variables (required)
        file_path: Path to YAML config file
        defaults: Default configuration values

    Usage:
        config = load_config(env_prefix="APP_", file_path="config.yml")
        # For required values, use get_required_env:
        database_url = get_required_env("DATABASE_URL")
    """
    loader = ConfigLoader(env_prefix)
    return loader.load(file_path, defaults)


def load_environment_config(
    env_prefix: str,
    config_dir: str | Path,
    environment: str | None = None,
    defaults: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Load environment-aware configuration with hierarchy.

    Precedence: defaults.yaml < {environment}.yaml < local.yaml < env vars

    Args:
        env_prefix: Prefix for environment variables (required)
        config_dir: Directory containing config files
        environment: Environment name (uses PROJECT_ENVIRONMENT if not specified)
        defaults: Additional default configuration values

    Usage:
        config = load_environment_config(env_prefix="APP_", config_dir="config/")
        # Loads: config/defaults.yaml, config/production.yaml, config/local.yaml
        # Plus environment variable overrides
    """
    loader = ConfigLoader(env_prefix)
    return loader.load_with_environment(config_dir, environment, defaults)
