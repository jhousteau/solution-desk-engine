"""Genesis shared Python utilities.

Provides essential utilities for retry logic, logging, configuration, health checks,
and error handling. All utilities are designed to be lightweight and dependency-free.
"""

from .ai_safety_constants import DEFAULT_AI_SAFETY_CHECK_TYPE, DEFAULT_AI_SAFETY_MODE
from .config import ConfigLoader, load_config
from .env import check_required_env_vars, get_required_env, validate_env_setup
from .errors import (
    AuthenticationError,
    AuthorizationError,
    ErrorCategory,
    ErrorContext,
    ErrorSeverity,
    ExternalServiceError,
    GenesisError,
    GenesisTimeoutError,
    InfrastructureError,
    NetworkError,
    RateLimitError,
    ResourceError,
    ValidationError,
    create_error_context,
    create_error_context_explicit,
    handle_error,
)
from .health import CheckResult, HealthCheck, HealthStatus
from .logger import LogConfig, get_logger
from .retry import RetryConfig, retry

# Backward compatibility alias
TimeoutError = GenesisTimeoutError

__version__ = "0.2.1"
__all__ = [
    # AI Safety constants
    "DEFAULT_AI_SAFETY_CHECK_TYPE",
    "DEFAULT_AI_SAFETY_MODE",
    # Retry utilities
    "retry",
    "RetryConfig",
    # Logging utilities
    "get_logger",
    "LogConfig",
    # Config utilities
    "load_config",
    "ConfigLoader",
    # Environment utilities
    "get_required_env",
    "check_required_env_vars",
    "validate_env_setup",
    # Health check utilities
    "CheckResult",
    "HealthCheck",
    "HealthStatus",
    # Error handling
    "ErrorSeverity",
    "ErrorCategory",
    "ErrorContext",
    "GenesisError",
    "InfrastructureError",
    "NetworkError",
    "ValidationError",
    "AuthenticationError",
    "AuthorizationError",
    "GenesisTimeoutError",
    "TimeoutError",
    "RateLimitError",
    "ExternalServiceError",
    "ResourceError",
    "handle_error",
    "create_error_context",
    "create_error_context_explicit",
]
